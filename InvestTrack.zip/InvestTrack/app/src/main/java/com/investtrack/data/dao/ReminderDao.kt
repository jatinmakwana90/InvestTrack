package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Reminder
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY dueDayOfMonth ASC, remind1Hour ASC")
    fun getAllReminders(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE isActive = 1 ORDER BY dueDayOfMonth ASC")
    suspend fun getActiveReminders(): List<Reminder>

    // All reminders regardless of active state — used for full data backups so nothing is lost.
    @Query("SELECT * FROM reminders ORDER BY dueDayOfMonth ASC")
    suspend fun getAllRemindersList(): List<Reminder>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: Reminder): Long

    @Update
    suspend fun updateReminder(reminder: Reminder)

    @Delete
    suspend fun deleteReminder(reminder: Reminder)

    @Query("UPDATE reminders SET isActive = :active WHERE id = :id")
    suspend fun setActive(id: Long, active: Boolean)

    @Query("SELECT * FROM reminders WHERE linkedLoanId = :loanId LIMIT 1")
    suspend fun getReminderForLoan(loanId: Long): Reminder?

    @Query("DELETE FROM reminders WHERE linkedLoanId = :loanId")
    suspend fun deleteReminderForLoan(loanId: Long)
}
