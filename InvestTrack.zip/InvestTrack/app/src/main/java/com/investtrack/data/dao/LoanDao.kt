package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Loan
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanDao {
    @Query("SELECT * FROM loans WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getAllLoans(): Flow<List<Loan>>

    @Query("SELECT * FROM loans WHERE isActive = 1 ORDER BY createdAt DESC")
    suspend fun getAllLoansList(): List<Loan>

    @Query("SELECT * FROM loans WHERE id = :id")
    suspend fun getLoanById(id: Long): Loan?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: Loan): Long

    @Update
    suspend fun updateLoan(loan: Loan)

    @Query("UPDATE loans SET isActive = 0 WHERE id = :id")
    suspend fun deleteLoan(id: Long)

    @Query("SELECT SUM(outstandingAmount) FROM loans WHERE isActive = 1")
    suspend fun getTotalOutstanding(): Double?

    @Query("SELECT SUM(emiAmount) FROM loans WHERE isActive = 1")
    suspend fun getTotalMonthlyEmi(): Double?
}
