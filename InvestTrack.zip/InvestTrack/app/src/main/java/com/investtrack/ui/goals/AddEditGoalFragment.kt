package com.investtrack.ui.goals

import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.dao.GoalDao
import com.investtrack.data.models.Goal
import com.investtrack.databinding.FragmentAddEditGoalBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

private val GOAL_ICONS = listOf("🎯", "🛡️", "📱", "🏠", "🚗", "✈️", "🎓", "💍", "👶", "🏥", "💻", "🎁", "🏖️", "📚", "🎮", "🐾")
private val GOAL_COLORS = listOf("#10b981", "#3b82f6", "#f59e0b", "#8b5cf6", "#ef4444", "#ec4899", "#14b8a6", "#f97316")

@HiltViewModel
class AddEditGoalViewModel @Inject constructor(
    private val goalDao: GoalDao,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val goalId: Long = savedStateHandle.get<Long>("goalId") ?: 0L
    val isEdit: Boolean = goalId != 0L

    private val _existing = MutableStateFlow<Goal?>(null)
    val existing: StateFlow<Goal?> = _existing

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved

    init {
        if (isEdit) viewModelScope.launch { _existing.value = goalDao.getGoalById(goalId) }
    }

    fun save(goal: Goal) {
        viewModelScope.launch {
            if (isEdit) goalDao.updateGoal(goal.copy(id = goalId, updatedAt = System.currentTimeMillis()))
            else goalDao.insertGoal(goal)
            _saved.value = true
        }
    }
}

@AndroidEntryPoint
class AddEditGoalFragment : Fragment() {
    private var _binding: FragmentAddEditGoalBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddEditGoalViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    private var selectedIcon = GOAL_ICONS[0]
    private var selectedColor = GOAL_COLORS[0]
    private var selectedDeadline: Long? = null
    private val iconViews = mutableListOf<TextView>()
    private val colorViews = mutableListOf<View>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddEditGoalBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = if (viewModel.isEdit) "Edit Goal" else "Add Goal"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        buildIconPicker()
        buildColorPicker()

        binding.etDeadline.setOnClickListener { showDatePicker() }

        binding.btnSave.setOnClickListener { onSaveClicked() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.existing.collect { goal ->
                goal ?: return@collect
                binding.etName.setText(goal.name)
                binding.etTarget.setText(formatNum(goal.targetAmount))
                binding.etCurrent.setText(formatNum(goal.currentAmount))
                goal.deadline?.let {
                    selectedDeadline = it
                    binding.etDeadline.setText(dateFmt.format(Date(it)))
                }
                selectIcon(goal.icon)
                selectColor(goal.color)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.saved.collect { saved ->
                if (saved) activity?.onBackPressedDispatcher?.onBackPressed()
            }
        }
    }

    private fun formatNum(v: Double): String =
        if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

    private fun buildIconPicker() {
        binding.llIconPicker.removeAllViews()
        iconViews.clear()
        val sizePx = (44 * resources.displayMetrics.density).toInt()
        val marginPx = (6 * resources.displayMetrics.density).toInt()
        GOAL_ICONS.forEach { icon ->
            val tv = TextView(requireContext()).apply {
                text = icon
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(0)
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply {
                    marginEnd = marginPx
                }
                background = makeCircleDrawable(Color.parseColor("#00000000"), selected = icon == selectedIcon)
                setOnClickListener { selectIcon(icon) }
            }
            iconViews.add(tv)
            binding.llIconPicker.addView(tv)
        }
    }

    private fun buildColorPicker() {
        binding.llColorPicker.removeAllViews()
        colorViews.clear()
        val sizePx = (36 * resources.displayMetrics.density).toInt()
        val marginPx = (8 * resources.displayMetrics.density).toInt()
        GOAL_COLORS.forEach { hex ->
            val v = View(requireContext()).apply {
                layoutParams = LinearLayout.LayoutParams(sizePx, sizePx).apply { marginEnd = marginPx }
                background = makeSwatchDrawable(Color.parseColor(hex), selected = hex == selectedColor)
                setOnClickListener { selectColor(hex) }
            }
            colorViews.add(v)
            binding.llColorPicker.addView(v)
        }
    }

    private fun selectIcon(icon: String) {
        selectedIcon = icon
        iconViews.forEachIndexed { i, tv ->
            tv.background = makeCircleDrawable(Color.parseColor("#00000000"), selected = GOAL_ICONS[i] == icon)
        }
    }

    private fun selectColor(hex: String) {
        selectedColor = runCatching { Color.parseColor(hex); hex }.getOrDefault(GOAL_COLORS[0])
        colorViews.forEachIndexed { i, v ->
            v.background = makeSwatchDrawable(Color.parseColor(GOAL_COLORS[i]), selected = GOAL_COLORS[i] == selectedColor)
        }
    }

    private fun makeCircleDrawable(fill: Int, selected: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(if (selected) Color.parseColor("#E8EAF6") else fill)
        val strokeWidth = if (selected) (2 * resources.displayMetrics.density).toInt() else 0
        setStroke(strokeWidth, Color.parseColor("#3F51B5"))
    }

    private fun makeSwatchDrawable(fill: Int, selected: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        if (selected) setStroke((3 * resources.displayMetrics.density).toInt(), Color.parseColor("#1A237E"))
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        selectedDeadline?.let { cal.timeInMillis = it }
        DatePickerDialog(requireContext(), { _, y, m, d ->
            val picked = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }
            selectedDeadline = picked.timeInMillis
            binding.etDeadline.setText(dateFmt.format(picked.time))
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun onSaveClicked() {
        val name = binding.etName.text?.toString()?.trim().orEmpty()
        val target = binding.etTarget.text?.toString()?.toDoubleOrNull()
        val current = binding.etCurrent.text?.toString()?.toDoubleOrNull() ?: 0.0

        if (name.isEmpty()) { binding.etName.error = "Required"; return }
        if (target == null || target <= 0) { binding.etTarget.error = "Enter a valid amount"; return }

        viewModel.save(
            Goal(
                name = name,
                icon = selectedIcon,
                targetAmount = target,
                currentAmount = current,
                color = selectedColor,
                deadline = selectedDeadline
            )
        )
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(goalId: Long) = AddEditGoalFragment().apply {
            arguments = Bundle().apply { putLong("goalId", goalId) }
        }
    }
}
