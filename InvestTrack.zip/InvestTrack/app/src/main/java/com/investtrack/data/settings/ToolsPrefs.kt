package com.investtrack.data.settings

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/** Remembers the numbers typed into the planning tools so they are there next time. */
@Singleton
class ToolsPrefs @Inject constructor(@ApplicationContext context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("investtrack_tools", Context.MODE_PRIVATE)

    var emergencyMonthlyExpense: Double
        get() = prefs.getFloat("em_monthly", 0f).toDouble()
        set(v) { prefs.edit().putFloat("em_monthly", v.toFloat()).apply() }
    var emergencyTargetMonths: Int
        get() = prefs.getInt("em_target", 6)
        set(v) { prefs.edit().putInt("em_target", v).apply() }
    var emergencyCash: Double
        get() = prefs.getFloat("em_cash", 0f).toDouble()
        set(v) { prefs.edit().putFloat("em_cash", v.toFloat()).apply() }
    /** SecurityType names that count as liquid savings. */
    var emergencyTypes: Set<String>
        get() = prefs.getStringSet("em_types", setOf("DEBT_MF", "FIXED_DEPOSIT")) ?: emptySet()
        set(v) { prefs.edit().putStringSet("em_types", v).apply() }

    var monthlyIncome: Double
        get() = prefs.getFloat("income", 0f).toDouble()
        set(v) { prefs.edit().putFloat("income", v.toFloat()).apply() }
}
