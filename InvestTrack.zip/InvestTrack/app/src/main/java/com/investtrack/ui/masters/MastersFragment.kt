package com.investtrack.ui.masters

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import com.investtrack.databinding.FragmentMastersBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AddAccountFragment
import com.investtrack.ui.securities.AddSecurityFragment
import com.investtrack.ui.securities.PriceSyncFragment
import com.investtrack.ui.securities.SecuritiesFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MastersFragment : Fragment() {

    private var _binding: FragmentMastersBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMastersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.cardAccountMaster.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AccountMasterListFragment())
        }
        binding.btnAddAccount.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddAccountFragment())
        }
        binding.cardSecurityMaster.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(SecuritiesFragment())
        }
        binding.btnAddSecurity.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddSecurityFragment())
        }
        binding.btnSyncPrices.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(PriceSyncFragment())
        }
        binding.cardGoals.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.goals.GoalsFragment())
        }
        binding.cardWhatsapp.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.whatsapp.WhatsAppTemplatesFragment())
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
