package com.investtrack.ui.tools

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.LendingDao
import com.investtrack.data.models.LendingEntry
import com.investtrack.data.models.LendingPayment
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Money lent to or borrowed from people, with due dates, part-repayments and reminders. */
@AndroidEntryPoint
class LendingFragment : ToolListFragment() {

    @Inject lateinit var lendingDao: LendingDao

    override val screenTitle = "Lending"
    override val emptyText = "No entries yet.\nTap + to record money you lent or borrowed. Part-repayments are tracked too."

    private var entries: List<LendingEntry> = emptyList()
    private var payments: List<LendingPayment> = emptyList()

    override fun observe() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(lendingDao.getEntries(), lendingDao.getPayments()) { e, p -> e to p }
                    .collect { (e, p) -> entries = e; payments = p; render() }
            }
        }
    }

    private fun paidSoFar(entryId: Long) = payments.filter { it.lendingId == entryId }.sumOf { it.amount }
    private fun pending(e: LendingEntry) = (e.amount - paidSoFar(e.id)).coerceAtLeast(0.0)

    private fun render() {
        val rows = entries.map { e ->
            val lent = e.direction == "LENT"
            val pend = pending(e)
            val settled = e.isSettled || pend <= 0.5
            val (status, color) = when {
                settled -> "Settled ✓" to R.color.gain_green
                e.dueDate > 0 -> {
                    val days = DateUtil.daysUntil(e.dueDate)
                    val text = if (days < 0) "Overdue by ${-days} day${if (days != -1) "s" else ""} (${DateUtil.format(e.dueDate)})"
                    else "Due ${DateUtil.format(e.dueDate)} (${DateUtil.duesLabel(days)})"
                    text to (if (days <= 3) R.color.loss_red else if (days <= 14) R.color.text_accent else R.color.text_secondary)
                }
                else -> "No due date" to R.color.text_secondary
            }
            ToolRow(
                key = "l:${e.id}", title = e.personName,
                subtitle = "${if (lent) "You lent" else "You borrowed"} ${CurrencyFormatter.formatFullNoDecimals(e.amount)} on ${DateUtil.format(e.date)}",
                amount = CurrencyFormatter.formatFullNoDecimals(if (settled) 0.0 else pend),
                amountSub = if (settled) "nothing pending" else if (lent) "they owe you" else "you owe",
                status = status, statusColor = color,
                actions = listOf("pay" to "Payment", "history" to "History", "edit" to "Edit", "delete" to "Delete")
            )
        }
        val open = entries.filter { !it.isSettled && pending(it) > 0.5 }
        val receive = open.filter { it.direction == "LENT" }.sumOf { pending(it) }
        val owe = open.filter { it.direction == "BORROWED" }.sumOf { pending(it) }
        val summary = if (entries.isEmpty()) "" else
            "You will receive: ${CurrencyFormatter.formatFullNoDecimals(receive)}\nYou owe: ${CurrencyFormatter.formatFullNoDecimals(owe)}"
        submit(rows, summary)
    }

    override fun onAdd() = showEntryDialog(null)

    override fun onRowClick(row: ToolRow) {
        entries.firstOrNull { "l:${it.id}" == row.key }?.let { showHistory(it) }
    }

    override fun onRowAction(row: ToolRow, action: String) {
        val e = entries.firstOrNull { "l:${it.id}" == row.key } ?: return
        when (action) {
            "pay" -> showPaymentDialog(e)
            "history" -> showHistory(e)
            "edit" -> showEntryDialog(e)
            "delete" -> MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete this entry?")
                .setMessage("${e.personName} and all its repayments will be removed.")
                .setPositiveButton("Delete") { _, _ ->
                    viewLifecycleOwner.lifecycleScope.launch { lendingDao.deletePaymentsFor(e.id); lendingDao.deleteEntry(e.id) }
                }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun showEntryDialog(existing: LendingEntry?) {
        lateinit var person: TextInputEditText
        lateinit var direction: android.widget.AutoCompleteTextView
        lateinit var amount: TextInputEditText
        lateinit var date: DateField
        lateinit var due: DateField
        lateinit var notes: TextInputEditText
        val lentLabel = "I lent money"
        val borrowedLabel = "I borrowed money"

        showFormDialog(
            if (existing == null) "Add Entry" else "Edit Entry",
            build = { f ->
                person = f.text("Person", "e.g. Rahul", existing?.personName.orEmpty())
                direction = f.dropdown("What happened", listOf(lentLabel, borrowedLabel), if (existing?.direction == "BORROWED") borrowedLabel else lentLabel)
                amount = f.number("Amount (₹)", "e.g. 20000", existing?.amount?.let { if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString() }.orEmpty())
                date = f.date("Date", existing?.date ?: System.currentTimeMillis())
                due = f.date("Due date", existing?.dueDate?.takeIf { it > 0 }, optional = true)
                notes = f.text("Notes (optional)", "", existing?.notes.orEmpty(), android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            },
            onSave = {
                val name = person.text.toString().trim()
                when {
                    name.isEmpty() -> { toast("Enter the person's name"); false }
                    amount.num() <= 0 -> { toast("Enter the amount"); false }
                    else -> {
                        viewLifecycleOwner.lifecycleScope.launch {
                            lendingDao.insertEntry(LendingEntry(
                                id = existing?.id ?: 0, personName = name,
                                direction = if (direction.text.toString() == borrowedLabel) "BORROWED" else "LENT",
                                amount = amount.num(), date = date.value ?: System.currentTimeMillis(),
                                dueDate = due.value ?: 0L, notes = notes.text.toString().trim(),
                                isSettled = existing?.isSettled ?: false,
                                createdAt = existing?.createdAt ?: System.currentTimeMillis()
                            ))
                        }
                        true
                    }
                }
            }
        )
    }

    private fun showPaymentDialog(e: LendingEntry) {
        lateinit var amount: TextInputEditText
        lateinit var date: DateField
        lateinit var notes: TextInputEditText
        val pend = pending(e)
        showFormDialog(
            "Repayment from ${e.personName}".takeIf { e.direction == "LENT" } ?: "Repayment to ${e.personName}",
            build = { f ->
                f.note("Pending: ${CurrencyFormatter.formatFullNoDecimals(pend)}")
                amount = f.number("Amount paid (₹)", "", if (pend == pend.toLong().toDouble()) pend.toLong().toString() else pend.toString())
                date = f.date("Date", System.currentTimeMillis())
                notes = f.text("Notes (optional)", "", "", android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            },
            onSave = {
                val paid = amount.num()
                if (paid <= 0) { toast("Enter the amount paid"); false }
                else {
                    viewLifecycleOwner.lifecycleScope.launch {
                        lendingDao.insertPayment(LendingPayment(
                            lendingId = e.id, amount = paid, date = date.value ?: System.currentTimeMillis(),
                            notes = notes.text.toString().trim()
                        ))
                        if (pend - paid <= 0.5) lendingDao.insertEntry(e.copy(isSettled = true))
                    }
                    true
                }
            }
        )
    }

    private fun showHistory(e: LendingEntry) {
        val list = payments.filter { it.lendingId == e.id }
        val lines = mutableListOf("${if (e.direction == "LENT") "Lent" else "Borrowed"} ${CurrencyFormatter.formatFullNoDecimals(e.amount)} on ${DateUtil.format(e.date)}")
        list.forEach { lines += "${DateUtil.format(it.date)}: ${CurrencyFormatter.formatFullNoDecimals(it.amount)}${if (it.notes.isNotBlank()) " (${it.notes})" else ""}" }
        val pend = pending(e)
        lines += "Pending: ${CurrencyFormatter.formatFullNoDecimals(pend)}"
        val settled = e.isSettled || pend <= 0.5
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(e.personName)
            .setItems(lines.toTypedArray()) { _, which ->
                val pay = list.getOrNull(which - 1) ?: return@setItems
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Delete this repayment?")
                    .setMessage("${DateUtil.format(pay.date)}: ${CurrencyFormatter.formatFullNoDecimals(pay.amount)}")
                    .setPositiveButton("Delete") { _, _ ->
                        viewLifecycleOwner.lifecycleScope.launch {
                            lendingDao.deletePayment(pay.id)
                            if (e.isSettled) lendingDao.insertEntry(e.copy(isSettled = false))
                        }
                    }
                    .setNegativeButton("Cancel", null).show()
            }
            .setNeutralButton(if (settled) "Reopen" else "Mark settled") { _, _ ->
                viewLifecycleOwner.lifecycleScope.launch { lendingDao.insertEntry(e.copy(isSettled = !settled)) }
            }
            .setPositiveButton("Close", null)
            .show()
    }
}
