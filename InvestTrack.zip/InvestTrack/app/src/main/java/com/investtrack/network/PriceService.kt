package com.investtrack.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Multi-source price service:
 *
 * 1. mfapi.in — Free, no-auth Indian MF NAV by AMFI scheme code
 *    GET https://api.mfapi.in/mf/{schemeCode}/latest
 *    Security field: use "AMFI Code" in the yahooFinanceCode field (just the number e.g. 120503)
 *
 * 2. Yahoo Finance — Stocks, ETFs, international funds by ticker
 *    Security field: yahooFinanceCode e.g. "RELIANCE.NS", "NIFTYBEES.NS"
 *    If yahooFinanceCode ends with .BO or .NS → Yahoo Finance
 *    If it's a plain number (AMFI code) → mfapi.in
 */
@Singleton
class PriceService @Inject constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
                .header("Accept", "application/json")
                .build())
        }.build()

    data class PriceResult(
        val code: String,
        val price: Double,
        val previousClose: Double,
        val change: Double,
        val changePercent: Double,
        val source: String
    )

    /**
     * Fetch a single price. Auto-detects source from the code format:
     * - Plain number (e.g. "120503") → mfapi.in
     * - Contains .NS or .BO → Yahoo Finance
     * - Other → try Yahoo Finance
     */
    fun fetchPrice(code: String): PriceResult? {
        val trimmed = code.trim()
        return if (trimmed.matches(Regex("^\\d+$"))) {
            fetchFromMFApi(trimmed)
        } else {
            fetchFromYahoo(trimmed)
        }
    }

    /** Fetch MF NAV from mfapi.in using AMFI scheme code */
    private fun fetchFromMFApi(amfiCode: String): PriceResult? {
        return try {
            val url = "https://api.mfapi.in/mf/$amfiCode/latest"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val json = JSONObject(body)
                if (json.getString("status") != "SUCCESS") return null
                val dataArray = json.getJSONArray("data")
                if (dataArray.length() == 0) return null
                val latest = dataArray.getJSONObject(0)
                val nav = latest.getString("nav").toDoubleOrNull() ?: return null

                // Get previous NAV if available
                val prevNav = if (dataArray.length() > 1)
                    dataArray.getJSONObject(1).getString("nav").toDoubleOrNull() ?: nav
                else nav

                val change = nav - prevNav
                val changePct = if (prevNav > 0) (change / prevNav) * 100 else 0.0
                PriceResult(amfiCode, nav, prevNav, change, changePct, "mfapi.in")
            }
        } catch (e: Exception) { null }
    }

    /** Fetch price from Yahoo Finance using ticker symbol */
    private fun fetchFromYahoo(ticker: String): PriceResult? {
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$ticker?interval=1d&range=2d"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                val price = Regex(""""regularMarketPrice"\s*:\s*([\d.]+)""")
                    .find(body)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
                val prev = Regex(""""regularMarketPreviousClose"\s*:\s*([\d.]+)""")
                    .find(body)?.groupValues?.get(1)?.toDoubleOrNull() ?: price
                val change = price - prev
                val changePct = if (prev > 0) (change / prev) * 100 else 0.0
                PriceResult(ticker, price, prev, change, changePct, "Yahoo Finance")
            }
        } catch (e: Exception) { null }
    }

    /** Search MF by name on mfapi.in and return matching schemes */
    fun searchMFByName(query: String): List<MFSearchResult> {
        return try {
            val url = "https://api.mfapi.in/mf/search?q=${query.replace(" ", "+")}"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return emptyList()
                val body = response.body?.string() ?: return emptyList()
                val results = mutableListOf<MFSearchResult>()
                val json = org.json.JSONArray(body)
                for (i in 0 until minOf(json.length(), 10)) {
                    val item = json.getJSONObject(i)
                    results.add(MFSearchResult(
                        schemeCode = item.getInt("schemeCode").toString(),
                        schemeName = item.getString("schemeName")
                    ))
                }
                results
            }
        } catch (e: Exception) { emptyList() }
    }

    data class MFSearchResult(val schemeCode: String, val schemeName: String)

    /** Fetch multiple prices - returns map of code → PriceResult */
    fun fetchPrices(codes: List<String>): Map<String, PriceResult> {
        val results = mutableMapOf<String, PriceResult>()
        codes.forEach { code ->
            fetchPrice(code)?.let { results[code] = it }
            Thread.sleep(200) // be polite to free APIs
        }
        return results
    }
}
