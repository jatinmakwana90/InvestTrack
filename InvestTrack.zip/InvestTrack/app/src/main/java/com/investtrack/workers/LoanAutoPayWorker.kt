package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.settings.AutomationSettings
import com.investtrack.utils.LoanAutoPay
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

@HiltWorker
class LoanAutoPayWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val automation: AutomationSettings
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        if (!automation.autoPayEmis) return Result.success()
        return try {
            LoanAutoPay.process(loanDao, loanAdjustmentDao)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
