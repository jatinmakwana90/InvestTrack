package com.investtrack.ui.loans

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.models.AdjustmentType
import com.investtrack.data.models.Loan
import com.investtrack.data.models.LoanAdjustment
import com.investtrack.databinding.FragmentLoanDetailBinding
import com.investtrack.databinding.ItemLoanCashflowRowBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.utils.LoanScheduleRow
import com.investtrack.utils.LoanScheduleSummary
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class LoanDetailViewModel @Inject constructor(
    private val loanDao: LoanDao,
    private val adjustmentDao: LoanAdjustmentDao,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val loanId: Long = savedStateHandle.get<Long>("loanId") ?: 0L

    val loan: StateFlow<Loan?> = loanDao.getLoanByIdFlow(loanId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val adjustments: StateFlow<List<LoanAdjustment>> = adjustmentDao.getAdjustmentsForLoan(loanId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val schedule: StateFlow<LoanScheduleSummary?> = combine(loan, adjustments) { l, adj ->
        l?.let { LoanAmortizationCalculator.buildSchedule(it, adj) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted

    fun markPaid(installmentNumber: Int) {
        viewModelScope.launch {
            val current = loan.value ?: return@launch
            val set = current.paidInstallmentSet().toMutableSet()
            if (!set.add(installmentNumber)) return@launch
            loanDao.updateLoan(
                current.copy(
                    paidInstallments = set.sorted().joinToString(","),
                    emisPaid = set.size
                )
            )
        }
    }

    fun addPartPayment(amount: Double, effectiveFromInstallment: Int) {
        viewModelScope.launch {
            adjustmentDao.insert(
                LoanAdjustment(
                    loanId = loanId,
                    type = AdjustmentType.PART_PAYMENT,
                    effectiveFromInstallment = effectiveFromInstallment,
                    effectiveDate = System.currentTimeMillis(),
                    partPaymentAmount = amount
                )
            )
        }
    }

    fun changeRate(newRate: Double, effectiveFromInstallment: Int) {
        viewModelScope.launch {
            adjustmentDao.insert(
                LoanAdjustment(
                    loanId = loanId,
                    type = AdjustmentType.RATE_CHANGE,
                    effectiveFromInstallment = effectiveFromInstallment,
                    effectiveDate = System.currentTimeMillis(),
                    newInterestRate = newRate
                )
            )
        }
    }

    fun changeEmi(newEmi: Double, effectiveFromInstallment: Int) {
        viewModelScope.launch {
            adjustmentDao.insert(
                LoanAdjustment(
                    loanId = loanId,
                    type = AdjustmentType.EMI_CHANGE,
                    effectiveFromInstallment = effectiveFromInstallment,
                    effectiveDate = System.currentTimeMillis(),
                    newEmiAmount = newEmi
                )
            )
        }
    }

    fun delete() {
        viewModelScope.launch {
            loanDao.deleteLoan(loanId)
            _deleted.value = true
        }
    }
}

@AndroidEntryPoint
class LoanDetailFragment : Fragment() {
    private var _binding: FragmentLoanDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LoanDetailViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    private lateinit var cashFlowAdapter: CashFlowAdapter
    private var currentLoan: Loan? = null
    private var currentSchedule: LoanScheduleSummary? = null
    private var showAll = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLoanDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.btnEdit.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddEditLoanFragment.newInstance(viewModel.loanId))
        }
        binding.btnDelete.setOnClickListener { confirmDelete() }
        binding.btnSimulator.setOnClickListener { showSimulatorDialog() }
        binding.btnPartPayment.setOnClickListener { showPartPaymentDialog() }
        binding.btnChangeRate.setOnClickListener { showChangeRateDialog() }
        binding.btnChangeEmi.setOnClickListener { showChangeEmiDialog() }
        binding.tvShowAll.setOnClickListener {
            showAll = !showAll
            binding.tvShowAll.text = if (showAll) "▴ Show less" else "▾ Show all"
            renderCashFlow()
        }

        cashFlowAdapter = CashFlowAdapter { row -> viewModel.markPaid(row.installmentNumber) }
        binding.rvCashFlow.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = cashFlowAdapter
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.loan.collect { loan ->
                loan ?: return@collect
                currentLoan = loan
                bindLoanHeader(loan)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.schedule.collect { schedule ->
                currentSchedule = schedule
                schedule ?: return@collect
                bindScheduleStats(schedule)
                renderCashFlow()
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.deleted.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }
    }

    private fun bindLoanHeader(loan: Loan) {
        binding.tvTypeEmoji.text = loan.loanType.emoji
        binding.tvLoanName.text = loan.loanName
        val years = loan.totalEmis / 12.0
        binding.tvLoanSubtitle.text = "${loan.lenderName.ifEmpty { "—" }} · ${"%.1f".format(years)}yr @ ${formatPct(loan.interestRate)}%"
        binding.tvLoanAmount.text = CurrencyFormatter.formatFull(loan.principalAmount)
    }

    private fun bindScheduleStats(schedule: LoanScheduleSummary) {
        binding.tvCurrentEmi.text = CurrencyFormatter.formatFull(schedule.currentEmi)
        binding.tvOutstanding.text = CurrencyFormatter.formatFull(schedule.currentOutstanding)
        binding.tvRemainingEmis.text = schedule.remainingInstallments.toString()
        binding.tvLastEmiDate.text = schedule.lastEmiDate?.let { dateFmt.format(it) } ?: "—"
        binding.tvPrincipalPaid.text = CurrencyFormatter.formatFull(schedule.principalPaidTillNow)
        binding.tvInterestPaid.text = CurrencyFormatter.formatFull(schedule.interestPaidTillNow)
        binding.tvTotalPaid.text = CurrencyFormatter.formatFull(schedule.totalPaidTillNow)
        binding.tvEmiStart.text = schedule.rows.firstOrNull()?.dueDate?.let { dateFmt.format(it) } ?: "—"
        binding.tvLastEmiPaid.text = schedule.lastEmiPaidDate?.let { dateFmt.format(it) } ?: "—"
        binding.tvNextEmiDate.text = schedule.nextEmiDate?.let { dateFmt.format(it) } ?: "—"
    }

    private fun renderCashFlow() {
        val schedule = currentSchedule ?: return
        val loan = currentLoan ?: return
        val paidSet = loan.paidInstallmentSet()
        val nextUnpaid = schedule.rows.firstOrNull { it.installmentNumber !in paidSet }?.installmentNumber
        val rows = if (showAll) schedule.rows else schedule.rows.take(5)
        binding.tvShowAll.text = if (showAll) "▴ Show less (${schedule.rows.size})" else "▾ Show all ${schedule.rows.size}"
        cashFlowAdapter.submit(rows, paidSet, nextUnpaid, dateFmt)
    }

    private fun formatPct(v: Double): String = if (v == v.toLong().toDouble()) v.toLong().toString() else "%.2f".format(v)

    private fun nextInstallmentNumber(): Int {
        val loan = currentLoan ?: return 1
        val paid = loan.paidInstallmentSet()
        return (currentSchedule?.rows?.firstOrNull { it.installmentNumber !in paid }?.installmentNumber) ?: 1
    }

    private fun showSimulatorDialog() {
        val loan = currentLoan
        val schedule = currentSchedule
        val paid = loan?.paidInstallmentSet() ?: emptySet()
        val next = schedule?.rows?.firstOrNull { it.installmentNumber !in paid }
        if (loan == null || schedule == null || next == null) {
            android.widget.Toast.makeText(requireContext(), "This loan has no EMIs left to simulate", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val prev = schedule.rows.firstOrNull { it.installmentNumber == next.installmentNumber - 1 }
        val balanceBefore = prev?.balance ?: loan.principalAmount
        val monthlyRate = if (balanceBefore > 0) next.interest / balanceBefore else loan.interestRate / 1200.0
        val emi = next.emi

        val v = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_prepayment_sim, null)
        val etLump = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_sim_lump)
        val etExtra = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_sim_extra)
        val tvHead = v.findViewById<android.widget.TextView>(R.id.tv_sim_headline)
        val tvMonths = v.findViewById<android.widget.TextView>(R.id.tv_sim_months)
        val tvDetail = v.findViewById<android.widget.TextView>(R.id.tv_sim_detail)
        val monthFmt = SimpleDateFormat("MMM yyyy", Locale.getDefault())

        fun update() {
            val lump = etLump.text?.toString()?.replace(",", "")?.toDoubleOrNull() ?: 0.0
            val extra = etExtra.text?.toString()?.replace(",", "")?.toDoubleOrNull() ?: 0.0
            val base = com.investtrack.utils.PrepaymentSimulator.simulate(balanceBefore, monthlyRate, emi, 0.0, 0.0, next.dueDate)
            if (lump <= 0 && extra <= 0) {
                tvHead.text = "Enter an amount above"
                tvMonths.text = if (base.baseMonths >= 0) "Today: ${base.baseMonths} EMIs left, ₹${"%,.0f".format(base.baseInterest)} interest still to pay" else ""
                tvDetail.text = ""
                return
            }
            val r = com.investtrack.utils.PrepaymentSimulator.simulate(balanceBefore, monthlyRate, emi, lump, extra, next.dueDate)
            tvHead.text = "You save ₹${"%,.0f".format(r.interestSaved)} in interest"
            val years = r.monthsSaved / 12; val months = r.monthsSaved % 12
            val earlier = buildString {
                if (years > 0) append("$years year${if (years > 1) "s" else ""} ")
                if (months > 0 || years == 0) append("$months month${if (months != 1) "s" else ""}")
            }.trim()
            tvMonths.text = "Loan closes $earlier earlier" + (r.closingDate?.let { " (${monthFmt.format(Date(it))})" } ?: "")
            tvDetail.text = "EMIs left: ${r.baseMonths} → ${r.newMonths}\n" +
                "Interest still to pay: ₹${"%,.0f".format(r.baseInterest)} → ₹${"%,.0f".format(r.newInterest)}\n" +
                "Your EMI of ₹${"%,.0f".format(emi)} stays the same."
        }
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) { update() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        etLump.addTextChangedListener(watcher)
        etExtra.addTextChangedListener(watcher)
        update()

        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Prepayment Simulator")
            .setView(v)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showPartPaymentDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_loan_amount_input, null)
        val label = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_label)
        val hint = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_hint)
        val input = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_dialog_amount)
        label.text = "PART PAYMENT AMOUNT (₹)"
        hint.text = "This will reduce your outstanding principal and recalculate the schedule."
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Make Part Payment")
            .setView(dialogView)
            .setPositiveButton("Confirm") { _, _ ->
                val amount = input.text.toString().toDoubleOrNull()
                if (amount != null && amount > 0) {
                    viewModel.addPartPayment(amount, nextInstallmentNumber())
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showChangeRateDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_loan_amount_input, null)
        val label = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_label)
        val hint = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_hint)
        val input = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_dialog_amount)
        label.text = "NEW ANNUAL INTEREST RATE (%)"
        hint.text = "Your EMI will be recalculated to keep the remaining tenure the same."
        currentLoan?.let { input.setText(formatPct(it.interestRate)) }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Change Interest Rate")
            .setView(dialogView)
            .setPositiveButton("Confirm") { _, _ ->
                val rate = input.text.toString().toDoubleOrNull()
                if (rate != null && rate > 0) {
                    viewModel.changeRate(rate, nextInstallmentNumber())
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showChangeEmiDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_loan_amount_input, null)
        val label = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_label)
        val hint = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_hint)
        val input = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_dialog_amount)
        label.text = "NEW MONTHLY EMI (₹)"
        hint.text = "Your remaining tenure will be recalculated based on the new EMI."
        currentSchedule?.let { input.setText(formatPct(it.currentEmi)) }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Change EMI Amount")
            .setView(dialogView)
            .setPositiveButton("Confirm") { _, _ ->
                val emi = input.text.toString().toDoubleOrNull()
                if (emi != null && emi > 0) {
                    viewModel.changeEmi(emi, nextInstallmentNumber())
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete() {
        val loan = currentLoan ?: return
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Loan")
            .setMessage("Remove \"${loan.loanName}\"? This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> viewModel.delete() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(loanId: Long) = LoanDetailFragment().apply {
            arguments = Bundle().apply { putLong("loanId", loanId) }
        }
    }
}

private fun SimpleDateFormat.format(millis: Long): String = this.format(java.util.Date(millis))

class CashFlowAdapter(
    private val onPayClick: (LoanScheduleRow) -> Unit
) : RecyclerView.Adapter<CashFlowAdapter.VH>() {
    private var rows: List<LoanScheduleRow> = emptyList()
    private var paidSet: Set<Int> = emptySet()
    private var nextUnpaid: Int? = null
    private var dateFmt: SimpleDateFormat? = null

    fun submit(newRows: List<LoanScheduleRow>, paid: Set<Int>, next: Int?, fmt: SimpleDateFormat) {
        rows = newRows; paidSet = paid; nextUnpaid = next; dateFmt = fmt
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemLoanCashflowRowBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLoanCashflowRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]
        val b = holder.b
        val ctx = b.root.context
        b.tvRowDate.text = dateFmt?.format(row.dueDate) ?: ""
        b.tvRowEmi.text = CurrencyFormatter.formatFullNoDecimals(row.emi)
        b.tvRowInterest.text = CurrencyFormatter.formatFull(row.interest)
        b.tvRowPrincipal.text = CurrencyFormatter.formatFull(row.principal)
        b.tvRowBalance.text = CurrencyFormatter.formatFull(row.balance)

        val isPaid = row.installmentNumber in paidSet
        val isNext = row.installmentNumber == nextUnpaid
        when {
            isPaid -> {
                b.tvRowStatus.text = "✓"
                b.tvRowStatus.setBackgroundResource(R.drawable.bg_loan_status_paid)
                b.tvRowStatus.setTextColor(ctx.getColor(R.color.loan_green))
                b.tvRowStatus.setOnClickListener(null)
            }
            isNext -> {
                b.tvRowStatus.text = "Pay"
                b.tvRowStatus.setBackgroundResource(R.drawable.bg_loan_status_due)
                b.tvRowStatus.setTextColor(ctx.getColor(android.R.color.white))
                b.tvRowStatus.setOnClickListener { onPayClick(row) }
            }
            else -> {
                b.tvRowStatus.text = "Pay"
                b.tvRowStatus.setBackgroundResource(R.drawable.bg_loan_status_pending)
                b.tvRowStatus.setTextColor(ctx.getColor(R.color.loan_text_primary))
                b.tvRowStatus.setOnClickListener { onPayClick(row) }
            }
        }
    }
}
