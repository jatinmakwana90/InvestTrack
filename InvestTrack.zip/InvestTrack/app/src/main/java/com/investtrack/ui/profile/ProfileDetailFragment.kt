package com.investtrack.ui.profile

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentProfileDetailBinding
import com.investtrack.ui.accounts.FolioAdapter
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileDetailViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val profileId: Long = savedStateHandle.get<Long>("profileId") ?: 0L

    private val _uiState = MutableStateFlow(ProfileDetailUiState())
    val uiState: StateFlow<ProfileDetailUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val profile = repository.getProfileById(profileId)
                val folios = repository.getFoliosForProfile(profileId)
                val summary = repository.getProfileSummary(profileId)

                // Group by security type
                val byType = folios.groupBy { it.securityType }
                    .map { (type, list) ->
                        TypeGroup(
                            type = type,
                            folios = list.sortedByDescending { it.currentValue },
                            totalValue = list.sumOf { it.currentValue },
                            totalInvested = list.sumOf { it.totalInvested }
                        )
                    }.sortedByDescending { it.totalValue }

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        profile = profile,
                        summary = summary,
                        folios = folios,
                        typeGroups = byType
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}

data class ProfileDetailUiState(
    val isLoading: Boolean = false,
    val profile: Profile? = null,
    val summary: PortfolioSummary? = null,
    val folios: List<Folio> = emptyList(),
    val typeGroups: List<TypeGroup> = emptyList(),
    val error: String? = null
)

data class TypeGroup(
    val type: SecurityType,
    val folios: List<Folio>,
    val totalValue: Double,
    val totalInvested: Double
)

@AndroidEntryPoint
class ProfileDetailFragment : Fragment() {

    private var _binding: FragmentProfileDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProfileDetailViewModel by viewModels()
    private lateinit var folioAdapter: FolioAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        folioAdapter = FolioAdapter { folio ->
            val bundle = android.os.Bundle().apply {
                putLong("accountId", folio.accountId)
                putLong("securityId", folio.securityId)
            }
            findNavController().navigate(R.id.action_profileDetail_to_folioDetail, bundle)
        }
        binding.rvHoldings.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = folioAdapter
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                state.profile?.let {
                    binding.toolbar.title = it.name
                    binding.tvProfileName.text = it.name
                    binding.tvRelation.text = it.relation.displayName
                    binding.tvPan.text = if (it.pan.isNotEmpty()) "PAN: ${it.pan}" else ""
                }
                state.summary?.let { s ->
                    binding.tvCurrentValue.text = CurrencyFormatter.format(s.currentValue)
                    binding.tvInvested.text = "Invested: ${CurrencyFormatter.format(s.totalInvested)}"
                    val pnl = s.totalPnL
                    binding.tvPnl.text = "${if (pnl >= 0) "+" else ""}${CurrencyFormatter.format(pnl)} (${String.format("%.2f", s.totalPnLPercent)}%)"
                    binding.tvPnl.setTextColor(requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red))
                    binding.tvHoldingsCount.text = "${s.folioCount} Holdings across ${s.accountCount} accounts"
                }
                folioAdapter.submitList(state.folios)
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
