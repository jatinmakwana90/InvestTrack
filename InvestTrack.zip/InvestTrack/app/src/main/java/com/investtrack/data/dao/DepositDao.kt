package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Deposit
import kotlinx.coroutines.flow.Flow

@Dao
interface DepositDao {
    @Query("SELECT * FROM deposits ORDER BY isClosed ASC, maturityDate ASC")
    fun getAll(): Flow<List<Deposit>>

    @Query("SELECT * FROM deposits ORDER BY maturityDate ASC")
    suspend fun getAllList(): List<Deposit>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(deposit: Deposit): Long

    @Query("DELETE FROM deposits WHERE id = :id")
    suspend fun delete(id: Long)
}
