package com.investtrack.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.Policy
import com.investtrack.databinding.ItemDashboardPolicyBinding
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil

class DashboardPolicyAdapter(
    private val onClick: (Policy) -> Unit
) : ListAdapter<Policy, DashboardPolicyAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemDashboardPolicyBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(p: Policy) {
            val ctx = b.root.context
            b.tvPolicyName.text = p.name
            b.tvPolicyInsurer.text = p.insurer
            b.tvPolicyInsurer.visibility = if (p.insurer.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            b.tvPolicyPremium.text = CurrencyFormatter.formatFullNoDecimals(p.premiumAmount)
            b.tvPolicyFreq.text = when (p.frequency) {
                "MONTHLY" -> "Monthly"; "QUARTERLY" -> "Quarterly"; "HALF_YEARLY" -> "Half-yearly"; else -> "Yearly"
            }
            b.tvPolicyCover.text = CurrencyFormatter.format(p.coverAmount)

            val days = DateUtil.daysUntil(p.nextDueDate)
            b.tvPolicyNext.text = if (days < 0) "Premium overdue by ${-days} day${if (days != -1) "s" else ""}"
                                  else "Next premium ${DateUtil.format(p.nextDueDate)} · ${DateUtil.duesLabel(days)}"
            b.tvPolicyNext.setTextColor(ctx.getColor(when {
                days <= 7 -> R.color.loss_red
                days <= 30 -> R.color.text_accent
                else -> R.color.text_secondary
            }))
            b.root.setOnClickListener { onClick(p) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemDashboardPolicyBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Policy>() {
            override fun areItemsTheSame(a: Policy, b: Policy) = a.id == b.id
            override fun areContentsTheSame(a: Policy, b: Policy) = a == b
        }
    }
}
