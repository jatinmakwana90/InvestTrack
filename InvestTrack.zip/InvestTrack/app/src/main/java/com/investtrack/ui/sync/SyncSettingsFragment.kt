package com.investtrack.ui.sync

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.investtrack.data.models.SyncConfig
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentSyncSettingsBinding
import com.investtrack.network.SyncClient
import com.investtrack.network.SyncServer
import com.investtrack.workers.WifiSyncWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class SyncViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val syncServer: SyncServer,
    private val syncClient: SyncClient
) : ViewModel() {

    private val _uiState = MutableStateFlow(SyncUiState())
    val uiState: StateFlow<SyncUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getSyncConfig().collect { config ->
                _uiState.update { it.copy(config = config) }
            }
        }
    }

    fun setPrimaryDevice(isPrimary: Boolean) {
        viewModelScope.launch {
            val existing = repository.getSyncConfigOnce() ?: SyncConfig()
            if (isPrimary) {
                val token = generateToken()
                val newConfig = existing.copy(isPrimaryDevice = true, pairingToken = token, syncEnabled = true)
                repository.upsertSyncConfig(newConfig)
                val pairingStr = syncServer.buildPairingString(token)
                syncServer.start(token)
                _uiState.update { it.copy(pairingString = pairingStr, statusMessage = "Primary device active. Share the pairing code.") }
            } else {
                syncServer.stop()
                val newConfig = existing.copy(isPrimaryDevice = false, syncEnabled = true)
                repository.upsertSyncConfig(newConfig)
                _uiState.update { it.copy(pairingString = "", statusMessage = "Non-Primary mode. Enter pairing code from Primary device.") }
            }
        }
    }

    fun pairWithPrimary(pairingStr: String, context: android.content.Context) {
        viewModelScope.launch {
            val parsed = syncClient.parsePairingString(pairingStr)
            if (parsed == null) {
                _uiState.update { it.copy(statusMessage = "Invalid pairing code. Please check and try again.") }
                return@launch
            }
            val (ip, port, token) = parsed
            _uiState.update { it.copy(isSyncing = true, statusMessage = "Connecting to Primary device...") }

            val reachable = syncClient.ping(ip, port)
            if (!reachable) {
                _uiState.update { it.copy(isSyncing = false, statusMessage = "Cannot reach Primary device. Ensure both devices are on same Wi-Fi.") }
                return@launch
            }

            val existing = repository.getSyncConfigOnce() ?: SyncConfig()
            repository.upsertSyncConfig(existing.copy(targetIp = ip, targetPort = port, pairingToken = token, syncEnabled = true))

            val result = syncClient.sync(ip, port, token)
            repository.updateLastSyncTime(System.currentTimeMillis())
            WifiSyncWorker.schedule(context)

            _uiState.update {
                it.copy(
                    isSyncing = false,
                    statusMessage = if (result.success) "✓ ${result.message}" else "✗ ${result.message}"
                )
            }
        }
    }

    fun syncNow(context: android.content.Context) {
        WifiSyncWorker.runOnce(context)
        _uiState.update { it.copy(statusMessage = "Sync triggered in background...") }
    }

    private fun generateToken(): String {
        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return (1..8).map { chars.random() }.joinToString("")
    }
}

data class SyncUiState(
    val config: SyncConfig? = null,
    val pairingString: String = "",
    val isSyncing: Boolean = false,
    val statusMessage: String = ""
)

@AndroidEntryPoint
class SyncSettingsFragment : Fragment() {

    private var _binding: FragmentSyncSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SyncViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSyncSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        binding.switchPrimaryDevice.setOnCheckedChangeListener { _, checked ->
            viewModel.setPrimaryDevice(checked)
            updateVisibility(checked)
        }

        binding.btnPair.setOnClickListener {
            val code = binding.etPairingCode.text.toString().trim()
            if (code.isBlank()) { binding.tilPairingCode.error = "Enter pairing code"; return@setOnClickListener }
            viewModel.pairWithPrimary(code, requireContext())
        }

        binding.btnSyncNow.setOnClickListener {
            viewModel.syncNow(requireContext())
        }

        binding.btnCopyPairing.setOnClickListener {
            val clip = android.content.ClipData.newPlainText("Pairing Code", binding.tvPairingCode.text)
            val cm = requireContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(clip)
            com.google.android.material.snackbar.Snackbar.make(binding.root, "Pairing code copied!", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                state.config?.let { config ->
                    binding.switchPrimaryDevice.isChecked = config.isPrimaryDevice
                    updateVisibility(config.isPrimaryDevice)
                    if (config.lastSyncTime > 0) {
                        binding.tvLastSync.text = "Last sync: ${dateFmt.format(Date(config.lastSyncTime))}"
                        binding.tvLastSync.visibility = View.VISIBLE
                    }
                }
                if (state.pairingString.isNotEmpty()) {
                    binding.tvPairingCode.text = state.pairingString
                    binding.cardPrimaryInfo.visibility = View.VISIBLE
                }
                binding.tvStatus.text = state.statusMessage
                binding.tvStatus.visibility = if (state.statusMessage.isNotEmpty()) View.VISIBLE else View.GONE
                binding.progressSync.visibility = if (state.isSyncing) View.VISIBLE else View.GONE
            }
        }
    }

    private fun updateVisibility(isPrimary: Boolean) {
        binding.cardPrimaryInfo.visibility = if (isPrimary) View.VISIBLE else View.GONE
        binding.cardNonPrimaryInfo.visibility = if (!isPrimary) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
