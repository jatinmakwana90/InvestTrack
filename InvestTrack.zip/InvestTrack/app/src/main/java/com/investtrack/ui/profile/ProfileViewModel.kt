package com.investtrack.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ProfileListUiState())
    val uiState: StateFlow<ProfileListUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            repository.getAllProfiles().collect { profiles ->
                val summaries = repository.getAllProfileSummaries()
                _uiState.update {
                    it.copy(isLoading = false, profileSummaries = summaries)
                }
            }
        }
    }

    fun deleteProfile(id: Long) {
        viewModelScope.launch { repository.deactivateProfile(id) }
    }
}

data class ProfileListUiState(
    val isLoading: Boolean = false,
    val profileSummaries: List<ProfileSummary> = emptyList(),
    val error: String? = null
)
