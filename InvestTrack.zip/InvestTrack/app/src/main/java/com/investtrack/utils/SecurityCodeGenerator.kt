package com.investtrack.utils

object SecurityCodeGenerator {
    private val CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

    fun generate(prefix: String = ""): String {
        val random = (1..6).map { CHARS.random() }.joinToString("")
        val ts = System.currentTimeMillis().toString().takeLast(4)
        return "${prefix.take(2).uppercase()}$random$ts"
    }

    fun generateForType(typeName: String): String {
        val prefix = when {
            typeName.contains("EQUITY", true) -> "EQ"
            typeName.contains("DEBT") -> "DF"
            typeName.contains("GOLD") -> "GD"
            typeName.contains("DEPOSIT") || typeName.contains("FD") -> "FD"
            typeName.contains("BOND") -> "BD"
            else -> "SC"
        }
        return generate(prefix)
    }
}
