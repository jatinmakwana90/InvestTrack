package com.investtrack.ui.securities

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.tabs.TabLayout
import com.investtrack.databinding.FragmentSecuritiesPriceUpdateBinding
import com.investtrack.ui.reminders.AutoPriceSyncFragment
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single home for everything related to keeping security prices current: scheduled daily
 * auto-sync, typing a price in by hand, and a live "sync now" fetch — previously three
 * separate screens reachable from different places (Settings and Masters), now one place
 * with a tab per action.
 */
@AndroidEntryPoint
class SecuritiesPriceUpdateFragment : Fragment() {
    private var _binding: FragmentSecuritiesPriceUpdateBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSecuritiesPriceUpdateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val initialTab = arguments?.getInt(ARG_INITIAL_TAB, 0) ?: 0

        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) { showTab(tab.position) }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })

        if (savedInstanceState == null) {
            val tab = binding.tabLayout.getTabAt(initialTab)
            if (tab != null && tab.isSelected) {
                // TabLayout won't fire onTabSelected for a tab that's already selected
                // (position 0 by default), so drive the initial content load explicitly here.
                showTab(initialTab)
            } else {
                tab?.select()
            }
        }
    }

    private fun showTab(position: Int) {
        val fragment = when (position) {
            0 -> AutoPriceSyncFragment()
            1 -> ManualPriceUpdateFragment()
            else -> PriceSyncFragment()
        }
        childFragmentManager.beginTransaction()
            .replace(binding.priceUpdateContent.id, fragment)
            .commit()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        private const val ARG_INITIAL_TAB = "initial_tab"
        const val TAB_AUTO = 0
        const val TAB_MANUAL = 1
        const val TAB_SYNC = 2

        fun newInstance(initialTab: Int = TAB_AUTO) = SecuritiesPriceUpdateFragment().apply {
            arguments = Bundle().apply { putInt(ARG_INITIAL_TAB, initialTab) }
        }
    }
}
