package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * A monthly investment contribution target for a security type (e.g. "invest ₹5,000/month
 * in Equity Mutual Funds"). Progress is tracked against actual BUY transaction amounts for
 * securities of that type in the current calendar month — this is InvestTrack's equivalent
 * of a "budget limit", since the app tracks investment activity rather than everyday spend.
 */
@Parcelize
@Serializable
@Entity(tableName = "budget_limits")
data class BudgetLimit(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val securityType: SecurityType,
    val monthlyLimit: Double,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) : Parcelable
