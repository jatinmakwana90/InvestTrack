package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Security::class, parentColumns = ["id"], childColumns = ["securityId"], onDelete = ForeignKey.CASCADE)
    ],
    indices = [Index("accountId"), Index("securityId")]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val accountId: Long,
    val securityId: Long,
    val type: TransactionType,
    val quantity: Double,
    val price: Double,
    val amount: Double,
    val charges: Double = 0.0,
    val nav: Double? = null,
    val units: Double? = null,
    val folioNumber: String = "",
    val notes: String = "",
    val transactionDate: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

enum class TransactionType(val displayName: String) {
    BUY("Buy"),
    SELL("Sell"),
    MATURITY("Maturity")
}

data class Folio(
    val accountId: Long,
    val accountName: String,
    val profileId: Long = 0,
    val profileName: String = "",
    val securityId: Long,
    val securityName: String,
    val securitySymbol: String,
    val securityCode: String,
    val securityType: SecurityType,
    val folioNumber: String,
    val totalUnits: Double,
    val avgCostPrice: Double,
    val totalInvested: Double,
    val currentValue: Double,
    val currentPrice: Double,
    val pnl: Double,
    val pnlPercent: Double,
    val dayChange: Double = 0.0,
    val isPriceEstimated: Boolean = false
)

data class PortfolioSummary(
    val totalInvested: Double,
    val currentValue: Double,
    val totalPnL: Double,
    val totalPnLPercent: Double,
    val dayChange: Double,
    val dayChangePercent: Double,
    val folioCount: Int,
    val accountCount: Int
)
