package com.investtrack.ui.analytics

import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.PercentFormatter
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAnalyticsBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AllocationItem(
    val label: String,
    val currentValue: Double,
    val invested: Double,
    val pnl: Double,
    val pnlPercent: Double,
    val color: Int
)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _allocations = MutableStateFlow<List<AllocationItem>>(emptyList())
    val allocations: StateFlow<List<AllocationItem>> = _allocations

    private val _topGainers = MutableStateFlow<List<com.investtrack.data.models.Folio>>(emptyList())
    val topGainers: StateFlow<List<com.investtrack.data.models.Folio>> = _topGainers

    private val _topLosers = MutableStateFlow<List<com.investtrack.data.models.Folio>>(emptyList())
    val topLosers: StateFlow<List<com.investtrack.data.models.Folio>> = _topLosers

    private val _totalValue = MutableStateFlow(0.0)
    val totalValue: StateFlow<Double> = _totalValue

    private val _totalInvested = MutableStateFlow(0.0)
    val totalInvested: StateFlow<Double> = _totalInvested

    init { load() }

    private fun load() {
        viewModelScope.launch {
            val folios = repository.getAllFolios()
            val total = folios.sumOf { it.currentValue }
            val invested = folios.sumOf { it.totalInvested }
            _totalValue.value = total
            _totalInvested.value = invested

            // Group by security type
            val byType = folios.groupBy { it.securityType }
            val colors = mapOf(
                SecurityType.EQUITY to android.graphics.Color.parseColor("#3F51B5"),
                SecurityType.EQUITY_MF to android.graphics.Color.parseColor("#5C6BC0"),
                SecurityType.DEBT_MF to android.graphics.Color.parseColor("#00BCD4"),
                SecurityType.GOLD to android.graphics.Color.parseColor("#FFC107"),
                SecurityType.FIXED_DEPOSIT to android.graphics.Color.parseColor("#FF9800"),
                SecurityType.BOND to android.graphics.Color.parseColor("#4CAF50"),
                SecurityType.ETF to android.graphics.Color.parseColor("#009688"),
                SecurityType.PPF to android.graphics.Color.parseColor("#8BC34A"),
                SecurityType.NPS to android.graphics.Color.parseColor("#03A9F4"),
                SecurityType.CRYPTO to android.graphics.Color.parseColor("#F44336")
            )

            _allocations.value = byType.map { (type, items) ->
                val cv = items.sumOf { it.currentValue }
                val inv = items.sumOf { it.totalInvested }
                val pnl = cv - inv
                AllocationItem(
                    label = type.displayName,
                    currentValue = cv,
                    invested = inv,
                    pnl = pnl,
                    pnlPercent = if (inv > 0) pnl / inv * 100 else 0.0,
                    color = colors[type] ?: Color.GRAY
                )
            }.sortedByDescending { it.currentValue }

            // Top gainers/losers by % return
            _topGainers.value = folios.filter { it.pnlPercent > 0 }
                .sortedByDescending { it.pnlPercent }.take(5)
            _topLosers.value = folios.filter { it.pnlPercent < 0 }
                .sortedBy { it.pnlPercent }.take(5)
        }
    }
}

@AndroidEntryPoint
class AnalyticsFragment : Fragment() {
    private var _binding: FragmentAnalyticsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AnalyticsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAnalyticsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.allocations.collect { items ->
                if (items.isEmpty()) return@collect
                setupPieChart(items)
                setupAllocationTable(items)
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.topGainers.collect { folios ->
                val sb = StringBuilder()
                folios.forEachIndexed { i, f ->
                    sb.appendLine("${i+1}. ${f.securityName.take(25)}  +${String.format("%.1f", f.pnlPercent)}%")
                }
                binding.tvGainers.text = if (sb.isEmpty()) "No gainers" else sb.toString().trimEnd()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.topLosers.collect { folios ->
                val sb = StringBuilder()
                folios.forEachIndexed { i, f ->
                    sb.appendLine("${i+1}. ${f.securityName.take(25)}  ${String.format("%.1f", f.pnlPercent)}%")
                }
                binding.tvLosers.text = if (sb.isEmpty()) "No underperformers" else sb.toString().trimEnd()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalValue.collect { v ->
                if (v > 0) binding.tvTotalValue.text = CurrencyFormatter.format(v)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalInvested.collect { v ->
                if (v > 0) binding.tvTotalInvested.text = "Invested: ${CurrencyFormatter.format(v)}"
            }
        }
    }

    private fun setupPieChart(items: List<AllocationItem>) {
        val entries = items.map { PieEntry(it.currentValue.toFloat(), it.label) }
        val colors = items.map { it.color }

        val dataSet = PieDataSet(entries, "").apply {
            this.colors = colors
            sliceSpace = 2f
            valueTextSize = 11f
            valueFormatter = PercentFormatter(binding.pieChart)
            valueTextColor = Color.WHITE
        }

        binding.pieChart.apply {
            data = PieData(dataSet)
            description.isEnabled = false
            isDrawHoleEnabled = true
            holeRadius = 52f
            transparentCircleRadius = 57f
            setHoleColor(requireContext().getColor(com.investtrack.R.color.card_background))
            setCenterText("Allocation")
            setCenterTextSize(14f)
            setCenterTextColor(requireContext().getColor(com.investtrack.R.color.text_primary))
            setUsePercentValues(true)
            setEntryLabelColor(Color.WHITE)
            setEntryLabelTextSize(10f)
            legend.apply {
                isEnabled = true
                orientation = Legend.LegendOrientation.VERTICAL
                horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
                verticalAlignment = Legend.LegendVerticalAlignment.CENTER
                textColor = requireContext().getColor(com.investtrack.R.color.text_secondary)
            }
            animateY(800)
            invalidate()
        }
    }

    private fun setupAllocationTable(items: List<AllocationItem>) {
        val sb = StringBuilder()
        items.forEach { item ->
            val sign = if (item.pnl >= 0) "+" else ""
            sb.appendLine("${item.label}")
            sb.appendLine("  ${CurrencyFormatter.format(item.currentValue)}  $sign${String.format("%.1f", item.pnlPercent)}%")
            sb.appendLine()
        }
        binding.tvAllocationTable.text = sb.toString().trimEnd()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
