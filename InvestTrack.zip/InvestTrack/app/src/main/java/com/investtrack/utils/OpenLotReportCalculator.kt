package com.investtrack.utils

import com.investtrack.data.models.Account
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction

/**
 * One row of the "Open Lot Report": a single FIFO buy-lot that is still (partially) held,
 * with its cost basis, current market value, and returns.
 */
data class OpenLotRow(
    val accountId: Long,
    val accountName: String,
    val securityId: Long,
    val securityName: String,
    val securitySymbol: String,
    val buyDate: Long,
    val units: Double,
    val costNav: Double,
    val totalCost: Double,
    val marketNav: Double,
    val totalMarketValue: Double,
    val absoluteReturn: Double,
    val absoluteReturnPercent: Double,
    val xirrPercent: Double?,
    val percentOfTotalAssets: Double,
    val isPriceEstimated: Boolean
)

/** Subtotal row for all open lots of a single security. */
data class SecuritySubtotal(
    val securityId: Long,
    val securityName: String,
    val securitySymbol: String,
    val totalUnits: Double,
    val totalCost: Double,
    val totalMarketValue: Double,
    val absoluteReturn: Double,
    val absoluteReturnPercent: Double,
    val xirrPercent: Double?,
    val percentOfTotalAssets: Double
)

/** A security's lot rows plus its subtotal, in the order the report should render them. */
data class SecurityLotGroup(
    val subtotal: SecuritySubtotal,
    val lots: List<OpenLotRow>
)

data class OpenLotReport(
    val groups: List<SecurityLotGroup>,
    val grandTotalCost: Double,
    val grandTotalMarketValue: Double,
    val grandTotalAbsoluteReturn: Double,
    val grandTotalAbsoluteReturnPercent: Double
)

object OpenLotReportCalculator {

    /**
     * Builds the full open-lot report across all accounts/securities.
     *
     * @param transactionsBySecurityAccount all transactions, pre-grouped by (accountId, securityId)
     * @param securities lookup of securityId -> Security
     * @param accounts lookup of accountId -> Account
     * @param totalPortfolioValue current value of the whole portfolio, used for "% of total assets"
     */
    fun build(
        transactionsBySecurityAccount: Map<Pair<Long, Long>, List<Transaction>>,
        securities: Map<Long, Security>,
        accounts: Map<Long, Account>,
        totalPortfolioValue: Double
    ): OpenLotReport {
        // Group lots by security across all accounts (report is security-wise per the spec).
        val lotsBySecurity = mutableMapOf<Long, MutableList<OpenLotRow>>()

        for ((key, txns) in transactionsBySecurityAccount) {
            val (accountId, securityId) = key
            val security = securities[securityId] ?: continue
            val account = accounts[accountId] ?: continue
            val openLots = FIFOCalculator.getOpenLots(txns)
            if (openLots.isEmpty()) continue

            val priceUnavailable = security.currentPrice <= 0.0
            val marketNav = if (priceUnavailable) {
                // Fall back to a quantity-weighted average cost across this account's open lots.
                val totalQty = openLots.sumOf { it.quantity }
                if (totalQty > 0) openLots.sumOf { it.quantity * it.buyPrice } / totalQty else 0.0
            } else security.currentPrice

            for (lot in openLots) {
                if (lot.quantity <= 0.0001) continue
                val totalCost = lot.quantity * lot.buyPrice
                val totalMarketValue = lot.quantity * marketNav
                val absReturn = totalMarketValue - totalCost
                val absReturnPct = if (totalCost > 0) (absReturn / totalCost) * 100 else 0.0
                val xirr = try {
                    XIRRCalculator.calculate(
                        listOf(
                            XIRRCalculator.CashFlow(-totalCost, lot.buyDate),
                            XIRRCalculator.CashFlow(totalMarketValue, System.currentTimeMillis())
                        )
                    )
                } catch (e: Exception) { null }
                val pctOfAssets = if (totalPortfolioValue > 0) (totalMarketValue / totalPortfolioValue) * 100 else 0.0

                lotsBySecurity.getOrPut(securityId) { mutableListOf() }.add(
                    OpenLotRow(
                        accountId = accountId,
                        accountName = account.name,
                        securityId = securityId,
                        securityName = security.name,
                        securitySymbol = security.symbol,
                        buyDate = lot.buyDate,
                        units = lot.quantity,
                        costNav = lot.buyPrice,
                        totalCost = totalCost,
                        marketNav = marketNav,
                        totalMarketValue = totalMarketValue,
                        absoluteReturn = absReturn,
                        absoluteReturnPercent = absReturnPct,
                        xirrPercent = xirr,
                        percentOfTotalAssets = pctOfAssets,
                        isPriceEstimated = priceUnavailable
                    )
                )
            }
        }

        val groups = lotsBySecurity.values.map { lots ->
            val sortedLots = lots.sortedBy { it.buyDate }
            val totalCost = sortedLots.sumOf { it.totalCost }
            val totalMarketValue = sortedLots.sumOf { it.totalMarketValue }
            val totalUnits = sortedLots.sumOf { it.units }
            val absReturn = totalMarketValue - totalCost
            val absReturnPct = if (totalCost > 0) (absReturn / totalCost) * 100 else 0.0
            val pctOfAssets = if (totalPortfolioValue > 0) (totalMarketValue / totalPortfolioValue) * 100 else 0.0

            // Security-level XIRR from the combined cash flows of every open lot (buy dates)
            // plus one aggregate current-value inflow — gives a blended, date-weighted return.
            val cashFlows = sortedLots.map { XIRRCalculator.CashFlow(-it.totalCost, it.buyDate) } +
                    listOf(XIRRCalculator.CashFlow(totalMarketValue, System.currentTimeMillis()))
            val secXirr = try { XIRRCalculator.calculate(cashFlows) } catch (e: Exception) { null }

            val first = sortedLots.first()
            SecurityLotGroup(
                subtotal = SecuritySubtotal(
                    securityId = first.securityId,
                    securityName = first.securityName,
                    securitySymbol = first.securitySymbol,
                    totalUnits = totalUnits,
                    totalCost = totalCost,
                    totalMarketValue = totalMarketValue,
                    absoluteReturn = absReturn,
                    absoluteReturnPercent = absReturnPct,
                    xirrPercent = secXirr,
                    percentOfTotalAssets = pctOfAssets
                ),
                lots = sortedLots
            )
        }.sortedByDescending { it.subtotal.totalMarketValue }

        val grandTotalCost = groups.sumOf { it.subtotal.totalCost }
        val grandTotalMarketValue = groups.sumOf { it.subtotal.totalMarketValue }
        val grandTotalAbsReturn = grandTotalMarketValue - grandTotalCost
        val grandTotalAbsReturnPct = if (grandTotalCost > 0) (grandTotalAbsReturn / grandTotalCost) * 100 else 0.0

        return OpenLotReport(
            groups = groups,
            grandTotalCost = grandTotalCost,
            grandTotalMarketValue = grandTotalMarketValue,
            grandTotalAbsoluteReturn = grandTotalAbsReturn,
            grandTotalAbsoluteReturnPercent = grandTotalAbsReturnPct
        )
    }
}
