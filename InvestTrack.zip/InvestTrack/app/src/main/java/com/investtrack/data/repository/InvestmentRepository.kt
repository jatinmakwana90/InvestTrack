package com.investtrack.data.repository

import com.investtrack.data.dao.*
import com.investtrack.data.models.*
import com.investtrack.utils.SecurityCodeGenerator
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InvestmentRepository @Inject constructor(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val profileDao: ProfileDao,
    private val syncConfigDao: SyncConfigDao
) {
    // Profiles
    fun getAllProfiles(): Flow<List<Profile>> = profileDao.getAllProfiles()
    suspend fun getProfileById(id: Long): Profile? = profileDao.getProfileById(id)
    suspend fun insertProfile(profile: Profile): Long = profileDao.insertProfile(profile)
    suspend fun updateProfile(profile: Profile) = profileDao.updateProfile(profile)
    suspend fun deactivateProfile(id: Long) = profileDao.deactivateProfile(id)

    // Accounts
    fun getAllAccounts(): Flow<List<Account>> = accountDao.getAllAccounts()
    fun getAccountsByProfile(profileId: Long): Flow<List<Account>> = accountDao.getAccountsByProfile(profileId)
    suspend fun getAccountById(id: Long): Account? = accountDao.getAccountById(id)
    suspend fun insertAccount(account: Account): Long = accountDao.insertAccount(account)
    suspend fun updateAccount(account: Account) = accountDao.updateAccount(account)
    suspend fun deactivateAccount(id: Long) = accountDao.deactivateAccount(id)

    // Securities
    fun getAllSecurities(): Flow<List<Security>> = securityDao.getAllSecurities()
    fun getSecuritiesByType(type: SecurityType): Flow<List<Security>> = securityDao.getSecuritiesByType(type)
    suspend fun getSecurityById(id: Long): Security? = securityDao.getSecurityById(id)
    suspend fun searchSecurities(query: String): List<Security> = securityDao.searchSecurities(query)
    suspend fun updateSecurity(security: Security) = securityDao.updateSecurity(security)
    suspend fun updatePrice(id: Long, price: Double, prevPrice: Double = 0.0) = securityDao.updatePrice(id, price, prevPrice)
    suspend fun deactivateSecurity(id: Long) = securityDao.deactivateSecurity(id)
    suspend fun getAllSecuritiesList(): List<Security> = securityDao.getAllSecuritiesList()
    suspend fun getSecuritiesWithYahooCode(): List<Security> = securityDao.getSecuritiesWithYahooCode()

    suspend fun insertSecurity(security: Security): Long {
        // Auto-generate unique security code if not provided
        val code = if (security.securityCode.isBlank()) {
            var generated: String
            do {
                generated = SecurityCodeGenerator.generateForType(security.type.name)
            } while (securityDao.countByCode(generated) > 0)
            generated
        } else security.securityCode
        return securityDao.insertSecurity(security.copy(securityCode = code))
    }

    // Transactions
    fun getAllTransactions(): Flow<List<Transaction>> = transactionDao.getAllTransactions()
    fun getTransactionsByAccount(accountId: Long): Flow<List<Transaction>> = transactionDao.getTransactionsByAccount(accountId)
    fun getTransactionsByFolio(accountId: Long, securityId: Long): Flow<List<Transaction>> = transactionDao.getTransactionsByFolio(accountId, securityId)
    suspend fun insertTransaction(transaction: Transaction): Long = transactionDao.insertTransaction(transaction)
    suspend fun updateTransaction(transaction: Transaction) = transactionDao.updateTransaction(transaction)
    suspend fun deleteTransaction(transaction: Transaction) = transactionDao.deleteTransaction(transaction)
    suspend fun getAllTransactionsList(): List<Transaction> = transactionDao.getAllTransactionsList()
    suspend fun insertTransactions(transactions: List<Transaction>) = transactionDao.insertTransactions(transactions)

    // Sync Config
    fun getSyncConfig(): Flow<SyncConfig?> = syncConfigDao.getSyncConfig()
    suspend fun getSyncConfigOnce(): SyncConfig? = syncConfigDao.getSyncConfigOnce()
    suspend fun upsertSyncConfig(config: SyncConfig) = syncConfigDao.upsertSyncConfig(config)
    suspend fun updateLastSyncTime(time: Long) = syncConfigDao.updateLastSyncTime(time)

    // Folio building
    suspend fun getFoliosForAccount(accountId: Long): List<Folio> {
        val rawFolios = transactionDao.getActiveFoliosByAccount(accountId)
        return buildFolios(rawFolios)
    }

    suspend fun getAllFolios(): List<Folio> {
        val rawFolios = transactionDao.getAllActiveFolios()
        return buildFolios(rawFolios)
    }

    suspend fun getFoliosForProfile(profileId: Long): List<Folio> {
        val accounts = accountDao.getAccountsByProfileList(profileId)
        val result = mutableListOf<Folio>()
        for (account in accounts) {
            result.addAll(getFoliosForAccount(account.id))
        }
        return result
    }

    private suspend fun buildFolios(rawFolios: List<FolioRaw>): List<Folio> {
        val result = mutableListOf<Folio>()
        for (raw in rawFolios) {
            val account = accountDao.getAccountById(raw.accountId) ?: continue
            val security = securityDao.getSecurityById(raw.securityId) ?: continue
            val profile = profileDao.getProfileById(account.profileId)
            val netInvested = transactionDao.getNetInvestment(raw.accountId, raw.securityId)
            val netQty = raw.netQty
            val currentPrice = security.currentPrice
            val currentValue = netQty * currentPrice
            val pnl = currentValue - netInvested
            val pnlPercent = if (netInvested > 0) (pnl / netInvested) * 100 else 0.0
            val avgCost = if (netQty > 0) netInvested / netQty else 0.0
            val folioNums = transactionDao.getFolioNumbers(raw.accountId, raw.securityId)
            result.add(Folio(
                accountId = raw.accountId,
                accountName = account.name,
                profileId = account.profileId,
                profileName = profile?.name ?: "",
                securityId = raw.securityId,
                securityName = security.name,
                securitySymbol = security.symbol,
                securityCode = security.securityCode,
                securityType = security.type,
                folioNumber = folioNums.joinToString(", "),
                totalUnits = netQty,
                avgCostPrice = avgCost,
                totalInvested = netInvested,
                currentValue = currentValue,
                currentPrice = currentPrice,
                pnl = pnl,
                pnlPercent = pnlPercent
            ))
        }
        return result
    }

    suspend fun getPortfolioSummary(): PortfolioSummary {
        val folios = getAllFolios()
        return summarize(folios, accountDao.getAccountCount())
    }

    suspend fun getProfileSummary(profileId: Long): PortfolioSummary {
        val folios = getFoliosForProfile(profileId)
        return summarize(folios, 1)
    }

    suspend fun getAccountPortfolioSummary(accountId: Long): PortfolioSummary {
        val folios = getFoliosForAccount(accountId)
        return summarize(folios, 1)
    }

    suspend fun getAllProfileSummaries(): List<ProfileSummary> {
        val profiles = profileDao.getAllProfilesList()
        return profiles.map { profile ->
            val folios = getFoliosForProfile(profile.id)
            val summary = summarize(folios, 1)
            ProfileSummary(profile = profile, summary = summary, topHoldings = folios.sortedByDescending { it.currentValue }.take(3))
        }
    }

    private fun summarize(folios: List<Folio>, accountCount: Int): PortfolioSummary {
        val totalInvested = folios.sumOf { it.totalInvested }
        val currentValue = folios.sumOf { it.currentValue }
        val pnl = currentValue - totalInvested
        val pnlPercent = if (totalInvested > 0) (pnl / totalInvested) * 100 else 0.0
        return PortfolioSummary(
            totalInvested = totalInvested,
            currentValue = currentValue,
            totalPnL = pnl,
            totalPnLPercent = pnlPercent,
            dayChange = 0.0,
            dayChangePercent = 0.0,
            folioCount = folios.size,
            accountCount = accountCount
        )
    }
}
