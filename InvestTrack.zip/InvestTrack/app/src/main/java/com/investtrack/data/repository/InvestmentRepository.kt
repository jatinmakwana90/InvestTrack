package com.investtrack.data.repository

import com.investtrack.data.dao.*
import com.investtrack.data.models.*
import com.investtrack.utils.SecurityCodeGenerator
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class InvestmentRepository @Inject constructor(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) {
    fun getAllAccounts(): Flow<List<Account>> = accountDao.getAllAccounts()
    suspend fun getAccountById(id: Long): Account? = accountDao.getAccountById(id)
    suspend fun insertAccount(account: Account): Long {
        val code = if (account.accountCode.isBlank()) {
            val count = accountDao.getTotalCount()
            CodeGenerator.generateAccountCode(count)
        } else account.accountCode
        return accountDao.insertAccount(account.copy(accountCode = code))
    }
    suspend fun updateAccount(account: Account) = accountDao.updateAccount(account)
    suspend fun deactivateAccount(id: Long) = accountDao.deactivateAccount(id)

    fun getAllSecurities(): Flow<List<Security>> = securityDao.getAllSecurities()
    fun getSecuritiesByType(type: SecurityType): Flow<List<Security>> = securityDao.getSecuritiesByType(type)
    suspend fun getSecurityById(id: Long): Security? = securityDao.getSecurityById(id)
    suspend fun searchSecurities(query: String): List<Security> = securityDao.searchSecurities(query)
    suspend fun updateSecurity(security: Security) = securityDao.updateSecurity(security)
    suspend fun updatePrice(id: Long, price: Double, prevPrice: Double = 0.0) = securityDao.updatePrice(id, price, prevPrice)
    suspend fun deactivateSecurity(id: Long) = securityDao.deactivateSecurity(id)
    suspend fun getAllSecuritiesList(): List<Security> = securityDao.getAllSecuritiesList()
    suspend fun getSecuritiesWithYahooCode(): List<Security> = securityDao.getSecuritiesWithYahooCode()

    suspend fun insertSecurity(security: Security): Long {
        val code = if (security.securityCode.isBlank()) {
            val count = securityDao.getTotalCount()
            val prefix = CodeGenerator.securityTypePrefix(security.type.name)
            "${prefix}${String.format("%04d", count + 1)}"
        } else security.securityCode
        return securityDao.insertSecurity(security.copy(securityCode = code))
    }

    fun getAllTransactions(): Flow<List<Transaction>> = transactionDao.getAllTransactions()
    fun getTransactionsByAccount(accountId: Long): Flow<List<Transaction>> = transactionDao.getTransactionsByAccount(accountId)
    suspend fun getTransactionsByAccountList(accountId: Long): List<Transaction> = transactionDao.getTransactionsByAccountList(accountId)
    suspend fun getAllTransactionsList(): List<Transaction> = transactionDao.getAllTransactionsList()
    suspend fun getTransactionById(id: Long): Transaction? = transactionDao.getTransactionById(id)
    fun getTransactionsByFolio(accountId: Long, securityId: Long): Flow<List<Transaction>> = transactionDao.getTransactionsByFolio(accountId, securityId)
    suspend fun insertTransaction(transaction: Transaction): Long {
        val code = if (transaction.transactionCode.isBlank()) {
            val count = transactionDao.getTotalCount()
            CodeGenerator.generateTransactionCode(count)
        } else transaction.transactionCode
        return transactionDao.insertTransaction(transaction.copy(transactionCode = code))
    }
    suspend fun updateTransaction(transaction: Transaction) = transactionDao.updateTransaction(transaction)
    suspend fun deleteTransaction(transaction: Transaction) = transactionDao.deleteTransaction(transaction)

    suspend fun getFoliosForAccount(accountId: Long): List<Folio> {
        val rawFolios = transactionDao.getActiveFoliosByAccount(accountId)
        return buildFolios(rawFolios)
    }

    suspend fun getAllFolios(): List<Folio> {
        val rawFolios = transactionDao.getAllActiveFolios()
        return buildFolios(rawFolios)
    }

    private suspend fun buildFolios(rawFolios: List<FolioRaw>): List<Folio> {
        val result = mutableListOf<Folio>()
        for (raw in rawFolios) {
            val account = accountDao.getAccountById(raw.accountId) ?: continue
            val security = securityDao.getSecurityById(raw.securityId) ?: continue
            val netInvested = transactionDao.getNetInvestment(raw.accountId, raw.securityId)
            val netQty = raw.netQty
            val avgCost = if (netQty > 0) netInvested / netQty else 0.0

            // If no live price is available (price unavailable / never synced), fall back to
            // cost basis so the displayed current value matches invested amount instead of showing ₹0.
            val priceUnavailable = security.currentPrice <= 0.0
            val effectivePrice = if (priceUnavailable) avgCost else security.currentPrice

            val currentValue = netQty * effectivePrice
            val pnl = currentValue - netInvested
            val pnlPercent = if (netInvested > 0) (pnl / netInvested) * 100 else 0.0
            val folioNums = transactionDao.getFolioNumbers(raw.accountId, raw.securityId)
            result.add(Folio(
                accountId = raw.accountId, accountName = account.name,
                profileId = 0, profileName = "",
                securityId = raw.securityId, securityName = security.name,
                securitySymbol = security.symbol, securityCode = security.securityCode,
                securityType = security.type, folioNumber = folioNums.joinToString(", "),
                totalUnits = netQty, avgCostPrice = avgCost, totalInvested = netInvested,
                currentValue = currentValue, currentPrice = effectivePrice, pnl = pnl, pnlPercent = pnlPercent,
                isPriceEstimated = priceUnavailable
            ))
        }
        return result
    }

    suspend fun getPortfolioSummary(): PortfolioSummary {
        val folios = getAllFolios()
        return summarize(folios, accountDao.getAccountCount())
    }

    suspend fun getAccountPortfolioSummary(accountId: Long): PortfolioSummary {
        val folios = getFoliosForAccount(accountId)
        return summarize(folios, 1)
    }

    private fun summarize(folios: List<Folio>, accountCount: Int): PortfolioSummary {
        val totalInvested = folios.sumOf { it.totalInvested }
        val currentValue = folios.sumOf { it.currentValue }
        val pnl = currentValue - totalInvested
        val pnlPercent = if (totalInvested > 0) (pnl / totalInvested) * 100 else 0.0
        return PortfolioSummary(
            totalInvested = totalInvested, currentValue = currentValue,
            totalPnL = pnl, totalPnLPercent = pnlPercent,
            dayChange = 0.0, dayChangePercent = 0.0,
            folioCount = folios.size, accountCount = accountCount
        )
    }
}
