package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.backup.DriveBackupManager
import com.investtrack.backup.FullBackupBuilder
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.dao.DriveBackupConfigDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.settings.SettingsManager
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class DailyDriveBackupWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val reminderDao: ReminderDao,
    private val autoSyncConfigDao: AutoSyncConfigDao,
    private val settingsManager: SettingsManager,
    private val driveBackupConfigDao: DriveBackupConfigDao,
    private val incomeExpenseDao: IncomeExpenseDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        NotificationHelper.createChannels(applicationContext)
        val config = driveBackupConfigDao.getConfigOnce()
        if (config == null || !config.isEnabled) return@withContext Result.success()

        val account = DriveBackupManager.getSignedInAccount(applicationContext)
        if (account == null) {
            driveBackupConfigDao.upsert(
                config.copy(lastBackupStatus = "✗ Not signed in to Google", lastBackupAt = System.currentTimeMillis())
            )
            return@withContext Result.failure()
        }

        return@withContext try {
            val builder = FullBackupBuilder(
                accountDao, securityDao, transactionDao, loanDao,
                loanAdjustmentDao, reminderDao, autoSyncConfigDao, settingsManager,
                incomeExpenseDao
            )
            val data = builder.build()
            val jsonContent = builder.toJson(data)

            val manager = DriveBackupManager(applicationContext)
            val (folderId, fileId) = manager.uploadOrUpdateBackup(
                account, jsonContent, config.driveFolderId, config.driveFileId
            )

            val timeFmt = SimpleDateFormat("dd MMM, h:mm a", Locale.getDefault())
            driveBackupConfigDao.upsert(
                config.copy(
                    driveFolderId = folderId,
                    driveFileId = fileId,
                    lastBackupAt = System.currentTimeMillis(),
                    lastBackupStatus = "✓ Backed up ${timeFmt.format(Date())}"
                )
            )
            NotificationHelper.showBackupNotification(
                applicationContext, success = true, message = "InvestTrack backup saved to Google Drive"
            )
            Result.success()
        } catch (e: Exception) {
            driveBackupConfigDao.upsert(
                config.copy(
                    lastBackupStatus = "✗ Backup failed: ${e.message}",
                    lastBackupAt = System.currentTimeMillis()
                )
            )
            val attempt = runAttemptCount
            if (attempt >= 3) {
                NotificationHelper.showBackupNotification(
                    applicationContext, success = false,
                    message = "Could not back up to Drive: ${e.message ?: "unknown error"}"
                )
                Result.failure()
            } else {
                Result.retry()
            }
        }
    }

    companion object {
        const val WORK_NAME = "daily_drive_backup"

        fun schedule(context: Context, hour: Int, minute: Int) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            val initialDelay = target.timeInMillis - now.timeInMillis

            val request = PeriodicWorkRequestBuilder<DailyDriveBackupWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.REPLACE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
