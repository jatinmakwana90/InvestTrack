package com.investtrack.ui.accounts

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentFolioTransactionsBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.transactions.EditTransactionFragment
import com.investtrack.ui.transactions.TransactionFullAdapter
import com.investtrack.ui.transactions.TransactionDisplayItem
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class FolioTransactionsViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val accountId: Long = savedStateHandle.get<Long>("accountId") ?: 0L
    val securityId: Long = savedStateHandle.get<Long>("securityId") ?: 0L
    val folioNumber: String = savedStateHandle.get<String>("folioNumber") ?: ""

    private val _transactions = MutableStateFlow<List<TransactionDisplayItem>>(emptyList())
    val transactions: StateFlow<List<TransactionDisplayItem>> = _transactions

    init {
        viewModelScope.launch {
            repository.getTransactionsByFolio(accountId, securityId).collect { txns ->
                val filtered = txns.filter {
                    folioNumber == "No Folio" && it.folioNumber.isBlank() ||
                    it.folioNumber == folioNumber
                }
                val security = repository.getSecurityById(securityId)
                _transactions.value = filtered.map { TransactionDisplayItem(it, security) }
            }
        }
    }

    fun delete(transaction: Transaction) {
        viewModelScope.launch { repository.deleteTransaction(transaction) }
    }
}

@AndroidEntryPoint
class FolioTransactionsFragment : Fragment() {

    private var _binding: FragmentFolioTransactionsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FolioTransactionsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFolioTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val secName = arguments?.getString("securityName") ?: "Transactions"
        val folio = viewModel.folioNumber
        binding.toolbar.title = secName
        binding.toolbar.subtitle = if (folio == "No Folio") "No Folio" else "Folio: $folio"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = TransactionFullAdapter(
            onEdit = { item ->
                (activity as? MainActivity)?.navigateTo(EditTransactionFragment.newInstance(item.transaction.id))
            },
            onDelete = { item ->
                android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Transaction")
                    .setMessage("Delete this ${item.transaction.type.displayName} transaction?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(item.transaction) }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvTransactions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.transactions.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(accountId: Long, securityId: Long, folioNumber: String, securityName: String) =
            FolioTransactionsFragment().apply {
                arguments = Bundle().apply {
                    putLong("accountId", accountId)
                    putLong("securityId", securityId)
                    putString("folioNumber", folioNumber)
                    putString("securityName", securityName)
                }
            }
    }
}
