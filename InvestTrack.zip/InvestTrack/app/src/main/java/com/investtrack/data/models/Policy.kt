package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** An insurance policy with its cover amount and premium schedule. */
@Serializable
@Entity(tableName = "policies")
data class Policy(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val insurer: String,
    /** LIFE, TERM, HEALTH, VEHICLE, HOME or OTHER */
    val type: String,
    val policyNumber: String,
    val coverAmount: Double,
    val premiumAmount: Double,
    /** MONTHLY, QUARTERLY, HALF_YEARLY or YEARLY */
    val frequency: String,
    val nextDueDate: Long,
    /** Policy end / maturity date. 0 = none. */
    val endDate: Long,
    val notes: String,
    val isActive: Boolean,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun monthsPerPeriod(): Int = when (frequency) {
        "MONTHLY" -> 1; "QUARTERLY" -> 3; "HALF_YEARLY" -> 6; else -> 12
    }
    fun yearlyPremium(): Double = premiumAmount * (12.0 / monthsPerPeriod())
}
