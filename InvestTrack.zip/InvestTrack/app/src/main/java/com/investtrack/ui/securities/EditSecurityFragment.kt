package com.investtrack.ui.securities

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Security
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddSecurityBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditSecurityViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val securityId: Long = savedStateHandle.get<Long>("securityId") ?: 0L
    private val _security = MutableStateFlow<Security?>(null)
    val security: StateFlow<Security?> = _security
    private val _done = MutableStateFlow(false)
    val done: StateFlow<Boolean> = _done

    init { viewModelScope.launch { _security.value = repository.getSecurityById(securityId) } }

    fun save(security: Security) {
        viewModelScope.launch {
            repository.updateSecurity(security)
            _done.value = true
        }
    }

    fun delete() {
        viewModelScope.launch {
            repository.deactivateSecurity(securityId)
            _done.value = true
        }
    }
}

@AndroidEntryPoint
class EditSecurityFragment : Fragment() {
    private var _binding: FragmentAddSecurityBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EditSecurityViewModel by viewModels()
    private var selectedType = SecurityType.EQUITY

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddSecurityBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = "Edit Security"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.tilCurrentPrice.visibility = View.GONE

        // Show delete button
        binding.btnDelete.visibility = View.VISIBLE
        binding.btnDelete.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Delete Security")
                .setMessage("Delete this security? Related transactions will be affected.")
                .setPositiveButton("Delete") { _, _ -> viewModel.delete() }
                .setNegativeButton("Cancel", null).show()
        }

        val types = SecurityType.values().map { it.displayName }
        binding.actvSecurityType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types))
        binding.actvSecurityType.setOnItemClickListener { _, _, pos, _ ->
            selectedType = SecurityType.values()[pos]
            updateFieldVisibility()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.done.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.security.collect { sec ->
                sec ?: return@collect
                selectedType = sec.type
                binding.etName.setText(sec.name)
                binding.etSymbol.setText(sec.symbol)
                binding.etIsin.setText(sec.isin)
                binding.etYahooCode.setText(sec.yahooFinanceCode)
                binding.etExchange.setText(sec.exchange)
                binding.etSector.setText(sec.sector)
                binding.etAmc.setText(sec.amc)
                binding.etCategory.setText(sec.category)
                binding.etInterestRate.setText(sec.interestRate?.toString() ?: "")
                binding.actvSecurityType.setText(sec.type.displayName, false)
                updateFieldVisibility()
            }
        }

        binding.btnSave.setOnClickListener {
            val name = binding.etName.text.toString().trim()
            if (name.isEmpty()) { binding.tilName.error = "Name required"; return@setOnClickListener }
            val original = viewModel.security.value ?: return@setOnClickListener
            binding.btnSave.isEnabled = false
            binding.btnSave.text = "Saving..."
            viewModel.save(original.copy(
                name = name,
                symbol = binding.etSymbol.text.toString().trim(),
                type = selectedType,
                isin = binding.etIsin.text.toString().trim(),
                yahooFinanceCode = binding.etYahooCode.text.toString().trim(),
                exchange = binding.etExchange.text.toString().trim(),
                sector = binding.etSector.text.toString().trim(),
                amc = binding.etAmc.text.toString().trim(),
                category = binding.etCategory.text.toString().trim(),
                interestRate = binding.etInterestRate.text.toString().toDoubleOrNull()
            ))
        }
        updateFieldVisibility()
    }

    private fun updateFieldVisibility() {
        val isFD = selectedType == SecurityType.FIXED_DEPOSIT || selectedType == SecurityType.BOND
        val isMF = selectedType == SecurityType.EQUITY_MF || selectedType == SecurityType.DEBT_MF
        val isEquity = selectedType == SecurityType.EQUITY || selectedType == SecurityType.ETF
        binding.tilInterestRate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilMaturityDate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilAmc.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilCategory.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilExchange.visibility = if (isEquity || isMF) View.VISIBLE else View.GONE
        binding.tilCurrentPrice.visibility = View.GONE
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(securityId: Long) = EditSecurityFragment().apply {
            arguments = Bundle().apply { putLong("securityId", securityId) }
        }
    }
}
