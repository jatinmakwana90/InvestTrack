package com.investtrack.ui.securities

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.investtrack.data.models.Security
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddSecurityBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditSecurityViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val securityId: Long = savedStateHandle.get<Long>("securityId") ?: 0L
    private val _security = MutableStateFlow<Security?>(null)
    val security: StateFlow<Security?> = _security

    init {
        viewModelScope.launch {
            _security.value = repository.getSecurityById(securityId)
        }
    }

    fun save(security: Security) {
        viewModelScope.launch { repository.updateSecurity(security) }
    }
}

@AndroidEntryPoint
class EditSecurityFragment : Fragment() {

    private var _binding: FragmentAddSecurityBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EditSecurityViewModel by viewModels()
    private var selectedType = SecurityType.EQUITY
    private var originalSecurity: Security? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddSecurityBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = "Edit Security"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.btnSave.text = "Save Changes"

        val types = SecurityType.values().map { it.displayName }
        binding.actvSecurityType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types))
        binding.actvSecurityType.setOnItemClickListener { _, _, position, _ ->
            selectedType = SecurityType.values()[position]
            updateFieldVisibility()
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.security.collect { sec ->
                sec ?: return@collect
                originalSecurity = sec
                selectedType = sec.type

                // Populate all fields
                binding.actvSecurityType.setText(sec.type.displayName, false)
                binding.etName.setText(sec.name)
                binding.etSymbol.setText(sec.symbol)
                binding.etIsin.setText(sec.isin)
                binding.etYahooCode.setText(sec.yahooFinanceCode)
                binding.etExchange.setText(sec.exchange)
                binding.etCurrentPrice.setText(sec.currentPrice.toString())
                binding.etInterestRate.setText(sec.interestRate?.toString() ?: "")
                binding.etAmc.setText(sec.amc)
                binding.etCategory.setText(sec.category)
                binding.etSector.setText(sec.sector)
                updateFieldVisibility()
            }
        }

        binding.btnSave.setOnClickListener { save() }
    }

    private fun updateFieldVisibility() {
        val isFD = selectedType == SecurityType.FIXED_DEPOSIT || selectedType == SecurityType.BOND
        val isMF = selectedType == SecurityType.EQUITY_MF || selectedType == SecurityType.DEBT_MF
        val isEquity = selectedType == SecurityType.EQUITY || selectedType == SecurityType.ETF
        binding.tilInterestRate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilMaturityDate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilAmc.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilCategory.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilExchange.visibility = if (isEquity || isMF) View.VISIBLE else View.GONE
    }

    private fun save() {
        val orig = originalSecurity ?: return
        val name = binding.etName.text.toString().trim()
        if (name.isEmpty()) { binding.tilName.error = "Name required"; return }
        val updated = orig.copy(
            name = name,
            symbol = binding.etSymbol.text.toString().trim(),
            type = selectedType,
            isin = binding.etIsin.text.toString().trim(),
            yahooFinanceCode = binding.etYahooCode.text.toString().trim(),
            exchange = binding.etExchange.text.toString().trim(),
            currentPrice = binding.etCurrentPrice.text.toString().toDoubleOrNull() ?: orig.currentPrice,
            interestRate = binding.etInterestRate.text.toString().toDoubleOrNull(),
            amc = binding.etAmc.text.toString().trim(),
            category = binding.etCategory.text.toString().trim(),
            sector = binding.etSector.text.toString().trim(),
            lastUpdated = System.currentTimeMillis()
        )
        viewModel.save(updated)
        activity?.onBackPressedDispatcher?.onBackPressed()
    }


    companion object {
        fun newInstance(securityId: Long) = EditSecurityFragment().apply {
            arguments = android.os.Bundle().apply { putLong("securityId", securityId) }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
