package com.investtrack.ui.reports

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.databinding.ItemCashflowMonthBinding
import com.investtrack.databinding.ItemCashflowYearBinding
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.MonthlyCashFlow
import com.investtrack.utils.YearlyCashFlow

private const val TYPE_YEAR = 0
private const val TYPE_MONTH = 1

private sealed class CashFlowListItem {
    data class YearItem(val year: YearlyCashFlow, val expanded: Boolean) : CashFlowListItem()
    data class MonthItem(val month: MonthlyCashFlow) : CashFlowListItem()
}

class CashFlowYearAdapter(
    private val onYearClick: (Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var items: List<CashFlowListItem> = emptyList()

    fun submit(years: List<YearlyCashFlow>, expandedYears: Set<Int>) {
        val flat = mutableListOf<CashFlowListItem>()
        for (year in years) {
            val expanded = year.year in expandedYears
            flat.add(CashFlowListItem.YearItem(year, expanded))
            if (expanded) {
                year.months.forEach { flat.add(CashFlowListItem.MonthItem(it)) }
            }
        }
        items = flat
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int) = when (items[position]) {
        is CashFlowListItem.YearItem -> TYPE_YEAR
        is CashFlowListItem.MonthItem -> TYPE_MONTH
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_YEAR) YearVH(ItemCashflowYearBinding.inflate(inflater, parent, false))
               else MonthVH(ItemCashflowMonthBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is CashFlowListItem.YearItem -> (holder as YearVH).bind(item.year, item.expanded)
            is CashFlowListItem.MonthItem -> (holder as MonthVH).bind(item.month)
        }
    }

    inner class YearVH(private val b: ItemCashflowYearBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(year: YearlyCashFlow, expanded: Boolean) {
            val ctx = b.root.context
            b.tvYearLabel.text = year.year.toString()
            b.tvInvested.text = CurrencyFormatter.formatFullNoDecimals(year.invested)
            b.tvWithdrawal.text = CurrencyFormatter.formatFullNoDecimals(year.withdrawal)
            val net = year.net
            b.tvNet.text = (if (net >= 0) "+" else "") + CurrencyFormatter.formatFullNoDecimals(net)
            b.tvNet.setTextColor(ctx.getColor(if (net >= 0) R.color.gain_green else R.color.loss_red))
            b.ivExpandArrow.rotation = if (expanded) 180f else 0f
            b.root.setOnClickListener { onYearClick(year.year) }
        }
    }

    inner class MonthVH(private val b: ItemCashflowMonthBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(month: MonthlyCashFlow) {
            val ctx = b.root.context
            b.tvMonthLabel.text = month.monthLabel
            b.tvInvested.text = CurrencyFormatter.formatFullNoDecimals(month.invested)
            b.tvWithdrawal.text = CurrencyFormatter.formatFullNoDecimals(month.withdrawal)
            val net = month.net
            b.tvNet.text = (if (net >= 0) "+" else "") + CurrencyFormatter.formatFullNoDecimals(net)
            b.tvNet.setTextColor(ctx.getColor(if (net >= 0) R.color.gain_green else R.color.loss_red))
        }
    }
}
