package com.investtrack.utils

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtil {
    fun startOfDay(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    /** Whole days from today to [ms]; negative when the date has passed. */
    fun daysUntil(ms: Long, now: Long = System.currentTimeMillis()): Int =
        Math.round((startOfDay(ms) - startOfDay(now)) / 86_400_000.0).toInt()

    /** Adds months but keeps the day of month where possible (31 Jan + 1 month = 28/29 Feb). */
    fun addMonthsClamped(from: Long, months: Int): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = from }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, months)
        cal.set(Calendar.DAY_OF_MONTH, minOf(day, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
        return cal.timeInMillis
    }

    fun format(ms: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(ms))

    fun duesLabel(days: Int): String = when {
        days < 0 -> "${-days} day${if (days != -1) "s" else ""} ago"
        days == 0 -> "today"
        days == 1 -> "tomorrow"
        else -> "in $days days"
    }
}
