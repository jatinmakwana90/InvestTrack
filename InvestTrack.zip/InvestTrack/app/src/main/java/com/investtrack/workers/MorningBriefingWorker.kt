package com.investtrack.workers

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.WorkerParameters
import com.investtrack.data.dao.LendingDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.PolicyDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.data.settings.AutomationSettings
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.utils.NotificationHelper
import com.investtrack.utils.ReminderSchedule
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/** One notification each morning: how the portfolio moved, what is due today and what matures soon. */
@HiltWorker
class MorningBriefingWorker @AssistedInject constructor(
    @Assisted private val appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: InvestmentRepository,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val policyDao: PolicyDao,
    private val reminderDao: ReminderDao,
    private val lendingDao: LendingDao,
    private val automation: AutomationSettings
) : CoroutineWorker(appContext, params) {

    private fun money(v: Double) = CurrencyFormatter.formatFullNoDecimals(v)

    override suspend fun doWork(): Result {
        if (!automation.briefingEnabled) return Result.success()
        try {
            NotificationHelper.createChannels(appContext)
            val summary = repository.getPortfolioSummary()
            val change = summary.dayChange
            val arrow = if (change >= 0) "▲ +" else "▼ -"
            val title = "Good morning · ${CurrencyFormatter.format(summary.currentValue)}"

            val lines = mutableListOf<String>()
            lines += "Portfolio $arrow${money(Math.abs(change))} (${String.format("%.2f", Math.abs(summary.dayChangePercent))}%) since yesterday"

            // ---- due today
            val due = mutableListOf<String>()
            loanDao.getAllLoansList().filter { it.isActive }.forEach { loan ->
                val sch = LoanAmortizationCalculator.buildSchedule(loan, loanAdjustmentDao.getAdjustmentsForLoanList(loan.id))
                if (sch.currentOutstanding > 0.5 && sch.remainingInstallments > 0 && ReminderSchedule.daysUntilDue(loan.emiDay) == 0)
                    due += "EMI: ${loan.loanName} ${money(sch.currentEmi)}"
            }
            reminderDao.getAllRemindersList()
                .filter { it.isActive && it.linkedLoanId == null && ReminderSchedule.daysUntilDue(it.dueDayOfMonth) == 0 }
                .forEach { due += "${it.type.displayName}: ${it.title}${if (it.amount > 0) " " + money(it.amount) else ""}" }
            policyDao.getAllList().filter { it.isActive && DateUtil.daysUntil(it.nextDueDate) == 0 }
                .forEach { due += "Premium: ${it.name} ${money(it.premiumAmount)}" }
            val payments = lendingDao.getPaymentsList()
            lendingDao.getEntriesList().filter { !it.isSettled && it.dueDate > 0 && DateUtil.daysUntil(it.dueDate) == 0 }.forEach { e ->
                val pending = e.amount - payments.filter { it.lendingId == e.id }.sumOf { it.amount }
                if (pending > 0.5) due += (if (e.direction == "LENT") "${e.personName} to pay you " else "You owe ${e.personName} ") + money(pending)
            }
            if (due.isEmpty()) lines += "Nothing due today ✓"
            else { lines += "Due today:"; lines += due.map { "• $it" } }

            // ---- maturing within a week (FDs and bonds)
            try {
                val secs = repository.getAllSecuritiesList().associateBy { it.id }
                val soon = repository.getAllFolios()
                    .filter { it.securityType == SecurityType.FIXED_DEPOSIT || it.securityType == SecurityType.BOND }
                    .groupBy { it.securityId }
                    .mapNotNull { (id, folios) ->
                        val m = secs[id]?.maturityDate ?: return@mapNotNull null
                        val days = DateUtil.daysUntil(m)
                        if (days in 0..7) "• ${secs[id]!!.name} ${DateUtil.duesLabel(days)} (${money(folios.sumOf { it.currentValue })})" else null
                    }
                if (soon.isNotEmpty()) { lines += "Maturing soon:"; lines += soon }
            } catch (e: Exception) { }

            val pi = PendingIntent.getActivity(
                appContext, 7103, Intent(appContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationHelper.showActionNotification(appContext, 7103, title, lines.joinToString("\n"), pi)
        } catch (e: Exception) {
            // still schedule tomorrow's briefing
        }
        AutomationScheduler.scheduleBriefing(appContext, automation, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return Result.success()
    }
}
