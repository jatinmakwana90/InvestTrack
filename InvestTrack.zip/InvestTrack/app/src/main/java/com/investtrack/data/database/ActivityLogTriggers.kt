package com.investtrack.data.database

import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Records every add / edit / delete in the activity log with database triggers, so it works no matter
 * which screen made the change. Price updates and automatic EMI ticks are left out on purpose.
 * The triggers are (re)created every time the database opens, and only the latest 1000 entries are kept.
 */
object ActivityLogTriggers : RoomDatabase.Callback() {

    private fun insert(action: String, entity: String, description: String) =
        "BEGIN INSERT INTO activity_log(timestamp, action, entity, description) VALUES " +
            "(CAST(strftime('%s','now') AS INTEGER) * 1000, '$action', '$entity', $description); END"

    private fun trigger(name: String, event: String, table: String, whenClause: String?, body: String) =
        "CREATE TRIGGER IF NOT EXISTS $name AFTER $event ON $table " +
            (if (whenClause != null) "WHEN $whenClause " else "") + body

    private fun rupees(col: String) = "'₹' || CAST(ROUND($col) AS INTEGER)"

    override fun onOpen(db: SupportSQLiteDatabase) {
        super.onOpen(db)
        val sql = mutableListOf<String>()

        // ---- Transactions
        fun txnText(r: String) =
            "COALESCE((SELECT name FROM securities WHERE id = $r.securityId), 'security') || ' · ' || " +
            "CASE $r.type WHEN 'BUY' THEN 'Bought ' WHEN 'SELL' THEN 'Sold ' ELSE 'Maturity ' END || ${rupees("$r.amount")} || " +
            "' (' || COALESCE((SELECT name FROM accounts WHERE id = $r.accountId), '') || ')'"
        sql += trigger("trg_log_txn_ins", "INSERT", "transactions", null, insert("ADDED", "Transaction", txnText("NEW")))
        sql += trigger("trg_log_txn_upd", "UPDATE", "transactions",
            "OLD.amount IS NOT NEW.amount OR OLD.quantity IS NOT NEW.quantity OR OLD.price IS NOT NEW.price OR OLD.type IS NOT NEW.type " +
                "OR OLD.transactionDate IS NOT NEW.transactionDate OR OLD.securityId IS NOT NEW.securityId OR OLD.accountId IS NOT NEW.accountId",
            insert("EDITED", "Transaction", txnText("NEW")))
        sql += trigger("trg_log_txn_del", "DELETE", "transactions", null, insert("DELETED", "Transaction", txnText("OLD")))

        // ---- Accounts
        sql += trigger("trg_log_acc_ins", "INSERT", "accounts", null, insert("ADDED", "Account", "NEW.name"))
        sql += trigger("trg_log_acc_upd", "UPDATE", "accounts",
            "OLD.name IS NOT NEW.name OR OLD.type IS NOT NEW.type OR OLD.isActive IS NOT NEW.isActive",
            insert("EDITED", "Account", "NEW.name"))
        sql += trigger("trg_log_acc_del", "DELETE", "accounts", null, insert("DELETED", "Account", "OLD.name"))

        // ---- Securities (price changes are not logged)
        sql += trigger("trg_log_sec_ins", "INSERT", "securities", null, insert("ADDED", "Security", "NEW.name"))
        sql += trigger("trg_log_sec_upd", "UPDATE", "securities",
            "OLD.name IS NOT NEW.name OR OLD.type IS NOT NEW.type OR OLD.securityCode IS NOT NEW.securityCode " +
                "OR OLD.yahooFinanceCode IS NOT NEW.yahooFinanceCode OR OLD.maturityDate IS NOT NEW.maturityDate " +
                "OR OLD.interestRate IS NOT NEW.interestRate OR OLD.isActive IS NOT NEW.isActive",
            insert("EDITED", "Security", "NEW.name"))
        sql += trigger("trg_log_sec_del", "DELETE", "securities", null, insert("DELETED", "Security", "OLD.name"))

        // ---- Loans (ticking EMIs as paid is not logged)
        sql += trigger("trg_log_loan_ins", "INSERT", "loans", null, insert("ADDED", "Loan", "NEW.loanName"))
        sql += trigger("trg_log_loan_upd", "UPDATE", "loans",
            "OLD.loanName IS NOT NEW.loanName OR OLD.principalAmount IS NOT NEW.principalAmount OR OLD.interestRate IS NOT NEW.interestRate " +
                "OR OLD.emiAmount IS NOT NEW.emiAmount OR OLD.emiDay IS NOT NEW.emiDay OR OLD.startDate IS NOT NEW.startDate OR OLD.isActive IS NOT NEW.isActive",
            insert("EDITED", "Loan", "NEW.loanName"))
        sql += trigger("trg_log_loan_del", "DELETE", "loans", null, insert("DELETED", "Loan", "OLD.loanName"))
        sql += trigger("trg_log_ladj_ins", "INSERT", "loan_adjustments", null,
            insert("ADDED", "Loan change", "COALESCE((SELECT loanName FROM loans WHERE id = NEW.loanId), 'Loan') || ' · ' || REPLACE(NEW.type, '_', ' ')"))
        sql += trigger("trg_log_ladj_del", "DELETE", "loan_adjustments", null,
            insert("DELETED", "Loan change", "COALESCE((SELECT loanName FROM loans WHERE id = OLD.loanId), 'Loan') || ' · ' || REPLACE(OLD.type, '_', ' ')"))

        // ---- Goals
        sql += trigger("trg_log_goal_ins", "INSERT", "goals", null, insert("ADDED", "Goal", "NEW.name"))
        sql += trigger("trg_log_goal_upd", "UPDATE", "goals", null, insert("EDITED", "Goal", "NEW.name"))
        sql += trigger("trg_log_goal_del", "DELETE", "goals", null, insert("DELETED", "Goal", "OLD.name"))

        // ---- Insurance
        sql += trigger("trg_log_pol_ins", "INSERT", "policies", null, insert("ADDED", "Insurance", "NEW.name"))
        sql += trigger("trg_log_pol_upd", "UPDATE", "policies", null, insert("EDITED", "Insurance", "NEW.name"))
        sql += trigger("trg_log_pol_del", "DELETE", "policies", null, insert("DELETED", "Insurance", "OLD.name"))

        // ---- Lending
        fun lendText(r: String) = "$r.personName || ' · ' || CASE $r.direction WHEN 'LENT' THEN 'lent ' ELSE 'borrowed ' END || ${rupees("$r.amount")}"
        sql += trigger("trg_log_lend_ins", "INSERT", "lending_entries", null, insert("ADDED", "Lending", lendText("NEW")))
        sql += trigger("trg_log_lend_upd", "UPDATE", "lending_entries", null, insert("EDITED", "Lending", lendText("NEW")))
        sql += trigger("trg_log_lend_del", "DELETE", "lending_entries", null, insert("DELETED", "Lending", lendText("OLD")))
        sql += trigger("trg_log_lpay_ins", "INSERT", "lending_payments", null,
            insert("ADDED", "Repayment", "COALESCE((SELECT personName FROM lending_entries WHERE id = NEW.lendingId), 'Entry') || ' · ' || ${rupees("NEW.amount")}"))
        sql += trigger("trg_log_lpay_del", "DELETE", "lending_payments", null,
            insert("DELETED", "Repayment", "COALESCE((SELECT personName FROM lending_entries WHERE id = OLD.lendingId), 'Entry') || ' · ' || ${rupees("OLD.amount")}"))

        // ---- Reminders (only added / removed / switched on or off)
        sql += trigger("trg_log_rem_ins", "INSERT", "reminders", null, insert("ADDED", "Reminder", "NEW.title"))
        sql += trigger("trg_log_rem_upd", "UPDATE", "reminders", "OLD.isActive IS NOT NEW.isActive",
            insert("EDITED", "Reminder", "NEW.title || CASE NEW.isActive WHEN 1 THEN ' (switched on)' ELSE ' (switched off)' END"))
        sql += trigger("trg_log_rem_del", "DELETE", "reminders", null, insert("DELETED", "Reminder", "OLD.title"))

        // ---- Budget
        fun budgetText(r: String) = "$r.label || ' · ' || ${rupees("$r.amount")}"
        sql += trigger("trg_log_bud_ins", "INSERT", "income_expense_entries", null, insert("ADDED", "Budget", budgetText("NEW")))
        sql += trigger("trg_log_bud_upd", "UPDATE", "income_expense_entries", "OLD.amount IS NOT NEW.amount OR OLD.label IS NOT NEW.label OR OLD.isActive IS NOT NEW.isActive",
            insert("EDITED", "Budget", budgetText("NEW")))
        sql += trigger("trg_log_bud_del", "DELETE", "income_expense_entries", null, insert("DELETED", "Budget", budgetText("OLD")))

        // keep only the latest 1000 entries
        sql += "CREATE TRIGGER IF NOT EXISTS trg_log_trim AFTER INSERT ON activity_log BEGIN DELETE FROM activity_log WHERE id <= NEW.id - 1000; END"

        sql.forEach { statement ->
            try { db.execSQL(statement) } catch (e: Exception) { /* a missing table must never stop the app opening */ }
        }
    }
}
