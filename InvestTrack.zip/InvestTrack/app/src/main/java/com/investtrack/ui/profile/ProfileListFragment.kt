package com.investtrack.ui.profile

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.GridLayoutManager
import com.investtrack.R
import com.investtrack.databinding.FragmentProfileListBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ProfileListFragment : Fragment() {

    private var _binding: FragmentProfileListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ProfileViewModel by viewModels()
    private lateinit var adapter: ProfileCardAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = ProfileCardAdapter(
            onProfileClick = { summary ->
                val bundle = android.os.Bundle().apply { putLong("profileId", summary.profile.id) }
                findNavController().navigate(R.id.action_profileList_to_profileDetail, bundle)
            }
        )

        binding.rvProfiles.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            this.adapter = this@ProfileListFragment.adapter
        }

        binding.fabAddProfile.setOnClickListener {
            findNavController().navigate(R.id.action_profileList_to_addProfile)
        }

        binding.swipeRefresh.setOnRefreshListener { viewModel.load() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.swipeRefresh.isRefreshing = state.isLoading
                adapter.submitList(state.profileSummaries)
                binding.tvEmpty.visibility =
                    if (state.profileSummaries.isEmpty() && !state.isLoading) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
