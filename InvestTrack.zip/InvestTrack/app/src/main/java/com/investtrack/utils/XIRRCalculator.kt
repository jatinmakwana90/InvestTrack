package com.investtrack.utils

import kotlin.math.abs
import kotlin.math.pow

object XIRRCalculator {

    data class CashFlow(val amount: Double, val date: Long)

    fun calculate(cashFlows: List<CashFlow>, guess: Double = 0.1): Double? {
        if (cashFlows.size < 2) return null
        if (cashFlows.all { it.amount >= 0 } || cashFlows.all { it.amount <= 0 }) return null
        val baseDate = cashFlows.minOf { it.date }
        var rate = guess
        repeat(1000) {
            var npv = 0.0
            var dNpv = 0.0
            for (cf in cashFlows) {
                val t = (cf.date - baseDate) / (365.0 * 24 * 60 * 60 * 1000)
                val factor = (1 + rate).pow(t)
                npv += cf.amount / factor
                dNpv += -t * cf.amount / ((1 + rate) * factor)
            }
            if (abs(dNpv) < 1e-7) return null
            val newRate = rate - npv / dNpv
            if (abs(newRate - rate) < 1e-7) return if (abs(newRate) < 100) newRate * 100 else null
            rate = if (newRate <= -1) -0.9999 else newRate
        }
        return if (abs(rate) < 100) rate * 100 else null
    }

    fun buildCashFlows(
        transactions: List<com.investtrack.data.models.Transaction>,
        currentValue: Double
    ): List<CashFlow> {
        val flows = mutableListOf<CashFlow>()
        transactions.forEach { txn ->
            when (txn.type) {
                com.investtrack.data.models.TransactionType.BUY ->
                    flows.add(CashFlow(-txn.amount, txn.transactionDate))
                com.investtrack.data.models.TransactionType.SELL,
                com.investtrack.data.models.TransactionType.MATURITY ->
                    flows.add(CashFlow(txn.amount, txn.transactionDate))
                else -> {}
            }
        }
        if (currentValue > 0) flows.add(CashFlow(currentValue, System.currentTimeMillis()))
        return flows.sortedBy { it.date }
    }
}
