package com.investtrack.backup

import android.content.Context
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Talks to the Google Drive REST API (v3) directly over OkHttp using the
 * `drive.file` scope — this app can only see/manage files *it* creates, never your
 * whole Drive. The backup lives in a visible "InvestTrack Backups" folder in your
 * normal Drive so you can open it manually and other tools (e.g. a future WhatsApp
 * bot backend using a service account you share the folder with) can find it by name.
 */
class DriveBackupManager(private val context: Context) {

    companion object {
        private const val FOLDER_NAME = "InvestTrack Backups"
        private const val BACKUP_FILE_NAME = "InvestTrack_Backup.json"
        private const val DRIVE_API = "https://www.googleapis.com/drive/v3"
        private const val DRIVE_UPLOAD_API = "https://www.googleapis.com/upload/drive/v3"

        fun signInOptions(): GoogleSignInOptions =
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestScopes(Scope("https://www.googleapis.com/auth/drive.file"))
                .build()

        fun getSignInClient(context: Context): GoogleSignInClient =
            GoogleSignIn.getClient(context, signInOptions())

        fun getSignedInAccount(context: Context): GoogleSignInAccount? =
            GoogleSignIn.getLastSignedInAccount(context)
    }

    private val httpClient = OkHttpClient()

    /**
     * Blocking call — must be invoked from a background thread (e.g. Dispatchers.IO).
     * GoogleAuthUtil.getToken is itself a synchronous/blocking network call under the hood.
     */
    private fun getAccessToken(account: GoogleSignInAccount): String {
        val scope = "oauth2:https://www.googleapis.com/auth/drive.file"
        val androidAccount = account.account
            ?: throw IOException("Google account is missing required permissions — please sign in again")
        return com.google.android.gms.auth.GoogleAuthUtil.getToken(context, androidAccount, scope)
    }

    private fun authedRequest(url: String, token: String) = Request.Builder()
        .url(url)
        .addHeader("Authorization", "Bearer $token")

    /**
     * Finds (or creates) the "InvestTrack Backups" folder and returns its Drive file id.
     * Result is cached by the caller (in DriveBackupConfig) to avoid repeated lookups.
     */
    private fun ensureFolder(token: String): String {
        val query = "mimeType='application/vnd.google-apps.folder' and name='$FOLDER_NAME' " +
            "and trashed=false and 'root' in parents"
        val searchUrl = "$DRIVE_API/files?q=${java.net.URLEncoder.encode(query, "UTF-8")}&fields=files(id,name)"
        val searchReq = authedRequest(searchUrl, token).get().build()
        httpClient.newCall(searchReq).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Drive folder search failed: ${resp.code} ${resp.body?.string()}")
            val body = resp.body?.string() ?: "{}"
            val json = Json.parseToJsonElement(body).jsonObjectOrNull()
            val filesArray = json?.get("files") as? kotlinx.serialization.json.JsonArray
            if (!filesArray.isNullOrEmpty()) {
                val first = filesArray[0].jsonObjectOrNull()
                val id = first?.get("id")?.jsonPrimitive?.content
                if (id != null) return id
            }
        }

        // Not found — create it.
        val createBody = """{"name":"$FOLDER_NAME","mimeType":"application/vnd.google-apps.folder"}"""
            .toRequestBody("application/json".toMediaType())
        val createReq = authedRequest("$DRIVE_API/files?fields=id", token).post(createBody).build()
        httpClient.newCall(createReq).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Drive folder create failed: ${resp.code} ${resp.body?.string()}")
            val body = resp.body?.string() ?: "{}"
            val id = Json.parseToJsonElement(body).jsonObjectOrNull()?.get("id")?.jsonPrimitive?.content
                ?: throw IOException("Drive folder create returned no id")
            return id
        }
    }

    private fun kotlinx.serialization.json.JsonElement.jsonObjectOrNull(): JsonObject? =
        this as? JsonObject

    /**
     * Uploads (or overwrites, if a fileId is already known) the single backup file.
     * Returns the Drive file id so the caller can cache it for next time — this is what
     * makes every day's backup *overwrite the same file* rather than piling up copies.
     */
    fun uploadOrUpdateBackup(
        account: GoogleSignInAccount,
        jsonContent: String,
        knownFolderId: String,
        knownFileId: String
    ): Pair<String, String> {
        val token = getAccessToken(account)
        val folderId = knownFolderId.ifBlank { ensureFolder(token) }

        val metadataJson = if (knownFileId.isBlank()) {
            """{"name":"$BACKUP_FILE_NAME","parents":["$folderId"]}"""
        } else {
            """{"name":"$BACKUP_FILE_NAME"}"""
        }

        val jsonMediaType = "application/json; charset=UTF-8".toMediaType()
        val multipart = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addPart(
                MultipartBody.Part.create(
                    metadataJson.toRequestBody(jsonMediaType)
                )
            )
            .addPart(
                MultipartBody.Part.create(
                    jsonContent.toRequestBody(jsonMediaType)
                )
            )
            .build()

        val url = if (knownFileId.isBlank()) {
            "$DRIVE_UPLOAD_API/files?uploadType=multipart&fields=id"
        } else {
            "$DRIVE_UPLOAD_API/files/$knownFileId?uploadType=multipart&fields=id"
        }
        val request = authedRequest(url, token)
            .let { if (knownFileId.isBlank()) it.post(multipart) else it.patch(multipart) }
            .build()

        httpClient.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IOException("Drive upload failed: ${resp.code} ${resp.body?.string()}")
            }
            val body = resp.body?.string() ?: "{}"
            val id = Json.parseToJsonElement(body).jsonObjectOrNull()?.get("id")?.jsonPrimitive?.content
                ?: knownFileId
            return folderId to id
        }
    }

    /** Downloads the current backup file content by its known Drive file id, for restore. */
    fun downloadBackup(account: GoogleSignInAccount, fileId: String): String {
        val token = getAccessToken(account)
        val request = authedRequest("$DRIVE_API/files/$fileId?alt=media", token).get().build()
        httpClient.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Drive download failed: ${resp.code} ${resp.body?.string()}")
            return resp.body?.string() ?: throw IOException("Empty backup file")
        }
    }

    /**
     * Looks up the backup file id by name inside the "InvestTrack Backups" folder — used when
     * restoring on a fresh install where DriveBackupConfig hasn't cached ids yet.
     */
    fun findExistingBackup(account: GoogleSignInAccount): Pair<String, String>? {
        val token = getAccessToken(account)
        val query = "name='$BACKUP_FILE_NAME' and trashed=false"
        val url = "$DRIVE_API/files?q=${java.net.URLEncoder.encode(query, "UTF-8")}&fields=files(id,name,parents)"
        val request = authedRequest(url, token).get().build()
        httpClient.newCall(request).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("Drive lookup failed: ${resp.code} ${resp.body?.string()}")
            val body = resp.body?.string() ?: "{}"
            val filesArray = Json.parseToJsonElement(body).jsonObjectOrNull()?.get("files") as? kotlinx.serialization.json.JsonArray
            val first = filesArray?.firstOrNull()?.jsonObjectOrNull() ?: return null
            val fileId = first["id"]?.jsonPrimitive?.content ?: return null
            val folderId = (first["parents"] as? kotlinx.serialization.json.JsonArray)
                ?.firstOrNull()?.jsonPrimitive?.content ?: ""
            return folderId to fileId
        }
    }
}
