package com.investtrack.whatsapp

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Opens WhatsApp directly (not a generic share-sheet chooser) with the given phone number's
 * chat and the message pre-filled. The user still taps Send themselves — WhatsApp does not
 * allow third-party apps to send messages without that final user action, by design.
 */
object WhatsAppLauncher {

    /**
     * @param phoneNumber Any format (spaces, dashes, +) — digits are extracted and the country
     * code is assumed to already be included by the caller (e.g. "919876543210" for India).
     */
    fun sendMessage(context: Context, phoneNumber: String, message: String) {
        val digitsOnly = phoneNumber.filter { it.isDigit() }
        if (digitsOnly.isBlank()) {
            Toast.makeText(context, "Enter a valid phone number", Toast.LENGTH_SHORT).show()
            return
        }
        val encodedMessage = Uri.encode(message)
        val uri = Uri.parse("https://wa.me/$digitsOnly?text=$encodedMessage")

        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
        }
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // WhatsApp not installed — fall back to WhatsApp Business, then to letting the
            // system decide (which still opens wa.me correctly if any WhatsApp variant exists).
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp.w4b") })
            } catch (e2: ActivityNotFoundException) {
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                } catch (e3: ActivityNotFoundException) {
                    Toast.makeText(context, "WhatsApp is not installed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
