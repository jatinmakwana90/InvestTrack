package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sync_config")
data class SyncConfig(
    @PrimaryKey val id: Int = 1,
    val isPrimaryDevice: Boolean = false,
    val pairingToken: String = "",
    val targetIp: String = "",
    val targetPort: Int = 8765,
    val lastSyncTime: Long = 0L,
    val syncEnabled: Boolean = false
)
