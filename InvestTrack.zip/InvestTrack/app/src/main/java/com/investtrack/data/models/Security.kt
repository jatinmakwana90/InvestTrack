package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
@Entity(tableName = "securities")
data class Security(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val symbol: String,
    val securityCode: String = "",       // Auto-generated unique alphanumeric code
    val type: SecurityType,
    val isin: String = "",
    val exchange: String = "",
    val sector: String = "",
    val currentPrice: Double = 0.0,
    val previousPrice: Double = 0.0,
    val faceValue: Double = 10.0,
    val currency: String = "INR",
    val maturityDate: Long? = null,
    val interestRate: Double? = null,
    val nav: Double? = null,
    val amc: String = "",
    val category: String = "",
    val lastUpdated: Long = System.currentTimeMillis(),
    val isActive: Boolean = true
) : Parcelable

enum class SecurityType(val displayName: String) {
    LISTED_EQUITY("Listed Equity"),
    EQUITY_MF("Equity Mutual Fund"),
    DEBT_MF("Debt Mutual Fund"),
    GOLD("Gold"),
    FIXED_DEPOSIT("Fixed Deposit"),
    BOND("Bond"),
    ETF("ETF"),
    PPF("PPF"),
    NPS("NPS"),
    CRYPTO("Crypto")
}
