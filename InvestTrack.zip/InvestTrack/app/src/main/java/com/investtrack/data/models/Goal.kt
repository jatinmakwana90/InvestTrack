package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * A savings/investment goal the user tracks manually — e.g. "Emergency Fund ₹1,00,000".
 * Progress ("current") is entered by hand, matching how the person actually checks their
 * savings across possibly multiple accounts/instruments rather than being tied to one place.
 */
@Parcelize
@Serializable
@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val icon: String = "🎯",
    val targetAmount: Double,
    val currentAmount: Double = 0.0,
    val color: String = "#10b981",
    val deadline: Long? = null,      // optional target date
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) : Parcelable
