package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** A savings goal such as "Child education ₹20L by 2035", tracked against part of the portfolio. */
@Serializable
@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val targetAmount: Double,
    val targetDate: Long,
    /** Comma-separated account ids that count towards this goal. Empty = the whole portfolio. */
    val accountIds: String,
    /** Share (1..100) of the linked accounts' value that is earmarked for this goal. */
    val allocationPercent: Int,
    /** Assumed yearly return (%) used for the projection and the monthly amount needed. */
    val expectedReturn: Double,
    val notes: String,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun accountIdSet(): Set<Long> = accountIds.split(",").mapNotNull { it.trim().toLongOrNull() }.toSet()
}
