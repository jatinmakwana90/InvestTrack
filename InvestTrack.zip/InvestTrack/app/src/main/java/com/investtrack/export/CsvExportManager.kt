package com.investtrack.export

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.Folio
import com.investtrack.data.models.IncomeExpenseEntry
import com.investtrack.data.models.IncomeExpenseType
import com.investtrack.data.models.Loan
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.LoanAmortizationCalculator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Builds CSV text for each exportable data type. CSV (not a binary .xlsx) is used deliberately:
 * it opens natively in Excel, Google Sheets, and Numbers with zero conversion, and needs no
 * heavy spreadsheet-writing library in the app.
 */
class CsvExportManager(
    private val investmentRepository: InvestmentRepository,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val incomeExpenseDao: IncomeExpenseDao
) {
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())

    /** One CSV file's name and text content. */
    data class CsvFile(val fileName: String, val content: String)

    /** Escapes a single CSV field: wraps in quotes and doubles any embedded quotes if needed. */
    private fun csv(value: Any?): String {
        val s = value?.toString() ?: ""
        return if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            "\"${s.replace("\"", "\"\"")}\""
        } else s
    }

    private fun row(vararg values: Any?): String = values.joinToString(",") { csv(it) }

    suspend fun buildHoldingsCsv(): CsvFile {
        val folios: List<Folio> = investmentRepository.getAllFolios()
        val sb = StringBuilder()
        sb.appendLine(row(
            "Account", "Security", "Symbol", "Type", "Folio Number", "Units",
            "Avg Cost Price", "Total Invested", "Current Price", "Current Value",
            "P&L", "P&L %", "Day Change"
        ))
        folios.forEach { f ->
            sb.appendLine(row(
                f.accountName, f.securityName, f.securitySymbol, f.securityType.displayName,
                f.folioNumber, f.totalUnits, f.avgCostPrice, f.totalInvested, f.currentPrice,
                f.currentValue, f.pnl, "%.2f".format(Locale.US, f.pnlPercent), f.dayChange
            ))
        }
        return CsvFile("InvestTrack_Holdings.csv", sb.toString())
    }

    suspend fun buildTransactionsCsv(): CsvFile {
        val transactions: List<Transaction> = transactionDao.getAllTransactionsList()
        val accounts = accountDao.getAllAccountsIncludingInactiveList().associateBy { it.id }
        val securities = securityDao.getAllSecuritiesIncludingInactiveList().associateBy { it.id }

        val sb = StringBuilder()
        sb.appendLine(row(
            "Date", "Account", "Security", "Type", "Quantity", "Price", "Amount",
            "Charges", "NAV", "Units", "Folio Number", "Notes"
        ))
        transactions.sortedByDescending { it.transactionDate }.forEach { t ->
            sb.appendLine(row(
                dateFmt.format(Date(t.transactionDate)),
                accounts[t.accountId]?.name ?: "Unknown",
                securities[t.securityId]?.name ?: "Unknown",
                t.type.displayName, t.quantity, t.price, t.amount, t.charges,
                t.nav ?: "", t.units ?: "", t.folioNumber, t.notes
            ))
        }
        return CsvFile("InvestTrack_Transactions.csv", sb.toString())
    }

    suspend fun buildLoansCsv(): CsvFile {
        val loans: List<Loan> = loanDao.getAllLoansList()
        val sb = StringBuilder()
        sb.appendLine(row(
            "Loan Name", "Lender", "Type", "Principal", "Current Outstanding",
            "Interest Rate %", "Current EMI", "EMI Day", "Start Date", "End Date",
            "EMIs Paid", "EMIs Remaining", "Next EMI Due"
        ))
        loans.forEach { loan ->
            val adjustments = loanAdjustmentDao.getAdjustmentsForLoanList(loan.id)
            val schedule = LoanAmortizationCalculator.buildSchedule(loan, adjustments)
            val totalInstallments = schedule.rows.size
            val paidCount = totalInstallments - schedule.remainingInstallments
            sb.appendLine(row(
                loan.loanName, loan.lenderName, loan.loanType.displayName,
                loan.principalAmount, schedule.currentOutstanding, loan.interestRate,
                schedule.currentEmi, loan.emiDay,
                dateFmt.format(Date(loan.startDate)), dateFmt.format(Date(loan.endDate)),
                paidCount, schedule.remainingInstallments,
                schedule.nextEmiDate?.let { dateFmt.format(Date(it)) } ?: ""
            ))
        }
        return CsvFile("InvestTrack_Loans.csv", sb.toString())
    }

    suspend fun buildIncomeExpenseCsv(): CsvFile {
        val entries: List<IncomeExpenseEntry> = incomeExpenseDao.getAllEntriesList()
        val sb = StringBuilder()
        sb.appendLine(row("Date", "Type", "Label", "Amount", "Notes"))
        entries.sortedByDescending { it.date }.forEach { e ->
            sb.appendLine(row(
                dateFmt.format(Date(e.date)),
                if (e.type == IncomeExpenseType.INCOME) "Income" else "Expense",
                e.label, e.amount, e.notes
            ))
        }
        val totalIncome = entries.filter { it.type == IncomeExpenseType.INCOME }.sumOf { it.amount }
        val totalExpense = entries.filter { it.type == IncomeExpenseType.EXPENSE }.sumOf { it.amount }
        sb.appendLine()
        sb.appendLine(row("", "", "Total Income", totalIncome, ""))
        sb.appendLine(row("", "", "Total Expense", totalExpense, ""))
        sb.appendLine(row("", "", "Net Savings", totalIncome - totalExpense, ""))
        return CsvFile("InvestTrack_Budget.csv", sb.toString())
    }

    suspend fun buildAll(): List<CsvFile> = listOf(
        buildHoldingsCsv(), buildTransactionsCsv(), buildLoansCsv(), buildIncomeExpenseCsv()
    )
}
