package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Goal
import kotlinx.coroutines.flow.Flow

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals WHERE isActive = 1 ORDER BY createdAt DESC")
    fun getAllGoals(): Flow<List<Goal>>

    @Query("SELECT * FROM goals WHERE id = :id")
    suspend fun getGoalById(id: Long): Goal?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: Goal): Long

    @Update
    suspend fun updateGoal(goal: Goal)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    @Query("SELECT * FROM goals WHERE isActive = 1 ORDER BY createdAt DESC")
    suspend fun getAllGoalsList(): List<Goal>

    // Includes inactive (soft-deleted) goals too — used for full data backups so nothing is lost.
    @Query("SELECT * FROM goals ORDER BY createdAt DESC")
    suspend fun getAllGoalsIncludingInactiveList(): List<Goal>
}
