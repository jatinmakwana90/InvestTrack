package com.investtrack.data.share

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes a read-only snapshot of the portfolio to a Firebase Realtime Database path that only
 * the holder of the secret link can read. A small static web page (portfolio-viewer/index.html)
 * reads that path, so any phone can open the link and see the latest numbers.
 */
@Singleton
class LiveShareManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("investtrack_live_share", Context.MODE_PRIVATE)

    @Volatile private var latestJson: String? = null

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) { prefs.edit().putBoolean("enabled", v).apply() }

    var databaseUrl: String
        get() = prefs.getString("db_url", "") ?: ""
        set(v) { prefs.edit().putString("db_url", v.trim().trimEnd('/')).apply() }

    var viewerUrl: String
        get() = prefs.getString("viewer_url", "") ?: ""
        set(v) { prefs.edit().putString("viewer_url", v.trim()).apply() }

    var lastStatus: String
        get() = prefs.getString("last_status", "Not synced yet") ?: "Not synced yet"
        private set(v) { prefs.edit().putString("last_status", v).apply() }

    /** Long random secret that makes the link unguessable. Generated once. */
    val token: String
        get() {
            prefs.getString("token", null)?.let { return it }
            val chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            val rnd = SecureRandom()
            val t = (1..28).map { chars[rnd.nextInt(chars.length)] }.joinToString("")
            prefs.edit().putString("token", t).apply()
            return t
        }

    /** Creates a brand-new secret, which stops the old link from working. */
    fun regenerateToken() { prefs.edit().remove("token").apply(); token }

    val isConfigured: Boolean get() = databaseUrl.startsWith("http")

    /** Code the other phone pastes into Viewer mode (contains the database address + secret). */
    fun shareCode(): String? {
        if (!isConfigured) return null
        val raw = "$databaseUrl|$token"
        return "IT1-" + Base64.encodeToString(raw.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    /** Code this phone is currently viewing in Viewer mode (someone else's portfolio). */
    var viewerCode: String
        get() = prefs.getString("viewer_code", "") ?: ""
        set(v) { prefs.edit().putString("viewer_code", v.trim()).apply() }

    companion object {
        /** Returns (databaseUrl, token) or null if the code is not valid. */
        fun parseCode(code: String): Pair<String, String>? {
            val c = code.trim()
            if (!c.startsWith("IT1-")) return null
            return try {
                val raw = String(Base64.decode(c.removePrefix("IT1-"), Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING), Charsets.UTF_8)
                val db = raw.substringBefore('|'); val t = raw.substringAfter('|', "")
                if (db.startsWith("http") && t.length >= 16) db to t else null
            } catch (e: Exception) { null }
        }
    }

    /** The link to send to the other phone. Data location and secret live after '#', so they are never sent to the web host. */
    fun shareLink(): String? {
        if (!isConfigured || !viewerUrl.startsWith("http")) return null
        val enc = URLEncoder.encode(databaseUrl, "UTF-8")
        return "${viewerUrl.substringBefore('#')}#db=$enc&t=$token"
    }

    /** Called by the dashboard every time the numbers change. */
    suspend fun onSnapshot(json: String) {
        latestJson = json
        if (enabled && isConfigured) push(json)
    }

    suspend fun pushLatest(): Boolean {
        val json = latestJson ?: run { lastStatus = "Open the Dashboard first so there is data to share"; return false }
        return push(json)
    }

    private suspend fun push(json: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val conn = (URL("$databaseUrl/shared/$token.json").openConnection() as HttpURLConnection).apply {
                requestMethod = "PUT"
                connectTimeout = 15000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            conn.disconnect()
            if (code in 200..299) {
                lastStatus = "Synced " + java.text.SimpleDateFormat("d MMM, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
                true
            } else {
                lastStatus = if (code == 401 || code == 403) "Rejected (HTTP $code) – check the Firebase rules" else "Failed (HTTP $code)"
                false
            }
        } catch (e: Exception) {
            lastStatus = "Failed: ${e.message ?: "no internet"}"
            false
        }
    }
}
