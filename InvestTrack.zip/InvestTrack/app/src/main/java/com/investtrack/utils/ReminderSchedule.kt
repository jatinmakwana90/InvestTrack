package com.investtrack.utils

import java.util.Calendar

/** Date maths for monthly reminders. A due day of 29/30/31 falls on the last day of shorter months. */
object ReminderSchedule {

    fun ordinal(n: Int): String {
        val suffix = if (n % 100 in 11..13) "th" else when (n % 10) {
            1 -> "st"; 2 -> "nd"; 3 -> "rd"; else -> "th"
        }
        return "$n$suffix"
    }

    /** The real due date in the given month (month is 0-based), clamped to the month's length. */
    fun dueDate(year: Int, month: Int, dueDay: Int): Calendar =
        Calendar.getInstance().apply {
            clear()
            set(year, month, 1)
            set(Calendar.DAY_OF_MONTH, dueDay.coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
        }

    /** Next moment (after [now]) at which "daysBefore days before the due date" occurs. */
    fun nextTrigger(dueDay: Int, daysBefore: Int, hour: Int, minute: Int, now: Long = System.currentTimeMillis()): Long {
        val base = Calendar.getInstance().apply { timeInMillis = now }
        for (offset in -1..3) {
            val m = Calendar.getInstance().apply {
                clear(); set(base.get(Calendar.YEAR), base.get(Calendar.MONTH), 1); add(Calendar.MONTH, offset)
            }
            val trigger = dueDate(m.get(Calendar.YEAR), m.get(Calendar.MONTH), dueDay).apply {
                add(Calendar.DAY_OF_MONTH, -daysBefore)
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0)
            }
            if (trigger.timeInMillis > now) return trigger.timeInMillis
        }
        return now + 24L * 60 * 60 * 1000
    }

    /** Next due date (today counts) for a monthly due day, clamped in shorter months. */
    fun nextDueDate(dueDay: Int, now: Long = System.currentTimeMillis()): Calendar {
        val today = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        for (offset in 0..1) {
            val m = Calendar.getInstance().apply {
                clear(); set(today.get(Calendar.YEAR), today.get(Calendar.MONTH), 1); add(Calendar.MONTH, offset)
            }
            val due = dueDate(m.get(Calendar.YEAR), m.get(Calendar.MONTH), dueDay)
            if (!due.before(today)) return due
        }
        return dueDate(today.get(Calendar.YEAR), today.get(Calendar.MONTH), dueDay)
    }

    /** Whole days from today to the next due date (0 = today). */
    fun daysUntilDue(dueDay: Int, now: Long = System.currentTimeMillis()): Int {
        val today = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val due = nextDueDate(dueDay, now)
        return Math.round((due.timeInMillis - today.timeInMillis) / 86_400_000.0).toInt()
    }

    fun dueLabel(dueDay: Int): String =
        if (dueDay > 28) "${ordinal(dueDay)} of every month (last day in shorter months)"
        else "${ordinal(dueDay)} of every month"
}
