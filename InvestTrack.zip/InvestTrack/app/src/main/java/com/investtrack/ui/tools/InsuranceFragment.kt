package com.investtrack.ui.tools

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.PolicyDao
import com.investtrack.data.models.Policy
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

/** Insurance policies: cover amount, premium and the next due date, with alerts before each premium. */
@AndroidEntryPoint
class InsuranceFragment : ToolListFragment() {

    @Inject lateinit var policyDao: PolicyDao

    override val screenTitle = "Insurance"
    override val emptyText = "No policies yet.\nTap + to add a policy. You'll be reminded before each premium is due."

    private var policies: List<Policy> = emptyList()

    private val typeKeys = listOf("LIFE", "TERM", "HEALTH", "VEHICLE", "HOME", "OTHER")
    private val typeLabels = listOf("Life", "Term", "Health", "Vehicle", "Home", "Other")
    private val freqKeys = listOf("MONTHLY", "QUARTERLY", "HALF_YEARLY", "YEARLY")
    private val freqLabels = listOf("Monthly", "Quarterly", "Half-yearly", "Yearly")
    private val freqShort = mapOf("MONTHLY" to "month", "QUARTERLY" to "quarter", "HALF_YEARLY" to "half-year", "YEARLY" to "year")

    override fun observe() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                policyDao.getAll().collect { list -> policies = list; render() }
            }
        }
    }

    private fun render() {
        val rows = policies.map { p ->
            val typeLabel = typeLabels.getOrElse(typeKeys.indexOf(p.type)) { "Policy" }
            val days = DateUtil.daysUntil(p.nextDueDate)
            val (status, color) = when {
                !p.isActive -> "Inactive" to R.color.text_secondary
                days < 0 -> "Premium overdue by ${-days} day${if (days != -1) "s" else ""} (${DateUtil.format(p.nextDueDate)})" to R.color.loss_red
                days <= 7 -> "Premium due ${DateUtil.duesLabel(days)} (${DateUtil.format(p.nextDueDate)})" to R.color.loss_red
                days <= 30 -> "Premium due ${DateUtil.duesLabel(days)} (${DateUtil.format(p.nextDueDate)})" to R.color.text_accent
                else -> "Next premium ${DateUtil.format(p.nextDueDate)} (${DateUtil.duesLabel(days)})" to R.color.gain_green
            }
            ToolRow(
                key = "p:${p.id}", title = p.name,
                subtitle = "${p.insurer.ifBlank { typeLabel }} · $typeLabel${if (p.policyNumber.isNotBlank()) " · #${p.policyNumber}" else ""}",
                amount = "${CurrencyFormatter.formatFullNoDecimals(p.premiumAmount)} / ${freqShort[p.frequency] ?: "year"}",
                amountSub = "Cover ${CurrencyFormatter.format(p.coverAmount)}",
                status = status, statusColor = color,
                actions = listOf("paid" to "Premium paid", "edit" to "Edit", "delete" to "Delete")
            )
        }
        val active = policies.filter { it.isActive }
        val dueSoon = active.count { DateUtil.daysUntil(it.nextDueDate) <= 30 }
        val summary = if (active.isEmpty()) "" else
            "Total cover: ${CurrencyFormatter.format(active.sumOf { it.coverAmount })}\n" +
            "Premiums: ${CurrencyFormatter.formatFullNoDecimals(active.sumOf { it.yearlyPremium() })} a year · $dueSoon due in 30 days"
        submit(rows, summary)
    }

    override fun onAdd() = showDialog(null)

    override fun onRowClick(row: ToolRow) {
        policies.firstOrNull { "p:${it.id}" == row.key }?.let { showDialog(it) }
    }

    override fun onRowAction(row: ToolRow, action: String) {
        val p = policies.firstOrNull { "p:${it.id}" == row.key } ?: return
        when (action) {
            "edit" -> showDialog(p)
            "paid" -> {
                val next = DateUtil.addMonthsClamped(p.nextDueDate, p.monthsPerPeriod())
                viewLifecycleOwner.lifecycleScope.launch { policyDao.insert(p.copy(nextDueDate = next)) }
                toast("Next premium due ${DateUtil.format(next)}")
            }
            "delete" -> MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete \"${p.name}\"?")
                .setPositiveButton("Delete") { _, _ -> viewLifecycleOwner.lifecycleScope.launch { policyDao.delete(p.id) } }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun showDialog(existing: Policy?) {
        lateinit var name: TextInputEditText
        lateinit var type: android.widget.AutoCompleteTextView
        lateinit var insurer: TextInputEditText
        lateinit var number: TextInputEditText
        lateinit var cover: TextInputEditText
        lateinit var premium: TextInputEditText
        lateinit var freq: android.widget.AutoCompleteTextView
        lateinit var due: DateField
        lateinit var end: DateField
        lateinit var notes: TextInputEditText
        lateinit var active: android.widget.AutoCompleteTextView

        showFormDialog(
            if (existing == null) "Add Policy" else "Edit Policy",
            build = { f ->
                name = f.text("Policy name", "e.g. HDFC Click 2 Protect", existing?.name.orEmpty())
                type = f.dropdown("Type", typeLabels, existing?.let { typeLabels.getOrNull(typeKeys.indexOf(it.type)) })
                insurer = f.text("Insurer", "e.g. HDFC Life", existing?.insurer.orEmpty())
                number = f.text("Policy number (optional)", "", existing?.policyNumber.orEmpty(), android.text.InputType.TYPE_CLASS_TEXT)
                cover = f.number("Cover amount (₹)", "e.g. 10000000", existing?.coverAmount?.let { plain(it) }.orEmpty())
                premium = f.number("Premium amount (₹)", "e.g. 25000", existing?.premiumAmount?.let { plain(it) }.orEmpty())
                freq = f.dropdown("Premium paid", freqLabels, existing?.let { freqLabels.getOrNull(freqKeys.indexOf(it.frequency)) } ?: "Yearly")
                due = f.date("Next premium due", existing?.nextDueDate ?: Calendar.getInstance().apply { add(Calendar.MONTH, 12) }.timeInMillis)
                end = f.date("Policy end / maturity date", existing?.endDate?.takeIf { it > 0 }, optional = true)
                active = f.dropdown("Status", listOf("Active", "Inactive"), if (existing?.isActive == false) "Inactive" else "Active")
                notes = f.text("Notes (optional)", "", existing?.notes.orEmpty(), android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            },
            onSave = {
                val n = name.text.toString().trim()
                val d = due.value
                when {
                    n.isEmpty() -> { toast("Enter the policy name"); false }
                    premium.num() <= 0 -> { toast("Enter the premium amount"); false }
                    d == null -> { toast("Choose the next premium due date"); false }
                    else -> {
                        viewLifecycleOwner.lifecycleScope.launch {
                            policyDao.insert(Policy(
                                id = existing?.id ?: 0, name = n,
                                insurer = insurer.text.toString().trim(),
                                type = typeKeys.getOrElse(typeLabels.indexOf(type.text.toString())) { "OTHER" },
                                policyNumber = number.text.toString().trim(),
                                coverAmount = cover.num(), premiumAmount = premium.num(),
                                frequency = freqKeys.getOrElse(freqLabels.indexOf(freq.text.toString())) { "YEARLY" },
                                nextDueDate = d, endDate = end.value ?: 0L,
                                notes = notes.text.toString().trim(),
                                isActive = active.text.toString() != "Inactive",
                                createdAt = existing?.createdAt ?: System.currentTimeMillis()
                            ))
                        }
                        true
                    }
                }
            }
        )
    }

    private fun plain(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
}
