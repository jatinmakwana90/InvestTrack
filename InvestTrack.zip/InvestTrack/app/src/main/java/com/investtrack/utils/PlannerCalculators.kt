package com.investtrack.utils

data class SipResult(val invested: Double, val futureValue: Double, val flatInvested: Double, val flatFutureValue: Double)
data class LumpResult(val futureValue: Double, val gain: Double, val realValue: Double)
data class SwpResult(
    val monthsLasted: Int,          // months the corpus lasts (capped at the chosen period)
    val depleted: Boolean,
    val endBalance: Double,
    val totalWithdrawn: Double,
    val sustainableMonthly: Double  // monthly amount that would just use up the corpus over the period
)

object PlannerCalculators {

    /** SIP that grows by [stepUpPercent] every year. Instalments are made at the start of each month. */
    fun sipStepUp(monthly: Double, stepUpPercent: Double, annualReturn: Double, years: Int): SipResult {
        fun run(step: Double): Pair<Double, Double> {
            val rm = annualReturn / 12.0 / 100.0
            var sip = monthly
            var balance = 0.0
            var invested = 0.0
            for (m in 1..years * 12) {
                balance = (balance + sip) * (1 + rm)
                invested += sip
                if (m % 12 == 0) sip *= 1 + step / 100.0
            }
            return invested to balance
        }
        val (inv, fv) = run(stepUpPercent)
        val (flatInv, flatFv) = run(0.0)
        return SipResult(inv, fv, flatInv, flatFv)
    }

    fun lumpSum(amount: Double, annualReturn: Double, years: Int, inflationPercent: Double): LumpResult {
        val fv = amount * Math.pow(1 + annualReturn / 100.0, years.toDouble())
        val real = fv / Math.pow(1 + inflationPercent / 100.0, years.toDouble())
        return LumpResult(fv, fv - amount, real)
    }

    /** Systematic withdrawal plan: withdraw [monthlyWithdrawal] at the end of every month. */
    fun swp(corpus: Double, monthlyWithdrawal: Double, annualReturn: Double, years: Int): SwpResult {
        val n = years * 12
        val rm = annualReturn / 12.0 / 100.0
        var bal = corpus
        var withdrawn = 0.0
        var lasted = n
        var depleted = false
        for (m in 1..n) {
            bal *= (1 + rm)
            if (bal < monthlyWithdrawal) {
                withdrawn += bal; bal = 0.0; lasted = m; depleted = true; break
            }
            bal -= monthlyWithdrawal
            withdrawn += monthlyWithdrawal
        }
        val sustainable = if (n == 0) 0.0 else if (rm == 0.0) corpus / n else corpus * rm / (1 - Math.pow(1 + rm, -n.toDouble()))
        return SwpResult(lasted, depleted, bal, withdrawn, sustainable)
    }
}
