package com.investtrack.ui.settings

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.investtrack.backup.DriveBackupManager
import com.investtrack.backup.FullBackupBuilder
import com.investtrack.backup.FullBackupRestorer
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.dao.BudgetLimitDao
import com.investtrack.data.dao.DriveBackupConfigDao
import com.investtrack.data.dao.GoalDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.DriveBackupConfig
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentBackupRestoreBinding
import com.investtrack.workers.DailyDriveBackupWorker
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class BackupRestoreViewModel @Inject constructor(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val reminderDao: ReminderDao,
    private val autoSyncConfigDao: AutoSyncConfigDao,
    private val settingsManager: SettingsManager,
    val driveBackupConfigDao: DriveBackupConfigDao,
    private val goalDao: GoalDao,
    private val budgetLimitDao: BudgetLimitDao
) : ViewModel() {

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val builder = FullBackupBuilder(
        accountDao, securityDao, transactionDao, loanDao,
        loanAdjustmentDao, reminderDao, autoSyncConfigDao, settingsManager,
        goalDao, budgetLimitDao
    )
    private val restorer = FullBackupRestorer(
        accountDao, securityDao, transactionDao, loanDao,
        loanAdjustmentDao, reminderDao, autoSyncConfigDao, settingsManager,
        goalDao, budgetLimitDao
    )

    fun createBackupJson(onResult: (String?) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val json = try { builder.toJson(builder.build()) } catch (e: Exception) { null }
            withContext(Dispatchers.Main) { onResult(json) }
        }
    }

    fun saveBackupToFile(content: String, uri: Uri, contentResolver: android.content.ContentResolver) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(uri)?.use { os -> os.write(content.toByteArray()) }
                withContext(Dispatchers.Main) { _status.value = "✓ Backup saved successfully!" }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { _status.value = "✗ Backup failed: ${e.message}" }
            }
        }
    }

    fun restoreFromFile(uri: Uri, contentResolver: android.content.ContentResolver) {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { _isLoading.value = true; _status.value = "Restoring..." }
            try {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
                    ?: throw Exception("Could not read file")
                val backup = restorer.fromJson(content)
                val summary = restorer.restore(backup)
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✓ Restore complete! Accounts: ${summary.accounts}, Securities: ${summary.securities}, " +
                        "Transactions: ${summary.transactions}, Loans: ${summary.loans}, Reminders: ${summary.reminders}, " +
                        "Goals: ${summary.goals}, Budgets: ${summary.budgetLimits}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✗ Restore failed: ${e.message}"
                }
            }
        }
    }

    fun restoreFromDrive(context: android.content.Context, account: GoogleSignInAccount) {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { _isLoading.value = true; _status.value = "Restoring from Drive..." }
            try {
                val manager = DriveBackupManager(context)
                val config = driveBackupConfigDao.getConfigOnce()
                val fileId = config?.driveFileId?.takeIf { it.isNotBlank() }
                    ?: manager.findExistingBackup(account)?.second
                    ?: throw Exception("No backup found in Drive yet")

                val content = manager.downloadBackup(account, fileId)
                val backup = restorer.fromJson(content)
                val summary = restorer.restore(backup)

                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✓ Restored from Drive! Accounts: ${summary.accounts}, Securities: ${summary.securities}, " +
                        "Transactions: ${summary.transactions}, Loans: ${summary.loans}, Reminders: ${summary.reminders}, " +
                        "Goals: ${summary.goals}, Budgets: ${summary.budgetLimits}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✗ Restore from Drive failed: ${e.message}"
                }
            }
        }
    }

    fun runBackupNow(context: android.content.Context, account: GoogleSignInAccount) {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { _isLoading.value = true; _status.value = "Backing up to Drive..." }
            try {
                val config = driveBackupConfigDao.getConfigOnce() ?: DriveBackupConfig()
                val data = builder.build()
                val jsonContent = builder.toJson(data)
                val manager = DriveBackupManager(context)
                val (folderId, fileId) = manager.uploadOrUpdateBackup(
                    account, jsonContent, config.driveFolderId, config.driveFileId
                )
                val timeFmt = SimpleDateFormat("dd MMM, h:mm a", Locale.getDefault())
                driveBackupConfigDao.upsert(
                    config.copy(
                        accountEmail = account.email ?: config.accountEmail,
                        driveFolderId = folderId,
                        driveFileId = fileId,
                        lastBackupAt = System.currentTimeMillis(),
                        lastBackupStatus = "✓ Backed up ${timeFmt.format(Date())}"
                    )
                )
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✓ Backed up to Google Drive!"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✗ Drive backup failed: ${e.message}"
                }
            }
        }
    }

    fun setDriveEnabled(context: android.content.Context, enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = driveBackupConfigDao.getConfigOnce() ?: DriveBackupConfig()
            driveBackupConfigDao.upsert(config.copy(isEnabled = enabled, hour = hour, minute = minute))
            withContext(Dispatchers.Main) {
                if (enabled) DailyDriveBackupWorker.schedule(context, hour, minute)
                else DailyDriveBackupWorker.cancel(context)
            }
        }
    }

    fun setDriveTime(context: android.content.Context, hour: Int, minute: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = driveBackupConfigDao.getConfigOnce() ?: DriveBackupConfig()
            driveBackupConfigDao.upsert(config.copy(hour = hour, minute = minute))
            withContext(Dispatchers.Main) {
                if (config.isEnabled) DailyDriveBackupWorker.schedule(context, hour, minute)
            }
        }
    }

    fun setDriveAccount(email: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val config = driveBackupConfigDao.getConfigOnce() ?: DriveBackupConfig()
            driveBackupConfigDao.upsert(config.copy(accountEmail = email))
        }
    }
}

@AndroidEntryPoint
class BackupRestoreFragment : Fragment() {

    private var _binding: FragmentBackupRestoreBinding? = null
    private val binding get() = _binding!!
    private val viewModel: BackupRestoreViewModel by viewModels()

    private var pendingAction: PendingDriveAction = PendingDriveAction.NONE
    private enum class PendingDriveAction { NONE, ENABLE_TOGGLE, BACKUP_NOW, RESTORE }

    private val createFileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.createBackupJson { content ->
                    if (content != null) {
                        viewModel.saveBackupToFile(content, uri, requireContext().contentResolver)
                    } else {
                        binding.tvStatus.text = "✗ Failed to generate backup"
                        binding.tvStatus.visibility = View.VISIBLE
                    }
                }
            }
        }
    }

    private val openFileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.restoreFromFile(uri, requireContext().contentResolver)
            }
        }
    }

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).result
            if (account != null) {
                viewModel.setDriveAccount(account.email ?: "")
                updateDriveAccountLabel(account)
                when (pendingAction) {
                    PendingDriveAction.ENABLE_TOGGLE -> applyEnableToggle(true)
                    PendingDriveAction.BACKUP_NOW -> viewModel.runBackupNow(requireContext(), account)
                    PendingDriveAction.RESTORE -> viewModel.restoreFromDrive(requireContext(), account)
                    PendingDriveAction.NONE -> {}
                }
            }
        } catch (e: Exception) {
            binding.tvStatus.text = "✗ Google sign-in failed: ${e.message}"
            binding.tvStatus.visibility = View.VISIBLE
            binding.switchDriveEnabled.isChecked = false
        }
        pendingAction = PendingDriveAction.NONE
    }

    private var driveHour = 2
    private var driveMinute = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBackupRestoreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        binding.btnBackup.setOnClickListener {
            val dateFmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val fileName = "InvestTrack_Backup_${dateFmt.format(Date())}.json"
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, fileName)
            }
            createFileLauncher.launch(intent)
        }

        binding.btnRestore.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
            openFileLauncher.launch(intent)
        }

        setupDriveSection()

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.status.collect { msg ->
                if (msg.isNotEmpty()) {
                    binding.tvStatus.text = msg
                    binding.tvStatus.visibility = View.VISIBLE
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collect { loading ->
                binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
                binding.btnBackup.isEnabled = !loading
                binding.btnRestore.isEnabled = !loading
                binding.btnDriveBackupNow.isEnabled = !loading
                binding.btnDriveRestore.isEnabled = !loading
            }
        }
    }

    private fun setupDriveSection() {
        val existingAccount = DriveBackupManager.getSignedInAccount(requireContext())
        if (existingAccount != null) updateDriveAccountLabel(existingAccount)

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.driveBackupConfigDao.getConfig().collect { config ->
                val c = config ?: return@collect
                driveHour = c.hour
                driveMinute = c.minute
                binding.switchDriveEnabled.setOnCheckedChangeListener(null)
                binding.switchDriveEnabled.isChecked = c.isEnabled
                binding.switchDriveEnabled.setOnCheckedChangeListener { _, checked -> onToggleChanged(checked) }

                binding.tvDriveTime.text = formatTime(c.hour, c.minute)
                binding.tvDriveStatus.text = when {
                    c.lastBackupStatus.isNotBlank() -> c.lastBackupStatus
                    c.isEnabled -> "Not backed up yet — next run at ${formatTime(c.hour, c.minute)}"
                    else -> "Auto-backup is off"
                }
                binding.driveScheduleRow.visibility = if (c.isEnabled) View.VISIBLE else View.GONE
            }
        }

        binding.switchDriveEnabled.setOnCheckedChangeListener { _, checked -> onToggleChanged(checked) }

        binding.tvDriveTime.setOnClickListener { showTimePicker() }
        binding.driveScheduleRow.setOnClickListener { showTimePicker() }

        binding.btnDriveBackupNow.setOnClickListener {
            withGoogleAccount(PendingDriveAction.BACKUP_NOW) { account ->
                viewModel.runBackupNow(requireContext(), account)
            }
        }

        binding.btnDriveRestore.setOnClickListener {
            withGoogleAccount(PendingDriveAction.RESTORE) { account ->
                viewModel.restoreFromDrive(requireContext(), account)
            }
        }
    }

    private fun onToggleChanged(checked: Boolean) {
        if (checked) {
            withGoogleAccount(PendingDriveAction.ENABLE_TOGGLE) { applyEnableToggle(true) }
        } else {
            applyEnableToggle(false)
        }
    }

    private fun applyEnableToggle(enabled: Boolean) {
        viewModel.setDriveEnabled(requireContext(), enabled, driveHour, driveMinute)
    }

    private fun showTimePicker() {
        TimePickerDialog(requireContext(), { _, hour, minute ->
            driveHour = hour
            driveMinute = minute
            binding.tvDriveTime.text = formatTime(hour, minute)
            viewModel.setDriveTime(requireContext(), hour, minute)
        }, driveHour, driveMinute, false).show()
    }

    private fun withGoogleAccount(action: PendingDriveAction, onReady: (GoogleSignInAccount) -> Unit) {
        val account = DriveBackupManager.getSignedInAccount(requireContext())
        if (account != null) {
            onReady(account)
        } else {
            pendingAction = action
            val client = DriveBackupManager.getSignInClient(requireContext())
            signInLauncher.launch(client.signInIntent)
        }
    }

    private fun updateDriveAccountLabel(account: GoogleSignInAccount) {
        binding.tvDriveAccount.text = account.email ?: "Connected"
        binding.tvDriveAccount.visibility = View.VISIBLE
    }

    private fun formatTime(hour: Int, minute: Int): String {
        val cal = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute) }
        return SimpleDateFormat("h:mm a", Locale.getDefault()).format(cal.time)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
