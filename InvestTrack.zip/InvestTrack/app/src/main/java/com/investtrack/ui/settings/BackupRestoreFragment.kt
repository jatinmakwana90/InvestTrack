package com.investtrack.ui.settings

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.Account
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.databinding.FragmentBackupRestoreBinding
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.*
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@Serializable
data class BackupData(
    val version: Int = 1,
    val exportedAt: Long = System.currentTimeMillis(),
    val accounts: List<Account> = emptyList(),
    val securities: List<Security> = emptyList(),
    val transactions: List<Transaction> = emptyList()
)

@HiltViewModel
class BackupRestoreViewModel @Inject constructor(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) : ViewModel() {

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

    fun createBackup(): String? {
        return try {
            val accounts = runBlocking { accountDao.getAllAccountsList() }
            val securities = runBlocking { securityDao.getAllSecuritiesList() }
            val transactions = runBlocking { transactionDao.getAllTransactionsList() }
            val backup = BackupData(accounts = accounts, securities = securities, transactions = transactions)
            json.encodeToString(backup)
        } catch (e: Exception) { null }
    }

    private fun <T> runBlocking(block: suspend () -> T): T {
        var result: T? = null
        var error: Exception? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        viewModelScope.launch(Dispatchers.IO) {
            try { result = block() } catch (e: Exception) { error = e } finally { latch.countDown() }
        }
        latch.await()
        if (error != null) throw error!!
        @Suppress("UNCHECKED_CAST")
        return result as T
    }

    fun saveBackupToFile(content: String, uri: Uri, contentResolver: android.content.ContentResolver) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                contentResolver.openOutputStream(uri)?.use { os ->
                    os.write(content.toByteArray())
                }
                withContext(Dispatchers.Main) { _status.value = "✓ Backup saved successfully!" }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { _status.value = "✗ Backup failed: ${e.message}" }
            }
        }
    }

    fun restoreFromFile(uri: Uri, contentResolver: android.content.ContentResolver) {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) { _isLoading.value = true; _status.value = "Restoring..." }
            try {
                val content = contentResolver.openInputStream(uri)?.bufferedReader()?.readText()
                    ?: throw Exception("Could not read file")
                val backup = json.decodeFromString<BackupData>(content)

                backup.accounts.forEach { accountDao.insertAccount(it) }
                backup.securities.forEach { securityDao.insertSecurity(it) }
                backup.transactions.forEach { transactionDao.insertTransaction(it) }

                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✓ Restore complete! Accounts: ${backup.accounts.size}, Securities: ${backup.securities.size}, Transactions: ${backup.transactions.size}"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _isLoading.value = false
                    _status.value = "✗ Restore failed: ${e.message}"
                }
            }
        }
    }
}

@AndroidEntryPoint
class BackupRestoreFragment : Fragment() {

    private var _binding: FragmentBackupRestoreBinding? = null
    private val binding get() = _binding!!
    private val viewModel: BackupRestoreViewModel by viewModels()

    private val createFileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                val content = viewModel.createBackup()
                if (content != null) {
                    viewModel.saveBackupToFile(content, uri, requireContext().contentResolver)
                } else {
                    binding.tvStatus.text = "✗ Failed to generate backup"
                }
            }
        }
    }

    private val openFileLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                viewModel.restoreFromFile(uri, requireContext().contentResolver)
            }
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBackupRestoreBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        binding.btnBackup.setOnClickListener {
            val dateFmt = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val fileName = "InvestTrack_Backup_${dateFmt.format(Date())}.json"
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
                putExtra(Intent.EXTRA_TITLE, fileName)
            }
            createFileLauncher.launch(intent)
        }

        binding.btnRestore.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/json"
            }
            openFileLauncher.launch(intent)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.status.collect { msg ->
                if (msg.isNotEmpty()) {
                    binding.tvStatus.text = msg
                    binding.tvStatus.visibility = View.VISIBLE
                }
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isLoading.collect { loading ->
                binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
                binding.btnBackup.isEnabled = !loading
                binding.btnRestore.isEnabled = !loading
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
