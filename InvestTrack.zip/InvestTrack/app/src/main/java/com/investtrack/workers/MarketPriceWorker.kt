package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.SecurityDao
import com.investtrack.network.YahooFinanceService
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class MarketPriceWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val securityDao: SecurityDao,
    private val yahooFinanceService: YahooFinanceService
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val securities = securityDao.getSecuritiesWithYahooCode()
            if (securities.isEmpty()) return Result.success()
            val codes = securities.map { it.yahooFinanceCode }.filter { it.isNotBlank() }
            val prices = yahooFinanceService.fetchPrices(codes)
            securities.forEach { security ->
                prices[security.yahooFinanceCode]?.let { result ->
                    securityDao.updatePrice(
                        id = security.id,
                        price = result.price,
                        prevPrice = result.previousClose
                    )
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "market_price_update"

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = PeriodicWorkRequestBuilder<MarketPriceWorker>(1, TimeUnit.DAYS)
                .setConstraints(constraints)
                .setInitialDelay(1, TimeUnit.HOURS)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request
            )
        }

        fun runOnce(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<MarketPriceWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
