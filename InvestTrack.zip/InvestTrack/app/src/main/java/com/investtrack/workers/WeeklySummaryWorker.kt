package com.investtrack.workers

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.WorkerParameters
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.data.settings.AutomationSettings
import com.investtrack.data.settings.SettingsManager
import com.investtrack.utils.NotificationHelper
import com.investtrack.whatsapp.WhatsAppMessageBuilder
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * WhatsApp does not let apps send messages by themselves, so on the chosen day this prepares the
 * AUM summary and shows a notification. Tapping it opens WhatsApp with the message already typed;
 * you only press Send.
 */
@HiltWorker
class WeeklySummaryWorker @AssistedInject constructor(
    @Assisted private val appContext: Context,
    @Assisted params: WorkerParameters,
    private val repository: InvestmentRepository,
    private val accountDao: AccountDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val incomeExpenseDao: IncomeExpenseDao,
    private val automation: AutomationSettings,
    private val settingsManager: SettingsManager
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        if (!automation.weeklyEnabled) return Result.success()
        try {
            NotificationHelper.createChannels(appContext)
            val builder = WhatsAppMessageBuilder(
                repository, accountDao, loanDao, loanAdjustmentDao, incomeExpenseDao,
                appNameProvider = { settingsManager.appName.value }
            )
            val message = builder.buildAumMessage()
            val phone = automation.weeklyContactPhone.filter { it.isDigit() }

            val baseIntent: Intent = if (phone.isNotEmpty()) {
                Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=${Uri.encode(message)}"))
            } else {
                Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, message) },
                    "Send portfolio summary"
                )
            }
            val intent = baseIntent.apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

            val pi = PendingIntent.getActivity(
                appContext, 7101, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val who = automation.weeklyContactName.ifBlank { "WhatsApp" }
            NotificationHelper.showActionNotification(
                appContext, 7101, "Weekly portfolio summary ready",
                "Tap to open $who with your summary typed in, then press Send.", pi
            )
        } catch (e: Exception) {
            // fall through and still schedule next week
        }
        AutomationScheduler.scheduleWeekly(appContext, automation, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return Result.success()
    }
}
