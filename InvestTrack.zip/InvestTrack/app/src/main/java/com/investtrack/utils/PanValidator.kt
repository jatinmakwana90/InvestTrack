package com.investtrack.utils

object PanValidator {
    // PAN format: AAAAA0000A (5 letters, 4 digits, 1 letter)
    private val PAN_REGEX = Regex("^[A-Z]{5}[0-9]{4}[A-Z]{1}$")

    fun isValid(pan: String): Boolean = PAN_REGEX.matches(pan.uppercase().trim())

    fun format(pan: String): String = pan.uppercase().trim()

    fun errorMessage(pan: String): String? {
        if (pan.isBlank()) return "PAN is required"
        if (pan.length != 10) return "PAN must be exactly 10 characters"
        if (!isValid(pan)) return "Invalid PAN format (e.g. ABCDE1234F)"
        return null
    }
}
