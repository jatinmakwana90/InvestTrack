package com.investtrack.ui.profile

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.investtrack.data.models.Profile
import com.investtrack.data.models.ProfileRelation
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddProfileBinding
import com.investtrack.utils.PanValidator
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddProfileViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {
    fun saveProfile(name: String, relation: ProfileRelation, pan: String, address: String, phone: String, email: String) {
        viewModelScope.launch {
            repository.insertProfile(
                Profile(name = name, relation = relation, pan = pan, address = address, phone = phone, email = email)
            )
        }
    }
}

@AndroidEntryPoint
class AddProfileFragment : Fragment() {

    private var _binding: FragmentAddProfileBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddProfileViewModel by viewModels()
    private var selectedRelation = ProfileRelation.SELF

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        val relations = ProfileRelation.values().map { it.displayName }
        binding.actvRelation.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, relations))
        binding.actvRelation.setText(relations[0], false)
        binding.actvRelation.setOnItemClickListener { _, _, pos, _ ->
            selectedRelation = ProfileRelation.values()[pos]
        }

        // PAN real-time validation
        binding.etPan.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val pan = s.toString().uppercase()
                if (pan.isNotEmpty()) {
                    val err = PanValidator.errorMessage(pan)
                    binding.tilPan.error = err
                    binding.tilPan.isErrorEnabled = err != null
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        binding.btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val name = binding.etFullName.text.toString().trim()
        if (name.isEmpty()) { binding.tilFullName.error = "Full name required"; return }

        val pan = binding.etPan.text.toString().trim().uppercase()
        val panError = PanValidator.errorMessage(pan)
        if (panError != null) { binding.tilPan.error = panError; return }

        val address = binding.etAddress.text.toString().trim()
        val phone = binding.etPhone.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()

        viewModel.saveProfile(name, selectedRelation, pan, address, phone, email)
        findNavController().navigateUp()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
