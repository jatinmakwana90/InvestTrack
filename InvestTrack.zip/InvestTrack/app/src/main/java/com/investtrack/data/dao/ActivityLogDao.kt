package com.investtrack.data.dao

import androidx.room.Dao
import androidx.room.Query
import com.investtrack.data.models.ActivityLog
import kotlinx.coroutines.flow.Flow

@Dao
interface ActivityLogDao {
    @Query("SELECT * FROM activity_log ORDER BY id DESC LIMIT 500")
    fun recent(): Flow<List<ActivityLog>>

    @Query("DELETE FROM activity_log")
    suspend fun clear()
}
