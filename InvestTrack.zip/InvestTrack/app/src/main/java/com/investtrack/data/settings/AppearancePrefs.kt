package com.investtrack.data.settings

import android.content.Context
import com.investtrack.R

/** Accent colour and text size chosen in Settings → Appearance. Read directly (no injection) so it can be applied early. */
object AppearancePrefs {
    private const val PREFS = "investtrack_appearance"

    val accentKeys = listOf("teal", "indigo", "green", "purple", "orange", "rose")
    val accentLabels = listOf("Teal", "Indigo", "Green", "Purple", "Orange", "Rose")

    val sizeLabels = listOf("Small", "Normal", "Large", "Extra large")
    val sizeScales = listOf(0.9f, 1.0f, 1.15f, 1.3f)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun accentKey(ctx: Context): String = prefs(ctx).getString("accent", "teal") ?: "teal"
    fun setAccentKey(ctx: Context, key: String) { prefs(ctx).edit().putString("accent", key).apply() }

    fun accentStyle(ctx: Context): Int = when (accentKey(ctx)) {
        "indigo" -> R.style.ThemeOverlay_InvestTrack_AccentIndigo
        "green" -> R.style.ThemeOverlay_InvestTrack_AccentGreen
        "purple" -> R.style.ThemeOverlay_InvestTrack_AccentPurple
        "orange" -> R.style.ThemeOverlay_InvestTrack_AccentOrange
        "rose" -> R.style.ThemeOverlay_InvestTrack_AccentRose
        else -> R.style.ThemeOverlay_InvestTrack_AccentTeal
    }

    fun fontScale(ctx: Context): Float = prefs(ctx).getFloat("font_scale", 1.0f)
    fun setFontScale(ctx: Context, scale: Float) { prefs(ctx).edit().putFloat("font_scale", scale).apply() }
}
