package com.investtrack.utils

import java.util.Calendar

data class PrepaymentResult(
    val baseMonths: Int,          // EMIs left without any prepayment (-1 = never closes)
    val baseInterest: Double,     // interest still to be paid without prepayment
    val newMonths: Int,
    val newInterest: Double,
    val monthsSaved: Int,
    val interestSaved: Double,
    val closingDate: Long?        // due date of the last EMI after prepayment
)

/** "What if I prepay?" — keeps the EMI the same and shows how much sooner the loan closes. */
object PrepaymentSimulator {

    private data class Plan(val months: Int, val interest: Double)

    private fun run(balance: Double, monthlyRate: Double, payment: Double): Plan {
        var bal = balance
        var months = 0
        var interest = 0.0
        while (bal > 0.5 && months < 1200) {
            val i = bal * monthlyRate
            if (payment <= i + 0.01) return Plan(-1, interest)   // payment never reduces the principal
            months++
            interest += i
            bal -= (payment - i).coerceAtMost(bal)
        }
        return Plan(months, interest)
    }

    /**
     * @param balance outstanding principal before the next EMI
     * @param monthlyRate annual rate / 12 / 100
     * @param emi the EMI you pay now
     * @param firstDueDate due date of the next EMI (used to show the new closing month)
     */
    fun simulate(balance: Double, monthlyRate: Double, emi: Double, lumpSum: Double, extraMonthly: Double, firstDueDate: Long?): PrepaymentResult {
        val base = run(balance, monthlyRate, emi)
        val newBalance = (balance - lumpSum).coerceAtLeast(0.0)
        val scenario = if (newBalance <= 0.5) Plan(0, 0.0) else run(newBalance, monthlyRate, emi + extraMonthly)

        val saved = if (base.months >= 0 && scenario.months >= 0) (base.months - scenario.months).coerceAtLeast(0) else 0
        val interestSaved = if (base.months >= 0 && scenario.months >= 0) (base.interest - scenario.interest).coerceAtLeast(0.0) else 0.0
        val closing = if (scenario.months > 0 && firstDueDate != null) addMonthsClamped(firstDueDate, scenario.months - 1) else null
        return PrepaymentResult(base.months, base.interest, scenario.months, scenario.interest, saved, interestSaved, closing)
    }

    private fun addMonthsClamped(from: Long, months: Int): Long {
        val cal = Calendar.getInstance().apply { timeInMillis = from }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.add(Calendar.MONTH, months)
        cal.set(Calendar.DAY_OF_MONTH, minOf(day, cal.getActualMaximum(Calendar.DAY_OF_MONTH)))
        return cal.timeInMillis
    }
}
