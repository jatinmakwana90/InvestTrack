package com.investtrack.ui.tools

import androidx.lifecycle.lifecycleScope
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.report.ReportGenerator
import com.investtrack.workers.MonthlyReportWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

/** Creates a PDF statement for one account that you can send to a family member. */
@AndroidEntryPoint
class AccountStatementFragment : ToolFormFragment() {

    @Inject lateinit var repository: InvestmentRepository
    @Inject lateinit var reportGenerator: ReportGenerator

    override val screenTitle = "Account Statement"

    override fun buildForm(form: FormBuilder) {
        form.note("A PDF with the account's current holdings and its transactions. Share it with whoever owns the account.")
        viewLifecycleOwner.lifecycleScope.launch {
            val accounts = repository.getAllAccountsList()
            if (accounts.isEmpty()) { form.note("Add an account in Masters first."); return@launch }

            val now = Calendar.getInstance()
            val currentFy = if (now.get(Calendar.MONTH) >= Calendar.APRIL) now.get(Calendar.YEAR) else now.get(Calendar.YEAR) - 1
            val years = (0..5).map { currentFy - it }
            val periodLabels = listOf("All time") + years.map { "FY $it-${(it + 1) % 100}  (Apr $it – Mar ${it + 1})" }

            val account = form.dropdown("Account", accounts.map { it.name }, accounts.first().name)
            val period = form.dropdown("Period", periodLabels, periodLabels.first())
            val status = form.note("")

            form.button("Create PDF and share", filled = true) {
                val acc = accounts.firstOrNull { it.name == account.text.toString() } ?: return@button
                val idx = periodLabels.indexOf(period.text.toString())
                val fy = if (idx <= 0) null else years[idx - 1]
                status.text = "Creating the statement…"
                viewLifecycleOwner.lifecycleScope.launch {
                    try {
                        val file = reportGenerator.createAccountStatement(acc.id, fy)
                        status.text = "Ready: ${file.name}"
                        startActivity(MonthlyReportWorker.shareIntent(requireContext(), file, "application/pdf"))
                    } catch (e: Exception) {
                        status.text = "Could not create the statement: ${e.message}"
                    }
                }
            }
        }
    }
}
