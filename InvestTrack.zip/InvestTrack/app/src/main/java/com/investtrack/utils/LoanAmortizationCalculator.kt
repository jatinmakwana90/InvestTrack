package com.investtrack.utils

import com.investtrack.data.models.AdjustmentType
import com.investtrack.data.models.Loan
import com.investtrack.data.models.LoanAdjustment
import java.util.Calendar

/**
 * A single row in the amortization / cash-flow table.
 */
data class LoanScheduleRow(
    val installmentNumber: Int,
    val dueDate: Long,
    val emi: Double,
    val interest: Double,
    val principal: Double,
    val balance: Double,
    val isPartPayment: Boolean = false,
    val partPaymentAmount: Double = 0.0
)

data class LoanScheduleSummary(
    val rows: List<LoanScheduleRow>,
    val principalPaidTillNow: Double,
    val interestPaidTillNow: Double,
    val totalPaidTillNow: Double,
    val currentEmi: Double,
    val currentOutstanding: Double,
    val remainingInstallments: Int,
    val lastEmiDate: Long?,
    val nextEmiDate: Long?,
    val lastEmiPaidDate: Long?
)

object LoanAmortizationCalculator {

    /**
     * Builds the full amortization schedule for a loan, applying any rate/EMI changes
     * and part-payments in order of effective installment.
     *
     * The schedule recalculates EMI automatically after a part-payment or rate change
     * (keeping remaining tenure roughly constant) unless an explicit EMI_CHANGE adjustment
     * overrides it.
     */
    fun buildSchedule(loan: Loan, adjustments: List<LoanAdjustment>): LoanScheduleSummary {
        val paidSet = loan.paidInstallmentSet()
        val sortedAdjustments = adjustments.sortedBy { it.effectiveFromInstallment }

        var balance = loan.principalAmount
        var rate = loan.interestRate
        var emi = loan.emiAmount
        var tenureRemaining = loan.totalEmis

        val rows = mutableListOf<LoanScheduleRow>()
        val cal = Calendar.getInstance().apply { timeInMillis = loan.startDate }

        var installment = 1
        val maxInstallments = (loan.totalEmis + 12).coerceAtLeast(1) // small safety buffer
        var adjIndex = 0

        while (balance > 1.0 && installment <= maxInstallments) {
            // Apply any adjustments effective at this installment.
            while (adjIndex < sortedAdjustments.size &&
                sortedAdjustments[adjIndex].effectiveFromInstallment == installment) {
                val adj = sortedAdjustments[adjIndex]
                when (adj.type) {
                    AdjustmentType.RATE_CHANGE -> {
                        rate = adj.newInterestRate ?: rate
                        val monthlyRate = rate / 12 / 100
                        if (monthlyRate > 0 && tenureRemaining > 0) {
                            emi = emiFor(balance, monthlyRate, tenureRemaining)
                        }
                    }
                    AdjustmentType.EMI_CHANGE -> {
                        emi = adj.newEmiAmount ?: emi
                    }
                    AdjustmentType.PART_PAYMENT -> {
                        val payment = adj.partPaymentAmount ?: 0.0
                        balance = (balance - payment).coerceAtLeast(0.0)
                        val monthlyRate = rate / 12 / 100
                        if (monthlyRate > 0 && tenureRemaining > 0 && balance > 0) {
                            // Keep EMI same, recompute remaining tenure.
                            tenureRemaining = tenureFor(balance, monthlyRate, emi)
                        }
                    }
                }
                adjIndex++
            }

            if (balance <= 1.0) break

            val monthlyRate = rate / 12 / 100
            val interestPortion = balance * monthlyRate
            var principalPortion = emi - interestPortion
            if (principalPortion > balance) principalPortion = balance
            val actualEmi = interestPortion + principalPortion
            balance = (balance - principalPortion).coerceAtLeast(0.0)
            tenureRemaining = (tenureRemaining - 1).coerceAtLeast(0)

            rows.add(
                LoanScheduleRow(
                    installmentNumber = installment,
                    dueDate = cal.timeInMillis,
                    emi = actualEmi,
                    interest = interestPortion,
                    principal = principalPortion,
                    balance = balance
                )
            )

            cal.add(Calendar.MONTH, 1)
            installment++
        }

        val principalPaid = rows.filter { it.installmentNumber in paidSet }.sumOf { it.principal }
        val interestPaid = rows.filter { it.installmentNumber in paidSet }.sumOf { it.interest }
        val totalPaid = rows.filter { it.installmentNumber in paidSet }.sumOf { it.emi }

        val lastPaidRow = rows.filter { it.installmentNumber in paidSet }.maxByOrNull { it.installmentNumber }
        val nextUnpaidRow = rows.firstOrNull { it.installmentNumber !in paidSet }
        val lastRow = rows.lastOrNull()

        val currentOutstanding = nextUnpaidRow?.let {
            // balance BEFORE this installment is paid = balance after previous installment
            val prevRow = rows.firstOrNull { r -> r.installmentNumber == it.installmentNumber - 1 }
            prevRow?.balance ?: loan.principalAmount
        } ?: (lastRow?.balance ?: 0.0)

        val currentEmi = nextUnpaidRow?.emi ?: lastRow?.emi ?: loan.emiAmount

        return LoanScheduleSummary(
            rows = rows,
            principalPaidTillNow = principalPaid,
            interestPaidTillNow = interestPaid,
            totalPaidTillNow = totalPaid,
            currentEmi = currentEmi,
            currentOutstanding = currentOutstanding,
            remainingInstallments = rows.count { it.installmentNumber !in paidSet },
            lastEmiDate = lastRow?.dueDate,
            nextEmiDate = nextUnpaidRow?.dueDate,
            lastEmiPaidDate = lastPaidRow?.dueDate
        )
    }

    /** Standard EMI formula: P * r * (1+r)^n / ((1+r)^n - 1) */
    fun emiFor(principal: Double, monthlyRate: Double, months: Int): Double {
        if (monthlyRate <= 0) return principal / months.coerceAtLeast(1)
        val factor = Math.pow(1 + monthlyRate, months.toDouble())
        return principal * monthlyRate * factor / (factor - 1)
    }

    /** Solves for the number of months needed to pay off `principal` at `monthlyRate` with a fixed `emi`. */
    fun tenureFor(principal: Double, monthlyRate: Double, emi: Double): Int {
        if (monthlyRate <= 0) return Math.ceil(principal / emi).toInt().coerceAtLeast(0)
        if (emi <= principal * monthlyRate) return 360 // EMI too low to ever close the loan; cap at 30yrs
        val n = Math.log(emi / (emi - principal * monthlyRate)) / Math.log(1 + monthlyRate)
        return Math.ceil(n).toInt().coerceAtLeast(0)
    }
}
