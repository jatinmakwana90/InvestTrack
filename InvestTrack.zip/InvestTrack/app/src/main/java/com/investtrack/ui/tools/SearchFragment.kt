package com.investtrack.ui.tools

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.data.dao.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentSearchBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AccountDetailFragment
import com.investtrack.ui.loans.LoanDetailFragment
import com.investtrack.ui.securities.EditSecurityFragment
import com.investtrack.ui.transactions.EditTransactionFragment
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One search box across transactions, securities, accounts, loans, reminders, goals, deposits, policies and lending. */
@AndroidEntryPoint
class SearchFragment : Fragment() {

    @Inject lateinit var repository: InvestmentRepository
    @Inject lateinit var loanDao: LoanDao
    @Inject lateinit var reminderDao: ReminderDao
    @Inject lateinit var goalDao: GoalDao
    @Inject lateinit var policyDao: PolicyDao
    @Inject lateinit var lendingDao: LendingDao

    private var _b: FragmentSearchBinding? = null
    private val b get() = _b!!
    private lateinit var adapter: ToolRowAdapter

    /** A searchable thing: [text] is what is matched, [row] what is shown. */
    private class Entry(val section: String, val text: String, val row: ToolRow, val open: () -> Unit)
    private var entries: List<Entry> = emptyList()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentSearchBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = ToolRowAdapter(
            onClick = { row -> entries.firstOrNull { it.row.key == row.key }?.open?.invoke() },
            onAction = { _, _ -> }
        )
        b.rvSearch.layoutManager = LinearLayoutManager(requireContext())
        b.rvSearch.adapter = adapter
        b.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        b.etSearchQ.onChange { filter() }
        b.etSearchQ.requestFocus()
        load()
    }

    private val main get() = activity as? MainActivity

    private fun load() {
        viewLifecycleOwner.lifecycleScope.launch {
            val list = mutableListOf<Entry>()
            try {
                val accounts = repository.getAllAccountsList()
                val securities = repository.getAllSecuritiesList()
                val accName = accounts.associate { it.id to it.name }
                val secName = securities.associate { it.id to it.name }

                repository.getAllTransactionsList().sortedByDescending { it.transactionDate }.forEach { t ->
                    val sec = secName[t.securityId].orEmpty(); val acc = accName[t.accountId].orEmpty()
                    list += Entry("Transactions",
                        "$sec $acc ${t.folioNumber} ${t.notes} ${t.type.displayName} ${DateUtil.format(t.transactionDate)} ${t.amount.toLong()}",
                        ToolRow("t:${t.id}", sec, "${t.type.displayName} · $acc · ${DateUtil.format(t.transactionDate)}",
                            CurrencyFormatter.formatFullNoDecimals(t.amount), if (t.notes.isNotBlank()) t.notes else t.folioNumber)
                    ) { main?.navigateTo(EditTransactionFragment.newInstance(t.id)) }
                }
                securities.forEach { s ->
                    list += Entry("Securities", "${s.name} ${s.symbol} ${s.securityCode} ${s.yahooFinanceCode} ${s.isin} ${s.amc} ${s.category}",
                        ToolRow("s:${s.id}", s.name, "${s.type.displayName}${if (s.amc.isNotBlank()) " · ${s.amc}" else ""}",
                            if (s.currentPrice > 0) CurrencyFormatter.formatFull(s.currentPrice) else "")
                    ) { main?.navigateTo(EditSecurityFragment.newInstance(s.id)) }
                }
                accounts.forEach { a ->
                    list += Entry("Accounts", "${a.name} ${a.type.name}",
                        ToolRow("a:${a.id}", a.name, a.type.name.replace("_", " "))
                    ) { main?.navigateTo(AccountDetailFragment.newInstance(a.id)) }
                }
                loanDao.getAllLoansList().forEach { l ->
                    list += Entry("Loans", "${l.loanName} ${l.lenderName}",
                        ToolRow("l:${l.id}", l.loanName, l.lenderName.ifBlank { l.loanType.displayName })
                    ) { main?.navigateTo(LoanDetailFragment.newInstance(l.id)) }
                }
                reminderDao.getAllRemindersList().forEach { r ->
                    list += Entry("Reminders", "${r.title} ${r.description}",
                        ToolRow("r:${r.id}", r.title, r.description)
                    ) { main?.navigateTo(com.investtrack.ui.reminders.RemindersFragment()) }
                }
                goalDao.getAllGoalsList().forEach { g ->
                    list += Entry("Goals", "${g.name} ${g.notes}",
                        ToolRow("g:${g.id}", g.name, "Target ${CurrencyFormatter.format(g.targetAmount)} by ${DateUtil.format(g.targetDate)}")
                    ) { main?.navigateTo(com.investtrack.ui.goals.GoalsFragment()) }
                }
                policyDao.getAllList().forEach { p ->
                    list += Entry("Insurance", "${p.name} ${p.insurer} ${p.policyNumber} ${p.notes}",
                        ToolRow("p:${p.id}", p.name, "${p.insurer} · premium due ${DateUtil.format(p.nextDueDate)}", CurrencyFormatter.formatFullNoDecimals(p.premiumAmount))
                    ) { main?.navigateTo(InsuranceFragment()) }
                }
                lendingDao.getEntriesList().forEach { e ->
                    list += Entry("Lending", "${e.personName} ${e.notes}",
                        ToolRow("n:${e.id}", e.personName, "${if (e.direction == "LENT") "You lent" else "You borrowed"} on ${DateUtil.format(e.date)}",
                            CurrencyFormatter.formatFullNoDecimals(e.amount), e.notes)
                    ) { main?.navigateTo(LendingFragment()) }
                }
            } catch (e: Exception) { /* search whatever could be loaded */ }
            entries = list
            filter()
        }
    }

    private fun filter() {
        val binding = _b ?: return
        val q = binding.etSearchQ.text.toString().trim().lowercase()
        if (q.length < 2) {
            adapter.submitList(emptyList())
            binding.tvSearchEmpty.text = "Type at least 2 letters to search everything in the app."
            binding.tvSearchEmpty.visibility = View.VISIBLE
            return
        }
        val words = q.split(" ").filter { it.isNotBlank() }
        val hits = entries.filter { e -> val t = e.text.lowercase(); words.all { t.contains(it) } }
        val rows = mutableListOf<ToolRow>()
        hits.groupBy { it.section }.forEach { (section, items) ->
            rows += ToolRow("h:$section", "$section (${items.size})", isHeader = true)
            rows += items.take(30).map { it.row }
        }
        adapter.submitList(rows)
        binding.tvSearchEmpty.text = "Nothing found for \"$q\"."
        binding.tvSearchEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() { _b = null; super.onDestroyView() }
}
