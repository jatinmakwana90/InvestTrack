package com.investtrack.ui.tools

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.DepositDao
import com.investtrack.data.models.Deposit
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

/** Calendar of FD, RD and bond maturities, including FDs and bonds you already hold as investments. */
@AndroidEntryPoint
class MaturitiesFragment : ToolListFragment() {

    @Inject lateinit var depositDao: DepositDao
    @Inject lateinit var repository: InvestmentRepository

    override val screenTitle = "Maturity Calendar"
    override val emptyText = "Nothing to show yet.\nTap + to add an FD, RD or bond. You'll get an alert before it matures so the money doesn't sit idle."

    private var deposits: List<Deposit> = emptyList()

    private val kindKeys = listOf("FD", "RD", "BOND", "OTHER")
    private val kindLabels = listOf("Fixed Deposit", "Recurring Deposit", "Bond", "Other")

    override fun observe() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                depositDao.getAll().collect { list -> deposits = list; render() }
            }
        }
    }

    private data class Item(val maturity: Long, val closed: Boolean, val value: Double, val row: ToolRow)

    private fun estimateMaturity(d: Deposit): Double {
        if (d.maturityAmount > 0) return d.maturityAmount
        if (d.kind == "RD") return 0.0
        val years = (d.maturityDate - d.startDate) / (365.25 * 86_400_000.0)
        if (years <= 0) return d.principal
        return d.principal * Math.pow(1 + d.interestRate / 400.0, 4 * years)
    }

    private fun statusFor(maturity: Long, closed: Boolean): Pair<String, Int> {
        if (closed) return "Closed" to R.color.text_secondary
        val days = DateUtil.daysUntil(maturity)
        val date = DateUtil.format(maturity)
        return when {
            days < 0 -> "Matured ${DateUtil.duesLabel(days)} ($date): reinvest it or close this entry" to R.color.loss_red
            days == 0 -> "Matures today ($date)" to R.color.loss_red
            days <= 7 -> "Matures ${DateUtil.duesLabel(days)} ($date)" to R.color.loss_red
            days <= 30 -> "Matures ${DateUtil.duesLabel(days)} ($date)" to R.color.text_accent
            else -> "Matures ${DateUtil.duesLabel(days)} ($date)" to R.color.gain_green
        }
    }

    private suspend fun render() {
        val items = mutableListOf<Item>()

        deposits.forEach { d ->
            val value = estimateMaturity(d)
            val (status, color) = statusFor(d.maturityDate, d.isClosed)
            val kind = kindLabels.getOrElse(kindKeys.indexOf(d.kind)) { "Deposit" }
            items += Item(
                d.maturityDate, d.isClosed, value,
                ToolRow(
                    key = "d:${d.id}", title = d.name,
                    subtitle = "$kind${if (d.institution.isNotBlank()) " · ${d.institution}" else ""} · ${CurrencyFormatter.formatFullNoDecimals(d.principal)} @ ${trim(d.interestRate)}%",
                    amount = if (value > 0) CurrencyFormatter.formatFullNoDecimals(value) else "—",
                    amountSub = if (d.maturityAmount > 0) "At maturity" else "Est. at maturity",
                    status = status, statusColor = color,
                    actions = listOf("edit" to "Edit", (if (d.isClosed) "reopen" to "Reopen" else "close" to "Mark closed"), "delete" to "Delete")
                )
            )
        }

        // FDs and bonds that are held as investments (from Securities + Transactions)
        try {
            val secs = repository.getAllSecuritiesList().associateBy { it.id }
            repository.getAllFolios()
                .filter { it.securityType == SecurityType.FIXED_DEPOSIT || it.securityType == SecurityType.BOND }
                .groupBy { it.securityId }
                .forEach { (secId, folios) ->
                    val sec = secs[secId] ?: return@forEach
                    val maturity = sec.maturityDate ?: return@forEach
                    val value = folios.sumOf { it.currentValue }
                    val (status, color) = statusFor(maturity, false)
                    items += Item(
                        maturity, false, value,
                        ToolRow(
                            key = "s:$secId", title = sec.name,
                            subtitle = "${sec.type.displayName} · from your investments${sec.interestRate?.let { " · @ ${trim(it)}%" } ?: ""}",
                            amount = CurrencyFormatter.formatFullNoDecimals(value), amountSub = "Current value",
                            status = status, statusColor = color
                        )
                    )
                }
        } catch (e: Exception) { /* investments are optional here */ }

        val active = items.filter { !it.closed }.sortedBy { it.maturity }
        val closed = items.filter { it.closed }.sortedByDescending { it.maturity }
        val rows = mutableListOf<ToolRow>()
        if (active.isNotEmpty()) rows += ToolRow("h:up", "Upcoming", isHeader = true)
        rows += active.map { it.row }
        if (closed.isNotEmpty()) { rows += ToolRow("h:closed", "Closed", isHeader = true); rows += closed.map { it.row } }

        fun sumWithin(days: Int) = active.filter { DateUtil.daysUntil(it.maturity) in 0..days }
        val in30 = sumWithin(30); val in90 = sumWithin(90)
        val summary = if (active.isEmpty()) "" else
            "Next 30 days: ${CurrencyFormatter.formatFullNoDecimals(in30.sumOf { it.value })} (${in30.size})\n" +
            "Next 90 days: ${CurrencyFormatter.formatFullNoDecimals(in90.sumOf { it.value })} (${in90.size})"
        submit(rows, summary)
    }

    private fun trim(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else String.format("%.2f", v)

    override fun onAdd() = showDialog(null)

    override fun onRowClick(row: ToolRow) {
        val d = deposits.firstOrNull { "d:${it.id}" == row.key } ?: return
        showDialog(d)
    }

    override fun onRowAction(row: ToolRow, action: String) {
        val d = deposits.firstOrNull { "d:${it.id}" == row.key } ?: return
        when (action) {
            "edit" -> showDialog(d)
            "close" -> viewLifecycleOwner.lifecycleScope.launch { depositDao.insert(d.copy(isClosed = true)) }
            "reopen" -> viewLifecycleOwner.lifecycleScope.launch { depositDao.insert(d.copy(isClosed = false)) }
            "delete" -> MaterialAlertDialogBuilder(requireContext())
                .setTitle("Delete \"${d.name}\"?")
                .setPositiveButton("Delete") { _, _ -> viewLifecycleOwner.lifecycleScope.launch { depositDao.delete(d.id) } }
                .setNegativeButton("Cancel", null).show()
        }
    }

    private fun showDialog(existing: Deposit?) {
        lateinit var name: TextInputEditText
        lateinit var kind: android.widget.AutoCompleteTextView
        lateinit var inst: TextInputEditText
        lateinit var principal: TextInputEditText
        lateinit var rate: TextInputEditText
        lateinit var start: DateField
        lateinit var maturity: DateField
        lateinit var matAmount: TextInputEditText
        lateinit var notes: TextInputEditText

        showFormDialog(
            if (existing == null) "Add FD / Bond" else "Edit FD / Bond",
            build = { f ->
                name = f.text("Name", "e.g. SBI 1-year FD", existing?.name.orEmpty())
                kind = f.dropdown("Type", kindLabels, existing?.let { kindLabels.getOrNull(kindKeys.indexOf(it.kind)) })
                inst = f.text("Bank / issuer (optional)", "e.g. SBI", existing?.institution.orEmpty())
                principal = f.number("Amount invested (₹)", "e.g. 100000", existing?.principal?.let { plain(it) }.orEmpty())
                rate = f.number("Interest rate (% per year)", "e.g. 7.1", existing?.interestRate?.let { plain(it) }.orEmpty())
                start = f.date("Start date", existing?.startDate ?: System.currentTimeMillis())
                maturity = f.date("Maturity date", existing?.maturityDate ?: Calendar.getInstance().apply { add(Calendar.YEAR, 1) }.timeInMillis)
                matAmount = f.number("Amount at maturity (₹, optional)", "Leave blank to estimate", existing?.maturityAmount?.takeIf { it > 0 }?.let { plain(it) }.orEmpty())
                notes = f.text("Notes (optional)", "", existing?.notes.orEmpty(), android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            },
            onSave = {
                val n = name.text.toString().trim()
                val amt = principal.num()
                val s = start.value; val m = maturity.value
                when {
                    n.isEmpty() -> { toast("Enter a name"); false }
                    amt <= 0 -> { toast("Enter the amount invested"); false }
                    s == null || m == null -> { toast("Choose the start and maturity dates"); false }
                    m < s -> { toast("Maturity date must be after the start date"); false }
                    else -> {
                        val key = kindKeys.getOrElse(kindLabels.indexOf(kind.text.toString())) { "FD" }
                        viewLifecycleOwner.lifecycleScope.launch {
                            depositDao.insert(Deposit(
                                id = existing?.id ?: 0, name = n, kind = key, institution = inst.text.toString().trim(),
                                principal = amt, interestRate = rate.num(), startDate = s, maturityDate = m,
                                maturityAmount = matAmount.num(), notes = notes.text.toString().trim(),
                                isClosed = existing?.isClosed ?: false,
                                createdAt = existing?.createdAt ?: System.currentTimeMillis()
                            ))
                        }
                        true
                    }
                }
            }
        )
    }

    private fun plain(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()
}
