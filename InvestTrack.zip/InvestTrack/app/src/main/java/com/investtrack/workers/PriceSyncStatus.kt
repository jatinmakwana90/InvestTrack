package com.investtrack.workers

import android.content.Context

/** Remembers the outcome of the last price sync so the screen can show what happened. */
object PriceSyncStatus {
    private const val PREFS = "investtrack_price_sync"

    fun save(context: Context, summary: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("summary", summary)
            .putLong("at", System.currentTimeMillis())
            .apply()
    }

    fun summary(context: Context): String? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val s = p.getString("summary", null) ?: return null
        val at = p.getLong("at", 0L)
        val time = if (at > 0) java.text.SimpleDateFormat("dd MMM, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(at)) else ""
        return "$s${if (time.isNotEmpty()) "\n($time)" else ""}"
    }
}
