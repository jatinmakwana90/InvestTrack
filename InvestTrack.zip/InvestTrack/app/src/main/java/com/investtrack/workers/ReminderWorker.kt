package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Reminder
import com.investtrack.utils.NotificationHelper
import com.investtrack.utils.ReminderSchedule
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val reminderDao: ReminderDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        val notifId = inputData.getLong("reminder_id", -1L)
        val title = inputData.getString("title") ?: "InvestTrack Reminder"
        val message = inputData.getString("message") ?: ""
        NotificationHelper.showReminderNotification(applicationContext, notifId.toInt(), title, message)

        // Reminders repeat every month: queue the next occurrence if it is still active.
        val dbId = inputData.getLong("db_id", -1L)
        val slot = inputData.getInt("slot", 0)
        if (dbId > 0 && slot in 1..2) {
            reminderDao.getReminderById(dbId)?.let { r ->
                if (r.isActive) scheduleSlot(applicationContext, r, slot, ExistingWorkPolicy.APPEND_OR_REPLACE)
            }
        }
        return Result.success()
    }

    companion object {

        /** Schedule both advance reminders, e.g. SIP due on the 10th → remind on the 8th and 9th. */
        fun scheduleAll(context: Context, reminder: Reminder) {
            cancelAll(context, reminder.id)
            if (!reminder.isActive) return
            scheduleSlot(context, reminder, 1, ExistingWorkPolicy.REPLACE)
            scheduleSlot(context, reminder, 2, ExistingWorkPolicy.REPLACE)
        }

        private fun scheduleSlot(context: Context, r: Reminder, slot: Int, policy: ExistingWorkPolicy) {
            val enabled = if (slot == 1) r.remind1Enabled else r.remind2Enabled
            if (!enabled) return
            val daysBefore = if (slot == 1) r.remind1DaysBefore else r.remind2DaysBefore
            val hour = if (slot == 1) r.remind1Hour else r.remind2Hour
            val minute = if (slot == 1) r.remind1Minute else r.remind2Minute

            val whenText = when (daysBefore) {
                0 -> "due today"
                1 -> "due tomorrow"
                else -> "due in $daysBefore days"
            }
            val amtText = if (r.amount > 0) " (₹${String.format("%,.0f", r.amount)})" else ""
            val message = "${r.type.displayName} $whenText — ${ReminderSchedule.ordinal(r.dueDayOfMonth)}$amtText. ${r.description}".trim()

            val triggerAt = ReminderSchedule.nextTrigger(r.dueDayOfMonth, daysBefore, hour, minute)
            val delay = (triggerAt - System.currentTimeMillis()).coerceAtLeast(0L)
            val workName = "reminder_${r.id}_$slot"

            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(workDataOf(
                    "reminder_id" to (r.id * 10 + slot),
                    "db_id" to r.id,
                    "slot" to slot,
                    "title" to r.title,
                    "message" to message
                ))
                .addTag(workName)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(workName, policy, request)
        }

        fun cancelAll(context: Context, reminderId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork("reminder_${reminderId}_1")
            WorkManager.getInstance(context).cancelUniqueWork("reminder_${reminderId}_2")
        }
    }
}
