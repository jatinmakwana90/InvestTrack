package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Reminder
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val reminderDao: ReminderDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        val reminderId = inputData.getLong("reminder_id", -1L)
        val title = inputData.getString("title") ?: "InvestTrack Reminder"
        val message = inputData.getString("message") ?: ""
        NotificationHelper.showReminderNotification(
            applicationContext, reminderId.toInt(), title, message
        )
        return Result.success()
    }

    companion object {

        /**
         * Schedule both advance reminders for a Reminder object.
         * e.g. SIP due on 10th → remind on 8th and 9th at chosen times.
         */
        fun scheduleAll(context: Context, reminder: Reminder) {
            cancelAll(context, reminder.id)

            val dueDay = reminder.dueDayOfMonth
            val amtText = if (reminder.amount > 0) " (₹${String.format("%,.0f", reminder.amount)})" else ""

            if (reminder.remind1Enabled) {
                val notify1Day = dueDay - reminder.remind1DaysBefore
                val msg1 = "${reminder.type.displayName} due in ${reminder.remind1DaysBefore} day(s) on ${dueDay}th$amtText. ${reminder.description}"
                scheduleOne(context, reminder.id * 10 + 1, "reminder_${reminder.id}_1",
                    reminder.title, msg1, notify1Day, reminder.remind1Hour, reminder.remind1Minute)
            }

            if (reminder.remind2Enabled) {
                val notify2Day = dueDay - reminder.remind2DaysBefore
                val msg2 = "${reminder.type.displayName} due tomorrow on ${dueDay}th$amtText. ${reminder.description}"
                scheduleOne(context, reminder.id * 10 + 2, "reminder_${reminder.id}_2",
                    reminder.title, msg2, notify2Day, reminder.remind2Hour, reminder.remind2Minute)
            }
        }

        private fun scheduleOne(
            context: Context, notifId: Long, workName: String,
            title: String, message: String,
            dayOfMonth: Int, hour: Int, minute: Int
        ) {
            val cal = Calendar.getInstance().apply {
                // Set to this month first
                set(Calendar.DAY_OF_MONTH, dayOfMonth.coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                // If already past, schedule for next month
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.MONTH, 1)
                    set(Calendar.DAY_OF_MONTH, dayOfMonth.coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
                }
            }

            val delay = cal.timeInMillis - System.currentTimeMillis()
            val data = workDataOf(
                "reminder_id" to notifId,
                "title" to title,
                "message" to message
            )

            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .addTag(workName)
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                workName, ExistingWorkPolicy.REPLACE, request
            )
        }

        fun cancelAll(context: Context, reminderId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork("reminder_${reminderId}_1")
            WorkManager.getInstance(context).cancelUniqueWork("reminder_${reminderId}_2")
        }
    }
}
