package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.ReminderDao
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val reminderDao: ReminderDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        val reminderId = inputData.getLong("reminder_id", -1L)
        val title = inputData.getString("title") ?: "InvestTrack Reminder"
        val description = inputData.getString("description") ?: ""
        val amount = inputData.getDouble("amount", 0.0)

        val msg = buildString {
            append(description.ifBlank { "Time for your scheduled investment!" })
            if (amount > 0) append(" • Amount: ₹${String.format("%,.0f", amount)}")
        }
        NotificationHelper.showReminderNotification(
            applicationContext, reminderId.toInt(), title, msg
        )
        return Result.success()
    }

    companion object {
        fun schedule(context: Context, reminder: com.investtrack.data.models.Reminder) {
            val cal = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, reminder.dayOfMonth)
                set(Calendar.HOUR_OF_DAY, reminder.hour)
                set(Calendar.MINUTE, reminder.minute)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) {
                    add(Calendar.MONTH, 1) // schedule next month if day passed
                }
            }

            val delay = cal.timeInMillis - System.currentTimeMillis()

            val data = workDataOf(
                "reminder_id" to reminder.id,
                "title" to reminder.title,
                "description" to reminder.description,
                "amount" to reminder.amount
            )

            val request = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .addTag("reminder_${reminder.id}")
                .build()

            WorkManager.getInstance(context).enqueueUniqueWork(
                "reminder_${reminder.id}",
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context, reminderId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork("reminder_$reminderId")
        }
    }
}
