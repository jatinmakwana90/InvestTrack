package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

enum class AdjustmentType { RATE_CHANGE, EMI_CHANGE, PART_PAYMENT }

/**
 * Represents an event that changes the trajectory of a loan's amortization schedule
 * from a given installment number onwards: a rate change, an EMI change, or a
 * one-time part-payment (lump sum reducing outstanding principal).
 */
@Parcelize
@Serializable
@Entity(tableName = "loan_adjustments")
data class LoanAdjustment(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanId: Long,
    val type: AdjustmentType,
    // Installment number (1-based) from which this adjustment takes effect.
    val effectiveFromInstallment: Int,
    val effectiveDate: Long,
    // New annual interest rate (%) for RATE_CHANGE.
    val newInterestRate: Double? = null,
    // New monthly EMI amount for EMI_CHANGE.
    val newEmiAmount: Double? = null,
    // Lump sum amount paid for PART_PAYMENT.
    val partPaymentAmount: Double? = null,
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
