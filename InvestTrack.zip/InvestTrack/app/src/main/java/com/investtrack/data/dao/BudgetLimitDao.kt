package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.BudgetLimit
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetLimitDao {
    @Query("SELECT * FROM budget_limits ORDER BY monthlyLimit DESC")
    fun getAllBudgetLimits(): Flow<List<BudgetLimit>>

    @Query("SELECT * FROM budget_limits WHERE securityType = :type LIMIT 1")
    suspend fun getBudgetLimitForType(type: String): BudgetLimit?

    // One budget per security type — REPLACE keeps "set/edit limit" a single upsert call.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudgetLimit(budgetLimit: BudgetLimit): Long

    @Query("DELETE FROM budget_limits WHERE id = :id")
    suspend fun deleteBudgetLimit(id: Long)

    @Query("SELECT * FROM budget_limits ORDER BY monthlyLimit DESC")
    suspend fun getAllBudgetLimitsList(): List<BudgetLimit>
}
