package com.investtrack.ui.budget

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.models.IncomeExpenseEntry
import com.investtrack.data.models.IncomeExpenseType
import com.investtrack.databinding.FragmentIncomeExpenseBinding
import com.investtrack.databinding.ItemIncomeExpenseBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class IncomeExpenseViewModel @Inject constructor(
    private val incomeExpenseDao: IncomeExpenseDao
) : ViewModel() {
    val entries: StateFlow<List<IncomeExpenseEntry>> = incomeExpenseDao.getAllEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalIncome: StateFlow<Double> = entries.map { list ->
        list.filter { it.type == IncomeExpenseType.INCOME }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = entries.map { list ->
        list.filter { it.type == IncomeExpenseType.EXPENSE }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun addEntry(label: String, amount: Double, type: IncomeExpenseType) {
        viewModelScope.launch {
            incomeExpenseDao.insertEntry(IncomeExpenseEntry(label = label, amount = amount, type = type))
        }
    }

    fun deleteEntry(id: Long) {
        viewModelScope.launch { incomeExpenseDao.deleteEntry(id) }
    }
}

@AndroidEntryPoint
class IncomeExpenseFragment : Fragment() {
    private var _binding: FragmentIncomeExpenseBinding? = null
    private val binding get() = _binding!!
    private val viewModel: IncomeExpenseViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentIncomeExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = IncomeExpenseAdapter(
            onDelete = { entry ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Entry")
                    .setMessage("Remove \"${entry.label}\"?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteEntry(entry.id) }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvEntries.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.fabAddEntry.setOnClickListener { showAddEntryDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.entries.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalIncome.collect { updateNet() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalExpense.collect { updateNet() }
        }
    }

    private fun updateNet() {
        val income = viewModel.totalIncome.value
        val expense = viewModel.totalExpense.value
        val net = income - expense
        binding.tvTotalIncome.text = CurrencyFormatter.formatFullNoDecimals(income)
        binding.tvTotalExpense.text = CurrencyFormatter.formatFullNoDecimals(expense)
        binding.tvNetSavings.text = CurrencyFormatter.formatFullNoDecimals(net)
        binding.tvNetSavings.setTextColor(
            requireContext().getColor(if (net >= 0) R.color.gain_green else R.color.loss_red)
        )
    }

    private fun showAddEntryDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_income_expense, null)
        val btnIncome = dialogView.findViewById<MaterialButton>(R.id.btn_type_income)
        val btnExpense = dialogView.findViewById<MaterialButton>(R.id.btn_type_expense)
        val etLabel = dialogView.findViewById<TextInputEditText>(R.id.et_entry_label)
        val etAmount = dialogView.findViewById<TextInputEditText>(R.id.et_entry_amount)

        var selectedType = IncomeExpenseType.INCOME

        fun updateTypeButtons() {
            btnIncome.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (selectedType == IncomeExpenseType.INCOME) R.color.gain_green else R.color.divider)
            )
            btnExpense.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (selectedType == IncomeExpenseType.EXPENSE) R.color.loss_red else R.color.divider)
            )
        }
        btnIncome.setOnClickListener { selectedType = IncomeExpenseType.INCOME; updateTypeButtons() }
        btnExpense.setOnClickListener { selectedType = IncomeExpenseType.EXPENSE; updateTypeButtons() }
        updateTypeButtons()

        AlertDialog.Builder(requireContext())
            .setTitle("Add Entry")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val label = etLabel.text?.toString()?.trim().orEmpty()
                val amount = etAmount.text?.toString()?.toDoubleOrNull()
                if (label.isEmpty()) {
                    Toast.makeText(requireContext(), "Enter a label", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (amount == null || amount <= 0) {
                    Toast.makeText(requireContext(), "Enter a valid amount", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.addEntry(label, amount, selectedType)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class IncomeExpenseAdapter(
    private val onDelete: (IncomeExpenseEntry) -> Unit
) : ListAdapter<IncomeExpenseEntry, IncomeExpenseAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemIncomeExpenseBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(entry: IncomeExpenseEntry) {
            val isIncome = entry.type == IncomeExpenseType.INCOME
            val colorRes = if (isIncome) R.color.gain_green else R.color.loss_red
            val color = b.root.context.getColor(colorRes)

            b.tvEntryLabel.text = entry.label
            b.tvEntryAmount.text = "${if (isIncome) "+" else "-"}${CurrencyFormatter.formatFullNoDecimals(entry.amount)}"
            b.tvEntryAmount.setTextColor(color)
            b.viewTypeIndicator.setBackgroundColor(color)

            b.btnDelete.setOnClickListener { onDelete(entry) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemIncomeExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<IncomeExpenseEntry>() {
            override fun areItemsTheSame(a: IncomeExpenseEntry, b: IncomeExpenseEntry) = a.id == b.id
            override fun areContentsTheSame(a: IncomeExpenseEntry, b: IncomeExpenseEntry) = a == b
        }
    }
}
