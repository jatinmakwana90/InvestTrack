package com.investtrack.ui.budget

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.models.IncomeExpenseEntry
import com.investtrack.data.models.IncomeExpenseType
import com.investtrack.databinding.FragmentIncomeExpenseBinding
import com.investtrack.databinding.ItemIncomeExpenseBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class IncomeExpenseViewModel @Inject constructor(
    private val incomeExpenseDao: IncomeExpenseDao
) : ViewModel() {
    val entries: StateFlow<List<IncomeExpenseEntry>> = incomeExpenseDao.getAllEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalIncome: StateFlow<Double> = entries.map { list ->
        list.filter { it.type == IncomeExpenseType.INCOME }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalExpense: StateFlow<Double> = entries.map { list ->
        list.filter { it.type == IncomeExpenseType.EXPENSE }.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    /** New entries go to the end of the user's sequence. */
    fun addEntry(label: String, amount: Double, type: IncomeExpenseType) {
        viewModelScope.launch {
            val next = (incomeExpenseDao.getMaxSortOrder() ?: -1) + 1
            incomeExpenseDao.insertEntry(
                IncomeExpenseEntry(label = label, amount = amount, type = type, sortOrder = next)
            )
        }
    }

    /** Edits label/amount/type; keeps the entry's position, date and everything else as-is. */
    fun updateEntry(id: Long, label: String, amount: Double, type: IncomeExpenseType) {
        viewModelScope.launch {
            val existing = incomeExpenseDao.getEntryById(id) ?: return@launch
            incomeExpenseDao.updateEntry(existing.copy(label = label, amount = amount, type = type))
        }
    }

    /** Saves the sequence exactly as shown on screen after a drag. */
    fun saveOrder(ordered: List<IncomeExpenseEntry>) {
        viewModelScope.launch {
            incomeExpenseDao.updateEntries(ordered.mapIndexed { index, e -> e.copy(sortOrder = index) })
        }
    }

    fun deleteEntry(id: Long) {
        viewModelScope.launch { incomeExpenseDao.deleteEntry(id) }
    }
}

@AndroidEntryPoint
class IncomeExpenseFragment : Fragment() {
    private var _binding: FragmentIncomeExpenseBinding? = null
    private val binding get() = _binding!!
    private val viewModel: IncomeExpenseViewModel by viewModels()
    private lateinit var touchHelper: ItemTouchHelper

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentIncomeExpenseBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = IncomeExpenseAdapter(
            onEdit = { entry -> showEntryDialog(entry) },
            onDelete = { entry ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Entry")
                    .setMessage("Remove \"${entry.label}\"?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteEntry(entry.id) }
                    .setNegativeButton("Cancel", null).show()
            },
            onStartDrag = { holder -> touchHelper.startDrag(holder) }
        )
        binding.rvEntries.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        // Drag by the ☰ handle; the new sequence is saved when the finger lifts.
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            private var moved = false

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                adapter.moveItem(from, to)
                moved = true
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
            override fun isLongPressDragEnabled() = false

            override fun clearView(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(recyclerView, viewHolder)
                if (moved) {
                    moved = false
                    viewModel.saveOrder(adapter.currentItems())
                }
            }
        })
        touchHelper.attachToRecyclerView(binding.rvEntries)

        binding.fabAddEntry.setOnClickListener { showEntryDialog(null) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.entries.collect { list ->
                adapter.setItems(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalIncome.collect { updateNet() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalExpense.collect { updateNet() }
        }
    }

    private fun updateNet() {
        val income = viewModel.totalIncome.value
        val expense = viewModel.totalExpense.value
        val net = income - expense
        binding.tvTotalIncome.text = CurrencyFormatter.formatFullNoDecimals(income)
        binding.tvTotalExpense.text = CurrencyFormatter.formatFullNoDecimals(expense)
        binding.tvNetSavings.text = CurrencyFormatter.formatFullNoDecimals(net)
        binding.tvNetSavings.setTextColor(
            requireContext().getColor(if (net >= 0) R.color.gain_green else R.color.loss_red)
        )
    }

    private fun formatAmount(v: Double): String =
        if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

    /** Same dialog for adding (existing == null) and editing an entry. */
    private fun showEntryDialog(existing: IncomeExpenseEntry?) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_income_expense, null)
        val btnIncome = dialogView.findViewById<MaterialButton>(R.id.btn_type_income)
        val btnExpense = dialogView.findViewById<MaterialButton>(R.id.btn_type_expense)
        val etLabel = dialogView.findViewById<TextInputEditText>(R.id.et_entry_label)
        val etAmount = dialogView.findViewById<TextInputEditText>(R.id.et_entry_amount)

        var selectedType = existing?.type ?: IncomeExpenseType.INCOME
        existing?.let {
            etLabel.setText(it.label)
            etAmount.setText(formatAmount(it.amount))
        }

        fun updateTypeButtons() {
            btnIncome.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (selectedType == IncomeExpenseType.INCOME) R.color.gain_green else R.color.divider)
            )
            btnExpense.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (selectedType == IncomeExpenseType.EXPENSE) R.color.loss_red else R.color.divider)
            )
        }
        btnIncome.setOnClickListener { selectedType = IncomeExpenseType.INCOME; updateTypeButtons() }
        btnExpense.setOnClickListener { selectedType = IncomeExpenseType.EXPENSE; updateTypeButtons() }
        updateTypeButtons()

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle(if (existing == null) "Add Entry" else "Edit Entry")
            .setView(dialogView)
            .setPositiveButton("Save", null)
            .setNegativeButton("Cancel", null)
            .create()

        // Overridden so a mistake keeps the dialog open instead of throwing away what was typed.
        dialog.setOnShowListener {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val label = etLabel.text?.toString()?.trim().orEmpty()
                val amount = etAmount.text?.toString()?.toDoubleOrNull()
                if (label.isEmpty()) {
                    Toast.makeText(requireContext(), "Enter a label", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (amount == null || amount <= 0) {
                    Toast.makeText(requireContext(), "Enter a valid amount", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (existing == null) viewModel.addEntry(label, amount, selectedType)
                else viewModel.updateEntry(existing.id, label, amount, selectedType)
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class IncomeExpenseAdapter(
    private val onEdit: (IncomeExpenseEntry) -> Unit,
    private val onDelete: (IncomeExpenseEntry) -> Unit,
    private val onStartDrag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<IncomeExpenseAdapter.VH>() {

    private val items = mutableListOf<IncomeExpenseEntry>()

    fun setItems(newItems: List<IncomeExpenseEntry>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    fun currentItems(): List<IncomeExpenseEntry> = items.toList()

    fun moveItem(from: Int, to: Int) {
        val item = items.removeAt(from)
        items.add(to, item)
        notifyItemMoved(from, to)
    }

    inner class VH(private val b: ItemIncomeExpenseBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(entry: IncomeExpenseEntry) {
            val isIncome = entry.type == IncomeExpenseType.INCOME
            val color = b.root.context.getColor(if (isIncome) R.color.gain_green else R.color.loss_red)

            b.tvEntryLabel.text = entry.label
            b.tvEntryAmount.text = "${if (isIncome) "+" else "-"}${CurrencyFormatter.formatFullNoDecimals(entry.amount)}"
            b.tvEntryAmount.setTextColor(color)
            b.viewTypeIndicator.setBackgroundColor(color)

            b.root.setOnClickListener { onEdit(entry) }
            b.btnEdit.setOnClickListener { onEdit(entry) }
            b.btnDelete.setOnClickListener { onDelete(entry) }
            b.tvDragHandle.setOnTouchListener { _, event ->
                if (event.actionMasked == MotionEvent.ACTION_DOWN) onStartDrag(this)
                false
            }
        }
    }

    override fun getItemCount() = items.size
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemIncomeExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
}
