package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.LoanAdjustment
import kotlinx.coroutines.flow.Flow

@Dao
interface LoanAdjustmentDao {
    @Query("SELECT * FROM loan_adjustments WHERE loanId = :loanId ORDER BY effectiveFromInstallment ASC")
    fun getAdjustmentsForLoan(loanId: Long): Flow<List<LoanAdjustment>>

    @Query("SELECT * FROM loan_adjustments WHERE loanId = :loanId ORDER BY effectiveFromInstallment ASC")
    suspend fun getAdjustmentsForLoanList(loanId: Long): List<LoanAdjustment>

    @Insert
    suspend fun insert(adjustment: LoanAdjustment): Long

    @Delete
    suspend fun delete(adjustment: LoanAdjustment)

    @Query("DELETE FROM loan_adjustments WHERE loanId = :loanId")
    suspend fun deleteAllForLoan(loanId: Long)
}
