package com.investtrack.ui.loans

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Loan
import com.investtrack.data.models.LoanAdjustment
import com.investtrack.databinding.FragmentLoansBinding
import com.investtrack.databinding.ItemLoanBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.utils.LoanScheduleSummary
import com.investtrack.workers.ReminderWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/** A loan paired with its live-computed schedule summary (outstanding, EMIs paid, current EMI). */
data class LoanWithSchedule(
    val loan: Loan,
    val schedule: LoanScheduleSummary
)

@HiltViewModel
class LoansViewModel @Inject constructor(
    private val loanDao: LoanDao,
    private val adjustmentDao: LoanAdjustmentDao,
    private val reminderDao: ReminderDao,
    @dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context
) : ViewModel() {
    val loans: StateFlow<List<Loan>> = loanDao.getAllLoans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live-computed per loan — this is what keeps the list screen's outstanding/EMI figures
    // correct even after part-payments, rate/EMI changes, or marking installments paid on the
    // detail screen, instead of relying on the Loan entity's stored (and easily stale) fields.
    val loansWithSchedule: StateFlow<List<LoanWithSchedule>> = loans.map { list ->
        list.map { loan ->
            val adjustments = adjustmentDao.getAdjustmentsForLoanList(loan.id)
            LoanWithSchedule(loan, LoanAmortizationCalculator.buildSchedule(loan, adjustments))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalOutstanding: StateFlow<Double> = loansWithSchedule.map { list ->
        list.filter { it.loan.isActive }.sumOf { it.schedule.currentOutstanding }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalEmi: StateFlow<Double> = loansWithSchedule.map { list ->
        list.filter { it.loan.isActive && it.schedule.remainingInstallments > 0 }.sumOf { it.schedule.currentEmi }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun delete(id: Long) = viewModelScope.launch {
        // Clean up any EMI reminder linked to this loan so it doesn't keep firing for a loan
        // that no longer exists.
        reminderDao.getReminderForLoan(id)?.let { reminder ->
            ReminderWorker.cancelAll(appContext, reminder.id)
            reminderDao.deleteReminderForLoan(id)
        }
        loanDao.deleteLoan(id)
    }
}

@AndroidEntryPoint
class LoansFragment : Fragment() {
    private var _binding: FragmentLoansBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LoansViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLoansBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = LoanAdapter(
            onClick = { item ->
                (activity as? MainActivity)?.navigateTo(LoanDetailFragment.newInstance(item.loan.id))
            },
            onEdit = { item ->
                (activity as? MainActivity)?.navigateTo(AddEditLoanFragment.newInstance(item.loan.id))
            },
            onDelete = { item ->
                android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Loan")
                    .setMessage("Remove \"${item.loan.loanName}\"?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(item.loan.id) }
                    .setNegativeButton("Cancel", null).show()
            }
        )

        binding.rvLoans.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.fabAddLoan.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddEditLoanFragment.newInstance(0L))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.loansWithSchedule.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                val activeCount = list.count { it.loan.isActive }
                binding.tvActiveCount.text = if (activeCount > 0)
                    "$activeCount active loan${if (activeCount > 1) "s" else ""}" else ""
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalOutstanding.collect { total ->
                binding.tvTotalOutstanding.text = CurrencyFormatter.format(total)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalEmi.collect { emi ->
                binding.tvTotalEmi.text = "Monthly EMI: ${CurrencyFormatter.format(emi)}"
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class LoanAdapter(
    private val onClick: (LoanWithSchedule) -> Unit,
    private val onEdit: (LoanWithSchedule) -> Unit,
    private val onDelete: (LoanWithSchedule) -> Unit
) : ListAdapter<LoanWithSchedule, LoanAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemLoanBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: LoanWithSchedule) {
            val loan = item.loan
            val schedule = item.schedule
            b.tvLoanName.text = loan.loanName
            b.tvLoanType.text = loan.loanType.displayName
            b.tvLender.text = loan.lenderName.ifEmpty { "—" }
            b.tvOutstanding.text = CurrencyFormatter.format(schedule.currentOutstanding)
            b.tvEmi.text = "EMI: ${CurrencyFormatter.format(schedule.currentEmi)}/mo"
            b.tvRate.text = "${loan.interestRate}% p.a."

            val totalInstallments = schedule.rows.size
            val paidCount = totalInstallments - schedule.remainingInstallments
            val progress = if (totalInstallments > 0)
                ((paidCount.toFloat() / totalInstallments) * 100).toInt() else 0
            b.progressLoan.progress = progress
            b.tvProgress.text = "$paidCount/$totalInstallments EMIs paid"

            b.tvEmiDay.text = "Due: ${loan.emiDay}th of every month"

            b.root.setOnClickListener { onClick(item) }
            b.btnEdit.setOnClickListener { onEdit(item) }
            b.btnDelete.setOnClickListener { onDelete(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLoanBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<LoanWithSchedule>() {
            override fun areItemsTheSame(a: LoanWithSchedule, b: LoanWithSchedule) = a.loan.id == b.loan.id
            override fun areContentsTheSame(a: LoanWithSchedule, b: LoanWithSchedule) = a == b
        }
    }
}
