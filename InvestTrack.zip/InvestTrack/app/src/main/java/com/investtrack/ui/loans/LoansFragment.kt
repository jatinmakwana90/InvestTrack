package com.investtrack.ui.loans

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.models.Loan
import com.investtrack.databinding.FragmentLoansBinding
import com.investtrack.databinding.ItemLoanBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoansViewModel @Inject constructor(
    private val loanDao: LoanDao
) : ViewModel() {
    val loans: StateFlow<List<Loan>> = loanDao.getAllLoans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalOutstanding: StateFlow<Double> = loans.map { list ->
        list.sumOf { it.outstandingAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalEmi: StateFlow<Double> = loans.map { list ->
        list.sumOf { it.emiAmount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun delete(id: Long) = viewModelScope.launch { loanDao.deleteLoan(id) }
}

@AndroidEntryPoint
class LoansFragment : Fragment() {
    private var _binding: FragmentLoansBinding? = null
    private val binding get() = _binding!!
    private val viewModel: LoansViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentLoansBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = LoanAdapter(
            onEdit = { loan ->
                (activity as? MainActivity)?.navigateTo(AddEditLoanFragment.newInstance(loan.id))
            },
            onDelete = { loan ->
                android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Loan")
                    .setMessage("Remove \"${loan.loanName}\"?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(loan.id) }
                    .setNegativeButton("Cancel", null).show()
            }
        )

        binding.rvLoans.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.fabAddLoan.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddEditLoanFragment.newInstance(0L))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.loans.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalOutstanding.collect { total ->
                binding.tvTotalOutstanding.text = CurrencyFormatter.format(total)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalEmi.collect { emi ->
                binding.tvTotalEmi.text = "Monthly EMI: ${CurrencyFormatter.format(emi)}"
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class LoanAdapter(
    private val onEdit: (Loan) -> Unit,
    private val onDelete: (Loan) -> Unit
) : ListAdapter<Loan, LoanAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemLoanBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(loan: Loan) {
            b.tvLoanName.text = loan.loanName
            b.tvLoanType.text = loan.loanType.displayName
            b.tvLender.text = loan.lenderName.ifEmpty { "—" }
            b.tvOutstanding.text = CurrencyFormatter.format(loan.outstandingAmount)
            b.tvEmi.text = "EMI: ${CurrencyFormatter.format(loan.emiAmount)}/mo"
            b.tvRate.text = "${loan.interestRate}% p.a."

            val progress = if (loan.totalEmis > 0)
                ((loan.emisPaid.toFloat() / loan.totalEmis) * 100).toInt() else 0
            b.progressLoan.progress = progress
            b.tvProgress.text = "${loan.emisPaid}/${loan.totalEmis} EMIs paid"

            val emiDay = loan.emiDay
            b.tvEmiDay.text = "Due: ${emiDay}th of every month"

            b.btnEdit.setOnClickListener { onEdit(loan) }
            b.btnDelete.setOnClickListener { onDelete(loan) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLoanBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Loan>() {
            override fun areItemsTheSame(a: Loan, b: Loan) = a.id == b.id
            override fun areContentsTheSame(a: Loan, b: Loan) = a == b
        }
    }
}
