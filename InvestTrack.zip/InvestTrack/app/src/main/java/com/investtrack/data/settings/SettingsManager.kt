package com.investtrack.data.settings

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

enum class ReturnDisplayMode { ABS, XIRR }
enum class AmountDisplayMode { FULL, ROUNDED }

@Singleton
class SettingsManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("investtrack_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_RETURN_MODE = "return_mode"
        private const val KEY_AMOUNT_MODE = "amount_mode"
    }

    private val _returnMode = MutableStateFlow(loadReturnMode())
    val returnMode: StateFlow<ReturnDisplayMode> = _returnMode

    private val _amountMode = MutableStateFlow(loadAmountMode())
    val amountMode: StateFlow<AmountDisplayMode> = _amountMode

    private fun loadReturnMode(): ReturnDisplayMode {
        val saved = prefs.getString(KEY_RETURN_MODE, ReturnDisplayMode.ABS.name)
        return try { ReturnDisplayMode.valueOf(saved ?: ReturnDisplayMode.ABS.name) } catch (e: Exception) { ReturnDisplayMode.ABS }
    }

    private fun loadAmountMode(): AmountDisplayMode {
        val saved = prefs.getString(KEY_AMOUNT_MODE, AmountDisplayMode.ROUNDED.name)
        return try { AmountDisplayMode.valueOf(saved ?: AmountDisplayMode.ROUNDED.name) } catch (e: Exception) { AmountDisplayMode.ROUNDED }
    }

    fun setReturnMode(mode: ReturnDisplayMode) {
        prefs.edit().putString(KEY_RETURN_MODE, mode.name).apply()
        _returnMode.value = mode
    }

    fun setAmountMode(mode: AmountDisplayMode) {
        prefs.edit().putString(KEY_AMOUNT_MODE, mode.name).apply()
        _amountMode.value = mode
    }

    fun toggleReturnMode() {
        setReturnMode(if (_returnMode.value == ReturnDisplayMode.ABS) ReturnDisplayMode.XIRR else ReturnDisplayMode.ABS)
    }
}
