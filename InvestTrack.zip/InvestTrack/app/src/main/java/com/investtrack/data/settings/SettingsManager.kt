package com.investtrack.data.settings

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

enum class ReturnDisplayMode { ABS, XIRR }
enum class AmountDisplayMode { FULL, ROUNDED }
enum class DarkModeOption { SYSTEM, LIGHT, DARK }

@Singleton
class SettingsManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("investtrack_settings", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_RETURN_MODE = "return_mode"
        private const val KEY_AMOUNT_MODE = "amount_mode"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_APP_NAME = "app_name"
        const val DEFAULT_APP_NAME = "InvestTrack"
    }

    private val _returnMode = MutableStateFlow(loadReturnMode())
    val returnMode: StateFlow<ReturnDisplayMode> = _returnMode

    private val _amountMode = MutableStateFlow(loadAmountMode())
    val amountMode: StateFlow<AmountDisplayMode> = _amountMode

    private val _appName = MutableStateFlow(prefs.getString(KEY_APP_NAME, DEFAULT_APP_NAME)?.ifBlank { DEFAULT_APP_NAME } ?: DEFAULT_APP_NAME)
    val appName: StateFlow<String> = _appName

    fun setAppName(name: String) {
        val clean = name.trim().ifBlank { DEFAULT_APP_NAME }
        prefs.edit().putString(KEY_APP_NAME, clean).apply()
        _appName.value = clean
    }

    private val _darkMode = MutableStateFlow(loadDarkMode())
    val darkMode: StateFlow<DarkModeOption> = _darkMode

    private fun loadReturnMode(): ReturnDisplayMode {
        val saved = prefs.getString(KEY_RETURN_MODE, ReturnDisplayMode.ABS.name)
        return try { ReturnDisplayMode.valueOf(saved ?: ReturnDisplayMode.ABS.name) } catch (e: Exception) { ReturnDisplayMode.ABS }
    }

    private fun loadAmountMode(): AmountDisplayMode {
        val saved = prefs.getString(KEY_AMOUNT_MODE, AmountDisplayMode.ROUNDED.name)
        return try { AmountDisplayMode.valueOf(saved ?: AmountDisplayMode.ROUNDED.name) } catch (e: Exception) { AmountDisplayMode.ROUNDED }
    }

    fun setReturnMode(mode: ReturnDisplayMode) {
        prefs.edit().putString(KEY_RETURN_MODE, mode.name).apply()
        _returnMode.value = mode
    }

    fun setAmountMode(mode: AmountDisplayMode) {
        prefs.edit().putString(KEY_AMOUNT_MODE, mode.name).apply()
        _amountMode.value = mode
    }

    private fun loadDarkMode(): DarkModeOption {
        val saved = prefs.getString(KEY_DARK_MODE, DarkModeOption.SYSTEM.name)
        return try { DarkModeOption.valueOf(saved ?: DarkModeOption.SYSTEM.name) } catch (e: Exception) { DarkModeOption.SYSTEM }
    }

    fun setDarkMode(mode: DarkModeOption) {
        prefs.edit().putString(KEY_DARK_MODE, mode.name).apply()
        _darkMode.value = mode
    }

    fun toggleReturnMode() {
        setReturnMode(if (_returnMode.value == ReturnDisplayMode.ABS) ReturnDisplayMode.XIRR else ReturnDisplayMode.ABS)
    }
}
