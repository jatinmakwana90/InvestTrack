package com.investtrack.ui.masters

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.models.Account
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAccountMasterListBinding
import com.investtrack.databinding.ItemAccountMasterBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AddAccountFragment
import com.investtrack.ui.accounts.EditAccountFragment
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AccountMasterViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {
    val accounts: StateFlow<List<Account>> = repository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

@AndroidEntryPoint
class AccountMasterListFragment : Fragment() {
    private var _binding: FragmentAccountMasterListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AccountMasterViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAccountMasterListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        val adapter = AccountMasterAdapter { account ->
            (activity as? MainActivity)?.navigateTo(EditAccountFragment.newInstance(account.id))
        }
        binding.rvAccounts.apply { layoutManager = LinearLayoutManager(requireContext()); this.adapter = adapter }
        binding.fabAddAccount.setOnClickListener { (activity as? MainActivity)?.navigateTo(AddAccountFragment()) }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.accounts.collect { list -> adapter.submitList(list); binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE }
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class AccountMasterAdapter(private val onEdit: (Account) -> Unit) : ListAdapter<Account, AccountMasterAdapter.VH>(DIFF) {
    inner class VH(private val b: ItemAccountMasterBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(a: Account) {
            b.tvName.text = a.name
            b.tvAccountCode.text = if (a.accountCode.isNotBlank()) a.accountCode else ""
            b.tvType.text = a.type.name.replace("_", " ")
            b.tvCurrency.text = a.currency
            b.tvDescription.text = a.description.ifEmpty { "" }
            b.btnEdit.setOnClickListener { onEdit(a) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = VH(ItemAccountMasterBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))
    companion object { val DIFF = object : DiffUtil.ItemCallback<Account>() { override fun areItemsTheSame(a: Account, b: Account) = a.id == b.id; override fun areContentsTheSame(a: Account, b: Account) = a == b } }
}
