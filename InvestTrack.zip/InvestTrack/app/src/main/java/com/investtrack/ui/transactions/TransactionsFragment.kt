package com.investtrack.ui.transactions

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.models.Account
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentTransactionsBinding
import com.investtrack.databinding.ItemTransactionFullBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class TransactionDisplayItem(val transaction: Transaction, val security: Security?)

@HiltViewModel
class TransactionsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _all = MutableStateFlow<List<TransactionDisplayItem>>(emptyList())
    private val _filtered = MutableStateFlow<List<TransactionDisplayItem>>(emptyList())
    val filtered: StateFlow<List<TransactionDisplayItem>> = _filtered

    val accounts: StateFlow<List<Account>> = repository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val securities: StateFlow<List<Security>> = repository.getAllSecurities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active filters
    private var filterText = ""
    private var filterAccountId: Long? = null
    private var filterSecurityId: Long? = null
    private var filterFromDate: Long? = null
    private var filterToDate: Long? = null

    init {
        viewModelScope.launch {
            repository.getAllTransactions().collect { txns ->
                val items = txns.map { TransactionDisplayItem(it, repository.getSecurityById(it.securityId)) }
                _all.value = items
                applyFilters()
            }
        }
    }

    fun setTextFilter(q: String) { filterText = q.lowercase().trim(); applyFilters() }
    fun setAccountFilter(accountId: Long?) { filterAccountId = accountId; applyFilters() }
    fun setSecurityFilter(securityId: Long?) { filterSecurityId = securityId; applyFilters() }
    fun setDateFrom(ms: Long?) { filterFromDate = ms; applyFilters() }
    fun setDateTo(ms: Long?) { filterToDate = ms; applyFilters() }

    fun clearFilters() {
        filterText = ""; filterAccountId = null; filterSecurityId = null
        filterFromDate = null; filterToDate = null
        applyFilters()
    }

    private fun applyFilters() {
        _filtered.value = _all.value.filter { item ->
            val txn = item.transaction
            val matchText = filterText.isEmpty() ||
                item.security?.name?.lowercase()?.contains(filterText) == true ||
                txn.type.displayName.lowercase().contains(filterText)
            val matchAccount = filterAccountId == null || txn.accountId == filterAccountId
            val matchSecurity = filterSecurityId == null || txn.securityId == filterSecurityId
            val matchFrom = filterFromDate == null || txn.transactionDate >= filterFromDate!!
            val matchTo = filterToDate == null || txn.transactionDate <= filterToDate!! + 86400000L
            matchText && matchAccount && matchSecurity && matchFrom && matchTo
        }
    }

    fun delete(transaction: Transaction) {
        viewModelScope.launch { repository.deleteTransaction(transaction) }
    }
}

@AndroidEntryPoint
class TransactionsFragment : Fragment() {
    private var _binding: FragmentTransactionsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransactionsViewModel by viewModels()
    private lateinit var adapter: TransactionFullAdapter
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    private var accountList = listOf<Account>()
    private var securityList = listOf<Security>()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = TransactionFullAdapter(
            onEdit = { item ->
                (activity as? MainActivity)?.navigateTo(EditTransactionFragment.newInstance(item.transaction.id))
            },
            onDelete = { item ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Transaction")
                    .setMessage("Delete ${item.transaction.type.displayName} for ${item.security?.name ?: "Unknown"}?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(item.transaction) }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvTransactions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@TransactionsFragment.adapter
        }

        // Search
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { viewModel.setTextFilter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Account filter dropdown
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.accounts.collect { list ->
                accountList = list
                val names = listOf("All Accounts") + list.map { it.name }
                binding.actvFilterAccount.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names))
                binding.actvFilterAccount.setOnItemClickListener { _, _, pos, _ ->
                    viewModel.setAccountFilter(if (pos == 0) null else list[pos - 1].id)
                }
            }
        }

        // Security filter dropdown
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.securities.collect { list ->
                securityList = list
                val names = listOf("All Securities") + list.map { it.name }
                binding.actvFilterSecurity.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names))
                binding.actvFilterSecurity.setOnItemClickListener { _, _, pos, _ ->
                    viewModel.setSecurityFilter(if (pos == 0) null else list[pos - 1].id)
                }
            }
        }

        // Date From picker
        binding.etDateFrom.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d, 0, 0, 0)
                viewModel.setDateFrom(cal.timeInMillis)
                binding.etDateFrom.setText(dateFmt.format(cal.time))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Date To picker
        binding.etDateTo.setOnClickListener {
            val cal = Calendar.getInstance()
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d, 23, 59, 59)
                viewModel.setDateTo(cal.timeInMillis)
                binding.etDateTo.setText(dateFmt.format(cal.time))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Clear all filters
        binding.btnClearFilters.setOnClickListener {
            viewModel.clearFilters()
            binding.etSearch.setText("")
            binding.actvFilterAccount.setText("")
            binding.actvFilterSecurity.setText("")
            binding.etDateFrom.setText("")
            binding.etDateTo.setText("")
        }

        binding.fabAddTransaction.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddTransactionFragment.newInstance(0L))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.filtered.collect { items ->
                adapter.submitList(items)
                binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                binding.tvCount.text = "${items.size} transactions"
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class TransactionFullAdapter(
    private val onEdit: (TransactionDisplayItem) -> Unit,
    private val onDelete: (TransactionDisplayItem) -> Unit
) : ListAdapter<TransactionDisplayItem, TransactionFullAdapter.VH>(DIFF) {

    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    inner class VH(private val b: ItemTransactionFullBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: TransactionDisplayItem) {
            val txn = item.transaction
            b.tvSecurityName.text = item.security?.name ?: "Unknown"
            b.tvTxnType.text = txn.type.displayName
            b.tvTxnType.setBackgroundResource(when (txn.type) {
                com.investtrack.data.models.TransactionType.BUY -> com.investtrack.R.drawable.bg_type_buy
                com.investtrack.data.models.TransactionType.SELL -> com.investtrack.R.drawable.bg_type_sell
                com.investtrack.data.models.TransactionType.MATURITY -> com.investtrack.R.drawable.bg_type_other
            })
            b.tvAmount.text = CurrencyFormatter.format(txn.amount)
            b.tvQtyPrice.text = "Units: ${String.format("%.3f", txn.quantity)} @ NAV ${CurrencyFormatter.format(txn.price)}"
            b.tvDate.text = dateFmt.format(Date(txn.transactionDate))
            b.tvFolio.text = if (txn.folioNumber.isNotEmpty()) "Folio: ${txn.folioNumber}" else ""
            b.tvFolio.visibility = if (txn.folioNumber.isNotEmpty()) View.VISIBLE else View.GONE
            b.btnEdit.setOnClickListener { onEdit(item) }
            b.btnDelete.setOnClickListener { onDelete(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemTransactionFullBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<TransactionDisplayItem>() {
            override fun areItemsTheSame(a: TransactionDisplayItem, b: TransactionDisplayItem) = a.transaction.id == b.transaction.id
            override fun areContentsTheSame(a: TransactionDisplayItem, b: TransactionDisplayItem) = a == b
        }
    }
}
