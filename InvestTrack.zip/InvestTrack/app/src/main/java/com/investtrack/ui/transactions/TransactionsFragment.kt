package com.investtrack.ui.transactions

import android.app.AlertDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentTransactionsBinding
import com.investtrack.databinding.ItemTransactionFullBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class TransactionDisplayItem(val transaction: Transaction, val security: Security?)

@HiltViewModel
class TransactionsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {
    private val _all = MutableStateFlow<List<TransactionDisplayItem>>(emptyList())
    private val _filtered = MutableStateFlow<List<TransactionDisplayItem>>(emptyList())
    val filtered: StateFlow<List<TransactionDisplayItem>> = _filtered

    init {
        viewModelScope.launch {
            repository.getAllTransactions().collect { txns ->
                val items = txns.map { TransactionDisplayItem(it, repository.getSecurityById(it.securityId)) }
                _all.value = items
                _filtered.value = items
            }
        }
    }

    fun filter(q: String) {
        val query = q.lowercase().trim()
        _filtered.value = if (query.isEmpty()) _all.value
        else _all.value.filter {
            it.security?.name?.lowercase()?.contains(query) == true ||
            it.transaction.type.displayName.lowercase().contains(query)
        }
    }

    fun delete(transaction: Transaction) {
        viewModelScope.launch { repository.deleteTransaction(transaction) }
    }
}

@AndroidEntryPoint
class TransactionsFragment : Fragment() {
    private var _binding: FragmentTransactionsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransactionsViewModel by viewModels()
    private lateinit var adapter: TransactionFullAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTransactionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = TransactionFullAdapter(
            onEdit = { item ->
                (activity as? MainActivity)?.navigateTo(EditTransactionFragment.newInstance(item.transaction.id))
            },
            onDelete = { item ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Transaction")
                    .setMessage("Delete ${item.transaction.type.displayName} for ${item.security?.name ?: "Unknown"}?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(item.transaction) }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvTransactions.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@TransactionsFragment.adapter
        }
        binding.fabAddTransaction.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddTransactionFragment.newInstance(0L))
        }
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { viewModel.filter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.filtered.collect { items ->
                adapter.submitList(items)
                binding.tvEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
                binding.tvCount.text = "${items.size} transactions"
            }
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class TransactionFullAdapter(
    private val onEdit: (TransactionDisplayItem) -> Unit,
    private val onDelete: (TransactionDisplayItem) -> Unit
) : ListAdapter<TransactionDisplayItem, TransactionFullAdapter.VH>(DIFF) {
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    inner class VH(private val b: ItemTransactionFullBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: TransactionDisplayItem) {
            val txn = item.transaction
            b.tvTxnCode.text = if (txn.transactionCode.isNotBlank()) txn.transactionCode else ""
            b.tvSecurityName.text = item.security?.name ?: "Unknown"
            b.tvTxnType.text = txn.type.displayName
            b.tvTxnType.setBackgroundResource(when {
                txn.type.name.contains("BUY") || txn.type.name == "SIP" -> com.investtrack.R.drawable.bg_type_buy
                txn.type.name.contains("SELL") || txn.type.name == "SWP" -> com.investtrack.R.drawable.bg_type_sell
                else -> com.investtrack.R.drawable.bg_type_other
            })
            b.tvAmount.text = CurrencyFormatter.format(txn.amount)
            b.tvQtyPrice.text = "Qty: ${String.format("%.3f", txn.quantity)} @ ${CurrencyFormatter.format(txn.price)}"
            b.tvDate.text = dateFmt.format(Date(txn.transactionDate))
            b.tvFolio.text = if (txn.folioNumber.isNotEmpty()) "Folio: ${txn.folioNumber}" else ""
            b.tvFolio.visibility = if (txn.folioNumber.isNotEmpty()) View.VISIBLE else View.GONE
            b.btnEdit.setOnClickListener { onEdit(item) }
            b.btnDelete.setOnClickListener { onDelete(item) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemTransactionFullBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))
    companion object {
        val DIFF = object : DiffUtil.ItemCallback<TransactionDisplayItem>() {
            override fun areItemsTheSame(a: TransactionDisplayItem, b: TransactionDisplayItem) = a.transaction.id == b.transaction.id
            override fun areContentsTheSame(a: TransactionDisplayItem, b: TransactionDisplayItem) = a == b
        }
    }
}
