package com.investtrack.ui.host

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.investtrack.R
import com.investtrack.ui.budget.IncomeExpenseFragment
import com.investtrack.ui.goals.GoalsFragment
import com.investtrack.ui.loans.LoansFragment
import com.investtrack.ui.masters.AccountMasterListFragment
import com.investtrack.ui.reminders.RemindersFragment
import com.investtrack.ui.securities.SecuritiesFragment
import com.investtrack.ui.whatsapp.WhatsAppTemplatesFragment
import dagger.hilt.android.AndroidEntryPoint

/** A bottom-tab page that holds several screens as swipeable sub-tabs. */
abstract class SectionHostFragment : Fragment() {

    /** Key used by MainActivity.selectTab(tab, subTab) to switch the inner tab. */
    abstract val hostKey: String
    abstract val sections: List<Pair<String, () -> Fragment>>

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_section_host, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val tabs = view.findViewById<TabLayout>(R.id.sub_tabs)
        val pager = view.findViewById<ViewPager2>(R.id.sub_pager)
        val items = sections

        pager.adapter = object : FragmentStateAdapter(this) {
            override fun getItemCount() = items.size
            override fun createFragment(position: Int): Fragment = items[position].second()
        }
        TabLayoutMediator(tabs, pager) { tab, position -> tab.text = items[position].first }.attach()

        parentFragmentManager.setFragmentResultListener("sub_tab_$hostKey", viewLifecycleOwner) { _, bundle ->
            pager.setCurrentItem(bundle.getInt("sub", 0).coerceIn(0, items.size - 1), false)
        }
    }
}

/** Bottom tab "Masters": Account, Security and Loan masters. */
@AndroidEntryPoint
class MastersHostFragment : SectionHostFragment() {
    override val hostKey = "masters"
    override val sections: List<Pair<String, () -> Fragment>> = listOf(
        "Account" to { AccountMasterListFragment() },
        "Security" to { SecuritiesFragment() },
        "Loan" to { LoansFragment() }
    )
}

/** Bottom tab "Planner": Budget, Goals, Reminders and WhatsApp messages. */
@AndroidEntryPoint
class PlannerHostFragment : SectionHostFragment() {
    override val hostKey = "planner"
    override val sections: List<Pair<String, () -> Fragment>> = listOf(
        "Budget" to { IncomeExpenseFragment() },
        "Goals" to { GoalsFragment() },
        "Reminders" to { RemindersFragment() },
        "WhatsApp" to { WhatsAppTemplatesFragment() }
    )
}
