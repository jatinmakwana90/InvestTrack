package com.investtrack.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.databinding.ItemAccountSummaryBinding
import com.investtrack.utils.CurrencyFormatter
import kotlin.math.abs

class AccountSummaryAdapter(
    private val onClick: (AccountSummaryItem) -> Unit
) : ListAdapter<AccountSummaryItem, AccountSummaryAdapter.ViewHolder>(DIFF) {

    inner class ViewHolder(private val binding: ItemAccountSummaryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: AccountSummaryItem) {
            binding.tvAccountName.text = item.account.name
            binding.tvAccountType.text = item.account.type.name.replace("_", " ")
            binding.tvCurrentValue.text = CurrencyFormatter.format(item.summary.currentValue)
            binding.tvInvested.text = CurrencyFormatter.format(item.summary.totalInvested)
            binding.tvHoldings.text = "${item.summary.folioCount} holdings"

            val pnl = item.summary.totalPnL
            val pct = item.summary.totalPnLPercent
            val sign = if (pnl >= 0) "▲ +" else "▼ "
            binding.tvPnl.text = "$sign${CurrencyFormatter.format(abs(pnl))} (${String.format("%.2f", abs(pct))}%)"
            binding.tvPnl.setTextColor(
                binding.root.context.getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red)
            )
            binding.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemAccountSummaryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AccountSummaryItem>() {
            override fun areItemsTheSame(a: AccountSummaryItem, b: AccountSummaryItem) = a.account.id == b.account.id
            override fun areContentsTheSame(a: AccountSummaryItem, b: AccountSummaryItem) = a == b
        }
    }
}
