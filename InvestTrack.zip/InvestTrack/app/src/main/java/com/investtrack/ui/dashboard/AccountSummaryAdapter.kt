package com.investtrack.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.databinding.ItemAccountSummaryBinding
import com.investtrack.utils.CurrencyFormatter
import kotlin.math.abs

class AccountSummaryAdapter(
    private var returnMode: ReturnDisplayMode = ReturnDisplayMode.ABS,
    private var amountMode: AmountDisplayMode = AmountDisplayMode.ROUNDED,
    private val onClick: (AccountSummaryItem) -> Unit
) : ListAdapter<AccountSummaryItem, AccountSummaryAdapter.ViewHolder>(DIFF) {

    fun updateModes(returnMode: ReturnDisplayMode, amountMode: AmountDisplayMode) {
        this.returnMode = returnMode
        this.amountMode = amountMode
        notifyDataSetChanged()
    }

    inner class ViewHolder(private val b: ItemAccountSummaryBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: AccountSummaryItem) {
            b.tvAccountName.text = item.account.name
            b.tvAccountType.text = item.account.type.name.replace("_", " ")
            b.tvCurrentValue.text = CurrencyFormatter.format(item.summary.currentValue, amountMode)
            b.tvInvested.text = CurrencyFormatter.format(item.summary.totalInvested, amountMode)
            b.tvHoldings.text = "${item.summary.folioCount} holdings"

            if (returnMode == ReturnDisplayMode.ABS) {
                val pnl = item.summary.totalPnL
                val pct = item.summary.totalPnLPercent
                val sign = if (pnl >= 0) "▲ +" else "▼ "
                b.tvPnl.text = "$sign${CurrencyFormatter.format(abs(pnl), amountMode)} (${String.format("%.2f", abs(pct))}%)"
                b.tvPnl.setTextColor(b.root.context.getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red))
            } else {
                val xirr = item.xirrPercent
                if (xirr != null) {
                    val sign = if (xirr >= 0) "▲ +" else "▼ "
                    b.tvPnl.text = "$sign${String.format("%.2f", abs(xirr))}% XIRR"
                    b.tvPnl.setTextColor(b.root.context.getColor(if (xirr >= 0) R.color.gain_green else R.color.loss_red))
                } else {
                    b.tvPnl.text = "XIRR: N/A"
                    b.tvPnl.setTextColor(b.root.context.getColor(R.color.text_secondary))
                }
            }
            b.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        ViewHolder(ItemAccountSummaryBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: ViewHolder, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<AccountSummaryItem>() {
            override fun areItemsTheSame(a: AccountSummaryItem, b: AccountSummaryItem) = a.account.id == b.account.id
            override fun areContentsTheSame(a: AccountSummaryItem, b: AccountSummaryItem) = a == b
        }
    }
}
