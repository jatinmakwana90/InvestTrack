package com.investtrack.utils

import com.investtrack.data.models.Goal
import java.util.Calendar

data class GoalProgress(
    val current: Double,          // value currently earmarked for the goal
    val progressPercent: Double,  // current / target * 100
    val monthsLeft: Int,
    val projected: Double,        // what today's value grows to by the target date (no new money)
    val requiredMonthly: Double,  // extra monthly investment needed to still reach the target
    val onTrack: Boolean
)

object GoalCalculator {

    fun monthsBetween(from: Long, to: Long): Int {
        val a = Calendar.getInstance().apply { timeInMillis = from }
        val b = Calendar.getInstance().apply { timeInMillis = to }
        val months = (b.get(Calendar.YEAR) - a.get(Calendar.YEAR)) * 12 + (b.get(Calendar.MONTH) - a.get(Calendar.MONTH))
        return months.coerceAtLeast(0)
    }

    fun evaluate(goal: Goal, linkedValue: Double, now: Long = System.currentTimeMillis()): GoalProgress {
        val current = linkedValue * goal.allocationPercent.coerceIn(0, 100) / 100.0
        val n = monthsBetween(now, goal.targetDate)
        val rm = goal.expectedReturn / 12.0 / 100.0
        val growth = if (rm == 0.0) 1.0 else Math.pow(1 + rm, n.toDouble())
        val projected = current * growth
        val shortfall = goal.targetAmount - projected
        val required = when {
            shortfall <= 0 -> 0.0
            n == 0 -> shortfall
            rm == 0.0 -> shortfall / n
            else -> shortfall * rm / (growth - 1)
        }
        val pct = if (goal.targetAmount > 0) current / goal.targetAmount * 100 else 0.0
        return GoalProgress(current, pct, n, projected, required, shortfall <= 0)
    }

    fun timeLeftLabel(months: Int): String {
        if (months <= 0) return "Target date reached"
        val y = months / 12; val m = months % 12
        return when {
            y > 0 && m > 0 -> "${y}y ${m}m left"
            y > 0 -> "${y}y left"
            else -> "${m}m left"
        }
    }
}
