package com.investtrack.ui.accounts

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.investtrack.data.models.Account
import com.investtrack.data.models.AccountType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddAccountBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditAccountViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val accountId: Long = savedStateHandle.get<Long>("accountId") ?: 0L
    private val _account = MutableStateFlow<Account?>(null)
    val account: StateFlow<Account?> = _account

    init {
        viewModelScope.launch { _account.value = repository.getAccountById(accountId) }
    }

    fun save(account: Account) {
        viewModelScope.launch { repository.updateAccount(account) }
    }
}

@AndroidEntryPoint
class EditAccountFragment : Fragment() {

    private var _binding: FragmentAddAccountBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EditAccountViewModel by viewModels()
    private var originalAccount: Account? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddAccountBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = "Edit Account"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.btnSave.text = "Save Changes"

        val accountTypes = AccountType.values().map { it.name.replace("_", " ") }
        val typeAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, accountTypes)
        binding.actvAccountType.setAdapter(typeAdapter)

        val currencies = listOf("INR", "USD", "EUR", "GBP")
        binding.actvCurrency.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, currencies))

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.account.collect { account ->
                account ?: return@collect
                originalAccount = account
                binding.etAccountName.setText(account.name)
                binding.actvAccountType.setText(account.type.name.replace("_", " "), false)
                binding.actvCurrency.setText(account.currency, false)
                binding.etDescription.setText(account.description)
            }
        }

        binding.btnSave.setOnClickListener { save() }
    }

    private fun save() {
        val orig = originalAccount ?: return
        val name = binding.etAccountName.text.toString().trim()
        if (name.isEmpty()) { binding.tilAccountName.error = "Name required"; return }
        val typeStr = binding.actvAccountType.text.toString().replace(" ", "_")
        val type = try { AccountType.valueOf(typeStr) } catch (e: Exception) { orig.type }
        viewModel.save(orig.copy(
            name = name, type = type,
            currency = binding.actvCurrency.text.toString(),
            description = binding.etDescription.text.toString().trim()
        ))
        activity?.onBackPressedDispatcher?.onBackPressed()
    }


    companion object {
        fun newInstance(accountId: Long) = EditAccountFragment().apply {
            arguments = android.os.Bundle().apply { putLong("accountId", accountId) }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
