package com.investtrack.ui.accounts

import android.app.AlertDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Account
import com.investtrack.data.models.AccountType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddAccountBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EditAccountViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val accountId: Long = savedStateHandle.get<Long>("accountId") ?: 0L
    private val _account = MutableStateFlow<Account?>(null)
    val account: StateFlow<Account?> = _account
    private val _done = MutableStateFlow(false)
    val done: StateFlow<Boolean> = _done

    init { viewModelScope.launch { _account.value = repository.getAccountById(accountId) } }

    fun save(name: String, type: AccountType, description: String, currency: String) {
        viewModelScope.launch {
            val current = _account.value ?: return@launch
            repository.updateAccount(current.copy(name = name, type = type, description = description, currency = currency))
            _done.value = true
        }
    }

    fun delete() {
        viewModelScope.launch {
            repository.deactivateAccount(accountId)
            _done.value = true
        }
    }
}

@AndroidEntryPoint
class EditAccountFragment : Fragment() {
    private var _binding: FragmentAddAccountBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EditAccountViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddAccountBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = "Edit Account"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        // Show delete button
        binding.btnDelete.visibility = View.VISIBLE
        binding.btnDelete.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Delete Account")
                .setMessage("Delete this account? All holdings data will be hidden.")
                .setPositiveButton("Delete") { _, _ -> viewModel.delete() }
                .setNegativeButton("Cancel", null).show()
        }

        val accountTypes = AccountType.values().map { it.name.replace("_", " ") }
        binding.actvAccountType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, accountTypes))

        val currencies = listOf("INR", "USD", "EUR", "GBP")
        binding.actvCurrency.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, currencies))

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.done.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.account.collect { account ->
                account ?: return@collect
                binding.etAccountName.setText(account.name)
                binding.etDescription.setText(account.description)
                binding.actvAccountType.setText(account.type.name.replace("_", " "), false)
                binding.actvCurrency.setText(account.currency, false)
            }
        }

        binding.btnSave.setOnClickListener {
            val name = binding.etAccountName.text.toString().trim()
            if (name.isEmpty()) { binding.tilAccountName.error = "Name required"; return@setOnClickListener }
            val typeStr = binding.actvAccountType.text.toString().replace(" ", "_")
            val type = try { AccountType.valueOf(typeStr) } catch (e: Exception) { AccountType.INDIVIDUAL }
            binding.btnSave.isEnabled = false
            binding.btnSave.text = "Saving..."
            viewModel.save(name, type, binding.etDescription.text.toString().trim(), binding.actvCurrency.text.toString())
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(accountId: Long) = EditAccountFragment().apply {
            arguments = Bundle().apply { putLong("accountId", accountId) }
        }
    }
}
