package com.investtrack.data.settings

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.inject.Inject
import javax.inject.Singleton

/** PIN / biometric app lock. The PIN is never stored, only a salted PBKDF2 hash of it. */
@Singleton
class AppLockManager @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("investtrack_lock", Context.MODE_PRIVATE)

    /** False after the app process starts, so the lock screen shows on every cold start. */
    @Volatile var unlocked = false
    @Volatile private var lastBackgroundAt = 0L
    @Volatile private var failedAttempts = 0
    @Volatile private var lockedUntil = 0L

    val hasPin: Boolean get() = prefs.getString("pin_hash", null) != null
    val pinLength: Int get() = prefs.getInt("pin_length", 4)

    val enabled: Boolean get() = prefs.getBoolean("enabled", false) && hasPin

    var biometricEnabled: Boolean
        get() = prefs.getBoolean("biometric", true)
        set(v) { prefs.edit().putBoolean("biometric", v).apply() }

    var hideInRecents: Boolean
        get() = prefs.getBoolean("hide_recents", true)
        set(v) { prefs.edit().putBoolean("hide_recents", v).apply() }

    /** Seconds the app may stay in the background before it locks again (0 = immediately). */
    var timeoutSeconds: Int
        get() = prefs.getInt("timeout", 30)
        set(v) { prefs.edit().putInt("timeout", v).apply() }

    fun enable(pin: String) {
        setPin(pin)
        prefs.edit().putBoolean("enabled", true).apply()
        unlocked = true
    }

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("pin_length", pin.length)
            .apply()
    }

    fun disable() {
        prefs.edit().putBoolean("enabled", false).remove("pin_hash").remove("pin_salt").apply()
    }

    fun verifyPin(pin: String): Boolean {
        val saltB64 = prefs.getString("pin_salt", null) ?: return false
        val hashB64 = prefs.getString("pin_hash", null) ?: return false
        val expected = Base64.decode(hashB64, Base64.NO_WRAP)
        val actual = hash(pin, Base64.decode(saltB64, Base64.NO_WRAP))
        var diff = expected.size xor actual.size
        for (i in 0 until minOf(expected.size, actual.size)) diff = diff or (expected[i].toInt() xor actual[i].toInt())
        val ok = diff == 0
        if (ok) { failedAttempts = 0 }
        else {
            failedAttempts++
            if (failedAttempts >= 5) { lockedUntil = System.currentTimeMillis() + 30_000; failedAttempts = 0 }
        }
        return ok
    }

    /** Seconds the PIN pad is blocked after too many wrong attempts (0 = not blocked). */
    fun lockoutSecondsLeft(): Int {
        val left = lockedUntil - System.currentTimeMillis()
        return if (left > 0) ((left + 999) / 1000).toInt() else 0
    }

    fun markUnlocked() { unlocked = true }
    fun onBackgrounded() { lastBackgroundAt = System.currentTimeMillis() }

    fun shouldLock(): Boolean {
        if (!enabled) return false
        if (!unlocked) return true
        val away = System.currentTimeMillis() - lastBackgroundAt
        return lastBackgroundAt > 0 && away > timeoutSeconds * 1000L
    }

    fun relock() { unlocked = false }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 10_000, 256)).encoded
}
