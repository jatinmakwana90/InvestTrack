package com.investtrack.network

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.ProfileDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.network.SyncPayload
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.runBlocking
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.net.NetworkInterface
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncServer @Inject constructor(
    private val profileDao: ProfileDao,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) {
    val port = 8765
    private var server: InvestTrackHttpServer? = null
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun start(token: String) {
        stop()
        server = InvestTrackHttpServer(port, token, profileDao, accountDao, securityDao, transactionDao, json)
        server?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
    }

    fun stop() {
        server?.stop()
        server = null
    }

    fun getLocalIp(): String {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains('.') == true }
                ?.hostAddress ?: "0.0.0.0"
        } catch (e: Exception) { "0.0.0.0" }
    }

    fun buildPairingString(token: String) = "INVESTTRACK:${getLocalIp()}:$port:$token"
}

class InvestTrackHttpServer(
    port: Int,
    private val token: String,
    private val profileDao: ProfileDao,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val json: Json
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        return when {
            session.uri == "/ping" ->
                newFixedLengthResponse("INVESTTRACK_OK")
            session.uri.startsWith("/sync/") -> {
                val reqToken = session.uri.removePrefix("/sync/")
                if (reqToken != token) {
                    newFixedLengthResponse(Response.Status.UNAUTHORIZED, MIME_PLAINTEXT, "UNAUTHORIZED")
                } else {
                    val payload = runBlocking { buildPayload() }
                    newFixedLengthResponse(Response.Status.OK, "application/json", payload)
                }
            }
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "NOT_FOUND")
        }
    }

    private suspend fun buildPayload(): String {
        val payload = SyncPayload(
            profiles = profileDao.getAllProfilesList(),
            accounts = accountDao.getAllAccountsList(),
            securities = securityDao.getAllSecuritiesList(),
            transactions = transactionDao.getAllTransactionsList()
        )
        return json.encodeToString(payload)
    }
}
