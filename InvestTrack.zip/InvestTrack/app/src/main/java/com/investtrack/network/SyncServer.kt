package com.investtrack.network

import android.content.Context
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.ProfileDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.net.NetworkInterface
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class SyncPayload(
    val profiles: List<com.investtrack.data.models.Profile> = emptyList(),
    val accounts: List<com.investtrack.data.models.Account> = emptyList(),
    val securities: List<com.investtrack.data.models.Security> = emptyList(),
    val transactions: List<com.investtrack.data.models.Transaction> = emptyList(),
    val syncTimestamp: Long = System.currentTimeMillis()
)

@Singleton
class SyncServer @Inject constructor(
    private val profileDao: ProfileDao,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) {
    private var server: ApplicationEngine? = null
    val port = 8765

    fun start(token: String) {
        if (server != null) return
        server = embeddedServer(Netty, port = port) {
            install(ContentNegotiation) {
                json(Json { ignoreUnknownKeys = true; encodeDefaults = true })
            }
            routing {
                get("/ping") {
                    call.respondText("INVESTTRACK_OK")
                }
                get("/sync/{token}") {
                    val reqToken = call.parameters["token"]
                    if (reqToken != token) {
                        call.respondText("UNAUTHORIZED", status = io.ktor.http.HttpStatusCode.Unauthorized)
                        return@get
                    }
                    val payload = buildPayload()
                    call.respond(payload)
                }
            }
        }
        CoroutineScope(Dispatchers.IO).launch {
            server?.start(wait = false)
        }
    }

    fun stop() {
        server?.stop(1000, 3000)
        server = null
    }

    private suspend fun buildPayload(): SyncPayload {
        return SyncPayload(
            profiles = profileDao.getAllProfilesList(),
            accounts = accountDao.getAllAccountsList(),
            securities = securityDao.getAllSecuritiesList(),
            transactions = transactionDao.getAllTransactionsList()
        )
    }

    fun getLocalIp(): String {
        return try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains('.') == true }
                ?.hostAddress ?: "0.0.0.0"
        } catch (e: Exception) {
            "0.0.0.0"
        }
    }

    fun buildPairingString(token: String): String {
        val ip = getLocalIp()
        return "INVESTTRACK:$ip:$port:$token"
    }
}
