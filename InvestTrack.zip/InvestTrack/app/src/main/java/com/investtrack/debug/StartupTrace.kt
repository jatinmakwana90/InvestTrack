package com.investtrack.debug

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Writes startup checkpoints to a plain text file in external storage so a hang can be
 * diagnosed without any logcat/adb access — just open the file with any file manager or
 * text app. Each call appends one line with a timestamp. Deliberately does its own file I/O
 * synchronously and defensively (never throws) since it's used to debug startup itself.
 */
object StartupTrace {
    private const val FILE_NAME = "investtrack_startup_trace.txt"
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun mark(context: Context, checkpoint: String) {
        try {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val file = File(dir, FILE_NAME)
            file.appendText("${timeFmt.format(Date())}  $checkpoint\n")
        } catch (e: Exception) {
            // Never let tracing itself break startup.
        }
    }

    /** Clears the trace file at the very start of a fresh app launch. */
    fun reset(context: Context) {
        try {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            File(dir, FILE_NAME).writeText("")
        } catch (e: Exception) { }
    }

    /** Human-readable path, shown in the crash screen / logs to tell the user where to look. */
    fun filePath(context: Context): String {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        return File(dir, FILE_NAME).absolutePath
    }
}
