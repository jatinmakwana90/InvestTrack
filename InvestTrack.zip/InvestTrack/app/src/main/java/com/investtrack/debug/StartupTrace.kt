package com.investtrack.debug

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Keeps startup checkpoints entirely in memory — no file/storage access needed, since that
 * turned out to be inaccessible without root on some devices. Paired with a watchdog
 * (see WatchdogKt) that force-displays these checkpoints via CrashActivity if startup stalls,
 * so a hang can be diagnosed with nothing more than opening the app and waiting.
 */
object StartupTrace {
    private val checkpoints = CopyOnWriteArrayList<String>()
    private val timeFmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    @Volatile var reachedEnd: Boolean = false
        private set

    fun mark(checkpoint: String) {
        checkpoints.add("${timeFmt.format(Date())}  $checkpoint")
        if (checkpoint.endsWith("END (all listeners wired)") || checkpoint == "STARTUP COMPLETE") {
            reachedEnd = true
        }
    }

    fun dump(): String =
        if (checkpoints.isEmpty()) "No checkpoints recorded yet — hang is before InvestTrackApp.onCreate even starts."
        else checkpoints.joinToString("\n")
}
