package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.DriveBackupConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface DriveBackupConfigDao {
    @Query("SELECT * FROM drive_backup_config WHERE id = 1")
    fun getConfig(): Flow<DriveBackupConfig?>

    @Query("SELECT * FROM drive_backup_config WHERE id = 1")
    suspend fun getConfigOnce(): DriveBackupConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(config: DriveBackupConfig)
}
