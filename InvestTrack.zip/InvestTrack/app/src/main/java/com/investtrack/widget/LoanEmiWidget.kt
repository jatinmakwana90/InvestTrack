package com.investtrack.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.investtrack.R
import com.investtrack.data.database.InvestTrackDatabase
import com.investtrack.ui.MainActivity
import com.investtrack.utils.LoanAmortizationCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Shows the loan with the soonest upcoming EMI due date across all active loans —
 * next due date, amount, and days remaining — computed live via the same amortization
 * engine the Loans screen uses, so it reflects any part-payments/rate changes/marked-paid
 * installments rather than a stale stored value.
 */
class LoanEmiWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, LoanEmiWidget::class.java))
            onUpdate(context, mgr, ids)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.investtrack.LOAN_WIDGET_REFRESH"

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_loan_emi)

            val openIntent = Intent(context, MainActivity::class.java)
            val openPi = PendingIntent.getActivity(context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_loan_root, openPi)

            val refreshIntent = Intent(context, LoanEmiWidget::class.java).apply {
                action = ACTION_REFRESH
            }
            val refreshPi = PendingIntent.getBroadcast(context, 2, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.btn_loan_widget_refresh, refreshPi)

            views.setTextViewText(R.id.tv_widget_loan_name, "Loading...")
            views.setTextViewText(R.id.tv_widget_loan_amount, "")
            views.setTextViewText(R.id.tv_widget_loan_due, "")
            manager.updateAppWidget(widgetId, views)

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = InvestTrackDatabase.getInstance(context)
                    val loans = db.loanDao().getAllLoansList().filter { it.isActive }

                    data class Upcoming(val loanName: String, val emi: Double, val dueDate: Long)

                    val upcoming = loans.mapNotNull { loan ->
                        val adjustments = db.loanAdjustmentDao().getAdjustmentsForLoanList(loan.id)
                        val schedule = LoanAmortizationCalculator.buildSchedule(loan, adjustments)
                        val dueDate = schedule.nextEmiDate ?: return@mapNotNull null
                        Upcoming(loan.loanName, schedule.currentEmi, dueDate)
                    }.minByOrNull { it.dueDate }

                    withContext(Dispatchers.Main) {
                        if (upcoming == null) {
                            views.setTextViewText(R.id.tv_widget_loan_name, "No active loans")
                            views.setTextViewText(R.id.tv_widget_loan_amount, "")
                            views.setTextViewText(R.id.tv_widget_loan_due, "")
                        } else {
                            val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                            val daysRemaining = TimeUnit.MILLISECONDS.toDays(
                                stripTime(upcoming.dueDate) - stripTime(System.currentTimeMillis())
                            ).toInt()
                            val dueLabel = when {
                                daysRemaining < 0 -> "Overdue by ${-daysRemaining} day${if (daysRemaining != -1) "s" else ""}"
                                daysRemaining == 0 -> "Due today · ${dateFmt.format(Date(upcoming.dueDate))}"
                                else -> "Due in $daysRemaining day${if (daysRemaining != 1) "s" else ""} · ${dateFmt.format(Date(upcoming.dueDate))}"
                            }
                            views.setTextViewText(R.id.tv_widget_loan_name, upcoming.loanName)
                            views.setTextViewText(R.id.tv_widget_loan_amount, formatAmount(upcoming.emi))
                            views.setTextViewText(R.id.tv_widget_loan_due, dueLabel)
                        }
                        manager.updateAppWidget(widgetId, views)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        views.setTextViewText(R.id.tv_widget_loan_name, "Tap to open app")
                        views.setTextViewText(R.id.tv_widget_loan_amount, "")
                        views.setTextViewText(R.id.tv_widget_loan_due, "")
                        manager.updateAppWidget(widgetId, views)
                    }
                }
            }
        }

        private fun stripTime(millis: Long): Long {
            val cal = java.util.Calendar.getInstance().apply {
                timeInMillis = millis
                set(java.util.Calendar.HOUR_OF_DAY, 0)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }
            return cal.timeInMillis
        }

        private fun formatAmount(amount: Double): String = when {
            kotlin.math.abs(amount) >= 10_000_000 -> "₹${String.format("%.2f", amount / 10_000_000)}Cr"
            kotlin.math.abs(amount) >= 100_000 -> "₹${String.format("%.2f", amount / 100_000)}L"
            else -> "₹${String.format("%,.0f", amount)}"
        }
    }
}
