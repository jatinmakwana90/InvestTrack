package com.investtrack.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CrashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val crashText = intent.getStringExtra("crash_text") ?: "Unknown crash"

        val scrollView = ScrollView(this)
        val layout = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 64, 32, 32)
        }

        val title = TextView(this).apply {
            text = "App Crashed - Error Details"
            textSize = 18f
            setTextColor(0xFFCC0000.toInt())
            setPadding(0, 0, 0, 24)
        }

        val textView = TextView(this).apply {
            text = crashText
            textSize = 11f
            setTextColor(0xFF222222.toInt())
            setBackgroundColor(0xFFF5F5F5.toInt())
            setPadding(16, 16, 16, 16)
            setTextIsSelectable(true)
        }

        val copyBtn = Button(this).apply {
            text = "Copy Error Text"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", crashText))
                Toast.makeText(this@CrashActivity, "Copied! Please share this text.", Toast.LENGTH_LONG).show()
            }
        }

        layout.addView(title)
        layout.addView(copyBtn)
        layout.addView(textView)
        scrollView.addView(layout)
        setContentView(scrollView)
    }
}
