package com.investtrack.data.settings

import android.content.Context
import android.content.SharedPreferences
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

/** Switches and schedules for the background automations (EMI marking, WhatsApp summary, monthly PDF). */
@Singleton
class AutomationSettings @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("investtrack_automation", Context.MODE_PRIVATE)

    var autoPayEmis: Boolean
        get() = prefs.getBoolean("auto_pay_emis", false)
        set(v) { prefs.edit().putBoolean("auto_pay_emis", v).apply() }

    /** Keeps a "Add transaction" notification in the shade for quick entry. */
    var quickAddNotification: Boolean
        get() = prefs.getBoolean("quick_add_notification", false)
        set(v) { prefs.edit().putBoolean("quick_add_notification", v).apply() }

    // Weekly WhatsApp summary
    var weeklyEnabled: Boolean
        get() = prefs.getBoolean("weekly_enabled", false)
        set(v) { prefs.edit().putBoolean("weekly_enabled", v).apply() }
    var weeklyDay: Int   // Calendar.SUNDAY (1) .. Calendar.SATURDAY (7)
        get() = prefs.getInt("weekly_day", Calendar.SUNDAY)
        set(v) { prefs.edit().putInt("weekly_day", v).apply() }
    var weeklyHour: Int
        get() = prefs.getInt("weekly_hour", 9)
        set(v) { prefs.edit().putInt("weekly_hour", v).apply() }
    var weeklyMinute: Int
        get() = prefs.getInt("weekly_minute", 0)
        set(v) { prefs.edit().putInt("weekly_minute", v).apply() }
    var weeklyContactName: String
        get() = prefs.getString("weekly_contact_name", "") ?: ""
        set(v) { prefs.edit().putString("weekly_contact_name", v).apply() }
    var weeklyContactPhone: String
        get() = prefs.getString("weekly_contact_phone", "") ?: ""
        set(v) { prefs.edit().putString("weekly_contact_phone", v).apply() }

    // Monthly PDF report
    var monthlyEnabled: Boolean
        get() = prefs.getBoolean("monthly_enabled", false)
        set(v) { prefs.edit().putBoolean("monthly_enabled", v).apply() }
    var monthlyDay: Int  // 1..28
        get() = prefs.getInt("monthly_day", 1)
        set(v) { prefs.edit().putInt("monthly_day", v.coerceIn(1, 28)).apply() }
    var monthlyHour: Int
        get() = prefs.getInt("monthly_hour", 9)
        set(v) { prefs.edit().putInt("monthly_hour", v).apply() }
    var monthlyMinute: Int
        get() = prefs.getInt("monthly_minute", 0)
        set(v) { prefs.edit().putInt("monthly_minute", v).apply() }
}
