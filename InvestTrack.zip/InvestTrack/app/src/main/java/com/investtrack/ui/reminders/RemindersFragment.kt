package com.investtrack.ui.reminders

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.NumberPicker
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Reminder
import com.investtrack.data.models.ReminderType
import com.investtrack.databinding.FragmentRemindersBinding
import com.investtrack.databinding.ItemReminderBinding
import com.investtrack.workers.ReminderWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RemindersViewModel @Inject constructor(
    private val reminderDao: ReminderDao
) : ViewModel() {
    val reminders: StateFlow<List<Reminder>> = reminderDao.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(reminder: Reminder) = viewModelScope.launch { reminderDao.insertReminder(reminder) }
    fun delete(reminder: Reminder) = viewModelScope.launch { reminderDao.deleteReminder(reminder) }
    fun toggle(reminder: Reminder, active: Boolean) = viewModelScope.launch {
        reminderDao.setActive(reminder.id, active)
    }
}

@AndroidEntryPoint
class RemindersFragment : Fragment() {
    private var _binding: FragmentRemindersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RemindersViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRemindersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = ReminderAdapter(
            onToggle = { reminder, active ->
                viewModel.toggle(reminder, active)
                if (active) ReminderWorker.scheduleAll(requireContext(), reminder)
                else ReminderWorker.cancelAll(requireContext(), reminder.id)
            },
            onDelete = { reminder ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Reminder")
                    .setMessage("Delete \"${reminder.title}\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        ReminderWorker.cancelAll(requireContext(), reminder.id)
                        viewModel.delete(reminder)
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvReminders.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
        binding.fabAddReminder.setOnClickListener { showAddReminderDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.reminders.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showAddReminderDialog() {
        val v = LayoutInflater.from(requireContext()).inflate(com.investtrack.R.layout.dialog_add_reminder, null)

        val etTitle = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_title)
        val etDesc = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_desc)
        val etAmount = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_amount)
        val actvType = v.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_reminder_type)
        val npDueDay = v.findViewById<NumberPicker>(com.investtrack.R.id.np_day)

        val tvR1Days = v.findViewById<NumberPicker>(com.investtrack.R.id.np_remind1_days)
        val tvR1Time = v.findViewById<TextView>(com.investtrack.R.id.tv_remind1_time)
        val tvR2Days = v.findViewById<NumberPicker>(com.investtrack.R.id.np_remind2_days)
        val tvR2Time = v.findViewById<TextView>(com.investtrack.R.id.tv_remind2_time)

        var r1Hour = 9; var r1Min = 0
        var r2Hour = 9; var r2Min = 0

        npDueDay.minValue = 1; npDueDay.maxValue = 28; npDueDay.value = 10
        tvR1Days.minValue = 1; tvR1Days.maxValue = 7; tvR1Days.value = 2
        tvR2Days.minValue = 1; tvR2Days.maxValue = 7; tvR2Days.value = 1

        tvR1Time.text = "09:00 AM"
        tvR2Time.text = "09:00 AM"

        tvR1Time.setOnClickListener {
            TimePickerDialog(requireContext(), { _, h, m ->
                r1Hour = h; r1Min = m; tvR1Time.text = formatTime(h, m)
            }, r1Hour, r1Min, false).show()
        }
        tvR2Time.setOnClickListener {
            TimePickerDialog(requireContext(), { _, h, m ->
                r2Hour = h; r2Min = m; tvR2Time.text = formatTime(h, m)
            }, r2Hour, r2Min, false).show()
        }

        val types = ReminderType.values().map { it.displayName }
        actvType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types))
        actvType.setText(types[0], false)

        AlertDialog.Builder(requireContext())
            .setTitle("Add Reminder")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val title = etTitle.text.toString().trim().ifBlank { "SIP Reminder" }
                val type = ReminderType.values().firstOrNull { it.displayName == actvType.text.toString() } ?: ReminderType.SIP
                val reminder = Reminder(
                    title = title,
                    description = etDesc.text.toString().trim(),
                    type = type,
                    dueDayOfMonth = npDueDay.value,
                    amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0,
                    remind1DaysBefore = tvR1Days.value,
                    remind1Hour = r1Hour, remind1Minute = r1Min,
                    remind2DaysBefore = tvR2Days.value,
                    remind2Hour = r2Hour, remind2Minute = r2Min
                )
                viewModel.save(reminder)
                // Schedule after a short delay to get the saved ID
                viewLifecycleOwner.lifecycleScope.launch {
                    kotlinx.coroutines.delay(300)
                    viewModel.reminders.value.lastOrNull()?.let {
                        ReminderWorker.scheduleAll(requireContext(), it)
                    }
                }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun formatTime(h: Int, m: Int): String {
        val ampm = if (h >= 12) "PM" else "AM"
        val dh = if (h > 12) h - 12 else if (h == 0) 12 else h
        return String.format("%02d:%02d %s", dh, m, ampm)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class ReminderAdapter(
    private val onToggle: (Reminder, Boolean) -> Unit,
    private val onDelete: (Reminder) -> Unit
) : ListAdapter<Reminder, ReminderAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemReminderBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(r: Reminder) {
            b.tvTitle.text = r.title
            b.tvType.text = r.type.displayName
            val amtText = if (r.amount > 0) " • ₹${String.format("%,.0f", r.amount)}" else ""
            b.tvDetails.text = "Due: ${r.dueDayOfMonth}th of every month$amtText"

            // Show both reminders
            val r1Day = r.dueDayOfMonth - r.remind1DaysBefore
            val r2Day = r.dueDayOfMonth - r.remind2DaysBefore
            b.tvTime.text = "🔔 ${r1Day}th @ ${formatTime(r.remind1Hour, r.remind1Minute)}  " +
                "🔔 ${r2Day}th @ ${formatTime(r.remind2Hour, r.remind2Minute)}"

            b.switchActive.isChecked = r.isActive
            b.switchActive.setOnCheckedChangeListener(null)
            b.switchActive.setOnCheckedChangeListener { _, checked -> onToggle(r, checked) }
            b.btnDelete.setOnClickListener { onDelete(r) }
        }

        private fun formatTime(h: Int, m: Int): String {
            val ampm = if (h >= 12) "PM" else "AM"
            val dh = if (h > 12) h - 12 else if (h == 0) 12 else h
            return String.format("%02d:%02d %s", dh, m, ampm)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemReminderBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Reminder>() {
            override fun areItemsTheSame(a: Reminder, b: Reminder) = a.id == b.id
            override fun areContentsTheSame(a: Reminder, b: Reminder) = a == b
        }
    }
}
