package com.investtrack.ui.reminders

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.NumberPicker
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Reminder
import com.investtrack.data.models.ReminderType
import com.investtrack.databinding.FragmentRemindersBinding
import com.investtrack.databinding.ItemReminderBinding
import com.investtrack.workers.ReminderWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@HiltViewModel
class RemindersViewModel @Inject constructor(
    private val reminderDao: ReminderDao
) : ViewModel() {
    val reminders: StateFlow<List<Reminder>> = reminderDao.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(reminder: Reminder) = viewModelScope.launch { reminderDao.insertReminder(reminder) }
    fun delete(reminder: Reminder) = viewModelScope.launch { reminderDao.deleteReminder(reminder) }
    fun toggle(reminder: Reminder) = viewModelScope.launch {
        reminderDao.setActive(reminder.id, !reminder.isActive)
    }
}

@AndroidEntryPoint
class RemindersFragment : Fragment() {
    private var _binding: FragmentRemindersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RemindersViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRemindersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = ReminderAdapter(
            onToggle = { reminder ->
                viewModel.toggle(reminder)
                if (!reminder.isActive) ReminderWorker.schedule(requireContext(), reminder)
                else ReminderWorker.cancel(requireContext(), reminder.id)
            },
            onDelete = { reminder ->
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Reminder")
                    .setMessage("Delete \"${reminder.title}\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        ReminderWorker.cancel(requireContext(), reminder.id)
                        viewModel.delete(reminder)
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvReminders.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.fabAddReminder.setOnClickListener { showAddReminderDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.reminders.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showAddReminderDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(com.investtrack.R.layout.dialog_add_reminder, null)

        val etTitle = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_title)
        val etDesc = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_desc)
        val etAmount = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_amount)
        val actvType = dialogView.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_reminder_type)
        val npDay = dialogView.findViewById<NumberPicker>(com.investtrack.R.id.np_day)
        val tvTime = dialogView.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_selected_time)

        var selectedHour = 9
        var selectedMinute = 0

        npDay.minValue = 1
        npDay.maxValue = 28
        npDay.value = 1

        val types = ReminderType.values().map { it.displayName }
        actvType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types))
        actvType.setText(types[0], false)

        tvTime.text = "09:00 AM"
        tvTime.setOnClickListener {
            TimePickerDialog(requireContext(), { _, h, m ->
                selectedHour = h; selectedMinute = m
                tvTime.text = String.format("%02d:%02d %s", if (h > 12) h - 12 else if (h == 0) 12 else h, m, if (h >= 12) "PM" else "AM")
            }, selectedHour, selectedMinute, false).show()
        }

        AlertDialog.Builder(requireContext())
            .setTitle("Add Reminder")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val title = etTitle.text.toString().trim().ifBlank { "SIP Reminder" }
                val typeStr = actvType.text.toString()
                val type = ReminderType.values().firstOrNull { it.displayName == typeStr } ?: ReminderType.SIP
                val reminder = Reminder(
                    title = title,
                    description = etDesc.text.toString().trim(),
                    type = type,
                    dayOfMonth = npDay.value,
                    hour = selectedHour,
                    minute = selectedMinute,
                    amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0
                )
                viewModel.save(reminder)
                // Schedule notification after save
                viewLifecycleOwner.lifecycleScope.launch {
                    kotlinx.coroutines.delay(500)
                    viewModel.reminders.value.lastOrNull()?.let {
                        ReminderWorker.schedule(requireContext(), it)
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class ReminderAdapter(
    private val onToggle: (Reminder) -> Unit,
    private val onDelete: (Reminder) -> Unit
) : ListAdapter<Reminder, ReminderAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemReminderBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(r: Reminder) {
            b.tvTitle.text = r.title
            b.tvType.text = r.type.displayName
            val amtText = if (r.amount > 0) " • ₹${String.format("%,.0f", r.amount)}" else ""
            b.tvDetails.text = "Day ${r.dayOfMonth} of every month${amtText}"
            val h = r.hour; val m = r.minute
            val ampm = if (h >= 12) "PM" else "AM"
            val displayH = if (h > 12) h - 12 else if (h == 0) 12 else h
            b.tvTime.text = String.format("%02d:%02d %s", displayH, m, ampm)
            b.switchActive.isChecked = r.isActive
            b.switchActive.setOnCheckedChangeListener(null)
            b.switchActive.setOnCheckedChangeListener { _, _ -> onToggle(r) }
            b.btnDelete.setOnClickListener { onDelete(r) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemReminderBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Reminder>() {
            override fun areItemsTheSame(a: Reminder, b: Reminder) = a.id == b.id
            override fun areContentsTheSame(a: Reminder, b: Reminder) = a == b
        }
    }
}
