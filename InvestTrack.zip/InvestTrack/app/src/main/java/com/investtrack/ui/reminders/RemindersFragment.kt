package com.investtrack.ui.reminders

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Reminder
import com.investtrack.data.models.ReminderType
import com.investtrack.databinding.FragmentRemindersBinding
import com.investtrack.databinding.ItemReminderBinding
import com.investtrack.workers.ReminderWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RemindersViewModel @Inject constructor(
    private val reminderDao: ReminderDao,
    private val loanDao: com.investtrack.data.dao.LoanDao,
    @dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context
) : ViewModel() {

    init {
        // Keep reminders that were generated from a loan's EMI in sync with that loan
        // (name, EMI amount, due day) and drop them if the loan has been removed.
        viewModelScope.launch {
            loanDao.getAllLoans().collect { loans -> syncLoanReminders(loans) }
        }
    }

    private suspend fun syncLoanReminders(loans: List<com.investtrack.data.models.Loan>) {
        val byId = loans.associateBy { it.id }
        reminderDao.getAllRemindersList().filter { it.linkedLoanId != null }.forEach { r ->
            val loan = byId[r.linkedLoanId]
            if (loan == null) {
                ReminderWorker.cancelAll(appContext, r.id)
                reminderDao.deleteReminder(r)
            } else {
                val updated = r.copy(
                    title = "${loan.loanName} EMI",
                    dueDayOfMonth = loan.emiDay,
                    amount = loan.emiAmount
                )
                if (updated != r) {
                    reminderDao.insertReminder(updated)
                    if (updated.isActive) ReminderWorker.scheduleAll(appContext, updated)
                }
            }
        }
    }

    /** Saves a new reminder and schedules its notifications with the real database id. */
    fun saveAndSchedule(reminder: Reminder) = viewModelScope.launch {
        val id = reminderDao.insertReminder(reminder)
        ReminderWorker.scheduleAll(appContext, reminder.copy(id = if (reminder.id == 0L) id else reminder.id))
    }

    val reminders: StateFlow<List<Reminder>> = reminderDao.getAllReminders()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun save(reminder: Reminder) = viewModelScope.launch { reminderDao.insertReminder(reminder) }
    fun delete(reminder: Reminder) = viewModelScope.launch { reminderDao.deleteReminder(reminder) }
    fun toggle(reminder: Reminder, active: Boolean) = viewModelScope.launch {
        reminderDao.setActive(reminder.id, active)
    }
}

@AndroidEntryPoint
class RemindersFragment : Fragment() {
    private var _binding: FragmentRemindersBinding? = null
    private val binding get() = _binding!!
    private val viewModel: RemindersViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentRemindersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = ReminderAdapter(
            onToggle = { reminder, active ->
                viewModel.toggle(reminder, active)
                if (active) ReminderWorker.scheduleAll(requireContext(), reminder)
                else ReminderWorker.cancelAll(requireContext(), reminder.id)
            },
            onDelete = { reminder ->
                com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Delete Reminder")
                    .setMessage("Delete \"${reminder.title}\"?")
                    .setPositiveButton("Delete") { _, _ ->
                        ReminderWorker.cancelAll(requireContext(), reminder.id)
                        viewModel.delete(reminder)
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvReminders.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }
        binding.fabAddReminder.setOnClickListener { showAddReminderDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.reminders.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun showAddReminderDialog() {
        val v = LayoutInflater.from(requireContext()).inflate(com.investtrack.R.layout.dialog_add_reminder, null)
        val ctx = requireContext()

        val etTitle = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_title)
        val etDesc = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_desc)
        val etAmount = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_reminder_amount)
        val actvType = v.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_reminder_type)
        val actvDueDay = v.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_due_day)
        val actvR1Days = v.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_remind1_days)
        val actvR2Days = v.findViewById<android.widget.AutoCompleteTextView>(com.investtrack.R.id.actv_remind2_days)
        val etR1Time = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_remind1_time)
        val etR2Time = v.findViewById<com.google.android.material.textfield.TextInputEditText>(com.investtrack.R.id.et_remind2_time)

        var r1Hour = 9; var r1Min = 0
        var r2Hour = 9; var r2Min = 0

        // Due day: 1..31 (29/30/31 fall on the last day of shorter months)
        val dayLabels = (1..31).map { com.investtrack.utils.ReminderSchedule.ordinal(it) }
        actvDueDay.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, dayLabels))
        actvDueDay.setText(dayLabels[9], false) // 10th

        val beforeLabels = (1..7).map { if (it == 1) "1 day before" else "$it days before" }
        actvR1Days.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, beforeLabels))
        actvR2Days.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, beforeLabels))
        actvR1Days.setText(beforeLabels[1], false)
        actvR2Days.setText(beforeLabels[0], false)

        etR1Time.setText(formatTime(r1Hour, r1Min))
        etR2Time.setText(formatTime(r2Hour, r2Min))
        etR1Time.setOnClickListener {
            TimePickerDialog(ctx, com.investtrack.R.style.InvestTrackPickerDialog, { _, h, m ->
                r1Hour = h; r1Min = m; etR1Time.setText(formatTime(h, m))
            }, r1Hour, r1Min, false).show()
        }
        etR2Time.setOnClickListener {
            TimePickerDialog(ctx, com.investtrack.R.style.InvestTrackPickerDialog, { _, h, m ->
                r2Hour = h; r2Min = m; etR2Time.setText(formatTime(h, m))
            }, r2Hour, r2Min, false).show()
        }

        val types = ReminderType.values().map { it.displayName }
        actvType.setAdapter(ArrayAdapter(ctx, android.R.layout.simple_dropdown_item_1line, types))
        actvType.setText(types[0], false)

        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("Add Reminder")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val title = etTitle.text.toString().trim().ifBlank { "SIP Reminder" }
                val type = ReminderType.values().firstOrNull { it.displayName == actvType.text.toString() } ?: ReminderType.SIP
                val dueDay = (dayLabels.indexOf(actvDueDay.text.toString()) + 1).coerceIn(1, 31)
                val d1 = (beforeLabels.indexOf(actvR1Days.text.toString()) + 1).coerceIn(1, 7)
                val d2 = (beforeLabels.indexOf(actvR2Days.text.toString()) + 1).coerceIn(1, 7)
                viewModel.saveAndSchedule(
                    Reminder(
                        title = title,
                        description = etDesc.text.toString().trim(),
                        type = type,
                        dueDayOfMonth = dueDay,
                        amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0,
                        remind1DaysBefore = d1,
                        remind1Hour = r1Hour, remind1Minute = r1Min,
                        remind2DaysBefore = d2,
                        remind2Hour = r2Hour, remind2Minute = r2Min
                    )
                )
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun formatTime(h: Int, m: Int): String {
        val ampm = if (h >= 12) "PM" else "AM"
        val dh = if (h > 12) h - 12 else if (h == 0) 12 else h
        return String.format("%02d:%02d %s", dh, m, ampm)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class ReminderAdapter(
    private val onToggle: (Reminder, Boolean) -> Unit,
    private val onDelete: (Reminder) -> Unit
) : ListAdapter<Reminder, ReminderAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemReminderBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(r: Reminder) {
            b.tvTitle.text = r.title
            b.tvType.text = r.type.displayName
            val amtText = if (r.amount > 0) " • ₹${String.format("%,.0f", r.amount)}" else ""
            b.tvDetails.text = "Due: ${com.investtrack.utils.ReminderSchedule.dueLabel(r.dueDayOfMonth)}$amtText"

            // Show both reminders
            fun before(d: Int) = if (d == 1) "1 day before" else "$d days before"
            b.tvTime.text = "🔔 ${before(r.remind1DaysBefore)} @ ${formatTime(r.remind1Hour, r.remind1Minute)}
" +
                "🔔 ${before(r.remind2DaysBefore)} @ ${formatTime(r.remind2Hour, r.remind2Minute)}"

            b.switchActive.isChecked = r.isActive
            b.switchActive.setOnCheckedChangeListener(null)
            b.switchActive.setOnCheckedChangeListener { _, checked -> onToggle(r, checked) }
            b.btnDelete.setOnClickListener { onDelete(r) }
        }

        private fun formatTime(h: Int, m: Int): String {
            val ampm = if (h >= 12) "PM" else "AM"
            val dh = if (h > 12) h - 12 else if (h == 0) 12 else h
            return String.format("%02d:%02d %s", dh, m, ampm)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemReminderBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Reminder>() {
            override fun areItemsTheSame(a: Reminder, b: Reminder) = a.id == b.id
            override fun areContentsTheSame(a: Reminder, b: Reminder) = a == b
        }
    }
}
