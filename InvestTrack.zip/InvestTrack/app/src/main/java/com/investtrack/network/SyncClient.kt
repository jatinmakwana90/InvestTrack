package com.investtrack.network

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.ProfileDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncClient @Inject constructor(
    private val profileDao: ProfileDao,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) {
    private val client = HttpClient(OkHttp) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true; encodeDefaults = true })
        }
    }

    data class SyncResult(val success: Boolean, val message: String, val recordsUpdated: Int = 0)

    suspend fun ping(ip: String, port: Int): Boolean {
        return try {
            val response = client.get("http://$ip:$port/ping")
            response.body<String>() == "INVESTTRACK_OK"
        } catch (e: Exception) {
            false
        }
    }

    suspend fun sync(ip: String, port: Int, token: String): SyncResult {
        return try {
            val payload: SyncPayload = client.get("http://$ip:$port/sync/$token").body()
            var updated = 0

            // Merge profiles — latest updatedAt/createdAt wins
            payload.profiles.forEach { remote ->
                val local = profileDao.getProfileById(remote.id)
                if (local == null || remote.createdAt > local.createdAt) {
                    profileDao.insertProfile(remote)
                    updated++
                }
            }

            // Merge accounts
            payload.accounts.forEach { remote ->
                val local = accountDao.getAccountById(remote.id)
                if (local == null || remote.createdAt > local.createdAt) {
                    accountDao.insertAccount(remote)
                    updated++
                }
            }

            // Merge securities — latest lastUpdated wins
            payload.securities.forEach { remote ->
                val local = securityDao.getSecurityById(remote.id)
                if (local == null || remote.lastUpdated > local.lastUpdated) {
                    securityDao.insertSecurity(remote)
                    updated++
                }
            }

            // Merge transactions — latest updatedAt wins
            val remoteToInsert = payload.transactions.filter { remote ->
                val local = transactionDao.getTransactionById(remote.id)
                local == null || remote.updatedAt > local.updatedAt
            }
            if (remoteToInsert.isNotEmpty()) {
                transactionDao.insertTransactions(remoteToInsert)
                updated += remoteToInsert.size
            }

            SyncResult(true, "Sync complete. $updated records updated.", updated)
        } catch (e: Exception) {
            SyncResult(false, "Sync failed: ${e.message}")
        }
    }

    fun parsePairingString(pairingStr: String): Triple<String, Int, String>? {
        // Format: INVESTTRACK:ip:port:token
        return try {
            val parts = pairingStr.trim().split(":")
            if (parts.size != 4 || parts[0] != "INVESTTRACK") return null
            Triple(parts[1], parts[2].toInt(), parts[3])
        } catch (e: Exception) {
            null
        }
    }
}
