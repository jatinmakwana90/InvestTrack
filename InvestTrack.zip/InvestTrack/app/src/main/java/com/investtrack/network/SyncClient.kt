package com.investtrack.network

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.ProfileDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Serializable
data class SyncPayload(
    val profiles: List<Profile> = emptyList(),
    val accounts: List<Account> = emptyList(),
    val securities: List<Security> = emptyList(),
    val transactions: List<Transaction> = emptyList(),
    val syncTimestamp: Long = System.currentTimeMillis()
)

@Singleton
class SyncClient @Inject constructor(
    private val profileDao: ProfileDao,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao
) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    data class SyncResult(val success: Boolean, val message: String, val recordsUpdated: Int = 0)

    fun ping(ip: String, port: Int): Boolean {
        return try {
            val req = Request.Builder().url("http://$ip:$port/ping").build()
            client.newCall(req).execute().use { it.body?.string() == "INVESTTRACK_OK" }
        } catch (e: Exception) { false }
    }

    suspend fun sync(ip: String, port: Int, token: String): SyncResult {
        return try {
            val req = Request.Builder().url("http://$ip:$port/sync/$token").build()
            val body = client.newCall(req).execute().use { response ->
                if (!response.isSuccessful) return SyncResult(false, "Server error: ${response.code}")
                response.body?.string() ?: return SyncResult(false, "Empty response")
            }
            val payload = json.decodeFromString<SyncPayload>(body)
            var updated = 0

            payload.profiles.forEach { remote ->
                val local = profileDao.getProfileById(remote.id)
                if (local == null || remote.createdAt > local.createdAt) {
                    profileDao.insertProfile(remote); updated++
                }
            }
            payload.accounts.forEach { remote ->
                val local = accountDao.getAccountById(remote.id)
                if (local == null || remote.createdAt > local.createdAt) {
                    accountDao.insertAccount(remote); updated++
                }
            }
            payload.securities.forEach { remote ->
                val local = securityDao.getSecurityById(remote.id)
                if (local == null || remote.lastUpdated > local.lastUpdated) {
                    securityDao.insertSecurity(remote); updated++
                }
            }
            val toInsert = payload.transactions.filter { remote ->
                val local = transactionDao.getTransactionById(remote.id)
                local == null || remote.updatedAt > local.updatedAt
            }
            if (toInsert.isNotEmpty()) {
                transactionDao.insertTransactions(toInsert); updated += toInsert.size
            }
            SyncResult(true, "Sync complete. $updated records updated.", updated)
        } catch (e: Exception) {
            SyncResult(false, "Sync failed: ${e.message}")
        }
    }

    fun parsePairingString(pairingStr: String): Triple<String, Int, String>? {
        return try {
            val parts = pairingStr.trim().split(":")
            if (parts.size != 4 || parts[0] != "INVESTTRACK") return null
            Triple(parts[1], parts[2].toInt(), parts[3])
        } catch (e: Exception) { null }
    }
}
