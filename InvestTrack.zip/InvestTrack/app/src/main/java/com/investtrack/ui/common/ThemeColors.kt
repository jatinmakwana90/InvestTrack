package com.investtrack.ui.common

import android.content.Context
import com.google.android.material.color.MaterialColors

/** Resolves one of the accent attributes (R.attr.accentPrimary, …) to the colour of the current theme. */
fun Context.themeColor(attr: Int): Int = MaterialColors.getColor(this, attr, android.graphics.Color.GRAY)
