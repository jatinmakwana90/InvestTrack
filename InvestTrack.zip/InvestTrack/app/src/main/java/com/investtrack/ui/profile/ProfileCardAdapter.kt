package com.investtrack.ui.profile

import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.ProfileSummary
import com.investtrack.databinding.ItemProfileCardBinding
import com.investtrack.utils.CurrencyFormatter

class ProfileCardAdapter(
    private val onProfileClick: (ProfileSummary) -> Unit
) : ListAdapter<ProfileSummary, ProfileCardAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemProfileCardBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: ProfileSummary) {
            val profile = item.profile
            val summary = item.summary
            b.tvProfileName.text = profile.name
            b.tvRelation.text = profile.relation.displayName
            b.tvInitial.text = profile.name.first().uppercase()
            b.tvCurrentValue.text = CurrencyFormatter.format(summary.currentValue)
            b.tvInvested.text = "Inv: ${CurrencyFormatter.format(summary.totalInvested)}"

            val pnl = summary.totalPnL
            val pct = summary.totalPnLPercent
            val pnlStr = "${if (pnl >= 0) "▲" else "▼"} ${CurrencyFormatter.format(kotlin.math.abs(pnl))} (${String.format("%.2f", kotlin.math.abs(pct))}%)"
            b.tvPnl.text = pnlStr
            b.tvPnl.setTextColor(
                b.root.context.getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red)
            )
            b.tvHoldings.text = "${summary.folioCount} holdings"

            // Relation color badge
            val badgeColor = when (profile.relation.name) {
                "SELF" -> R.color.profile_self
                "SPOUSE" -> R.color.profile_spouse
                "CHILD" -> R.color.profile_child
                "PARENT" -> R.color.profile_parent
                else -> R.color.primary
            }
            b.viewBadge.setBackgroundColor(b.root.context.getColor(badgeColor))
            b.tvInitial.setBackgroundColor(b.root.context.getColor(badgeColor))

            b.root.setOnClickListener { onProfileClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemProfileCardBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ProfileSummary>() {
            override fun areItemsTheSame(a: ProfileSummary, b: ProfileSummary) = a.profile.id == b.profile.id
            override fun areContentsTheSame(a: ProfileSummary, b: ProfileSummary) = a == b
        }
    }
}
