package com.investtrack.ui.transactions

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddTransactionBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class EditTransactionViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val transactionId: Long = savedStateHandle.get<Long>("transactionId") ?: 0L
    private val _transaction = MutableStateFlow<Transaction?>(null)
    val transaction: StateFlow<Transaction?> = _transaction
    private val _securities = MutableStateFlow<List<Security>>(emptyList())
    val securities: StateFlow<List<Security>> = _securities
    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved

    init {
        viewModelScope.launch {
            _transaction.value = repository.getTransactionById(transactionId)
            repository.getAllSecurities().collect { _securities.value = it }
        }
    }

    fun save(updated: Transaction) {
        viewModelScope.launch { repository.updateTransaction(updated); _saved.value = true }
    }
}

@AndroidEntryPoint
class EditTransactionFragment : Fragment() {
    private var _binding: FragmentAddTransactionBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EditTransactionViewModel by viewModels()
    private var selectedDate = System.currentTimeMillis()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private var selectedSecurityId = 0L
    private var originalTransaction: Transaction? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddTransactionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = "Edit Transaction"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.btnSave.text = "Update Transaction"
        binding.tilAccount.visibility = View.GONE

        binding.actvTxnType.setAdapter(ArrayAdapter(requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            TransactionType.values().map { it.displayName }))

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.transaction.collect { txn ->
                txn ?: return@collect
                originalTransaction = txn
                selectedSecurityId = txn.securityId
                selectedDate = txn.transactionDate
                binding.etDate.setText(dateFmt.format(Date(selectedDate)))
                binding.actvTxnType.setText(txn.type.displayName, false)
                binding.etQty.setText(txn.quantity.toString())
                binding.etPrice.setText(txn.price.toString())
                binding.etCharges.setText(txn.charges.toString())
                binding.etFolioNo.setText(txn.folioNumber)
                binding.etNotes.setText(txn.notes)
                binding.tvCalculatedAmount.text = "Amount: ₹${String.format("%,.2f", txn.amount)}"
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.securities.collect { list ->
                val names = list.map { "${it.name} (${it.type.displayName})" }
                binding.actvSecurity.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names))
                list.firstOrNull { it.id == selectedSecurityId }?.let {
                    binding.actvSecurity.setText("${it.name} (${it.type.displayName})", false)
                }
                binding.actvSecurity.setOnItemClickListener { _, _, pos, _ -> selectedSecurityId = list[pos].id }
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.saved.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        binding.etDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d); selectedDate = cal.timeInMillis
                binding.etDate.setText(dateFmt.format(Date(selectedDate)))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding.etQty.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val qty = binding.etQty.text.toString().toDoubleOrNull() ?: return
                val price = binding.etPrice.text.toString().toDoubleOrNull() ?: return
                binding.tvCalculatedAmount.text = "Amount: ₹${String.format("%,.2f", qty * price)}"
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        binding.btnSave.setOnClickListener {
            val orig = originalTransaction ?: return@setOnClickListener
            val qty = binding.etQty.text.toString().toDoubleOrNull() ?: return@setOnClickListener
            val price = binding.etPrice.text.toString().toDoubleOrNull() ?: return@setOnClickListener
            val type = TransactionType.values().firstOrNull { it.displayName == binding.actvTxnType.text.toString() } ?: orig.type
            viewModel.save(orig.copy(securityId = selectedSecurityId, type = type, quantity = qty, price = price,
                amount = qty * price, charges = binding.etCharges.text.toString().toDoubleOrNull() ?: 0.0,
                folioNumber = binding.etFolioNo.text.toString().trim(),
                notes = binding.etNotes.text.toString().trim(),
                transactionDate = selectedDate, updatedAt = System.currentTimeMillis()))
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
    companion object {
        fun newInstance(id: Long) = EditTransactionFragment().apply {
            arguments = Bundle().apply { putLong("transactionId", id) }
        }
    }
}
