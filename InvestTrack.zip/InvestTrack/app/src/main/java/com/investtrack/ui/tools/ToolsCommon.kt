package com.investtrack.ui.tools

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AutoCompleteTextView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.databinding.FragmentToolFormBinding
import com.investtrack.databinding.FragmentToolListBinding
import com.investtrack.databinding.ItemToolHeaderBinding
import com.investtrack.databinding.ItemToolRowBinding
import com.investtrack.ui.common.NoFilterAdapter
import com.investtrack.utils.DateUtil
import java.util.Calendar

// ---------------------------------------------------------------- small helpers

fun TextView.num(): Double = text?.toString()?.replace(",", "")?.trim()?.toDoubleOrNull() ?: 0.0

fun TextView.onChange(action: () -> Unit) {
    addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { action() }
        override fun afterTextChanged(s: Editable?) {}
    })
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

// ---------------------------------------------------------------- list rows

data class ToolRow(
    val key: String,
    val title: String,
    val subtitle: String = "",
    val amount: String = "",
    val amountSub: String = "",
    val status: String = "",
    /** Colour resource for the status line; 0 = normal secondary text colour. */
    val statusColor: Int = 0,
    /** (actionId, label) pairs shown under the row. */
    val actions: List<Pair<String, String>> = emptyList(),
    val isHeader: Boolean = false
)

class ToolRowAdapter(
    private val onClick: (ToolRow) -> Unit,
    private val onAction: (ToolRow, String) -> Unit
) : ListAdapter<ToolRow, RecyclerView.ViewHolder>(DIFF) {

    override fun getItemViewType(position: Int) = if (getItem(position).isHeader) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 0) HeaderVH(ItemToolHeaderBinding.inflate(inflater, parent, false))
        else RowVH(ItemToolRowBinding.inflate(inflater, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = getItem(position)
        when (holder) {
            is HeaderVH -> holder.b.tvHeaderText.text = row.title
            is RowVH -> holder.bind(row)
        }
    }

    class HeaderVH(val b: ItemToolHeaderBinding) : RecyclerView.ViewHolder(b.root)

    inner class RowVH(private val b: ItemToolRowBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(row: ToolRow) {
            val ctx = b.root.context
            b.tvRowTitle.text = row.title
            b.tvRowSub.text = row.subtitle
            b.tvRowSub.visibility = if (row.subtitle.isEmpty()) View.GONE else View.VISIBLE
            b.tvRowAmount.text = row.amount
            b.tvRowAmountSub.text = row.amountSub
            b.tvRowAmountSub.visibility = if (row.amountSub.isEmpty()) View.GONE else View.VISIBLE
            b.tvRowStatus.text = row.status
            b.tvRowStatus.visibility = if (row.status.isEmpty()) View.GONE else View.VISIBLE
            b.tvRowStatus.setTextColor(ctx.getColor(if (row.statusColor != 0) row.statusColor else R.color.text_secondary))

            b.rowActions.removeAllViews()
            b.rowActions.visibility = if (row.actions.isEmpty()) View.GONE else View.VISIBLE
            row.actions.forEach { (id, label) ->
                val tv = TextView(ctx).apply {
                    text = label
                    textSize = 13f
                    setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
                    setTextColor(ctx.getColor(if (id == "delete") R.color.loss_red else R.color.text_link))
                    setBackgroundResource(android.R.drawable.list_selector_background)
                    setOnClickListener { onAction(row, id) }
                }
                b.rowActions.addView(tv)
            }
            b.root.setOnClickListener { onClick(row) }
        }
    }

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ToolRow>() {
            override fun areItemsTheSame(a: ToolRow, b: ToolRow) = a.key == b.key
            override fun areContentsTheSame(a: ToolRow, b: ToolRow) = a == b
        }
    }
}

// ---------------------------------------------------------------- form building

class DateField(val edit: TextInputEditText) {
    var value: Long? = null
        private set
    var optional = false
    private var onSet: (() -> Unit)? = null

    fun set(ms: Long?) {
        value = ms
        edit.setText(if (ms == null) "" else DateUtil.format(ms))
        onSet?.invoke()
    }
    fun onSet(action: () -> Unit) { onSet = action }
}

class ResultBox(val root: View) {
    private val head = root.findViewById<TextView>(R.id.tv_result_head)
    private val body = root.findViewById<TextView>(R.id.tv_result_body)

    /** [positive]: true = green headline, false = red, null = normal text colour. */
    fun show(headline: String, details: String, positive: Boolean? = true) {
        head.text = headline
        body.text = details
        val color = when (positive) {
            true -> R.color.gain_green
            false -> R.color.loss_red
            null -> R.color.loan_text_primary
        }
        head.setTextColor(root.context.getColor(color))
    }
}

/** A summary card: small title, one big figure, a caption and a tidy list of label / value rows. */
class StatCard(val root: View) {
    private val title = root.findViewById<TextView>(R.id.tv_stat_title)
    private val value = root.findViewById<TextView>(R.id.tv_stat_value)
    private val caption = root.findViewById<TextView>(R.id.tv_stat_caption)
    private val rows = root.findViewById<LinearLayout>(R.id.stat_rows)

    fun show(titleText: String, bigValue: String, captionText: String, items: List<Pair<String, String>>, positive: Boolean? = null) {
        val ctx = root.context
        title.text = titleText.uppercase()
        value.text = bigValue
        value.setTextColor(ctx.getColor(when (positive) {
            true -> R.color.gain_green
            false -> R.color.loss_red
            null -> R.color.loan_text_primary
        }))
        caption.text = captionText
        caption.visibility = if (captionText.isEmpty()) View.GONE else View.VISIBLE
        rows.removeAllViews()
        items.forEach { (label, v) ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, ctx.dp(5), 0, ctx.dp(5))
            }
            row.addView(TextView(ctx).apply {
                text = label; textSize = 13f
                setTextColor(ctx.getColor(R.color.loan_text_secondary))
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(TextView(ctx).apply {
                text = v; textSize = 14f
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
                setTextColor(ctx.getColor(R.color.loan_text_primary))
                gravity = android.view.Gravity.END
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            rows.addView(row)
        }
    }
}

class FormBuilder(private val ctx: Context, val container: LinearLayout) {
    private val inflater = LayoutInflater.from(ctx)

    fun sectionTitle(text: String): TextView {
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = 15f
            setTextColor(ctx.getColor(R.color.text_link))
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setPadding(0, ctx.dp(6), 0, ctx.dp(8))
        }
        container.addView(tv)
        return tv
    }

    fun note(text: String): TextView {
        val tv = TextView(ctx).apply {
            this.text = text
            textSize = 13f
            setTextColor(ctx.getColor(R.color.loan_text_secondary))
            setPadding(0, 0, 0, ctx.dp(12))
        }
        container.addView(tv)
        return tv
    }

    fun text(label: String, hint: String = "", initial: String = "",
             inputType: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS): TextInputEditText {
        val v = inflater.inflate(R.layout.view_form_text, container, false)
        v.findViewById<TextView>(R.id.form_label).text = label.uppercase()
        val et = v.findViewById<TextInputEditText>(R.id.form_input)
        et.inputType = inputType
        et.hint = hint
        if (initial.isNotEmpty()) et.setText(initial)
        container.addView(v)
        return et
    }

    fun number(label: String, hint: String = "", initial: String = ""): TextInputEditText =
        text(label, hint, initial, InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)

    fun multiline(label: String, hint: String = "", initial: String = "", lines: Int = 4): TextInputEditText {
        val et = text(label, hint, initial, InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
        et.minLines = lines
        et.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        return et
    }

    fun dropdown(label: String, options: List<String>, selected: String? = null): AutoCompleteTextView {
        val v = inflater.inflate(R.layout.view_form_dropdown, container, false)
        v.findViewById<TextView>(R.id.form_label).text = label.uppercase()
        val actv = v.findViewById<AutoCompleteTextView>(R.id.form_dropdown)
        actv.setAdapter(NoFilterAdapter(ctx, options))
        val start = if (selected != null && selected in options) selected else options.firstOrNull().orEmpty()
        actv.setText(start, false)
        container.addView(v)
        return actv
    }

    /** Tap to choose a date. For optional dates, long-press clears it. */
    fun date(label: String, initial: Long?, optional: Boolean = false): DateField {
        val et = text(label + if (optional) " (optional, hold to clear)" else "", if (optional) "Not set" else "Select date")
        et.inputType = InputType.TYPE_NULL
        et.isFocusable = false
        et.isClickable = true
        val field = DateField(et)
        field.optional = optional
        field.set(initial)
        et.setOnClickListener {
            val c = Calendar.getInstance().apply { timeInMillis = field.value ?: System.currentTimeMillis() }
            DatePickerDialog(ctx, R.style.InvestTrackPickerDialog, { _, y, m, d ->
                field.set(Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }.timeInMillis)
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        if (optional) et.setOnLongClickListener { field.set(null); true }
        return field
    }

    fun check(label: String, checked: Boolean): MaterialCheckBox {
        val cb = MaterialCheckBox(ctx).apply {
            text = label
            isChecked = checked
            textSize = 15f
            setTextColor(ctx.getColor(R.color.loan_text_primary))
        }
        container.addView(cb)
        return cb
    }

    fun statCard(): StatCard {
        val v = inflater.inflate(R.layout.view_stat_card, container, false)
        container.addView(v)
        return StatCard(v)
    }

    fun result(): ResultBox {
        val v = inflater.inflate(R.layout.view_result_box, container, false)
        container.addView(v)
        return ResultBox(v)
    }

    fun button(text: String, filled: Boolean = false, onClick: () -> Unit): MaterialButton {
        val b = MaterialButton(ctx, null, 0).apply {
            this.text = text
            setAllCaps(false)
            textSize = 15f
            cornerRadius = ctx.dp(14)
            minimumHeight = ctx.dp(50)
            backgroundTintList = android.content.res.ColorStateList.valueOf(
                ctx.getColor(if (filled) R.color.loan_accent else R.color.loan_surface_alt)
            )
            setTextColor(if (filled) android.graphics.Color.WHITE else ctx.getColor(R.color.text_link))
            setOnClickListener { onClick() }
        }
        container.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = ctx.dp(10)
        })
        return b
    }

    fun space(dp: Int) {
        container.addView(View(ctx), LinearLayout.LayoutParams(1, ctx.dp(dp)))
    }
}

/**
 * Shows a form in a dialog. [onSave] returns true when the form was valid (dialog closes),
 * false to keep it open so the person can correct something.
 */
fun Fragment.showFormDialog(title: String, positive: String = "Save", build: (FormBuilder) -> Unit, onSave: () -> Boolean) {
    val ctx = requireContext()
    val scroll = ScrollView(ctx)
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(4))
    }
    scroll.addView(box)
    build(FormBuilder(ctx, box))
    val dialog = MaterialAlertDialogBuilder(ctx)
        .setTitle(title)
        .setView(scroll)
        .setPositiveButton(positive, null)
        .setNegativeButton("Cancel", null)
        .create()
    dialog.setOnShowListener {
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            if (onSave()) dialog.dismiss()
        }
    }
    dialog.show()
}

fun Fragment.toast(msg: String) =
    android.widget.Toast.makeText(requireContext(), msg, android.widget.Toast.LENGTH_SHORT).show()

// ---------------------------------------------------------------- base screens

/** A header + list + "+" button screen. Subclasses fill the list through [submit]. */
abstract class ToolListFragment : Fragment() {

    private var _b: FragmentToolListBinding? = null
    private val b get() = _b!!

    abstract val screenTitle: String
    abstract val emptyText: String
    open val canAdd: Boolean = true

    abstract fun onAdd()
    abstract fun onRowClick(row: ToolRow)
    abstract fun onRowAction(row: ToolRow, action: String)
    /** Start collecting data; call [submit] with the rows whenever it changes. */
    abstract fun observe()

    private lateinit var adapter: ToolRowAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentToolListBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        b.tvToolTitle.text = screenTitle
        b.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        b.fabToolAdd.visibility = if (canAdd) View.VISIBLE else View.GONE
        b.fabToolAdd.setOnClickListener { onAdd() }
        adapter = ToolRowAdapter({ onRowClick(it) }, { row, action -> onRowAction(row, action) })
        b.rvTool.layoutManager = LinearLayoutManager(requireContext())
        b.rvTool.adapter = adapter
        b.tvToolEmpty.text = emptyText
        observe()
    }

    protected fun submit(rows: List<ToolRow>, summary: String) {
        val binding = _b ?: return
        adapter.submitList(rows)
        binding.tvToolSummary.text = summary
        binding.tvToolSummary.visibility = if (summary.isEmpty()) View.GONE else View.VISIBLE
        binding.tvToolEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onDestroyView() { _b = null; super.onDestroyView() }
}

/** A header + scrolling form screen (calculators, reports). Subclasses add fields in [buildForm]. */
abstract class ToolFormFragment : Fragment() {

    private var _b: FragmentToolFormBinding? = null
    protected val formContainer: LinearLayout get() = _b!!.formContainer

    abstract val screenTitle: String
    abstract fun buildForm(form: FormBuilder)

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentToolFormBinding.inflate(inflater, container, false)
        return _b!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _b!!.tvToolTitle.text = screenTitle
        _b!!.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        buildForm(FormBuilder(requireContext(), formContainer))
    }

    override fun onDestroyView() { _b = null; super.onDestroyView() }
}
