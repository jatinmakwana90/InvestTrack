package com.investtrack.ui.market

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.Security
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentMarketUpdateBinding
import com.investtrack.databinding.ItemPriceUpdateBinding
import com.investtrack.network.YahooFinanceService
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.workers.MarketPriceWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class PriceUpdateItem(
    val security: Security,
    val newPrice: Double = 0.0,
    val change: Double = 0.0,
    val changePercent: Double = 0.0,
    val status: UpdateStatus = UpdateStatus.PENDING
)

enum class UpdateStatus { PENDING, UPDATING, SUCCESS, FAILED, NO_CODE }

@HiltViewModel
class MarketUpdateViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val yahooFinanceService: YahooFinanceService
) : ViewModel() {

    private val _uiState = MutableStateFlow(MarketUpdateUiState())
    val uiState: StateFlow<MarketUpdateUiState> = _uiState.asStateFlow()

    init { loadSecurities() }

    private fun loadSecurities() {
        viewModelScope.launch {
            repository.getAllSecurities().collect { securities ->
                val items = securities.map { sec ->
                    PriceUpdateItem(
                        security = sec,
                        newPrice = sec.currentPrice,
                        status = if (sec.yahooFinanceCode.isBlank()) UpdateStatus.NO_CODE else UpdateStatus.PENDING
                    )
                }
                _uiState.update { it.copy(items = items) }
            }
        }
    }

    fun updateAllPrices() {
        viewModelScope.launch {
            val items = _uiState.value.items
            val updatableItems = items.filter { it.security.yahooFinanceCode.isNotBlank() }
            if (updatableItems.isEmpty()) return@launch
            _uiState.update { it.copy(isUpdating = true) }
            _uiState.update { state ->
                state.copy(items = state.items.map { item ->
                    if (item.security.yahooFinanceCode.isNotBlank()) item.copy(status = UpdateStatus.UPDATING) else item
                })
            }
            withContext(Dispatchers.IO) {
                val codes = updatableItems.map { it.security.yahooFinanceCode }
                val prices = yahooFinanceService.fetchPrices(codes)
                val updatedItems = _uiState.value.items.map { item ->
                    val result = prices[item.security.yahooFinanceCode]
                    if (result != null) {
                        repository.updatePrice(item.security.id, result.price, result.previousClose)
                        item.copy(newPrice = result.price, change = result.change, changePercent = result.changePercent, status = UpdateStatus.SUCCESS)
                    } else if (item.security.yahooFinanceCode.isNotBlank()) {
                        item.copy(status = UpdateStatus.FAILED)
                    } else item
                }
                val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(isUpdating = false, items = updatedItems, lastUpdated = "Updated: ${fmt.format(Date())}") }
                }
            }
        }
    }

    fun updateSinglePrice(security: Security) {
        viewModelScope.launch {
            if (security.yahooFinanceCode.isBlank()) return@launch
            _uiState.update { state ->
                state.copy(items = state.items.map { if (it.security.id == security.id) it.copy(status = UpdateStatus.UPDATING) else it })
            }
            withContext(Dispatchers.IO) {
                val result = yahooFinanceService.fetchPrice(security.yahooFinanceCode)
                withContext(Dispatchers.Main) {
                    if (result != null) {
                        repository.updatePrice(security.id, result.price, result.previousClose)
                        _uiState.update { state ->
                            state.copy(items = state.items.map {
                                if (it.security.id == security.id)
                                    it.copy(newPrice = result.price, change = result.change, changePercent = result.changePercent, status = UpdateStatus.SUCCESS)
                                else it
                            })
                        }
                    } else {
                        _uiState.update { state ->
                            state.copy(items = state.items.map { if (it.security.id == security.id) it.copy(status = UpdateStatus.FAILED) else it })
                        }
                    }
                }
            }
        }
    }
}

data class MarketUpdateUiState(
    val items: List<PriceUpdateItem> = emptyList(),
    val isUpdating: Boolean = false,
    val lastUpdated: String = ""
)

@AndroidEntryPoint
class MarketUpdateFragment : Fragment() {

    private var _binding: FragmentMarketUpdateBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MarketUpdateViewModel by viewModels()
    private lateinit var adapter: PriceUpdateAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMarketUpdateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }
        adapter = PriceUpdateAdapter { item -> viewModel.updateSinglePrice(item.security) }
        binding.rvPrices.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = this@MarketUpdateFragment.adapter
        }
        binding.btnUpdateAll.setOnClickListener { viewModel.updateAllPrices() }
        binding.btnSchedule.setOnClickListener {
            MarketPriceWorker.runOnce(requireContext())
            com.google.android.material.snackbar.Snackbar.make(binding.root, "Price update scheduled in background", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).show()
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                adapter.submitList(state.items)
                binding.progressUpdate.visibility = if (state.isUpdating) View.VISIBLE else View.GONE
                binding.btnUpdateAll.isEnabled = !state.isUpdating
                binding.btnUpdateAll.text = if (state.isUpdating) "Updating..." else "Update All Prices"
                binding.tvLastUpdated.text = state.lastUpdated
                binding.tvLastUpdated.visibility = if (state.lastUpdated.isNotEmpty()) View.VISIBLE else View.GONE
                val withCode = state.items.count { it.security.yahooFinanceCode.isNotBlank() }
                binding.tvSummary.text = "$withCode of ${state.items.size} securities linked to Yahoo Finance"
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class PriceUpdateAdapter(
    private val onRefreshClick: (PriceUpdateItem) -> Unit
) : ListAdapter<PriceUpdateItem, PriceUpdateAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemPriceUpdateBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: PriceUpdateItem) {
            val sec = item.security
            b.tvSecurityName.text = sec.name
            b.tvSecurityType.text = sec.type.displayName
            b.tvYahooCode.text = if (sec.yahooFinanceCode.isNotBlank()) sec.yahooFinanceCode else "No Yahoo code — set in Security Master"
            b.tvYahooCode.setTextColor(b.root.context.getColor(if (sec.yahooFinanceCode.isNotBlank()) R.color.text_secondary else R.color.loss_red))
            b.tvCurrentPrice.text = CurrencyFormatter.format(sec.currentPrice)
            when (item.status) {
                UpdateStatus.SUCCESS -> {
                    b.tvNewPrice.text = CurrencyFormatter.format(item.newPrice)
                    b.tvNewPrice.visibility = View.VISIBLE
                    val sign = if (item.change >= 0) "▲" else "▼"
                    b.tvChange.text = "$sign ${String.format("%.2f", kotlin.math.abs(item.changePercent))}%"
                    b.tvChange.setTextColor(b.root.context.getColor(if (item.change >= 0) R.color.gain_green else R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnRefresh.visibility = View.VISIBLE
                }
                UpdateStatus.UPDATING -> {
                    b.progressItem.visibility = View.VISIBLE
                    b.btnRefresh.visibility = View.GONE
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                }
                UpdateStatus.FAILED -> {
                    b.tvChange.text = "Failed to fetch"
                    b.tvChange.setTextColor(b.root.context.getColor(R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnRefresh.visibility = View.VISIBLE
                    b.tvNewPrice.visibility = View.GONE
                }
                else -> {
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                    b.progressItem.visibility = View.GONE
                    b.btnRefresh.visibility = if (sec.yahooFinanceCode.isNotBlank()) View.VISIBLE else View.GONE
                }
            }
            b.btnRefresh.setOnClickListener { onRefreshClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPriceUpdateBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PriceUpdateItem>() {
            override fun areItemsTheSame(a: PriceUpdateItem, b: PriceUpdateItem) = a.security.id == b.security.id
            override fun areContentsTheSame(a: PriceUpdateItem, b: PriceUpdateItem) = a == b
        }
    }
}
