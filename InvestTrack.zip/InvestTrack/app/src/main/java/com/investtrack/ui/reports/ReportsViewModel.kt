package com.investtrack.ui.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CashFlowBucket
import com.investtrack.utils.CashFlowPeriod
import com.investtrack.utils.CashFlowReportCalculator
import com.investtrack.utils.OpenLotReport
import com.investtrack.utils.OpenLotReportCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ReportTab { CASH_FLOW, OPEN_LOTS }

data class ReportsUiState(
    val isLoading: Boolean = true,
    val selectedTab: ReportTab = ReportTab.CASH_FLOW,
    val cashFlowPeriod: CashFlowPeriod = CashFlowPeriod.YEARLY,
    val cashFlowBuckets: List<CashFlowBucket> = emptyList(),
    val openLotReport: OpenLotReport? = null,
    val error: String? = null
)

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    private var allTransactions: List<Transaction> = emptyList()

    init { load() }

    fun selectTab(tab: ReportTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun setCashFlowPeriod(period: CashFlowPeriod) {
        _uiState.update {
            it.copy(cashFlowPeriod = period, cashFlowBuckets = CashFlowReportCalculator.build(allTransactions, period))
        }
    }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                val transactions = repository.getAllTransactionsList()
                allTransactions = transactions
                val securities = repository.getAllSecuritiesList().associateBy { it.id }
                val accounts = repository.getAllAccountsList().associateBy { it.id }
                val portfolioSummary = repository.getPortfolioSummary()

                val txnsByKey = transactions.groupBy { it.accountId to it.securityId }

                val openLotReport = OpenLotReportCalculator.build(
                    transactionsBySecurityAccount = txnsByKey,
                    securities = securities,
                    accounts = accounts,
                    totalPortfolioValue = portfolioSummary.currentValue
                )

                val currentPeriod = _uiState.value.cashFlowPeriod
                val buckets = CashFlowReportCalculator.build(transactions, currentPeriod)

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        cashFlowBuckets = buckets,
                        openLotReport = openLotReport
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}
