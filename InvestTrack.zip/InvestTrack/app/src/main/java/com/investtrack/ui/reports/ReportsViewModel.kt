package com.investtrack.ui.reports

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Account
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CashFlowReportCalculator
import com.investtrack.utils.OpenLotReport
import com.investtrack.utils.OpenLotReportCalculator
import com.investtrack.utils.YearlyCashFlow
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ReportTab { CASH_FLOW, OPEN_LOTS }

data class ReportsUiState(
    val isLoading: Boolean = true,
    val selectedTab: ReportTab = ReportTab.CASH_FLOW,
    val accounts: List<Account> = emptyList(),
    val selectedAccountId: Long? = null, // null = All Accounts
    val cashFlowYears: List<YearlyCashFlow> = emptyList(),
    val expandedYears: Set<Int> = emptySet(),
    val openLotReport: OpenLotReport? = null,
    val expandedSecurities: Set<Long> = emptySet(),
    val error: String? = null
)

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    private var allTransactions: List<Transaction> = emptyList()
    private var securities: Map<Long, Security> = emptyMap()
    private var accountsById: Map<Long, Account> = emptyMap()

    init { load() }

    fun selectTab(tab: ReportTab) {
        _uiState.update { it.copy(selectedTab = tab) }
    }

    fun toggleYearExpanded(year: Int) {
        _uiState.update {
            val current = it.expandedYears.toMutableSet()
            if (!current.add(year)) current.remove(year)
            it.copy(expandedYears = current)
        }
    }

    fun toggleSecurityExpanded(securityId: Long) {
        _uiState.update {
            val current = it.expandedSecurities.toMutableSet()
            if (!current.add(securityId)) current.remove(securityId)
            it.copy(expandedSecurities = current)
        }
    }

    fun selectAccount(accountId: Long?) {
        _uiState.update { it.copy(selectedAccountId = accountId) }
        viewModelScope.launch { recompute() }
    }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            try {
                allTransactions = repository.getAllTransactionsList()
                securities = repository.getAllSecuritiesList().associateBy { it.id }
                val accountList = repository.getAllAccountsList()
                accountsById = accountList.associateBy { it.id }
                _uiState.update { it.copy(accounts = accountList) }
                recompute()
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    private suspend fun recompute() {
        try {
            val accountId = _uiState.value.selectedAccountId
            val filteredTransactions = if (accountId == null) allTransactions
                                        else allTransactions.filter { it.accountId == accountId }

            val portfolioValue = if (accountId == null) repository.getPortfolioSummary().currentValue
                                  else repository.getAccountPortfolioSummary(accountId).currentValue

            val txnsByKey = filteredTransactions.groupBy { it.accountId to it.securityId }
            val openLotReport = OpenLotReportCalculator.build(
                transactionsBySecurityAccount = txnsByKey,
                securities = securities,
                accounts = accountsById,
                totalPortfolioValue = portfolioValue
            )
            val years = CashFlowReportCalculator.build(filteredTransactions)

            _uiState.update {
                it.copy(
                    isLoading = false,
                    cashFlowYears = years,
                    openLotReport = openLotReport,
                    // Default the most recent year expanded so the screen isn't empty-looking.
                    expandedYears = if (it.expandedYears.isEmpty() && years.isNotEmpty())
                        setOf(years.first().year) else it.expandedYears
                )
            }
        } catch (e: Exception) {
            _uiState.update { it.copy(isLoading = false, error = e.message) }
        }
    }
}
