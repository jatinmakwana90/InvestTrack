package com.investtrack.ui.reports

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.databinding.ItemCashflowPeriodBinding
import com.investtrack.utils.CashFlowBucket
import com.investtrack.utils.CurrencyFormatter

class CashFlowSummaryAdapter : RecyclerView.Adapter<CashFlowSummaryAdapter.VH>() {
    private var buckets: List<CashFlowBucket> = emptyList()

    fun submit(newBuckets: List<CashFlowBucket>) {
        // Show most recent period first in the list (chart stays chronological).
        buckets = newBuckets.asReversed()
        notifyDataSetChanged()
    }

    inner class VH(private val b: ItemCashflowPeriodBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(bucket: CashFlowBucket) {
            val ctx = b.root.context
            b.tvPeriodLabel.text = bucket.periodLabel
            b.tvInflow.text = CurrencyFormatter.formatFullNoDecimals(bucket.inflow)
            b.tvOutflow.text = CurrencyFormatter.formatFullNoDecimals(bucket.outflow)
            val net = bucket.net
            b.tvNet.text = (if (net >= 0) "+" else "") + CurrencyFormatter.formatFullNoDecimals(net)
            b.tvNet.setTextColor(ctx.getColor(if (net >= 0) R.color.gain_green else R.color.loss_red))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCashflowPeriodBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = buckets.size

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(buckets[position])
}
