package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Profile
import kotlinx.coroutines.flow.Flow

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles WHERE isActive = 1 ORDER BY name ASC")
    fun getAllProfiles(): Flow<List<Profile>>

    @Query("SELECT * FROM profiles WHERE id = :id")
    suspend fun getProfileById(id: Long): Profile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: Profile): Long

    @Update
    suspend fun updateProfile(profile: Profile)

    @Query("UPDATE profiles SET isActive = 0 WHERE id = :id")
    suspend fun deactivateProfile(id: Long)

    @Query("SELECT COUNT(*) FROM profiles WHERE isActive = 1")
    suspend fun getProfileCount(): Int

    @Query("SELECT * FROM profiles WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getAllProfilesList(): List<Profile>
}
