package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.SyncConfigDao
import com.investtrack.network.SyncClient
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

@HiltWorker
class WifiSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val syncConfigDao: SyncConfigDao,
    private val syncClient: SyncClient
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {
        val config = syncConfigDao.getSyncConfigOnce() ?: return Result.success()
        if (!config.syncEnabled || config.isPrimaryDevice) return Result.success()
        if (config.targetIp.isBlank() || config.pairingToken.isBlank()) return Result.success()

        val reachable = syncClient.ping(config.targetIp, config.targetPort)
        if (!reachable) return Result.retry()

        val result = syncClient.sync(config.targetIp, config.targetPort, config.pairingToken)
        return if (result.success) {
            syncConfigDao.updateLastSyncTime(System.currentTimeMillis())
            Result.success()
        } else {
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "wifi_sync"

        fun schedule(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val request = PeriodicWorkRequestBuilder<WifiSyncWorker>(1, TimeUnit.DAYS)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun runOnce(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()
            val request = OneTimeWorkRequestBuilder<WifiSyncWorker>()
                .setConstraints(constraints)
                .build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
