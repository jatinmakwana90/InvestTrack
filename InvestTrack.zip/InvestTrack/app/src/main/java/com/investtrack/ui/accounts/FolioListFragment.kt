package com.investtrack.ui.accounts

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.Folio
import com.investtrack.data.models.Transaction
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentFolioListBinding
import com.investtrack.databinding.ItemFolioSummaryBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class FolioSummary(
    val folioNumber: String,
    val accountId: Long,
    val securityId: Long,
    val securityName: String,
    val totalUnits: Double,
    val avgCost: Double,
    val invested: Double,
    val currentValue: Double,
    val pnl: Double,
    val pnlPercent: Double
)

@HiltViewModel
class FolioListViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val accountId: Long = savedStateHandle.get<Long>("accountId") ?: 0L
    val securityId: Long = savedStateHandle.get<Long>("securityId") ?: 0L

    private val _folios = MutableStateFlow<List<FolioSummary>>(emptyList())
    val folios: StateFlow<List<FolioSummary>> = _folios

    private val _securityName = MutableStateFlow("")
    val securityName: StateFlow<String> = _securityName

    init { load() }

    private fun load() {
        viewModelScope.launch {
            repository.getTransactionsByFolio(accountId, securityId).collect { transactions ->
                val security = repository.getSecurityById(securityId)
                _securityName.value = security?.name ?: ""

                // Group transactions by folio number
                val byFolio = transactions.groupBy { it.folioNumber.ifBlank { "No Folio" } }
                val summaries = byFolio.map { (folio, txns) ->
                    val buys = txns.filter { it.type.name == "BUY" }
                    val sells = txns.filter { it.type.name == "SELL" || it.type.name == "MATURITY" }
                    val totalBuyQty = buys.sumOf { it.quantity }
                    val totalSellQty = sells.sumOf { it.quantity }
                    val netQty = totalBuyQty - totalSellQty
                    val totalBuyAmount = buys.sumOf { it.amount }
                    val totalSellAmount = sells.sumOf { it.amount }
                    val netInvested = totalBuyAmount - totalSellAmount
                    val avgCost = if (netQty > 0) netInvested / netQty else 0.0
                    val cmp = security?.currentPrice ?: 0.0
                    val effectivePrice = if (cmp <= 0) avgCost else cmp
                    val currentValue = netQty * effectivePrice
                    val pnl = currentValue - netInvested
                    val pnlPct = if (netInvested > 0) pnl / netInvested * 100 else 0.0
                    FolioSummary(folio, accountId, securityId, security?.name ?: "",
                        netQty, avgCost, netInvested, currentValue, pnl, pnlPct)
                }.filter { it.totalUnits > 0.001 }

                _folios.value = summaries
            }
        }
    }
}

@AndroidEntryPoint
class FolioListFragment : Fragment() {

    private var _binding: FragmentFolioListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: FolioListViewModel by viewModels()
    @Inject lateinit var settingsManager: SettingsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFolioListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = FolioSummaryAdapter(settingsManager) { folio ->
            val fragment = FolioTransactionsFragment.newInstance(
                folio.accountId, folio.securityId, folio.folioNumber, folio.securityName)
            (activity as? MainActivity)?.navigateTo(fragment)
        }
        binding.rvFolios.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.securityName.collect { binding.toolbar.title = it }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.folios.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(accountId: Long, securityId: Long, securityName: String) =
            FolioListFragment().apply {
                arguments = Bundle().apply {
                    putLong("accountId", accountId)
                    putLong("securityId", securityId)
                    putString("securityName", securityName)
                }
            }
    }
}

class FolioSummaryAdapter(
    private val settingsManager: SettingsManager,
    private val onClick: (FolioSummary) -> Unit
) : ListAdapter<FolioSummary, FolioSummaryAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemFolioSummaryBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(f: FolioSummary) {
            val mode = settingsManager.amountMode.value
            b.tvFolioNumber.text = if (f.folioNumber == "No Folio") "No Folio Number" else "Folio: ${f.folioNumber}"
            b.tvUnits.text = "Units: ${String.format("%.3f", f.totalUnits)}"
            b.tvAvgCost.text = "Avg Cost: ${CurrencyFormatter.format(f.avgCost, mode)}"
            b.tvInvested.text = "Invested: ${CurrencyFormatter.format(f.invested, mode)}"
            b.tvCurrentValue.text = CurrencyFormatter.format(f.currentValue, mode)
            val sign = if (f.pnl >= 0) "+" else ""
            b.tvPnl.text = "$sign${CurrencyFormatter.format(f.pnl, mode)} ($sign${String.format("%.2f", f.pnlPercent)}%)"
            b.tvPnl.setTextColor(b.root.context.getColor(if (f.pnl >= 0) R.color.gain_green else R.color.loss_red))
            b.tvViewTxns.text = "View Transactions →"
            b.root.setOnClickListener { onClick(f) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemFolioSummaryBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<FolioSummary>() {
            override fun areItemsTheSame(a: FolioSummary, b: FolioSummary) = a.folioNumber == b.folioNumber
            override fun areContentsTheSame(a: FolioSummary, b: FolioSummary) = a == b
        }
    }
}
