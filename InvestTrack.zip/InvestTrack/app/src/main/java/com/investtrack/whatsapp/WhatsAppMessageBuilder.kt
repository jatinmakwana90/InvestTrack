package com.investtrack.whatsapp

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.models.IncomeExpenseType
import com.investtrack.data.models.Loan
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.utils.XIRRCalculator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Builds the text for each WhatsApp template. Kept separate from the Fragment/ViewModel so the
 * message-formatting logic can be unit-tested independently of Android UI classes.
 */
class WhatsAppMessageBuilder(
    private val investmentRepository: InvestmentRepository,
    private val accountDao: AccountDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val incomeExpenseDao: IncomeExpenseDao,
    private val appNameProvider: () -> String = { "InvestTrack" }
) {
    private val appName get() = appNameProvider()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private fun money(v: Double) = CurrencyFormatter.formatFullNoDecimals(v)
    private fun pct(v: Double) = "${if (v >= 0) "+" else ""}${"%.2f".format(Locale.US, v)}%"

    /** Template 1 — AUM: total portfolio value, then a breakdown per account. */
    suspend fun buildAumMessage(): String {
        val accounts = accountDao.getAllAccountsList()
        val totalSummary = investmentRepository.getPortfolioSummary()
        val allTransactions = investmentRepository.getAllTransactionsList()
        val totalXirr = runCatching {
            XIRRCalculator.calculate(XIRRCalculator.buildCashFlows(allTransactions, totalSummary.currentValue))
        }.getOrNull()

        val sb = StringBuilder()
        sb.appendLine("*📊 $appName — AUM Summary*")
        sb.appendLine("_as of ${dateFmt.format(Date())}_")
        sb.appendLine()
        sb.appendLine("*TOTAL PORTFOLIO*")
        sb.appendLine("Current Value: ${money(totalSummary.currentValue)}")
        sb.appendLine("Invested: ${money(totalSummary.totalInvested)}")
        val totalPnlSign = if (totalSummary.totalPnL >= 0) "🟢" else "🔴"
        sb.appendLine("Gain/Loss: $totalPnlSign ${money(totalSummary.totalPnL)} (${pct(totalSummary.totalPnLPercent)})")
        sb.appendLine("XIRR: ${totalXirr?.let { "%.2f".format(Locale.US, it) + "%" } ?: "N/A"}")
        sb.appendLine()
        sb.appendLine("*BY ACCOUNT*")

        accounts.filter { it.isActive }.forEach { account ->
            val summary = investmentRepository.getAccountPortfolioSummary(account.id)
            if (summary.totalInvested == 0.0 && summary.currentValue == 0.0) return@forEach
            val txns = investmentRepository.getTransactionsByAccountList(account.id)
            val xirr = runCatching {
                XIRRCalculator.calculate(XIRRCalculator.buildCashFlows(txns, summary.currentValue))
            }.getOrNull()
            val sign = if (summary.totalPnL >= 0) "🟢" else "🔴"

            sb.appendLine()
            sb.appendLine("▪️ *${account.name}*")
            sb.appendLine("  Value: ${money(summary.currentValue)}")
            sb.appendLine("  Invested: ${money(summary.totalInvested)}")
            sb.appendLine("  P&L: $sign ${money(summary.totalPnL)} (${pct(summary.totalPnLPercent)})")
            sb.appendLine("  XIRR: ${xirr?.let { "%.2f".format(Locale.US, it) + "%" } ?: "N/A"}")
        }
        return sb.toString().trim()
    }

    /**
     * Template 2 — Inflow/Outflow: total then per-account, for a given date range.
     * From the investor's perspective: investing (BUY) is money flowing IN to the portfolio,
     * withdrawing (SELL/MATURITY) is money flowing OUT.
     */
    suspend fun buildInflowOutflowMessage(periodLabel: String, rangeStart: Long, rangeEnd: Long): String {
        val accounts = accountDao.getAllAccountsList()
        val allTxns = investmentRepository.getAllTransactionsList()
            .filter { it.transactionDate in rangeStart..rangeEnd }

        fun inflow(txns: List<com.investtrack.data.models.Transaction>) =
            txns.filter { it.type == TransactionType.BUY }.sumOf { it.amount }
        fun outflow(txns: List<com.investtrack.data.models.Transaction>) =
            txns.filter { it.type == TransactionType.SELL || it.type == TransactionType.MATURITY }.sumOf { it.amount }

        val totalInflow = inflow(allTxns)
        val totalOutflow = outflow(allTxns)

        val sb = StringBuilder()
        sb.appendLine("*💸 $appName — Inflow/Outflow*")
        sb.appendLine("_${periodLabel}_")
        sb.appendLine()
        sb.appendLine("*TOTAL*")
        sb.appendLine("Inflow: ${money(totalInflow)}")
        sb.appendLine("Outflow: ${money(totalOutflow)}")
        val net = totalInflow - totalOutflow
        val netSign = if (net >= 0) "🟢" else "🔴"
        sb.appendLine("Net: $netSign ${money(net)}")
        sb.appendLine()
        sb.appendLine("*BY ACCOUNT*")

        accounts.filter { it.isActive }.forEach { account ->
            val accTxns = allTxns.filter { it.accountId == account.id }
            if (accTxns.isEmpty()) return@forEach
            val accIn = inflow(accTxns)
            val accOut = outflow(accTxns)
            val accNet = accIn - accOut
            val sign = if (accNet >= 0) "🟢" else "🔴"

            sb.appendLine()
            sb.appendLine("▪️ *${account.name}*")
            sb.appendLine("  Inflow: ${money(accIn)}")
            sb.appendLine("  Outflow: ${money(accOut)}")
            sb.appendLine("  Net: $sign ${money(accNet)}")
        }
        return sb.toString().trim()
    }

    /** Template 3 — Loan Summary: total outstanding, total EMI, then per-loan detail. */
    suspend fun buildLoanSummaryMessage(): String {
        val loans = loanDao.getAllLoansList().filter { it.isActive }
        if (loans.isEmpty()) {
            return "*🏦 $appName — Loan Summary*\n_as of ${dateFmt.format(Date())}_\n\nNo active loans."
        }

        data class LoanLine(val loan: Loan, val outstanding: Double, val emi: Double, val monthsRemaining: Int)
        val lines = loans.map { loan ->
            val adjustments = loanAdjustmentDao.getAdjustmentsForLoanList(loan.id)
            val schedule = LoanAmortizationCalculator.buildSchedule(loan, adjustments)
            LoanLine(loan, schedule.currentOutstanding, schedule.currentEmi, schedule.remainingInstallments)
        }

        val totalOutstanding = lines.sumOf { it.outstanding }
        val totalEmi = lines.filter { it.monthsRemaining > 0 }.sumOf { it.emi }

        val sb = StringBuilder()
        sb.appendLine("*🏦 $appName — Loan Summary*")
        sb.appendLine("_as of ${dateFmt.format(Date())}_")
        sb.appendLine()
        sb.appendLine("*TOTAL*")
        sb.appendLine("Outstanding: ${money(totalOutstanding)}")
        sb.appendLine("Monthly EMI: ${money(totalEmi)}")
        sb.appendLine("Active Loans: ${loans.size}")
        sb.appendLine()
        sb.appendLine("*BY LOAN*")

        lines.forEach { l ->
            sb.appendLine()
            sb.appendLine("▪️ *${l.loan.loanName}*${if (l.loan.lenderName.isNotBlank()) " (${l.loan.lenderName})" else ""}")
            sb.appendLine("  Outstanding: ${money(l.outstanding)}")
            sb.appendLine("  EMI: ${money(l.emi)}/mo")
            sb.appendLine("  Tenure Remaining: ${l.monthsRemaining} month${if (l.monthsRemaining != 1) "s" else ""}")
        }
        return sb.toString().trim()
    }

    /**
     * Template 4 — Budget: real income and expense entries from the Budget screen
     * (the budget is not period-wise), with net savings = total income − total expense.
     */
    suspend fun buildBudgetMessage(): String {
        val entries = incomeExpenseDao.getAllEntriesList()
        val incomeEntries = entries.filter { it.type == IncomeExpenseType.INCOME }
        val expenseEntries = entries.filter { it.type == IncomeExpenseType.EXPENSE }
        val income = incomeEntries.sumOf { it.amount }
        val expense = expenseEntries.sumOf { it.amount }
        val net = income - expense
        val netSign = if (net >= 0) "🟢" else "🔴"

        val sb = StringBuilder()
        sb.appendLine("*📒 $appName — Budget*")
        sb.appendLine()
        sb.appendLine("Income: ${money(income)}")
        sb.appendLine("Expense: ${money(expense)}")
        sb.appendLine("Net Savings: $netSign ${money(net)}")

        if (incomeEntries.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("*INCOME*")
            incomeEntries.forEach { e ->
                sb.appendLine("  ${e.label}: ${money(e.amount)}")
            }
        }
        if (expenseEntries.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("*EXPENSES*")
            expenseEntries.forEach { e ->
                sb.appendLine("  ${e.label}: ${money(e.amount)}")
            }
        }
        return sb.toString().trim()
    }

    companion object {
        /** Convenience: build [rangeStart, rangeEnd] millis for a given calendar year. */
        fun yearRange(year: Int): Pair<Long, Long> {
            val start = Calendar.getInstance().apply {
                set(year, Calendar.JANUARY, 1, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val end = Calendar.getInstance().apply {
                set(year, Calendar.DECEMBER, 31, 23, 59, 59); set(Calendar.MILLISECOND, 999)
            }.timeInMillis
            return start to end
        }

        /** Convenience: build [rangeStart, rangeEnd] millis for a given calendar year+month (0-based month). */
        fun monthRange(year: Int, month: Int): Pair<Long, Long> {
            val cal = Calendar.getInstance().apply {
                set(year, month, 1, 0, 0, 0); set(Calendar.MILLISECOND, 0)
            }
            val start = cal.timeInMillis
            val end = cal.apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
            }.timeInMillis
            return start to end
        }
    }
}
