package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.network.PriceService
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class AutoPriceSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: InvestmentRepository,
    private val priceService: PriceService,
    private val autoSyncConfigDao: AutoSyncConfigDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        return withContext(Dispatchers.IO) {
            try {
                // The job wakes up every few hours; it only fetches when today's update is due.
                val force = inputData.getBoolean(KEY_FORCE, false)
                if (!force) {
                    val cfg = autoSyncConfigDao.getConfigOnce()
                    if (cfg == null || !cfg.isEnabled || !isDue(cfg.hour, cfg.minute, cfg.lastSyncAt)) return@withContext Result.success()
                }

                val securities = repository.getSecuritiesWithYahooCode()
                if (securities.isEmpty()) {
                    PriceSyncStatus.save(applicationContext, "No security has a price code yet (Yahoo ticker or AMFI code).")
                    return@withContext Result.success()
                }

                // Fetch several prices at the same time so a slow source cannot run out the time limit.
                val gate = Semaphore(3)
                val fetched = coroutineScope {
                    securities.map { sec ->
                        async { gate.withPermit { sec to priceService.fetchPrice(sec.yahooFinanceCode) } }
                    }.awaitAll()
                }

                var updated = 0
                val failed = mutableListOf<String>()
                fetched.forEach { (sec, result) ->
                    if (result != null) {
                        repository.updatePrice(sec.id, result.price, result.previousClose)
                        updated++
                    } else failed += sec.name
                }

                // Nothing worked: most likely no internet right now — try again shortly.
                if (updated == 0 && runAttemptCount < 3) return@withContext Result.retry()

                val config = autoSyncConfigDao.getConfigOnce()
                if (config != null) {
                    autoSyncConfigDao.upsert(config.copy(lastSyncAt = System.currentTimeMillis()))
                }

                val summary = buildString {
                    append("Updated $updated of ${securities.size} prices.")
                    if (failed.isNotEmpty()) {
                        append("\nCould not fetch: ")
                        append(failed.take(5).joinToString(", "))
                        if (failed.size > 5) append(" and ${failed.size - 5} more")
                        append("\nCheck their Yahoo ticker / AMFI code.")
                    }
                }
                PriceSyncStatus.save(applicationContext, summary)
                NotificationHelper.showPriceSyncNotification(
                    applicationContext,
                    if (failed.isEmpty()) "$updated prices updated successfully" else "$updated prices updated, ${failed.size} failed"
                )
                Result.success()
            } catch (e: Exception) {
                if (runAttemptCount < 3) Result.retry()
                else {
                    PriceSyncStatus.save(applicationContext, "Price update failed: ${e.message ?: "unknown error"}")
                    Result.failure()
                }
            }
        }
    }

    companion object {
        const val WORK_NAME = "auto_price_sync"
        const val WORK_NOW = "auto_price_sync_now"
        const val KEY_FORCE = "force"

        private val network = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        /** True once today's scheduled time has passed and no update has happened since then (or the last one is very old). */
        fun isDue(hour: Int, minute: Int, lastSyncAt: Long, now: Long = System.currentTimeMillis()): Boolean {
            val todayAt = Calendar.getInstance().apply {
                timeInMillis = now
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            if (now >= todayAt && lastSyncAt < todayAt) return true
            return now - lastSyncAt > 30L * 60 * 60 * 1000
        }

        /** Checks every 4 hours; the worker itself decides whether today's update is due. */
        fun schedule(context: Context, hour: Int, minute: Int) {
            val request = PeriodicWorkRequestBuilder<AutoPriceSyncWorker>(4, TimeUnit.HOURS)
                .setConstraints(network)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.MINUTES)
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.REPLACE, request
            )
        }

        /** Re-creates the job if Android dropped it (e.g. after an update or a battery clean-up). */
        fun ensureScheduled(context: Context, hour: Int, minute: Int) {
            val infos = WorkManager.getInstance(context).getWorkInfosForUniqueWork(WORK_NAME).get()
            val active = infos.any { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.BLOCKED }
            if (!active) schedule(context, hour, minute)
        }

        /** Runs one update right now (needs internet). */
        fun syncNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<AutoPriceSyncWorker>()
                .setInputData(workDataOf(KEY_FORCE to true))
                .setConstraints(network)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(WORK_NOW, ExistingWorkPolicy.KEEP, request)
        }

        /** Runs an update only if today's is due (used when the app opens). */
        fun syncIfDue(context: Context) {
            val request = OneTimeWorkRequestBuilder<AutoPriceSyncWorker>().setConstraints(network).build()
            WorkManager.getInstance(context).enqueueUniqueWork("auto_price_sync_if_due", ExistingWorkPolicy.KEEP, request)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
