package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.network.PriceService
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class AutoPriceSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: InvestmentRepository,
    private val priceService: PriceService,
    private val autoSyncConfigDao: AutoSyncConfigDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        return withContext(Dispatchers.IO) {
            try {
                val securities = repository.getSecuritiesWithYahooCode()
                if (securities.isEmpty()) {
                    PriceSyncStatus.save(applicationContext, "No security has a price code yet (Yahoo ticker or AMFI code).")
                    return@withContext Result.success()
                }

                // Fetch several prices at the same time so a slow source cannot run out the time limit.
                val gate = Semaphore(5)
                val fetched = coroutineScope {
                    securities.map { sec ->
                        async { gate.withPermit { sec to priceService.fetchPrice(sec.yahooFinanceCode) } }
                    }.awaitAll()
                }

                var updated = 0
                val failed = mutableListOf<String>()
                fetched.forEach { (sec, result) ->
                    if (result != null) {
                        repository.updatePrice(sec.id, result.price, result.previousClose)
                        updated++
                    } else failed += sec.name
                }

                // Nothing worked: most likely no internet right now — try again shortly.
                if (updated == 0 && runAttemptCount < 3) return@withContext Result.retry()

                val config = autoSyncConfigDao.getConfigOnce()
                if (config != null) {
                    autoSyncConfigDao.upsert(config.copy(lastSyncAt = System.currentTimeMillis()))
                }

                val summary = buildString {
                    append("Updated $updated of ${securities.size} prices.")
                    if (failed.isNotEmpty()) {
                        append("\nCould not fetch: ")
                        append(failed.take(5).joinToString(", "))
                        if (failed.size > 5) append(" and ${failed.size - 5} more")
                        append("\nCheck their Yahoo ticker / AMFI code.")
                    }
                }
                PriceSyncStatus.save(applicationContext, summary)
                NotificationHelper.showPriceSyncNotification(
                    applicationContext,
                    if (failed.isEmpty()) "$updated prices updated successfully" else "$updated prices updated, ${failed.size} failed"
                )
                Result.success()
            } catch (e: Exception) {
                if (runAttemptCount < 3) Result.retry()
                else {
                    PriceSyncStatus.save(applicationContext, "Price update failed: ${e.message ?: "unknown error"}")
                    Result.failure()
                }
            }
        }
    }

    companion object {
        const val WORK_NAME = "auto_price_sync"
        const val WORK_NOW = "auto_price_sync_now"

        private val network = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        fun schedule(context: Context, hour: Int, minute: Int) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            val initialDelay = target.timeInMillis - now.timeInMillis

            val request = PeriodicWorkRequestBuilder<AutoPriceSyncWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(network)
                .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.MINUTES)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.REPLACE, request
            )
        }

        /** Re-creates the daily job if Android dropped it (e.g. after an update or battery clean-up). */
        fun ensureScheduled(context: Context, hour: Int, minute: Int) {
            val infos = WorkManager.getInstance(context).getWorkInfosForUniqueWork(WORK_NAME).get()
            val active = infos.any { it.state == WorkInfo.State.ENQUEUED || it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.BLOCKED }
            if (!active) schedule(context, hour, minute)
        }

        /** Runs one update right now (needs internet). */
        fun syncNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<AutoPriceSyncWorker>()
                .setConstraints(network)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(WORK_NOW, ExistingWorkPolicy.KEEP, request)
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
