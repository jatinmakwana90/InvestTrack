package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.network.PriceService
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.*
import java.util.concurrent.TimeUnit

@HiltWorker
class AutoPriceSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val repository: InvestmentRepository,
    private val priceService: PriceService,
    private val autoSyncConfigDao: AutoSyncConfigDao
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        NotificationHelper.createChannels(applicationContext)
        return withContext(Dispatchers.IO) {
            try {
                val securities = repository.getSecuritiesWithYahooCode()
                if (securities.isEmpty()) return@withContext Result.success()

                val codes = securities.map { it.yahooFinanceCode }
                val prices = priceService.fetchPrices(codes)

                var updated = 0
                securities.forEach { sec ->
                    val result = prices[sec.yahooFinanceCode]
                    if (result != null) {
                        repository.updatePrice(sec.id, result.price, result.previousClose)
                        updated++
                    }
                }

                // Update last sync time
                val config = autoSyncConfigDao.getConfigOnce()
                if (config != null) {
                    autoSyncConfigDao.upsert(config.copy(lastSyncAt = System.currentTimeMillis()))
                }

                NotificationHelper.showPriceSyncNotification(
                    applicationContext, "$updated prices updated successfully"
                )
                Result.success()
            } catch (e: Exception) {
                Result.retry()
            }
        }
    }

    companion object {
        const val WORK_NAME = "auto_price_sync"

        fun schedule(context: Context, hour: Int, minute: Int) {
            val now = Calendar.getInstance()
            val target = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
            }
            val initialDelay = target.timeInMillis - now.timeInMillis

            val request = PeriodicWorkRequestBuilder<AutoPriceSyncWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(initialDelay, TimeUnit.MILLISECONDS)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME, ExistingPeriodicWorkPolicy.REPLACE, request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
