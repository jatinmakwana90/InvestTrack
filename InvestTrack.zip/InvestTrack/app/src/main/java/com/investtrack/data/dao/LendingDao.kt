package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.LendingEntry
import com.investtrack.data.models.LendingPayment
import kotlinx.coroutines.flow.Flow

@Dao
interface LendingDao {
    @Query("SELECT * FROM lending_entries ORDER BY isSettled ASC, date DESC")
    fun getEntries(): Flow<List<LendingEntry>>

    @Query("SELECT * FROM lending_entries ORDER BY date DESC")
    suspend fun getEntriesList(): List<LendingEntry>

    @Query("SELECT * FROM lending_payments ORDER BY date ASC")
    fun getPayments(): Flow<List<LendingPayment>>

    @Query("SELECT * FROM lending_payments ORDER BY date ASC")
    suspend fun getPaymentsList(): List<LendingPayment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: LendingEntry): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: LendingPayment): Long

    @Query("DELETE FROM lending_payments WHERE id = :id")
    suspend fun deletePayment(id: Long)

    @Query("DELETE FROM lending_payments WHERE lendingId = :lendingId")
    suspend fun deletePaymentsFor(lendingId: Long)

    @Query("DELETE FROM lending_entries WHERE id = :id")
    suspend fun deleteEntry(id: Long)
}
