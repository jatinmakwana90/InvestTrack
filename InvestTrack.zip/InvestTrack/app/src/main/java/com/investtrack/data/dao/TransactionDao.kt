package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY transactionDate DESC")
    fun getAllTransactions(): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY transactionDate DESC")
    fun getTransactionsByAccount(accountId: Long): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId ORDER BY transactionDate ASC")
    suspend fun getTransactionsByAccountList(accountId: Long): List<Transaction>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND securityId = :securityId ORDER BY transactionDate ASC")
    suspend fun getTransactionsByFolioList(accountId: Long, securityId: Long): List<Transaction>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId AND securityId = :securityId ORDER BY transactionDate DESC")
    fun getTransactionsByFolio(accountId: Long, securityId: Long): Flow<List<Transaction>>

    @Query("SELECT * FROM transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): Transaction?

    @Query("SELECT * FROM transactions ORDER BY updatedAt DESC")
    suspend fun getAllTransactionsList(): List<Transaction>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: Transaction): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<Transaction>)

    @Update
    suspend fun updateTransaction(transaction: Transaction)

    @Delete
    suspend fun deleteTransaction(transaction: Transaction)

    @Query("""
        SELECT DISTINCT t.accountId, t.securityId, 
               COALESCE(SUM(CASE WHEN t.type IN ('BUY') THEN t.quantity 
                                 WHEN t.type IN ('SELL','MATURITY') THEN -t.quantity 
                                 ELSE 0 END), 0) as netQty
        FROM transactions t
        WHERE t.accountId = :accountId
        GROUP BY t.accountId, t.securityId
        HAVING netQty > 0
    """)
    suspend fun getActiveFoliosByAccount(accountId: Long): List<FolioRaw>

    @Query("""
        SELECT DISTINCT t.accountId, t.securityId,
               COALESCE(SUM(CASE WHEN t.type IN ('BUY') THEN t.quantity 
                                 WHEN t.type IN ('SELL','MATURITY') THEN -t.quantity 
                                 ELSE 0 END), 0) as netQty
        FROM transactions t
        GROUP BY t.accountId, t.securityId
        HAVING netQty > 0
    """)
    suspend fun getAllActiveFolios(): List<FolioRaw>

    @Query("""
        SELECT COALESCE(SUM(CASE WHEN type IN ('BUY') THEN amount 
                               WHEN type IN ('SELL','MATURITY') THEN -amount 
                               ELSE 0 END), 0)
        FROM transactions 
        WHERE accountId = :accountId AND securityId = :securityId
    """)
    suspend fun getNetInvestment(accountId: Long, securityId: Long): Double

    @Query("""
        SELECT COALESCE(SUM(CASE WHEN type IN ('BUY') THEN quantity 
                               WHEN type IN ('SELL','MATURITY') THEN -quantity 
                               ELSE 0 END), 0)
        FROM transactions 
        WHERE accountId = :accountId AND securityId = :securityId
    """)
    suspend fun getNetQuantity(accountId: Long, securityId: Long): Double

    @Query("SELECT DISTINCT folioNumber FROM transactions WHERE accountId = :accountId AND securityId = :securityId AND folioNumber != ''")
    suspend fun getFolioNumbers(accountId: Long, securityId: Long): List<String>

    @Query("SELECT COUNT(*) FROM transactions")
    suspend fun getTotalCount(): Int

    // Sum of BUY transaction amounts this month, grouped by the security's type —
    // powers the Budget tab's "invested this month vs target" progress per category.
    @Query("""
        SELECT s.type as securityType, COALESCE(SUM(t.amount), 0) as investedAmount
        FROM transactions t
        INNER JOIN securities s ON s.id = t.securityId
        WHERE t.type = 'BUY' AND t.transactionDate >= :monthStart AND t.transactionDate <= :monthEnd
        GROUP BY s.type
    """)
    suspend fun getMonthlyInvestedByType(monthStart: Long, monthEnd: Long): List<MonthlyInvestedByType>
}

data class MonthlyInvestedByType(
    val securityType: com.investtrack.data.models.SecurityType,
    val investedAmount: Double
)

data class FolioRaw(
    val accountId: Long,
    val securityId: Long,
    val netQty: Double
)
