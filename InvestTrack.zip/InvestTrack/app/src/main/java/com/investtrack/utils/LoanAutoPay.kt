package com.investtrack.utils

import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import java.util.Calendar

/** Marks every EMI whose due date is today or earlier as paid, for all active loans. */
object LoanAutoPay {
    suspend fun process(loanDao: LoanDao, adjustmentDao: LoanAdjustmentDao, now: Long = System.currentTimeMillis()): Int {
        val endOfToday = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
        }.timeInMillis

        var marked = 0
        for (loan in loanDao.getAllLoansList().filter { it.isActive }) {
            val schedule = LoanAmortizationCalculator.buildSchedule(loan, adjustmentDao.getAdjustmentsForLoanList(loan.id))
            val paid = loan.paidInstallmentSet().toMutableSet()
            val due = schedule.rows.filter { it.dueDate <= endOfToday && it.installmentNumber !in paid }.map { it.installmentNumber }
            if (due.isNotEmpty()) {
                paid.addAll(due)
                loanDao.updateLoan(loan.copy(paidInstallments = paid.sorted().joinToString(","), emisPaid = paid.size))
                marked += due.size
            }
        }
        return marked
    }
}
