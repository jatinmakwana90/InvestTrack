package com.investtrack.ui.securities

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.models.Security
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentManualPriceUpdateBinding
import com.investtrack.databinding.ItemManualPriceBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ManualPriceUpdateViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _allSecurities = MutableStateFlow<List<Security>>(emptyList())
    private val _filtered = MutableStateFlow<List<Security>>(emptyList())
    val filtered: StateFlow<List<Security>> = _filtered

    init {
        viewModelScope.launch {
            repository.getAllSecurities().collect {
                _allSecurities.value = it
                _filtered.value = it
            }
        }
    }

    fun filter(query: String) {
        val q = query.lowercase().trim()
        _filtered.value = if (q.isEmpty()) _allSecurities.value
        else _allSecurities.value.filter { it.name.lowercase().contains(q) || it.symbol.lowercase().contains(q) }
    }

    fun updatePrice(security: Security, newPrice: Double) {
        viewModelScope.launch {
            repository.updatePrice(security.id, newPrice, security.currentPrice)
        }
    }
}

@AndroidEntryPoint
class ManualPriceUpdateFragment : Fragment() {

    private var _binding: FragmentManualPriceUpdateBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ManualPriceUpdateViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentManualPriceUpdateBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = ManualPriceAdapter { security, newPrice ->
            viewModel.updatePrice(security, newPrice)
        }
        binding.rvSecurities.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { viewModel.filter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.filtered.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class ManualPriceAdapter(
    private val onSave: (Security, Double) -> Unit
) : ListAdapter<Security, ManualPriceAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemManualPriceBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(security: Security) {
            b.tvName.text = security.name
            b.tvType.text = security.type.displayName
            b.etPrice.setText(if (security.currentPrice > 0) security.currentPrice.toString() else "")
            b.etPrice.hint = "Enter price"

            b.btnSave.setOnClickListener {
                val newPrice = b.etPrice.text.toString().toDoubleOrNull()
                if (newPrice != null && newPrice >= 0) {
                    onSave(security, newPrice)
                    android.widget.Toast.makeText(b.root.context, "Price updated for ${security.name}", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    b.etPrice.error = "Enter a valid price"
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemManualPriceBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Security>() {
            override fun areItemsTheSame(a: Security, b: Security) = a.id == b.id
            override fun areContentsTheSame(a: Security, b: Security) = a == b
        }
    }
}
