package com.investtrack.ui.tools

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.dao.GoalDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.PolicyDao
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentHubBinding
import com.investtrack.databinding.ItemToolTileBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.budget.IncomeExpenseFragment
import com.investtrack.ui.goals.GoalsFragment
import com.investtrack.ui.loans.LoansFragment
import com.investtrack.ui.masters.AccountMasterListFragment
import com.investtrack.ui.reminders.RemindersFragment
import com.investtrack.ui.securities.SecuritiesFragment
import com.investtrack.ui.whatsapp.WhatsAppTemplatesFragment
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

class HubTile(val icon: String, val title: String, var sub: String, val open: () -> Fragment)

/** A bottom-tab page that shows a grid of cards; each card opens a full screen. */
abstract class HubFragment : Fragment() {

    abstract val hubTitle: String
    abstract val hubSubtitle: String
    abstract val tiles: List<HubTile>
    /** Called once the view exists, so subclasses can fill in live subtitles (e.g. "3 accounts"). */
    open suspend fun refreshSubtitles() {}

    private var _b: FragmentHubBinding? = null
    private var adapter: RecyclerView.Adapter<RecyclerView.ViewHolder>? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHubBinding.inflate(inflater, container, false)
        return _b!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = _b!!
        b.tvHubTitle.text = hubTitle
        b.tvHubSub.text = hubSubtitle
        val list = tiles
        val a = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = list.size
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(ItemToolTileBinding.inflate(LayoutInflater.from(parent.context), parent, false).root) {}
            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val t = list[position]
                holder.itemView.findViewById<TextView>(R.id.tv_tile_icon).text = t.icon
                holder.itemView.findViewById<TextView>(R.id.tv_tile_title).text = t.title
                holder.itemView.findViewById<TextView>(R.id.tv_tile_sub).text = t.sub
                holder.itemView.setOnClickListener { (activity as? MainActivity)?.navigateTo(t.open()) }
            }
        }
        adapter = a
        b.rvHub.layoutManager = GridLayoutManager(requireContext(), 2)
        b.rvHub.adapter = a
    }

    override fun onResume() {
        super.onResume()
        viewLifecycleOwner.lifecycleScope.launch {
            try { refreshSubtitles() } catch (e: Exception) { }
            adapter?.notifyDataSetChanged()
        }
    }

    override fun onDestroyView() { adapter = null; _b = null; super.onDestroyView() }
}

/** Masters tab: Account, Security, Loan and Insurance as cards. */
@AndroidEntryPoint
class MastersHubFragment : HubFragment() {

    @Inject lateinit var repository: InvestmentRepository
    @Inject lateinit var loanDao: LoanDao
    @Inject lateinit var policyDao: PolicyDao

    override val hubTitle = "Masters"
    override val hubSubtitle = "Your accounts, securities, loans and insurance"

    override val tiles = listOf(
        HubTile("👤", "Accounts", "Family & investment accounts") { AccountMasterListFragment() },
        HubTile("📈", "Securities", "Stocks, funds, FDs and bonds") { SecuritiesFragment() },
        HubTile("🏦", "Loans", "Home, car and other loans") { LoansFragment() },
        HubTile("🛡️", "Insurance", "Policies and premiums") { InsuranceFragment() }
    )

    override suspend fun refreshSubtitles() {
        val accounts = repository.getAllAccountsList().size
        val securities = repository.getAllSecuritiesList().size
        val loans = loanDao.getAllLoansList().count { it.isActive }
        val policies = policyDao.getAllList().count { it.isActive }
        tiles[0].sub = "$accounts account${if (accounts != 1) "s" else ""}"
        tiles[1].sub = "$securities ${if (securities == 1) "security" else "securities"}"
        tiles[2].sub = "$loans active loan${if (loans != 1) "s" else ""}"
        tiles[3].sub = "$policies polic${if (policies == 1) "y" else "ies"}"
    }
}

/** Tools tab: budget, goals, reminders, WhatsApp and all the planning tools as cards. */
@AndroidEntryPoint
class ToolsHubFragment : HubFragment() {

    @Inject lateinit var goalDao: GoalDao

    override val hubTitle = "Tools"
    override val hubSubtitle = "Plan, track and get things done"

    override val tiles = listOf(
        HubTile("💰", "Budget", "Income and expenses") { IncomeExpenseFragment() },
        HubTile("🎯", "Goals", "Savings targets") { GoalsFragment() },
        HubTile("⏰", "Reminders", "SIP / SWP alerts") { RemindersFragment() },
        HubTile("💬", "WhatsApp", "Send a summary") { WhatsAppTemplatesFragment() },
        HubTile("🤝", "Lending", "Money lent or borrowed") { LendingFragment() },
        HubTile("🆘", "Emergency Fund", "Months of expenses covered") { EmergencyFundFragment() },
        HubTile("📊", "Year in Review", "Invested, earned, EMIs") { YearReviewFragment() },
        HubTile("🧮", "Calculators", "SIP step-up, lump sum, SWP") { PlannersFragment() },
        HubTile("🧾", "Loan Tools", "Balance transfer, affordability") { LoanToolsFragment() },
        HubTile("✉️", "Quick Add", "Add a transaction from an SMS") { QuickAddFragment.newInstance(null) },
        HubTile("🔍", "Search", "Find anything in the app") { SearchFragment() }
    )

    override suspend fun refreshSubtitles() {
        val n = goalDao.getAllGoalsList().size
        tiles[1].sub = if (n == 0) "Savings targets" else "$n goal${if (n != 1) "s" else ""}"
    }
}
