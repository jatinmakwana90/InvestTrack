package com.investtrack.utils

import com.investtrack.data.models.Transaction
import com.investtrack.data.models.TransactionType
import java.util.Calendar

/**
 * One month's invested (money put in via buys) vs withdrawal (money taken out via
 * sells/maturity) totals, within a given year.
 */
data class MonthlyCashFlow(
    val monthLabel: String,
    val monthIndex: Int,
    val periodStart: Long,
    val invested: Double,
    val withdrawal: Double
) {
    val net: Double get() = invested - withdrawal
}

/** A year's total invested/withdrawal, plus its month-by-month breakdown for expansion. */
data class YearlyCashFlow(
    val year: Int,
    val periodStart: Long,
    val invested: Double,
    val withdrawal: Double,
    val months: List<MonthlyCashFlow>
) {
    val net: Double get() = invested - withdrawal
}

object CashFlowReportCalculator {

    private val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    /**
     * Builds year-wise totals, each carrying its own month-wise breakdown so the UI can
     * show years by default and expand a tapped year into its months.
     * BUY transactions count as "invested" (money going in); SELL/MATURITY count as
     * "withdrawal" (money coming out).
     */
    fun build(transactions: List<Transaction>): List<YearlyCashFlow> {
        if (transactions.isEmpty()) return emptyList()

        val investedByYearMonth = mutableMapOf<Pair<Int, Int>, Double>()
        val withdrawalByYearMonth = mutableMapOf<Pair<Int, Int>, Double>()

        for (txn in transactions) {
            val cal = Calendar.getInstance().apply { timeInMillis = txn.transactionDate }
            val key = cal.get(Calendar.YEAR) to cal.get(Calendar.MONTH)
            when (txn.type) {
                TransactionType.BUY ->
                    investedByYearMonth[key] = (investedByYearMonth[key] ?: 0.0) + txn.amount
                TransactionType.SELL, TransactionType.MATURITY ->
                    withdrawalByYearMonth[key] = (withdrawalByYearMonth[key] ?: 0.0) + txn.amount
            }
        }

        val allKeys = investedByYearMonth.keys + withdrawalByYearMonth.keys
        if (allKeys.isEmpty()) return emptyList()

        val minYear = allKeys.minOf { it.first }
        val maxYear = allKeys.maxOf { it.first }

        val years = mutableListOf<YearlyCashFlow>()
        for (year in minYear..maxYear) {
            val months = (0..11).map { monthIndex ->
                val key = year to monthIndex
                val cal = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year); set(Calendar.MONTH, monthIndex); set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }
                MonthlyCashFlow(
                    monthLabel = monthNames[monthIndex],
                    monthIndex = monthIndex,
                    periodStart = cal.timeInMillis,
                    invested = investedByYearMonth[key] ?: 0.0,
                    withdrawal = withdrawalByYearMonth[key] ?: 0.0
                )
            }
            val yearInvested = months.sumOf { it.invested }
            val yearWithdrawal = months.sumOf { it.withdrawal }
            val hasActivity = yearInvested > 0 || yearWithdrawal > 0
            if (!hasActivity) continue

            val yearCal = Calendar.getInstance().apply {
                set(Calendar.YEAR, year); set(Calendar.MONTH, 0); set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            years.add(
                YearlyCashFlow(
                    year = year,
                    periodStart = yearCal.timeInMillis,
                    invested = yearInvested,
                    withdrawal = yearWithdrawal,
                    // Only keep months that actually had activity, in chronological order.
                    months = months.filter { it.invested > 0 || it.withdrawal > 0 }
                )
            )
        }

        // Most recent year first, matching how people usually scan financial reports.
        return years.sortedByDescending { it.year }
    }
}
