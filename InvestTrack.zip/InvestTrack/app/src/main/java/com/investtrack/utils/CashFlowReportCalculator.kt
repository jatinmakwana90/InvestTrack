package com.investtrack.utils

import com.investtrack.data.models.Transaction
import com.investtrack.data.models.TransactionType
import java.util.Calendar

enum class CashFlowPeriod { MONTHLY, YEARLY }

/**
 * One bar-chart period: inflow (money received from sells/maturity) and
 * outflow (money invested via buys) for a given month or year.
 */
data class CashFlowBucket(
    val periodLabel: String,
    val periodStart: Long,
    val inflow: Double,
    val outflow: Double
) {
    val net: Double get() = inflow - outflow
}

object CashFlowReportCalculator {

    /**
     * Buckets all BUY (outflow) and SELL/MATURITY (inflow) transactions by month or year.
     * Returns buckets in chronological order, one per period between the earliest and latest
     * transaction (so gaps with zero activity still show up on the chart).
     */
    fun build(transactions: List<Transaction>, period: CashFlowPeriod): List<CashFlowBucket> {
        if (transactions.isEmpty()) return emptyList()

        fun bucketKey(date: Long): Pair<Int, Int> {
            val cal = Calendar.getInstance().apply { timeInMillis = date }
            val year = cal.get(Calendar.YEAR)
            val month = if (period == CashFlowPeriod.MONTHLY) cal.get(Calendar.MONTH) else 0
            return year to month
        }

        val inflowMap = mutableMapOf<Pair<Int, Int>, Double>()
        val outflowMap = mutableMapOf<Pair<Int, Int>, Double>()

        for (txn in transactions) {
            val key = bucketKey(txn.transactionDate)
            when (txn.type) {
                TransactionType.BUY ->
                    outflowMap[key] = (outflowMap[key] ?: 0.0) + txn.amount
                TransactionType.SELL, TransactionType.MATURITY ->
                    inflowMap[key] = (inflowMap[key] ?: 0.0) + txn.amount
            }
        }

        val allKeys = (inflowMap.keys + outflowMap.keys).toSortedSet(
            compareBy({ it.first }, { it.second })
        )
        if (allKeys.isEmpty()) return emptyList()

        // Fill in gaps so the chart shows continuous periods, not just active ones.
        val minKey = allKeys.first()
        val maxKey = allKeys.last()
        val filledKeys = mutableListOf<Pair<Int, Int>>()
        if (period == CashFlowPeriod.YEARLY) {
            for (y in minKey.first..maxKey.first) filledKeys.add(y to 0)
        } else {
            var y = minKey.first
            var m = minKey.second
            while (y < maxKey.first || (y == maxKey.first && m <= maxKey.second)) {
                filledKeys.add(y to m)
                m++
                if (m > 11) { m = 0; y++ }
            }
        }

        val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        return filledKeys.map { key ->
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, key.first)
                set(Calendar.MONTH, key.second)
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val label = if (period == CashFlowPeriod.YEARLY) key.first.toString()
                        else "${monthNames[key.second]} '${key.first.toString().takeLast(2)}"
            CashFlowBucket(
                periodLabel = label,
                periodStart = cal.timeInMillis,
                inflow = inflowMap[key] ?: 0.0,
                outflow = outflowMap[key] ?: 0.0
            )
        }
    }
}
