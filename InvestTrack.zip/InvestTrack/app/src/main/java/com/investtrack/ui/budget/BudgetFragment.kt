package com.investtrack.ui.budget

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.BudgetLimitDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.BudgetLimit
import com.investtrack.data.models.SecurityType
import com.investtrack.databinding.FragmentBudgetBinding
import com.investtrack.databinding.ItemBudgetLimitBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

/** One row per SecurityType — this month's invested amount vs an optional target limit. */
data class BudgetRow(
    val securityType: SecurityType,
    val limit: BudgetLimit?,
    val investedThisMonth: Double
)

private val TYPE_ICONS = mapOf(
    SecurityType.EQUITY to "📈", SecurityType.EQUITY_MF to "💹", SecurityType.DEBT_MF to "🏦",
    SecurityType.GOLD to "🪙", SecurityType.FIXED_DEPOSIT to "💰", SecurityType.BOND to "📜",
    SecurityType.ETF to "📊", SecurityType.PPF to "🏛️", SecurityType.NPS to "🧓", SecurityType.CRYPTO to "🚀"
)

@HiltViewModel
class BudgetViewModel @Inject constructor(
    private val budgetLimitDao: BudgetLimitDao,
    private val transactionDao: TransactionDao
) : ViewModel() {

    private val _rows = MutableStateFlow<List<BudgetRow>>(emptyList())
    val rows: StateFlow<List<BudgetRow>> = _rows

    private val limits: StateFlow<List<BudgetLimit>> = budgetLimitDao.getAllBudgetLimits()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            limits.collect { refresh(it) }
        }
    }

    private suspend fun refresh(currentLimits: List<BudgetLimit>) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1); cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val monthStart = cal.timeInMillis
        val monthEnd = System.currentTimeMillis()

        val invested = transactionDao.getMonthlyInvestedByType(monthStart, monthEnd)
            .associate { it.securityType to it.investedAmount }

        val sorted = SecurityType.values().sortedByDescending { type ->
            val limit = currentLimits.find { it.securityType == type }
            val spent = invested[type] ?: 0.0
            if (limit != null && limit.monthlyLimit > 0) spent / limit.monthlyLimit else if (spent > 0) 999.0 else 0.0
        }

        _rows.value = sorted.map { type ->
            BudgetRow(
                securityType = type,
                limit = currentLimits.find { it.securityType == type },
                investedThisMonth = invested[type] ?: 0.0
            )
        }
    }

    fun setLimit(type: SecurityType, amount: Double) {
        viewModelScope.launch {
            // Look up any existing limit for this type first — upsertBudgetLimit REPLACEs by
            // primary key `id`, not by securityType, so reusing the existing id (if any) keeps
            // this a true update instead of inserting a second row for the same category.
            val existing = budgetLimitDao.getBudgetLimitForType(type.name)
            budgetLimitDao.upsertBudgetLimit(
                BudgetLimit(id = existing?.id ?: 0, securityType = type, monthlyLimit = amount)
            )
        }
    }

    fun removeLimit(limit: BudgetLimit) {
        viewModelScope.launch { budgetLimitDao.deleteBudgetLimit(limit.id) }
    }
}

@AndroidEntryPoint
class BudgetFragment : Fragment() {
    private var _binding: FragmentBudgetBinding? = null
    private val binding get() = _binding!!
    private val viewModel: BudgetViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBudgetBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = BudgetAdapter(
            onSetLimit = { row -> showLimitDialog(row) },
            onEditLimit = { row -> showLimitDialog(row) },
            onDeleteLimit = { row ->
                row.limit?.let {
                    android.app.AlertDialog.Builder(requireContext())
                        .setTitle("Remove Limit")
                        .setMessage("Remove the monthly limit for ${row.securityType.displayName}?")
                        .setPositiveButton("Remove") { _, _ -> viewModel.removeLimit(it) }
                        .setNegativeButton("Cancel", null).show()
                }
            }
        )
        binding.rvBudgets.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.rows.collect { adapter.submitList(it) }
        }
    }

    private fun showLimitDialog(row: BudgetRow) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_loan_amount_input, null)
        val label = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_label)
        val hint = dialogView.findViewById<android.widget.TextView>(R.id.tv_dialog_hint)
        val input = dialogView.findViewById<TextInputEditText>(R.id.et_dialog_amount)
        label.text = "MONTHLY LIMIT (₹)"
        hint.text = "How much you plan to invest in ${row.securityType.displayName} each month."
        row.limit?.let { input.setText(if (it.monthlyLimit == it.monthlyLimit.toLong().toDouble()) it.monthlyLimit.toLong().toString() else it.monthlyLimit.toString()) }

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Set Budget Limit")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val amount = input.text.toString().toDoubleOrNull()
                if (amount != null && amount > 0) viewModel.setLimit(row.securityType, amount)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class BudgetAdapter(
    private val onSetLimit: (BudgetRow) -> Unit,
    private val onEditLimit: (BudgetRow) -> Unit,
    private val onDeleteLimit: (BudgetRow) -> Unit
) : ListAdapter<BudgetRow, BudgetAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemBudgetLimitBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(row: BudgetRow) {
            b.tvCatIcon.text = TYPE_ICONS[row.securityType] ?: "💼"
            b.tvCatName.text = row.securityType.displayName

            val limit = row.limit
            if (limit != null && limit.monthlyLimit > 0) {
                val rawPct = (row.investedThisMonth / limit.monthlyLimit * 100)
                val displayPct = rawPct.toInt().coerceIn(0, 100)
                val colorRes = when {
                    rawPct >= 100 -> R.color.loss_red
                    rawPct >= 70 -> R.color.other_color
                    else -> R.color.gain_green
                }
                val statusEmoji = if (rawPct >= 100) "🔴 Over!" else if (rawPct >= 70) "🟡" else "🟢"
                b.tvCatProgress.text = "${CurrencyFormatter.format(row.investedThisMonth)} / ${CurrencyFormatter.format(limit.monthlyLimit)} · $statusEmoji ${rawPct.toInt()}%"
                b.tvCatProgress.setTextColor(b.root.context.getColor(colorRes))
                b.progressBudget.visibility = View.VISIBLE
                b.progressBudget.progress = displayPct
                b.progressBudget.progressTintList = android.content.res.ColorStateList.valueOf(b.root.context.getColor(colorRes))
                b.btnSetLimit.visibility = View.GONE
                b.btnEditLimit.visibility = View.VISIBLE
                b.btnDeleteLimit.visibility = View.VISIBLE
                b.btnEditLimit.setOnClickListener { onEditLimit(row) }
                b.btnDeleteLimit.setOnClickListener { onDeleteLimit(row) }
            } else {
                b.progressBudget.visibility = View.GONE
                if (row.investedThisMonth > 0) {
                    b.tvCatProgress.text = "${CurrencyFormatter.format(row.investedThisMonth)} invested · no limit set"
                    b.tvCatProgress.setTextColor(b.root.context.getColor(R.color.text_secondary))
                } else {
                    b.tvCatProgress.text = ""
                }
                b.btnSetLimit.visibility = View.VISIBLE
                b.btnEditLimit.visibility = View.GONE
                b.btnDeleteLimit.visibility = View.GONE
                b.btnSetLimit.setOnClickListener { onSetLimit(row) }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemBudgetLimitBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<BudgetRow>() {
            override fun areItemsTheSame(a: BudgetRow, b: BudgetRow) = a.securityType == b.securityType
            override fun areContentsTheSame(a: BudgetRow, b: BudgetRow) = a == b
        }
    }
}
