package com.investtrack.ui.securities

import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.Security
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddSecurityBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AddSecurityViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved

    fun saveSecurity(security: Security) {
        viewModelScope.launch {
            repository.insertSecurity(security)
            _saved.value = true
        }
    }
}

@AndroidEntryPoint
class AddSecurityFragment : Fragment() {

    private var _binding: FragmentAddSecurityBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddSecurityViewModel by viewModels()
    private var selectedType = SecurityType.EQUITY

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddSecurityBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.toolbar.setNavigationOnClickListener {
            activity?.onBackPressedDispatcher?.onBackPressed()
        }

        val types = SecurityType.values().map { it.displayName }
        binding.actvSecurityType.setAdapter(
            ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types)
        )
        binding.actvSecurityType.setText(types[0], false)
        binding.actvSecurityType.setOnItemClickListener { _, _, position, _ ->
            selectedType = SecurityType.values()[position]
            updateFieldVisibility()
        }
        updateFieldVisibility()

        // Observe save completion then navigate back
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.saved.collect { saved ->
                if (saved) {
                    activity?.onBackPressedDispatcher?.onBackPressed()
                }
            }
        }

        binding.btnSave.setOnClickListener { saveSecurity() }
    }

    private fun updateFieldVisibility() {
        val isFD = selectedType == SecurityType.FIXED_DEPOSIT || selectedType == SecurityType.BOND
        val isMF = selectedType == SecurityType.EQUITY_MF || selectedType == SecurityType.DEBT_MF
        val isEquity = selectedType == SecurityType.EQUITY || selectedType == SecurityType.ETF
        binding.tilInterestRate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilMaturityDate.visibility = if (isFD) View.VISIBLE else View.GONE
        binding.tilAmc.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilCategory.visibility = if (isMF) View.VISIBLE else View.GONE
        binding.tilExchange.visibility = if (isEquity || isMF) View.VISIBLE else View.GONE
        binding.tilCurrentPrice.visibility = View.GONE
    }

    private fun saveSecurity() {
        val name = binding.etName.text.toString().trim()
        if (name.isEmpty()) {
            binding.tilName.error = "Security name is required"
            return
        }
        binding.btnSave.isEnabled = false
        binding.btnSave.text = "Saving..."

        val security = Security(
            name = name,
            symbol = binding.etSymbol.text.toString().trim(),
            type = selectedType,
            isin = binding.etIsin.text.toString().trim(),
            yahooFinanceCode = binding.etYahooCode.text.toString().trim(),
            exchange = binding.etExchange.text.toString().trim(),
            currentPrice = 0.0,
            interestRate = binding.etInterestRate.text.toString().toDoubleOrNull(),
            amc = binding.etAmc.text.toString().trim(),
            category = binding.etCategory.text.toString().trim(),
            sector = binding.etSector.text.toString().trim()
        )
        viewModel.saveSecurity(security)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
