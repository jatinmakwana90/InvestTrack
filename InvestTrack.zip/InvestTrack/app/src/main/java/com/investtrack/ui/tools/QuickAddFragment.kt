package com.investtrack.ui.tools

import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.investtrack.data.models.Account
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.SmsParser
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Add a transaction from an SMS / e-mail: paste or share the message, check the numbers, save. */
@AndroidEntryPoint
class QuickAddFragment : ToolFormFragment() {

    @Inject lateinit var repository: InvestmentRepository

    override val screenTitle = "Quick Add"

    override fun buildForm(form: FormBuilder) {
        val startText = arguments?.getString(ARG_TEXT).orEmpty()
        viewLifecycleOwner.lifecycleScope.launch {
            val accounts: List<Account> = repository.getAllAccountsList()
            val securities: List<Security> = repository.getAllSecuritiesList()
            if (accounts.isEmpty() || securities.isEmpty()) {
                form.note("Add at least one account and one security in Masters first.")
                return@launch
            }

            form.note("Paste or share a purchase / redemption SMS or e-mail. The app reads the amount, units, NAV and date. Check them, then save.")
            val message = form.multiline("Message", "Paste the SMS here", startText, 4)
            form.button("Paste from clipboard") {
                val cm = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val txt = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(requireContext())?.toString().orEmpty()
                if (txt.isBlank()) toast("Clipboard is empty") else message.setText(txt)
            }
            val info = form.note("")

            form.sectionTitle("Transaction")
            val typeList = TransactionType.values().map { it.displayName }
            val type = form.dropdown("Type", typeList, TransactionType.BUY.displayName)
            val account = form.dropdown("Account", accounts.map { it.name }, accounts.first().name)
            val security = form.dropdown("Security", securities.map { it.name }, securities.first().name)
            val date = form.date("Date", System.currentTimeMillis())
            val units = form.number("Units / quantity", "")
            val nav = form.number("NAV / price per unit (₹)", "")
            val amount = form.number("Amount (₹)", "")
            val folio = form.text("Folio number (optional)", "", "", android.text.InputType.TYPE_CLASS_TEXT)

            fun readMessage() {
                val p = SmsParser.parse(message.text.toString(), securities)
                type.setText(p.type.displayName, false)
                p.security?.let { security.setText(it.name, false) }
                p.date?.let { date.set(it) }
                if (p.units != null) units.setText(p.units.toString())
                if (p.nav != null) nav.setText(p.nav.toString())
                if (p.amount != null) amount.setText(p.amount.toString())
                p.folio?.let { folio.setText(it) }
                val found = mutableListOf<String>()
                if (p.amount != null) found += "amount ${CurrencyFormatter.formatFullNoDecimals(p.amount)}"
                if (p.units != null) found += "${p.units} units"
                if (p.nav != null) found += "NAV ${p.nav}"
                found += if (p.security != null) "matched ${p.security.name}" else "security not matched, please choose it"
                info.text = "Found: " + found.joinToString(", ")
            }
            form.button("Read the message") { readMessage() }
            if (startText.isNotBlank()) readMessage()

            form.button("Save transaction", filled = true) {
                val acc = accounts.firstOrNull { it.name == account.text.toString() }
                val sec = securities.firstOrNull { it.name == security.text.toString() }
                val u = units.num(); val n = nav.num(); val a = amount.num()
                val qty = if (u > 0) u else if (a > 0 && n > 0) a / n else 0.0
                val price = if (n > 0) n else if (a > 0 && u > 0) a / u else 0.0
                val total = if (a > 0) a else qty * price
                when {
                    acc == null || sec == null -> toast("Choose the account and the security")
                    qty <= 0 || price <= 0 -> toast("Enter units with NAV, or the amount with units or NAV")
                    else -> viewLifecycleOwner.lifecycleScope.launch {
                        repository.insertTransaction(Transaction(
                            accountId = acc.id, securityId = sec.id,
                            type = TransactionType.values().firstOrNull { it.displayName == type.text.toString() } ?: TransactionType.BUY,
                            quantity = qty, price = price, amount = total,
                            folioNumber = folio.text.toString().trim(),
                            notes = "Added from message",
                            transactionDate = date.value ?: System.currentTimeMillis()
                        ))
                        toast("Transaction saved")
                        activity?.onBackPressedDispatcher?.onBackPressed()
                    }
                }
            }
        }
    }

    companion object {
        private const val ARG_TEXT = "text"
        fun newInstance(text: String?) = QuickAddFragment().apply {
            arguments = Bundle().apply { putString(ARG_TEXT, text.orEmpty()) }
        }
    }
}
