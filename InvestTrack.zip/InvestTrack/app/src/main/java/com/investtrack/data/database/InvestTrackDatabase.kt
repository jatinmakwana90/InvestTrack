package com.investtrack.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.investtrack.data.dao.*
import com.investtrack.data.models.*

@Database(
    entities = [Account::class, Security::class, Transaction::class,
                Reminder::class, AutoSyncConfig::class, Loan::class, LoanAdjustment::class,
                DriveBackupConfig::class, IncomeExpenseEntry::class, WhatsAppContact::class, Goal::class],
    version = 13,
    exportSchema = false
)
abstract class InvestTrackDatabase : RoomDatabase() {

    companion object {
        @Volatile private var INSTANCE: InvestTrackDatabase? = null

        /** Adds the user-controlled sequence to Budget entries without touching any other data. */
        val MIGRATION_11_12 = object : Migration(11, 12) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE income_expense_entries ADD COLUMN sortOrder INTEGER NOT NULL DEFAULT 0")
                // Start from the order people already see (newest first).
                database.execSQL(
                    "UPDATE income_expense_entries SET sortOrder = (" +
                    "SELECT COUNT(*) FROM income_expense_entries AS b " +
                    "WHERE b.date > income_expense_entries.date " +
                    "OR (b.date = income_expense_entries.date AND b.id > income_expense_entries.id))"
                )
            }
        }

        /** Adds the Goals table without touching any existing data. */
        val MIGRATION_12_13 = object : Migration(12, 13) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS `goals` (" +
                    "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                    "`name` TEXT NOT NULL, " +
                    "`targetAmount` REAL NOT NULL, " +
                    "`targetDate` INTEGER NOT NULL, " +
                    "`accountIds` TEXT NOT NULL, " +
                    "`allocationPercent` INTEGER NOT NULL, " +
                    "`expectedReturn` REAL NOT NULL, " +
                    "`notes` TEXT NOT NULL, " +
                    "`createdAt` INTEGER NOT NULL)"
                )
            }
        }

        fun getInstance(context: android.content.Context): InvestTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = androidx.room.Room.databaseBuilder(
                    context.applicationContext,
                    InvestTrackDatabase::class.java,
                    "investtrack.db"
                ).addMigrations(MIGRATION_11_12, MIGRATION_12_13).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
    abstract fun accountDao(): AccountDao
    abstract fun securityDao(): SecurityDao
    abstract fun transactionDao(): TransactionDao
    abstract fun reminderDao(): ReminderDao
    abstract fun autoSyncConfigDao(): AutoSyncConfigDao
    abstract fun loanDao(): LoanDao
    abstract fun loanAdjustmentDao(): LoanAdjustmentDao
    abstract fun driveBackupConfigDao(): DriveBackupConfigDao
    abstract fun incomeExpenseDao(): IncomeExpenseDao
    abstract fun whatsAppContactDao(): WhatsAppContactDao
    abstract fun goalDao(): GoalDao
}
