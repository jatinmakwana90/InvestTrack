package com.investtrack.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.investtrack.data.dao.*
import com.investtrack.data.models.*

@Database(
    entities = [Account::class, Security::class, Transaction::class, Profile::class, SyncConfig::class],
    version = 2,
    exportSchema = false
)
abstract class InvestTrackDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun securityDao(): SecurityDao
    abstract fun transactionDao(): TransactionDao
    abstract fun profileDao(): ProfileDao
    abstract fun syncConfigDao(): SyncConfigDao
}
