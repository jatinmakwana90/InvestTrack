package com.investtrack.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.investtrack.data.dao.*
import com.investtrack.data.models.*

@Database(
    entities = [Account::class, Security::class, Transaction::class,
                Reminder::class, AutoSyncConfig::class],
    version = 4,
    exportSchema = false
)
abstract class InvestTrackDatabase : RoomDatabase() {

    companion object {
        @Volatile private var INSTANCE: InvestTrackDatabase? = null

        fun getInstance(context: android.content.Context): InvestTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = androidx.room.Room.databaseBuilder(
                    context.applicationContext,
                    InvestTrackDatabase::class.java,
                    "investtrack.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
    abstract fun accountDao(): AccountDao
    abstract fun securityDao(): SecurityDao
    abstract fun transactionDao(): TransactionDao
    abstract fun reminderDao(): ReminderDao
    abstract fun autoSyncConfigDao(): AutoSyncConfigDao
}
