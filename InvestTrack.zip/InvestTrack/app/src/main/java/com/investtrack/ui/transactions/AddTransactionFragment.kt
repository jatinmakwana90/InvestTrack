package com.investtrack.ui.transactions

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentAddTransactionBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class AddTransactionViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val preselectedAccountId: Long = savedStateHandle.get<Long>("accountId") ?: 0L

    val accounts: StateFlow<List<Account>> = repository.getAllAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val securities: StateFlow<List<Security>> = repository.getAllSecurities()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved

    fun saveTransaction(
        accountId: Long, securityId: Long, type: TransactionType,
        qty: Double, price: Double, amount: Double, charges: Double,
        folioNo: String, notes: String, date: Long
    ) {
        viewModelScope.launch {
            repository.insertTransaction(Transaction(
                accountId = accountId, securityId = securityId, type = type,
                quantity = qty, price = price, amount = amount,
                charges = charges, folioNumber = folioNo, notes = notes,
                transactionDate = date
            ))
            _saved.value = true
        }
    }
}

@AndroidEntryPoint
class AddTransactionFragment : Fragment() {

    private var _binding: FragmentAddTransactionBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddTransactionViewModel by viewModels()

    private var selectedAccountId = 0L
    private var selectedSecurityId = 0L
    private var selectedDate = System.currentTimeMillis()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    // true = Amount+Units mode (MF), false = Units+Price mode (Equity)
    private var isAmountMode = true

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddTransactionBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.etDate.setText(dateFmt.format(Date(selectedDate)))

        // Input mode toggle
        setInputMode(true) // default: Amount + Units
        binding.btnModeAmount.setOnClickListener { setInputMode(true) }
        binding.btnModePrice.setOnClickListener { setInputMode(false) }

        // Transaction types
        binding.actvTxnType.setAdapter(ArrayAdapter(requireContext(),
            android.R.layout.simple_dropdown_item_1line,
            TransactionType.values().map { it.displayName }))
        binding.actvTxnType.setText(TransactionType.BUY.displayName, false)

        // Accounts dropdown
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.accounts.collect { list ->
                val names = list.map { it.name }
                binding.actvAccount.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names))
                if (viewModel.preselectedAccountId != 0L) {
                    list.firstOrNull { it.id == viewModel.preselectedAccountId }?.let {
                        binding.actvAccount.setText(it.name, false)
                        selectedAccountId = it.id
                        binding.tilAccount.visibility = View.GONE
                    }
                }
                binding.actvAccount.setOnItemClickListener { _, _, pos, _ -> selectedAccountId = list[pos].id }
            }
        }

        // Securities dropdown
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.securities.collect { list ->
                val names = list.map { "${it.name} (${it.type.displayName})" }
                binding.actvSecurity.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, names))
                binding.actvSecurity.setOnItemClickListener { _, _, pos, _ ->
                    selectedSecurityId = list[pos].id
                    // Auto-switch mode based on security type
                    val isMF = list[pos].type == SecurityType.EQUITY_MF || list[pos].type == SecurityType.DEBT_MF
                    setInputMode(isMF)
                }
            }
        }

        // Navigate back only after save
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.saved.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        // Date picker
        binding.etDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d); selectedDate = cal.timeInMillis
                binding.etDate.setText(dateFmt.format(Date(selectedDate)))
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Live calculation watchers
        val watcher = object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { updateCalculation() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        binding.etAmountInput.addTextChangedListener(watcher)
        binding.etUnits.addTextChangedListener(watcher)
        binding.etQty.addTextChangedListener(watcher)
        binding.etPrice.addTextChangedListener(watcher)

        binding.btnSave.setOnClickListener { save() }
    }

    private fun setInputMode(amountMode: Boolean) {
        isAmountMode = amountMode
        if (amountMode) {
            binding.layoutAmountUnits.visibility = View.VISIBLE
            binding.layoutUnitsPrice.visibility = View.GONE
            binding.btnModeAmount.backgroundTintList =
                android.content.res.ColorStateList.valueOf(requireContext().getColor(com.investtrack.R.color.primary))
            binding.btnModeAmount.setTextColor(android.graphics.Color.WHITE)
            binding.btnModePrice.setTextColor(requireContext().getColor(com.investtrack.R.color.primary))
        } else {
            binding.layoutAmountUnits.visibility = View.GONE
            binding.layoutUnitsPrice.visibility = View.VISIBLE
            binding.btnModePrice.backgroundTintList =
                android.content.res.ColorStateList.valueOf(requireContext().getColor(com.investtrack.R.color.primary))
            binding.btnModePrice.setTextColor(android.graphics.Color.WHITE)
            binding.btnModeAmount.setTextColor(requireContext().getColor(com.investtrack.R.color.primary))
            binding.btnModeAmount.backgroundTintList =
                android.content.res.ColorStateList.valueOf(android.graphics.Color.TRANSPARENT)
        }
        updateCalculation()
    }

    private fun updateCalculation() {
        if (isAmountMode) {
            val amount = binding.etAmountInput.text.toString().toDoubleOrNull()
            val units = binding.etUnits.text.toString().toDoubleOrNull()
            if (amount != null && units != null && units > 0) {
                val nav = amount / units
                binding.tvCalculatedAmount.text = "NAV = ₹${String.format("%.4f", nav)}"
            } else {
                binding.tvCalculatedAmount.text = "NAV = ₹—  (enter amount & units)"
            }
        } else {
            val qty = binding.etQty.text.toString().toDoubleOrNull()
            val price = binding.etPrice.text.toString().toDoubleOrNull()
            if (qty != null && price != null) {
                binding.tvCalculatedAmount.text = "Amount = ₹${String.format("%,.2f", qty * price)}"
            } else {
                binding.tvCalculatedAmount.text = "Amount = ₹—  (enter qty & price)"
            }
        }
    }

    private fun save() {
        if (selectedAccountId == 0L) { binding.tilAccount.error = "Select an account"; return }
        if (selectedSecurityId == 0L) { binding.tilSecurity.error = "Select a security"; return }

        val type = TransactionType.values().firstOrNull {
            it.displayName == binding.actvTxnType.text.toString()
        } ?: TransactionType.BUY

        val qty: Double
        val price: Double
        val amount: Double

        if (isAmountMode) {
            val amountInput = binding.etAmountInput.text.toString().toDoubleOrNull()
            val units = binding.etUnits.text.toString().toDoubleOrNull()
            if (amountInput == null || amountInput <= 0) { binding.tilAmount.error = "Enter amount"; return }
            if (units == null || units <= 0) { binding.tilUnits.error = "Enter units"; return }
            qty = units
            price = amountInput / units   // NAV = Amount / Units
            amount = amountInput
        } else {
            val qtyInput = binding.etQty.text.toString().toDoubleOrNull()
            val priceInput = binding.etPrice.text.toString().toDoubleOrNull()
            if (qtyInput == null || qtyInput <= 0) { binding.tilQty.error = "Enter quantity"; return }
            if (priceInput == null || priceInput < 0) { binding.tilPrice.error = "Enter price"; return }
            qty = qtyInput
            price = priceInput
            amount = qty * price
        }

        binding.btnSave.isEnabled = false
        binding.btnSave.text = "Saving..."
        viewModel.saveTransaction(
            selectedAccountId, selectedSecurityId, type, qty, price, amount,
            binding.etCharges.text.toString().toDoubleOrNull() ?: 0.0,
            binding.etFolioNo.text.toString().trim(),
            binding.etNotes.text.toString().trim(),
            selectedDate
        )
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(accountId: Long) = AddTransactionFragment().apply {
            arguments = Bundle().apply { putLong("accountId", accountId) }
        }
    }
}
