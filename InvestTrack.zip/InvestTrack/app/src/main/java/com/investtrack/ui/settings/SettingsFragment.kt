package com.investtrack.ui.settings

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentSettingsBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.securities.ManualPriceUpdateFragment
import com.investtrack.ui.settings.BackupRestoreFragment
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val settingsManager: SettingsManager
) : ViewModel()

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        // Return mode radio
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.returnMode.collect { mode ->
                if (mode == ReturnDisplayMode.ABS) binding.radioAbs.isChecked = true
                else binding.radioXirr.isChecked = true
            }
        }
        binding.radioGroupReturn.setOnCheckedChangeListener { _, checkedId ->
            val mode = if (checkedId == binding.radioAbs.id) ReturnDisplayMode.ABS else ReturnDisplayMode.XIRR
            viewModel.settingsManager.setReturnMode(mode)
        }

        // Amount mode radio
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.amountMode.collect { mode ->
                if (mode == AmountDisplayMode.ROUNDED) binding.radioRounded.isChecked = true
                else binding.radioFull.isChecked = true
            }
        }
        binding.radioGroupAmount.setOnCheckedChangeListener { _, checkedId ->
            val mode = if (checkedId == binding.radioRounded.id) AmountDisplayMode.ROUNDED else AmountDisplayMode.FULL
            viewModel.settingsManager.setAmountMode(mode)
        }

        // Manual price update
        binding.cardManualPrices.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(ManualPriceUpdateFragment())
        }

        // Backup & Restore
        binding.cardBackupRestore.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(BackupRestoreFragment())
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
