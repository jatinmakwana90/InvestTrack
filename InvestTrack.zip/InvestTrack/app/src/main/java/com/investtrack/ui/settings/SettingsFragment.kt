package com.investtrack.ui.settings

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.DarkModeOption
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentSettingsBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.securities.SecuritiesPriceUpdateFragment
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val settingsManager: SettingsManager
) : ViewModel()

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    @Inject lateinit var liveShare: com.investtrack.data.share.LiveShareManager

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // App name
        binding.etAppName.setText(viewModel.settingsManager.appName.value)
        binding.btnSaveAppName.setOnClickListener {
            viewModel.settingsManager.setAppName(binding.etAppName.text?.toString().orEmpty())
            binding.etAppName.setText(viewModel.settingsManager.appName.value)
            android.widget.Toast.makeText(requireContext(), "App name updated", android.widget.Toast.LENGTH_SHORT).show()
        }

        // Live portfolio link
        binding.switchLiveShare.isChecked = liveShare.enabled
        binding.etShareDbUrl.setText(liveShare.databaseUrl)
        binding.etShareViewerUrl.setText(liveShare.viewerUrl)
        binding.tvShareStatus.text = liveShare.lastStatus
        fun saveShareFields() {
            liveShare.databaseUrl = binding.etShareDbUrl.text?.toString().orEmpty()
            liveShare.viewerUrl = binding.etShareViewerUrl.text?.toString().orEmpty()
        }
        binding.switchLiveShare.setOnCheckedChangeListener { _, checked ->
            saveShareFields()
            liveShare.enabled = checked
        }
        binding.btnShareSync.setOnClickListener {
            saveShareFields()
            if (!liveShare.isConfigured) {
                binding.tvShareStatus.text = "Enter the Firebase database URL (starts with https://)"
                return@setOnClickListener
            }
            liveShare.enabled = true
            binding.switchLiveShare.isChecked = true
            binding.tvShareStatus.text = "Syncing…"
            viewLifecycleOwner.lifecycleScope.launch {
                liveShare.pushLatest()
                _binding?.tvShareStatus?.text = liveShare.lastStatus
            }
        }
        binding.btnShareLink.setOnClickListener {
            saveShareFields()
            val code = liveShare.shareCode()
            if (code == null) {
                binding.tvShareStatus.text = "Enter the Firebase database URL first"
                return@setOnClickListener
            }
            val link = liveShare.shareLink()
            val text = if (link != null) {
                // Hosted viewer page set: send a plain link that opens in any browser, no app needed
                "View my portfolio (live, read-only):\n$link"
            } else {
                "View my portfolio (live, read-only):\n" +
                    "1. Install the same app\n2. Settings → Live Portfolio Link → Open Viewer mode\n3. Paste this code:\n\n$code"
            }
            startActivity(
                android.content.Intent.createChooser(
                    android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, text)
                    }, "Share portfolio code"
                )
            )
        }
        binding.btnOpenViewer.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.viewer.ViewerFragment())
        }
        binding.btnShareReset.setOnClickListener {
            liveShare.regenerateToken()
            binding.tvShareStatus.text = "New code created. Tap Save & Sync, then share the new code."
        }

        // Return mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.returnMode.collect { mode ->
                if (mode == ReturnDisplayMode.ABS) binding.radioAbs.isChecked = true
                else binding.radioXirr.isChecked = true
            }
        }
        binding.radioGroupReturn.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioAbs.id) ReturnDisplayMode.ABS else ReturnDisplayMode.XIRR
            viewModel.settingsManager.setReturnMode(mode)
        }

        // Amount mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.amountMode.collect { mode ->
                if (mode == AmountDisplayMode.ROUNDED) binding.radioRounded.isChecked = true
                else binding.radioFull.isChecked = true
            }
        }
        binding.radioGroupAmount.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioRounded.id) AmountDisplayMode.ROUNDED else AmountDisplayMode.FULL
            viewModel.settingsManager.setAmountMode(mode)
        }

        // Dark mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.darkMode.collect { mode ->
                when (mode) {
                    DarkModeOption.SYSTEM -> binding.radioDarkSystem.isChecked = true
                    DarkModeOption.LIGHT -> binding.radioDarkLight.isChecked = true
                    DarkModeOption.DARK -> binding.radioDarkDark.isChecked = true
                }
            }
        }
        binding.radioGroupDark.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                binding.radioDarkLight.id -> DarkModeOption.LIGHT
                binding.radioDarkDark.id -> DarkModeOption.DARK
                else -> DarkModeOption.SYSTEM
            }
            viewModel.settingsManager.setDarkMode(mode)
            applyDarkMode(mode)
        }

        // Navigation cards
        binding.cardSecuritiesPriceUpdate.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(SecuritiesPriceUpdateFragment())
        }
        binding.cardBackupRestore.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(BackupRestoreFragment())
        }
    }

    private fun applyDarkMode(mode: DarkModeOption) {
        when (mode) {
            DarkModeOption.LIGHT -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            DarkModeOption.DARK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            DarkModeOption.SYSTEM -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
