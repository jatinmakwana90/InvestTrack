package com.investtrack.ui.settings

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.DarkModeOption
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentSettingsBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.securities.SecuritiesPriceUpdateFragment
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val settingsManager: SettingsManager
) : ViewModel()

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    @Inject lateinit var liveShare: com.investtrack.data.share.LiveShareManager
    @Inject lateinit var appLock: com.investtrack.data.settings.AppLockManager
    @Inject lateinit var automation: com.investtrack.data.settings.AutomationSettings
    @Inject lateinit var reportGenerator: com.investtrack.report.ReportGenerator
    @Inject lateinit var contactDao: com.investtrack.data.dao.WhatsAppContactDao

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // App name
        binding.etAppName.setText(viewModel.settingsManager.appName.value)
        binding.btnSaveAppName.setOnClickListener {
            viewModel.settingsManager.setAppName(binding.etAppName.text?.toString().orEmpty())
            binding.etAppName.setText(viewModel.settingsManager.appName.value)
            android.widget.Toast.makeText(requireContext(), "App name updated", android.widget.Toast.LENGTH_SHORT).show()
        }

        // Live portfolio link
        binding.switchLiveShare.isChecked = liveShare.enabled
        binding.etShareDbUrl.setText(liveShare.databaseUrl)
        binding.etShareViewerUrl.setText(liveShare.viewerUrl)
        binding.tvShareStatus.text = liveShare.lastStatus
        fun saveShareFields() {
            liveShare.databaseUrl = binding.etShareDbUrl.text?.toString().orEmpty()
            liveShare.viewerUrl = binding.etShareViewerUrl.text?.toString().orEmpty()
        }
        binding.switchLiveShare.setOnCheckedChangeListener { _, checked ->
            saveShareFields()
            liveShare.enabled = checked
        }
        binding.btnShareSync.setOnClickListener {
            saveShareFields()
            if (!liveShare.isConfigured) {
                binding.tvShareStatus.text = "Enter the Firebase database URL (starts with https://)"
                return@setOnClickListener
            }
            liveShare.enabled = true
            binding.switchLiveShare.isChecked = true
            binding.tvShareStatus.text = "Syncing…"
            viewLifecycleOwner.lifecycleScope.launch {
                liveShare.pushLatest()
                _binding?.tvShareStatus?.text = liveShare.lastStatus
            }
        }
        binding.btnShareLink.setOnClickListener {
            saveShareFields()
            val text = liveShare.shareText()
            if (text == null) {
                binding.tvShareStatus.text = "Enter the Firebase database URL first"
                return@setOnClickListener
            }
            startActivity(
                android.content.Intent.createChooser(
                    android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, text)
                    }, "Share portfolio link"
                )
            )
        }
        binding.btnOpenViewer.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.viewer.ViewerFragment())
        }
        binding.btnShareReset.setOnClickListener {
            liveShare.regenerateToken()
            binding.tvShareStatus.text = "New code created. Tap Save & Sync, then share the new code."
        }

        setupAppLock()
        setupAutomation()
        setupExport()

        // Return mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.returnMode.collect { mode ->
                if (mode == ReturnDisplayMode.ABS) binding.radioAbs.isChecked = true
                else binding.radioXirr.isChecked = true
            }
        }
        binding.radioGroupReturn.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioAbs.id) ReturnDisplayMode.ABS else ReturnDisplayMode.XIRR
            viewModel.settingsManager.setReturnMode(mode)
        }

        // Amount mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.amountMode.collect { mode ->
                if (mode == AmountDisplayMode.ROUNDED) binding.radioRounded.isChecked = true
                else binding.radioFull.isChecked = true
            }
        }
        binding.radioGroupAmount.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioRounded.id) AmountDisplayMode.ROUNDED else AmountDisplayMode.FULL
            viewModel.settingsManager.setAmountMode(mode)
        }

        // Dark mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.darkMode.collect { mode ->
                when (mode) {
                    DarkModeOption.SYSTEM -> binding.radioDarkSystem.isChecked = true
                    DarkModeOption.LIGHT -> binding.radioDarkLight.isChecked = true
                    DarkModeOption.DARK -> binding.radioDarkDark.isChecked = true
                }
            }
        }
        binding.radioGroupDark.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                binding.radioDarkLight.id -> DarkModeOption.LIGHT
                binding.radioDarkDark.id -> DarkModeOption.DARK
                else -> DarkModeOption.SYSTEM
            }
            viewModel.settingsManager.setDarkMode(mode)
            applyDarkMode(mode)
        }

        // Navigation cards
        binding.cardSecuritiesPriceUpdate.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(SecuritiesPriceUpdateFragment())
        }
        binding.cardBackupRestore.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(BackupRestoreFragment())
        }
    }

    private fun applyDarkMode(mode: DarkModeOption) {
        when (mode) {
            DarkModeOption.LIGHT -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            DarkModeOption.DARK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            DarkModeOption.SYSTEM -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    // ---------------- App lock ----------------

    private fun askPin(title: String, onPin: (String) -> Unit, onCancel: () -> Unit = {}) {
        val ctx = requireContext()
        val box = android.widget.LinearLayout(ctx).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(56, 24, 56, 0) }
        fun pinField(hint: String) = android.widget.EditText(ctx).apply {
            this.hint = hint
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val first = pinField("PIN (4 to 6 digits)")
        val second = pinField("Repeat PIN")
        box.addView(first); box.addView(second)
        var done = false
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val a = first.text.toString(); val b = second.text.toString()
                if (a.length < 4) {
                    android.widget.Toast.makeText(ctx, "PIN must be 4 to 6 digits", android.widget.Toast.LENGTH_SHORT).show()
                } else if (a != b) {
                    android.widget.Toast.makeText(ctx, "The two PINs do not match", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    done = true
                    onPin(a)
                }
            }
            .setNegativeButton("Cancel", null)
            .setOnDismissListener { if (!done) onCancel() }
            .show()
    }

    private fun verifyCurrentPin(onOk: () -> Unit) {
        val ctx = requireContext()
        val input = android.widget.EditText(ctx).apply {
            hint = "Current PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        }
        val box = android.widget.FrameLayout(ctx).apply { setPadding(56, 24, 56, 0); addView(input) }
        com.google.android.material.dialog.MaterialAlertDialogBuilder(ctx)
            .setTitle("Enter your current PIN")
            .setView(box)
            .setPositiveButton("OK") { _, _ ->
                if (appLock.verifyPin(input.text.toString())) onOk()
                else android.widget.Toast.makeText(ctx, "Wrong PIN", android.widget.Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private val lockTimeoutLabels = listOf("Immediately", "After 30 seconds", "After 1 minute", "After 5 minutes")
    private val lockTimeoutValues = listOf(0, 30, 60, 300)

    private fun setupAppLock() {
        binding.actvLockTimeout.setAdapter(
            com.investtrack.ui.common.NoFilterAdapter(requireContext(), lockTimeoutLabels)
        )
        binding.actvLockTimeout.setOnItemClickListener { _, _, position, _ ->
            appLock.timeoutSeconds = lockTimeoutValues[position]
        }
        binding.btnChangePin.setOnClickListener {
            verifyCurrentPin { askPin("Choose a new PIN", { pin -> appLock.setPin(pin); appLock.markUnlocked() }) }
        }
        renderLockUi()
    }

    /** Shows the saved lock settings and (re)attaches the switch listeners. */
    private fun renderLockUi() {
        val b = _binding ?: return
        val on = appLock.enabled
        b.switchAppLock.setOnCheckedChangeListener(null)
        b.switchBiometric.setOnCheckedChangeListener(null)
        b.switchHideRecents.setOnCheckedChangeListener(null)

        b.switchAppLock.isChecked = on
        b.layoutLockOptions.visibility = if (on) View.VISIBLE else View.GONE
        b.switchBiometric.isChecked = appLock.biometricEnabled
        b.switchHideRecents.isChecked = appLock.hideInRecents
        val idx = lockTimeoutValues.indexOf(appLock.timeoutSeconds).let { if (it < 0) 1 else it }
        b.actvLockTimeout.setText(lockTimeoutLabels[idx], false)

        b.switchAppLock.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                askPin("Set a PIN", { pin -> appLock.enable(pin); renderLockUi() }, { renderLockUi() })
            } else {
                renderLockUi() // keep the switch ON until the current PIN has been confirmed
                verifyCurrentPin { appLock.disable(); renderLockUi() }
            }
        }
        b.switchBiometric.setOnCheckedChangeListener { _, c -> appLock.biometricEnabled = c }
        b.switchHideRecents.setOnCheckedChangeListener { _, c ->
            appLock.hideInRecents = c
            if (c) activity?.window?.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
            else activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    // ---------------- Automation ----------------

    private fun timeText(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        return String.format("%d:%02d %s", h12, m, if (h < 12) "AM" else "PM")
    }

    private fun setupAutomation() {
        val ctx = requireContext()

        // Mark EMIs paid automatically
        binding.switchAutoEmi.isChecked = automation.autoPayEmis
        binding.switchAutoEmi.setOnCheckedChangeListener { _, c ->
            automation.autoPayEmis = c
            com.investtrack.workers.AutomationScheduler.applyLoanAutoPay(ctx, c)
        }

        // Quick-add notification
        binding.switchQuickAdd.isChecked = automation.quickAddNotification
        binding.switchQuickAdd.setOnCheckedChangeListener { _, c ->
            automation.quickAddNotification = c
            if (c) com.investtrack.utils.NotificationHelper.showQuickAdd(ctx)
            else com.investtrack.utils.NotificationHelper.cancelQuickAdd(ctx)
        }

        // Weekly WhatsApp summary
        val days = listOf("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        binding.actvWeeklyDay.setAdapter(com.investtrack.ui.common.NoFilterAdapter(ctx, days))
        binding.actvWeeklyDay.setText(days[(automation.weeklyDay - 1).coerceIn(0, 6)], false)
        binding.etWeeklyTime.setText(timeText(automation.weeklyHour, automation.weeklyMinute))
        binding.switchWeekly.isChecked = automation.weeklyEnabled
        binding.layoutWeeklyOptions.visibility = if (automation.weeklyEnabled) View.VISIBLE else View.GONE

        fun resync() = com.investtrack.workers.AutomationScheduler.syncAll(ctx, automation)

        binding.switchWeekly.setOnCheckedChangeListener { _, c ->
            automation.weeklyEnabled = c
            binding.layoutWeeklyOptions.visibility = if (c) View.VISIBLE else View.GONE
            resync()
        }
        binding.actvWeeklyDay.setOnItemClickListener { _, _, pos, _ -> automation.weeklyDay = pos + 1; resync() }
        binding.etWeeklyTime.setOnClickListener {
            android.app.TimePickerDialog(ctx, com.investtrack.R.style.InvestTrackPickerDialog, { _, h, m ->
                automation.weeklyHour = h; automation.weeklyMinute = m
                binding.etWeeklyTime.setText(timeText(h, m)); resync()
            }, automation.weeklyHour, automation.weeklyMinute, false).show()
        }
        viewLifecycleOwner.lifecycleScope.launch {
            val contacts = contactDao.getAllContactsList()
            val labels = listOf("Choose when sending") + contacts.map { it.name }
            _binding?.actvWeeklyContact?.setAdapter(com.investtrack.ui.common.NoFilterAdapter(ctx, labels))
            val current = automation.weeklyContactName
            _binding?.actvWeeklyContact?.setText(if (current.isBlank() || current !in labels) labels[0] else current, false)
            _binding?.actvWeeklyContact?.setOnItemClickListener { _, _, pos, _ ->
                if (pos == 0) { automation.weeklyContactName = ""; automation.weeklyContactPhone = "" }
                else { automation.weeklyContactName = contacts[pos - 1].name; automation.weeklyContactPhone = contacts[pos - 1].phoneNumber }
            }
        }

        // Monthly PDF report
        val monthDays = (1..28).map { com.investtrack.utils.ReminderSchedule.ordinal(it) }
        binding.actvMonthlyDay.setAdapter(com.investtrack.ui.common.NoFilterAdapter(ctx, monthDays))
        binding.actvMonthlyDay.setText(monthDays[(automation.monthlyDay - 1).coerceIn(0, 27)], false)
        binding.etMonthlyTime.setText(timeText(automation.monthlyHour, automation.monthlyMinute))
        binding.switchMonthly.isChecked = automation.monthlyEnabled
        binding.layoutMonthlyOptions.visibility = if (automation.monthlyEnabled) View.VISIBLE else View.GONE
        binding.switchMonthly.setOnCheckedChangeListener { _, c ->
            automation.monthlyEnabled = c
            binding.layoutMonthlyOptions.visibility = if (c) View.VISIBLE else View.GONE
            resync()
        }
        binding.actvMonthlyDay.setOnItemClickListener { _, _, pos, _ -> automation.monthlyDay = pos + 1; resync() }
        binding.etMonthlyTime.setOnClickListener {
            android.app.TimePickerDialog(ctx, com.investtrack.R.style.InvestTrackPickerDialog, { _, h, m ->
                automation.monthlyHour = h; automation.monthlyMinute = m
                binding.etMonthlyTime.setText(timeText(h, m)); resync()
            }, automation.monthlyHour, automation.monthlyMinute, false).show()
        }
    }

    // ---------------- Export ----------------

    private fun setupExport() {
        fun run(label: String, mime: String, make: suspend () -> java.io.File) {
            binding.tvExportStatus.text = "Creating $label…"
            viewLifecycleOwner.lifecycleScope.launch {
                try {
                    val file = make()
                    _binding?.tvExportStatus?.text = "$label ready: ${file.name}"
                    startActivity(com.investtrack.workers.MonthlyReportWorker.shareIntent(requireContext(), file, mime))
                } catch (e: Exception) {
                    _binding?.tvExportStatus?.text = "Could not create the $label: ${e.message}"
                }
            }
        }
        binding.btnExportExcel.setOnClickListener {
            run("Excel file", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") { reportGenerator.createExcel() }
        }
        binding.btnExportPdf.setOnClickListener {
            run("PDF report", "application/pdf") { reportGenerator.createPdf() }
        }
    }
}
