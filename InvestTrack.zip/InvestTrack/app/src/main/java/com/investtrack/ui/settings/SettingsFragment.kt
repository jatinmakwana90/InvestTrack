package com.investtrack.ui.settings

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.DarkModeOption
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentSettingsBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.analytics.AnalyticsFragment
import com.investtrack.ui.reminders.AutoPriceSyncFragment
import com.investtrack.ui.reminders.RemindersFragment
import com.investtrack.ui.reports.ReportsFragment
import com.investtrack.ui.securities.ManualPriceUpdateFragment
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    val settingsManager: SettingsManager
) : ViewModel()

@AndroidEntryPoint
class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: SettingsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        // Return mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.returnMode.collect { mode ->
                if (mode == ReturnDisplayMode.ABS) binding.radioAbs.isChecked = true
                else binding.radioXirr.isChecked = true
            }
        }
        binding.radioGroupReturn.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioAbs.id) ReturnDisplayMode.ABS else ReturnDisplayMode.XIRR
            viewModel.settingsManager.setReturnMode(mode)
        }

        // Amount mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.amountMode.collect { mode ->
                if (mode == AmountDisplayMode.ROUNDED) binding.radioRounded.isChecked = true
                else binding.radioFull.isChecked = true
            }
        }
        binding.radioGroupAmount.setOnCheckedChangeListener { _, id ->
            val mode = if (id == binding.radioRounded.id) AmountDisplayMode.ROUNDED else AmountDisplayMode.FULL
            viewModel.settingsManager.setAmountMode(mode)
        }

        // Dark mode
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.settingsManager.darkMode.collect { mode ->
                when (mode) {
                    DarkModeOption.SYSTEM -> binding.radioDarkSystem.isChecked = true
                    DarkModeOption.LIGHT -> binding.radioDarkLight.isChecked = true
                    DarkModeOption.DARK -> binding.radioDarkDark.isChecked = true
                }
            }
        }
        binding.radioGroupDark.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                binding.radioDarkLight.id -> DarkModeOption.LIGHT
                binding.radioDarkDark.id -> DarkModeOption.DARK
                else -> DarkModeOption.SYSTEM
            }
            viewModel.settingsManager.setDarkMode(mode)
            applyDarkMode(mode)
        }

        // Navigation cards
        binding.cardAnalytics.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AnalyticsFragment())
        }
        binding.cardReports.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(ReportsFragment())
        }
        binding.cardManualPrices.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(ManualPriceUpdateFragment())
        }
        binding.cardReminders.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(RemindersFragment())
        }
        binding.cardAutoPriceSync.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AutoPriceSyncFragment())
        }
        binding.cardBackupRestore.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(BackupRestoreFragment())
        }
    }

    private fun applyDarkMode(mode: DarkModeOption) {
        when (mode) {
            DarkModeOption.LIGHT -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            DarkModeOption.DARK -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            DarkModeOption.SYSTEM -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
