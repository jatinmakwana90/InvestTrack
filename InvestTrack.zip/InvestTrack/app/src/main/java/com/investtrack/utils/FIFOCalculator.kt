package com.investtrack.utils

import com.investtrack.data.models.Transaction
import com.investtrack.data.models.TransactionType

data class FIFOLot(val buyDate: Long, val buyPrice: Double, val quantity: Double)
data class FIFOAllocation(val buyDate: Long, val buyPrice: Double, val sellPrice: Double, val quantity: Double, val realizedPnL: Double)
data class FIFOSellAllocation(val sellTransaction: Transaction, val allocations: List<FIFOAllocation>, val totalRealizedPnL: Double, val totalRealizedPnLPercent: Double)

object FIFOCalculator {
    fun processFIFO(transactions: List<Transaction>): List<FIFOSellAllocation> {
        val sorted = transactions.sortedBy { it.transactionDate }
        val queue = ArrayDeque<FIFOLot>()
        val results = mutableListOf<FIFOSellAllocation>()
        for (txn in sorted) {
            when (txn.type) {
                TransactionType.BUY ->
                    queue.addLast(FIFOLot(txn.transactionDate, txn.price, txn.quantity))
                TransactionType.SELL, TransactionType.MATURITY -> {
                    var remaining = txn.quantity
                    val allocs = mutableListOf<FIFOAllocation>()
                    var totalCost = 0.0
                    while (remaining > 0.0001 && queue.isNotEmpty()) {
                        val lot = queue.first()
                        val consumed = minOf(remaining, lot.quantity)
                        val cost = consumed * lot.buyPrice
                        allocs.add(FIFOAllocation(lot.buyDate, lot.buyPrice, txn.price, consumed, consumed * txn.price - cost))
                        totalCost += cost
                        remaining -= consumed
                        if (consumed >= lot.quantity - 0.0001) queue.removeFirst()
                        else queue[0] = lot.copy(quantity = lot.quantity - consumed)
                    }
                    val pnl = allocs.sumOf { it.realizedPnL }
                    results.add(FIFOSellAllocation(txn, allocs, pnl, if (totalCost > 0) pnl / totalCost * 100 else 0.0))
                }
                else -> {}
            }
        }
        return results
    }
}
