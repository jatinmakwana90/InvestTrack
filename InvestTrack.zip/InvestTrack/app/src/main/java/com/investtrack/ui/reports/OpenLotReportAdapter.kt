package com.investtrack.ui.reports

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.databinding.ItemLotGrandTotalRowBinding
import com.investtrack.databinding.ItemLotSubtotalRowBinding
import com.investtrack.databinding.ItemOpenLotRowBinding
import com.investtrack.utils.OpenLotReport
import com.investtrack.utils.OpenLotRow
import com.investtrack.utils.SecuritySubtotal
import com.investtrack.utils.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val TYPE_SUBTOTAL = 0
private const val TYPE_LOT = 1
private const val TYPE_GRAND_TOTAL = 2

private sealed class LotReportItem {
    data class SubtotalItem(val subtotal: SecuritySubtotal) : LotReportItem()
    data class LotItem(val lot: OpenLotRow) : LotReportItem()
    data class GrandTotalItem(val report: OpenLotReport) : LotReportItem()
}

class OpenLotReportAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var items: List<LotReportItem> = emptyList()
    private val dateFmt = SimpleDateFormat("dd/MM/yy", Locale.getDefault())

    fun submit(report: OpenLotReport) {
        val flat = mutableListOf<LotReportItem>()
        for (group in report.groups) {
            flat.add(LotReportItem.SubtotalItem(group.subtotal))
            group.lots.forEach { flat.add(LotReportItem.LotItem(it)) }
        }
        if (report.groups.isNotEmpty()) flat.add(LotReportItem.GrandTotalItem(report))
        items = flat
        notifyDataSetChanged()
    }

    override fun getItemViewType(position: Int): Int = when (items[position]) {
        is LotReportItem.SubtotalItem -> TYPE_SUBTOTAL
        is LotReportItem.LotItem -> TYPE_LOT
        is LotReportItem.GrandTotalItem -> TYPE_GRAND_TOTAL
    }

    override fun getItemCount() = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_SUBTOTAL -> SubtotalVH(ItemLotSubtotalRowBinding.inflate(inflater, parent, false))
            TYPE_GRAND_TOTAL -> GrandTotalVH(ItemLotGrandTotalRowBinding.inflate(inflater, parent, false))
            else -> LotVH(ItemOpenLotRowBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val item = items[position]) {
            is LotReportItem.SubtotalItem -> (holder as SubtotalVH).bind(item.subtotal)
            is LotReportItem.LotItem -> (holder as LotVH).bind(item.lot)
            is LotReportItem.GrandTotalItem -> (holder as GrandTotalVH).bind(item.report)
        }
    }

    private fun returnColor(ctx: android.content.Context, value: Double) =
        ctx.getColor(if (value >= 0) R.color.gain_green else R.color.loss_red)

    private fun signed(value: Double, formatted: String) = if (value >= 0) "+$formatted" else formatted

    inner class LotVH(private val b: ItemOpenLotRowBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(lot: OpenLotRow) {
            val ctx = b.root.context
            b.tvDate.text = dateFmt.format(Date(lot.buyDate))
            b.tvSecurity.text = lot.securityName
            b.tvUnits.text = "%,.3f".format(lot.units)
            b.tvCostNav.text = CurrencyFormatter.formatFull(lot.costNav)
            b.tvTotalCost.text = CurrencyFormatter.formatFullNoDecimals(lot.totalCost)
            b.tvMarketNav.text = CurrencyFormatter.formatFull(lot.marketNav) + if (lot.isPriceEstimated) "*" else ""
            b.tvMarketValue.text = CurrencyFormatter.formatFullNoDecimals(lot.totalMarketValue)
            val returnColor = returnColor(ctx, lot.absoluteReturn)
            b.tvAbsReturn.text = signed(lot.absoluteReturn, CurrencyFormatter.formatFullNoDecimals(lot.absoluteReturn))
            b.tvAbsReturn.setTextColor(returnColor)
            b.tvAbsReturnPct.text = signed(lot.absoluteReturnPercent, "%.2f%%".format(lot.absoluteReturnPercent))
            b.tvAbsReturnPct.setTextColor(returnColor)
            b.tvXirr.text = lot.xirrPercent?.let { "%.1f%%".format(it) } ?: "—"
            b.tvXirr.setTextColor(lot.xirrPercent?.let { returnColor(ctx, it) } ?: ctx.getColor(R.color.text_secondary))
            b.tvPctAssets.text = "%.2f%%".format(lot.percentOfTotalAssets)
        }
    }

    inner class SubtotalVH(private val b: ItemLotSubtotalRowBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(s: SecuritySubtotal) {
            val ctx = b.root.context
            b.tvSecurity.text = s.securityName
            b.tvUnits.text = "%,.3f".format(s.totalUnits)
            b.tvTotalCost.text = CurrencyFormatter.formatFullNoDecimals(s.totalCost)
            b.tvMarketNav.text = if (s.totalUnits > 0) CurrencyFormatter.formatFull(s.totalMarketValue / s.totalUnits) else "—"
            b.tvMarketValue.text = CurrencyFormatter.formatFullNoDecimals(s.totalMarketValue)
            val returnColor = returnColor(ctx, s.absoluteReturn)
            b.tvAbsReturn.text = signed(s.absoluteReturn, CurrencyFormatter.formatFullNoDecimals(s.absoluteReturn))
            b.tvAbsReturn.setTextColor(returnColor)
            b.tvAbsReturnPct.text = signed(s.absoluteReturnPercent, "%.2f%%".format(s.absoluteReturnPercent))
            b.tvAbsReturnPct.setTextColor(returnColor)
            b.tvXirr.text = s.xirrPercent?.let { "%.1f%%".format(it) } ?: "—"
            b.tvXirr.setTextColor(s.xirrPercent?.let { returnColor(ctx, it) } ?: ctx.getColor(R.color.text_secondary))
            b.tvPctAssets.text = "%.2f%%".format(s.percentOfTotalAssets)
        }
    }

    inner class GrandTotalVH(private val b: ItemLotGrandTotalRowBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(report: OpenLotReport) {
            val ctx = b.root.context
            b.tvTotalCost.text = CurrencyFormatter.formatFullNoDecimals(report.grandTotalCost)
            b.tvMarketValue.text = CurrencyFormatter.formatFullNoDecimals(report.grandTotalMarketValue)
            val returnColor = returnColor(ctx, report.grandTotalAbsoluteReturn)
            b.tvAbsReturn.text = signed(report.grandTotalAbsoluteReturn, CurrencyFormatter.formatFullNoDecimals(report.grandTotalAbsoluteReturn))
            b.tvAbsReturn.setTextColor(returnColor)
            b.tvAbsReturnPct.text = signed(report.grandTotalAbsoluteReturnPercent, "%.2f%%".format(report.grandTotalAbsoluteReturnPercent))
            b.tvAbsReturnPct.setTextColor(returnColor)
            val totalPct = report.groups.sumOf { it.subtotal.percentOfTotalAssets }
            b.tvPctAssets.text = "%.2f%%".format(totalPct)
        }
    }
}
