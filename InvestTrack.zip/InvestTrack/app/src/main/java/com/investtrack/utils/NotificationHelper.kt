package com.investtrack.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.investtrack.R
import com.investtrack.ui.MainActivity

object NotificationHelper {

    const val CHANNEL_REMINDERS = "investtrack_reminders"
    const val CHANNEL_PRICE_SYNC = "investtrack_price_sync"

    fun createChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val reminderChannel = NotificationChannel(
            CHANNEL_REMINDERS, "SIP/SWP Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Reminders for SIP investments and SWP withdrawals"
            enableVibration(true)
        }

        val syncChannel = NotificationChannel(
            CHANNEL_PRICE_SYNC, "Price Sync",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Automatic market price sync notifications"
        }

        nm.createNotificationChannel(reminderChannel)
        nm.createNotificationChannel(syncChannel)
    }

    fun showReminderNotification(context: Context, id: Int, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(id, notification)
    }

    fun showPriceSyncNotification(context: Context, message: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_PRICE_SYNC)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("Price Sync Complete")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9999, notification)
    }
}
