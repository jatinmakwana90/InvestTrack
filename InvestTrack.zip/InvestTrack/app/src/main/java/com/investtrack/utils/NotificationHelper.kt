package com.investtrack.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.investtrack.R
import com.investtrack.ui.MainActivity

object NotificationHelper {

    const val CHANNEL_REMINDERS = "investtrack_reminders"
    const val CHANNEL_PRICE_SYNC = "investtrack_price_sync"
    const val CHANNEL_BACKUP = "investtrack_backup"
    const val CHANNEL_REPORTS = "investtrack_reports"
    const val CHANNEL_QUICK = "investtrack_quick_add"
    const val QUICK_ADD_ID = 7300

    fun createChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val reminderChannel = NotificationChannel(
            CHANNEL_REMINDERS, "SIP/SWP Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Reminders for SIP investments and SWP withdrawals"
            enableVibration(true)
        }

        val syncChannel = NotificationChannel(
            CHANNEL_PRICE_SYNC, "Price Sync",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Automatic market price sync notifications"
        }

        val backupChannel = NotificationChannel(
            CHANNEL_BACKUP, "Drive Backup",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Automatic daily Google Drive backup notifications"
        }

        val reportsChannel = NotificationChannel(
            CHANNEL_REPORTS, "Reports & summaries",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Weekly WhatsApp summary and monthly PDF report" }
        nm.createNotificationChannel(reportsChannel)
        nm.createNotificationChannel(NotificationChannel(
            CHANNEL_QUICK, "Quick add", NotificationManager.IMPORTANCE_LOW
        ).apply { description = "Shortcut to add a transaction" })

        nm.createNotificationChannel(reminderChannel)
        nm.createNotificationChannel(syncChannel)
        nm.createNotificationChannel(backupChannel)
    }

    fun showReminderNotification(context: Context, id: Int, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(context, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(id, notification)
    }

    fun showPriceSyncNotification(context: Context, message: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_PRICE_SYNC)
            .setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("Price Sync Complete")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9999, notification)
    }

    fun showBackupNotification(context: Context, success: Boolean, message: String) {
        val notification = NotificationCompat.Builder(context, CHANNEL_BACKUP)
            .setSmallIcon(if (success) android.R.drawable.stat_sys_upload_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (success) "Drive Backup Complete" else "Drive Backup Failed")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .build()

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(9998, notification)
    }

    /** A notification whose tap runs [pendingIntent] (e.g. open WhatsApp, or share a PDF). */
    fun showActionNotification(context: Context, id: Int, title: String, text: String, pendingIntent: PendingIntent) {
        val notification = NotificationCompat.Builder(context, CHANNEL_REPORTS)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(id, notification)
    }

    /** A quiet, always-there notification: tap it to add a transaction from an SMS. */
    fun showQuickAdd(context: Context) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_QUICK_ADD, true)
        }
        val pi = PendingIntent.getActivity(context, QUICK_ADD_ID, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, CHANNEL_QUICK)
            .setSmallIcon(android.R.drawable.ic_input_add)
            .setContentTitle("Add transaction")
            .setContentText("Tap to add one from an SMS or message")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pi)
            .addAction(android.R.drawable.ic_input_add, "Add transaction", pi)
            .build()
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(QUICK_ADD_ID, notification)
    }

    fun cancelQuickAdd(context: Context) {
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(QUICK_ADD_ID)
    }
}
