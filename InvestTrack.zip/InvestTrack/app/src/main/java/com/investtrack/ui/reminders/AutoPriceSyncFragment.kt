package com.investtrack.ui.reminders

import android.app.TimePickerDialog
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.models.AutoSyncConfig
import com.investtrack.databinding.FragmentAutoPriceSyncBinding
import com.investtrack.workers.AutoPriceSyncWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AutoPriceSyncViewModel @Inject constructor(
    private val dao: AutoSyncConfigDao
) : ViewModel() {
    val config: StateFlow<AutoSyncConfig?> = dao.getConfig()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun save(enabled: Boolean, hour: Int, minute: Int) {
        viewModelScope.launch {
            val current = dao.getConfigOnce() ?: AutoSyncConfig()
            dao.upsert(current.copy(isEnabled = enabled, hour = hour, minute = minute))
        }
    }
}

@AndroidEntryPoint
class AutoPriceSyncFragment : Fragment() {
    private var _binding: FragmentAutoPriceSyncBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AutoPriceSyncViewModel by viewModels()
    private var selectedHour = 9
    private var selectedMinute = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAutoPriceSyncBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.visibility = View.GONE
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        binding.tvSyncTime.setOnClickListener {
            TimePickerDialog(requireContext(), { _, h, m ->
                selectedHour = h; selectedMinute = m
                updateTimeDisplay()
            }, selectedHour, selectedMinute, false).show()
        }

        binding.btnSave.setOnClickListener {
            val enabled = binding.switchAutoSync.isChecked
            viewModel.save(enabled, selectedHour, selectedMinute)
            if (enabled) {
                AutoPriceSyncWorker.schedule(requireContext(), selectedHour, selectedMinute)
                binding.tvStatus.text = "✓ Auto sync scheduled daily at ${formatTime(selectedHour, selectedMinute)}"
            } else {
                AutoPriceSyncWorker.cancel(requireContext())
                binding.tvStatus.text = "Auto sync disabled"
            }
            binding.tvStatus.visibility = View.VISIBLE
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.config.collect { config ->
                config ?: return@collect
                selectedHour = config.hour
                selectedMinute = config.minute
                binding.switchAutoSync.isChecked = config.isEnabled
                updateTimeDisplay()
                if (config.lastSyncAt > 0) {
                    val fmt = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault())
                    binding.tvLastSync.text = "Last sync: ${fmt.format(java.util.Date(config.lastSyncAt))}"
                    binding.tvLastSync.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun updateTimeDisplay() {
        binding.tvSyncTime.text = "Sync Time: ${formatTime(selectedHour, selectedMinute)}"
    }

    private fun formatTime(h: Int, m: Int): String {
        val ampm = if (h >= 12) "PM" else "AM"
        val dh = if (h > 12) h - 12 else if (h == 0) 12 else h
        return String.format("%02d:%02d %s", dh, m, ampm)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
