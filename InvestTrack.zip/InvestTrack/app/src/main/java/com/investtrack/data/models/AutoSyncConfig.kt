package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "auto_sync_config")
data class AutoSyncConfig(
    @PrimaryKey
    val id: Int = 1,
    val isEnabled: Boolean = false,
    val hour: Int = 9,        // sync at 9 AM by default
    val minute: Int = 0,
    val lastSyncAt: Long = 0
)
