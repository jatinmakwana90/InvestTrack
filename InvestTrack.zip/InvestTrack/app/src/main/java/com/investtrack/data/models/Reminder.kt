package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val type: ReminderType,
    val dayOfMonth: Int,        // 1-31: day to remind each month
    val hour: Int,              // 0-23
    val minute: Int,            // 0-59
    val isActive: Boolean = true,
    val securityId: Long? = null,
    val accountId: Long? = null,
    val amount: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ReminderType(val displayName: String) {
    SIP("SIP Investment"),
    SWP("SWP Withdrawal"),
    REVIEW("Portfolio Review"),
    CUSTOM("Custom")
}
