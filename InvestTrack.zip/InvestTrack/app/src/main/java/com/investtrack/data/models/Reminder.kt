package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val type: ReminderType,
    val dueDayOfMonth: Int,         // actual due date e.g. 10 for SIP on 10th
    val amount: Double = 0.0,

    // First advance reminder
    val remind1DaysBefore: Int = 2, // days before due date
    val remind1Hour: Int = 9,
    val remind1Minute: Int = 0,
    val remind1Enabled: Boolean = true,

    // Second advance reminder
    val remind2DaysBefore: Int = 1, // days before due date
    val remind2Hour: Int = 9,
    val remind2Minute: Int = 0,
    val remind2Enabled: Boolean = true,

    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

enum class ReminderType(val displayName: String) {
    SIP("SIP Investment"),
    SWP("SWP Withdrawal"),
    REVIEW("Portfolio Review"),
    CUSTOM("Custom")
}
