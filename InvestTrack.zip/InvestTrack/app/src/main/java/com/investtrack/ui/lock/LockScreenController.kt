package com.investtrack.ui.lock

import android.view.View
import android.view.ViewGroup
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.google.android.material.button.MaterialButton
import com.investtrack.R
import com.investtrack.data.settings.AppLockManager

/** Full-screen PIN pad (with optional fingerprint / face) that covers the whole app until unlocked. */
class LockScreenController(
    private val activity: FragmentActivity,
    private val root: View,
    private val lock: AppLockManager,
    private val onVisibilityChanged: (Boolean) -> Unit
) {
    private val dots = root.findViewById<LinearLayout>(R.id.lock_dots)
    private val keypad = root.findViewById<GridLayout>(R.id.lock_keypad)
    private val title = root.findViewById<TextView>(R.id.tv_lock_title)
    private val error = root.findViewById<TextView>(R.id.tv_lock_error)
    private val bioButton = root.findViewById<TextView>(R.id.btn_lock_bio)
    private val entered = StringBuilder()
    private var promptShowing = false
    private var built = false

    val isShowing: Boolean get() = root.visibility == View.VISIBLE

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()

    fun setAppName(name: String) { root.findViewById<TextView>(R.id.tv_lock_app).text = name }

    private fun build() {
        if (built) return
        built = true
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
        keys.forEach { k ->
            val size = dp(74)
            val v: View = if (k.isEmpty()) View(activity) else MaterialButton(activity, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
                text = k
                textSize = 24f
                setAllCaps(false)
                cornerRadius = size / 2
                insetTop = 0; insetBottom = 0
                setPadding(0, 0, 0, 0)
                setTextColor(activity.getColor(R.color.loan_text_primary))
                strokeColor = android.content.res.ColorStateList.valueOf(activity.getColor(R.color.loan_border))
                setOnClickListener { onKey(k) }
            }
            keypad.addView(v, GridLayout.LayoutParams().apply {
                width = size; height = size
                setMargins(dp(8), dp(6), dp(8), dp(6))
            })
        }
        bioButton.setOnClickListener { promptBiometric() }
    }

    private fun renderDots() {
        dots.removeAllViews()
        val n = lock.pinLength
        for (i in 0 until n) {
            val d = View(activity).apply {
                background = androidx.core.content.ContextCompat.getDrawable(
                    activity, if (i < entered.length) R.drawable.lock_dot_filled else R.drawable.lock_dot_empty
                )
            }
            dots.addView(d, LinearLayout.LayoutParams(dp(14), dp(14)).apply { setMargins(dp(7), 0, dp(7), 0) })
        }
    }

    fun show(autoBiometric: Boolean) {
        build()
        if (!isShowing) {
            entered.setLength(0)
            error.text = ""
            title.text = "Enter your PIN"
            renderDots()
            root.visibility = View.VISIBLE
            onVisibilityChanged(true)
        }
        val bioOk = lock.biometricEnabled && biometricAvailable()
        bioButton.visibility = if (bioOk) View.VISIBLE else View.GONE
        if (autoBiometric && bioOk) promptBiometric()
    }

    fun hide() {
        root.visibility = View.GONE
        entered.setLength(0)
        onVisibilityChanged(false)
    }

    private fun onKey(k: String) {
        val wait = lock.lockoutSecondsLeft()
        if (wait > 0) { error.text = "Too many attempts. Try again in ${wait}s"; return }
        if (k == "⌫") {
            if (entered.isNotEmpty()) entered.deleteCharAt(entered.length - 1)
        } else if (entered.length < lock.pinLength) {
            entered.append(k)
        }
        error.text = ""
        renderDots()
        if (entered.length == lock.pinLength) {
            if (lock.verifyPin(entered.toString())) {
                lock.markUnlocked(); hide()
            } else {
                val left = lock.lockoutSecondsLeft()
                error.text = if (left > 0) "Too many attempts. Try again in ${left}s" else "Wrong PIN"
                entered.setLength(0)
                renderDots()
            }
        }
    }

    private fun biometricAvailable(): Boolean =
        BiometricManager.from(activity).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS

    private fun promptBiometric() {
        if (promptShowing || !isShowing) return
        promptShowing = true
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    promptShowing = false
                    lock.markUnlocked(); hide()
                }
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { promptShowing = false }
                override fun onAuthenticationFailed() { /* keep the prompt open for another try */ }
            })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock")
            .setSubtitle("Use your fingerprint or face")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        prompt.authenticate(info)
    }
}
