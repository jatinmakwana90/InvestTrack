package com.investtrack.ui.tools

import android.content.res.ColorStateList
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.investtrack.R
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.models.IncomeExpenseType
import com.investtrack.data.models.SecurityType
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.data.settings.ToolsPrefs
import com.investtrack.utils.*
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Calendar
import javax.inject.Inject

private fun money(v: Double) = CurrencyFormatter.formatFullNoDecimals(v)
private fun plain(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

// ======================================================================= Emergency fund

@AndroidEntryPoint
class EmergencyFundFragment : ToolFormFragment() {

    @Inject lateinit var prefs: ToolsPrefs
    @Inject lateinit var repository: InvestmentRepository
    @Inject lateinit var incomeExpenseDao: IncomeExpenseDao

    override val screenTitle = "Emergency Fund"

    override fun buildForm(form: FormBuilder) {
        form.note("How many months of expenses could your liquid savings cover if income stopped?")
        val monthly = form.number("Monthly expenses (₹)", "e.g. 40000", prefs.emergencyMonthlyExpense.takeIf { it > 0 }?.let { plain(it) }.orEmpty())
        form.button("Use the total of my Budget expenses") {
            viewLifecycleOwner.lifecycleScope.launch {
                val total = incomeExpenseDao.getAllEntriesList().filter { it.type == IncomeExpenseType.EXPENSE }.sumOf { it.amount }
                if (total > 0) monthly.setText(plain(total)) else toast("No expenses in your Budget yet")
            }
        }
        val target = form.number("Months of cover you want", "6", plain(prefs.emergencyTargetMonths.toDouble()))
        val cash = form.number("Cash & savings account balance (₹)", "e.g. 150000", prefs.emergencyCash.takeIf { it > 0 }?.let { plain(it) }.orEmpty())

        form.sectionTitle("Count these investments as liquid")
        val selected = prefs.emergencyTypes
        val boxes = SecurityType.values().map { t -> t to form.check(t.displayName, t.name in selected) }
        val result = form.result()

        var valuesByType: Map<SecurityType, Double> = emptyMap()

        fun compute() {
            val m = monthly.num()
            val tm = target.num().toInt().coerceAtLeast(1)
            val chosen = boxes.filter { it.second.isChecked }.map { it.first }
            val investments = chosen.sumOf { valuesByType[it] ?: 0.0 }
            val total = investments + cash.num()

            prefs.emergencyMonthlyExpense = m
            prefs.emergencyTargetMonths = tm
            prefs.emergencyCash = cash.num()
            prefs.emergencyTypes = chosen.map { it.name }.toSet()

            if (m <= 0) { result.show("Enter your monthly expenses", "", null); return }
            val months = total / m
            val goal = m * tm
            val gap = goal - total
            val head = String.format("%.1f months covered", months)
            val body = "Liquid investments: ${money(investments)}\nCash & savings: ${money(cash.num())}\nTotal liquid: ${money(total)}\n\n" +
                "Target: $tm months = ${money(goal)}\n" +
                if (gap > 0) "Shortfall: ${money(gap)}. Keeping it in a liquid fund or savings account is a good idea."
                else "Surplus: ${money(-gap)}. Your emergency fund is fully covered."
            result.show(head, body, if (gap <= 0) true else if (months < 3) false else null)
        }

        listOf(monthly, target, cash).forEach { it.onChange { compute() } }
        boxes.forEach { it.second.setOnCheckedChangeListener { _, _ -> compute() } }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                valuesByType = repository.getAllFolios().groupBy { it.securityType }.mapValues { e -> e.value.sumOf { it.currentValue } }
            } catch (e: Exception) { }
            compute()
        }
    }
}

// ======================================================================= Year in review

@AndroidEntryPoint
class YearReviewFragment : ToolFormFragment() {

    @Inject lateinit var repository: InvestmentRepository
    @Inject lateinit var loanDao: LoanDao
    @Inject lateinit var loanAdjustmentDao: LoanAdjustmentDao

    override val screenTitle = "Year in Review"

    override fun buildForm(form: FormBuilder) {
        val now = Calendar.getInstance()
        val currentFy = if (now.get(Calendar.MONTH) >= Calendar.APRIL) now.get(Calendar.YEAR) else now.get(Calendar.YEAR) - 1
        val years = (0..5).map { currentFy - it }
        val labels = years.map { "FY $it-${(it + 1) % 100}" }

        form.note("What you invested, earned and paid in EMIs during a financial year (April to March).")
        val picker = form.dropdown("Financial year", labels, labels.first())
        val investedCard = form.statCard()
        val earnedCard = form.statCard()
        val emiCard = form.statCard()
        var shareText = ""
        form.button("Share this summary", filled = true) {
            if (shareText.isNotEmpty()) startActivity(android.content.Intent.createChooser(
                android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                }, "Share summary"))
        }

        fun load() {
            val fy = years.getOrElse(labels.indexOf(picker.text.toString())) { currentFy }
            viewLifecycleOwner.lifecycleScope.launch {
                val start = Calendar.getInstance().apply { clear(); set(fy, Calendar.APRIL, 1) }.timeInMillis
                val end = Calendar.getInstance().apply { clear(); set(fy + 1, Calendar.APRIL, 1) }.timeInMillis
                try {
                    val all = repository.getAllTransactionsList()
                    val inYear = all.filter { it.transactionDate in start until end }
                    val bought = inYear.filter { it.type == TransactionType.BUY }.sumOf { it.amount }
                    val sold = inYear.filter { it.type != TransactionType.BUY }.sumOf { it.amount }

                    // Realised gains: FIFO per account + security, counting only sales made in the year
                    val realised = all.groupBy { it.accountId to it.securityId }.values.sumOf { txns ->
                        FIFOCalculator.processFIFO(txns).filter { it.sellTransaction.transactionDate in start until end }.sumOf { it.totalRealizedPnL }
                    }
                    val summary = repository.getPortfolioSummary()

                    var emiTotal = 0.0; var interest = 0.0; var principal = 0.0; var count = 0; var partPay = 0.0
                    loanDao.getAllLoansList().forEach { loan ->
                        val sch = LoanAmortizationCalculator.buildSchedule(loan, loanAdjustmentDao.getAdjustmentsForLoanList(loan.id))
                        val paid = loan.paidInstallmentSet()
                        sch.rows.forEach { r ->
                            if (r.dueDate !in start until end) return@forEach
                            if (r.isPartPayment) partPay += r.partPaymentAmount
                            else if (r.installmentNumber in paid) { emiTotal += r.emi; interest += r.interest; principal += r.principal; count++ }
                        }
                    }

                    fun signed(v: Double) = (if (v >= 0) "+" else "-") + money(Math.abs(v))

                    investedCard.show("Invested", money(bought), "Money you put into investments",
                        listOf("Withdrawn" to money(sold), "Net added" to money(bought - sold), "Transactions" to inYear.size.toString()))
                    earnedCard.show("Earned (realised)", signed(realised), "Gains booked on sales and maturities",
                        listOf("Portfolio value today" to money(summary.currentValue), "Unrealised gain so far" to signed(summary.totalPnL)),
                        realised >= 0)
                    val emiRows = mutableListOf("EMIs paid" to count.toString(), "Interest" to money(interest), "Principal" to money(principal))
                    if (partPay > 0) emiRows += "Part-prepayments" to money(partPay)
                    emiCard.show("Paid in EMIs", money(emiTotal), "Loan instalments in this year", emiRows)

                    shareText = "My FY $fy-${(fy + 1) % 100} in review\n" +
                        "• Invested: ${money(bought)} (withdrawn ${money(sold)})\n" +
                        "• Earned (realised): ${money(realised)}\n" +
                        "• Paid in EMIs: ${money(emiTotal)} (interest ${money(interest)})"
                } catch (e: Exception) {
                    investedCard.show("Could not build the summary", "—", e.message ?: "", emptyList(), false)
                }
            }
        }
        picker.setOnItemClickListener { _, _, _, _ -> load() }
        load()
    }
}

// ======================================================================= Planners (SIP step-up, lump sum, SWP)

@AndroidEntryPoint
class PlannersFragment : ToolFormFragment() {

    override val screenTitle = "Investment Planners"

    override fun buildForm(form: FormBuilder) {
        val ctx = requireContext()
        val names = listOf("SIP step-up", "Lump sum", "SWP")
        val buttons = mutableListOf<MaterialButton>()
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        fun select(index: Int) {
            buttons.forEachIndexed { i, b ->
                val on = i == index
                b.backgroundTintList = ColorStateList.valueOf(ctx.getColor(if (on) R.color.loan_accent else R.color.loan_chip_unselected))
                b.setTextColor(if (on) Color.WHITE else ctx.getColor(R.color.loan_text_primary))
            }
            content.removeAllViews()
            val f = FormBuilder(ctx, content)
            when (index) { 0 -> sipForm(f); 1 -> lumpForm(f); else -> swpForm(f) }
        }
        names.forEachIndexed { i, n ->
            val b = MaterialButton(ctx, null, 0).apply {
                text = n; setAllCaps(false); textSize = 12f; cornerRadius = ctx.dp(12)
                setPadding(ctx.dp(4), 0, ctx.dp(4), 0)
                minimumWidth = 0; minWidth = 0; minimumHeight = ctx.dp(44)
                maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                setOnClickListener { select(i) }
            }
            buttons += b
            row.addView(b, LinearLayout.LayoutParams(0, ViewGroupWrap, 1f).apply { marginEnd = if (i < 2) ctx.dp(8) else 0 })
        }
        form.container.addView(row)
        form.space(14)
        form.container.addView(content)
        select(0)
    }

    private val ViewGroupWrap = android.view.ViewGroup.LayoutParams.WRAP_CONTENT

    private fun sipForm(f: FormBuilder) {
        f.note("A SIP that grows every year as your income grows.")
        val sip = f.number("Monthly SIP (₹)", "e.g. 10000", "10000")
        val step = f.number("Increase every year (%)", "e.g. 10", "10")
        val ret = f.number("Expected return (% per year)", "e.g. 12", "12")
        val years = f.number("Years", "e.g. 15", "15")
        val res = f.result()
        fun calc() {
            val y = years.num().toInt()
            if (sip.num() <= 0 || y <= 0) { res.show("Enter the SIP amount and years", "", null); return }
            val r = PlannerCalculators.sipStepUp(sip.num(), step.num(), ret.num(), y)
            res.show("${money(r.futureValue)} after $y years",
                "You invest: ${money(r.invested)}\nGains: ${money(r.futureValue - r.invested)}\n\n" +
                "Without the yearly increase: ${money(r.flatFutureValue)} (you invest ${money(r.flatInvested)})\n" +
                "The step-up adds ${money(r.futureValue - r.flatFutureValue)}.")
        }
        listOf(sip, step, ret, years).forEach { it.onChange { calc() } }
        calc()
    }

    private fun lumpForm(f: FormBuilder) {
        f.note("What a one-time investment could grow to.")
        val amt = f.number("Amount (₹)", "e.g. 500000", "500000")
        val ret = f.number("Expected return (% per year)", "e.g. 12", "12")
        val years = f.number("Years", "e.g. 10", "10")
        val infl = f.number("Inflation (% per year)", "e.g. 6", "6")
        val res = f.result()
        fun calc() {
            val y = years.num().toInt()
            if (amt.num() <= 0 || y <= 0) { res.show("Enter the amount and years", "", null); return }
            val r = PlannerCalculators.lumpSum(amt.num(), ret.num(), y, infl.num())
            res.show("${money(r.futureValue)} after $y years",
                "Gain: ${money(r.gain)}\nIn today's money (after inflation): ${money(r.realValue)}")
        }
        listOf(amt, ret, years, infl).forEach { it.onChange { calc() } }
        calc()
    }

    private fun swpForm(f: FormBuilder) {
        f.note("Withdraw a fixed amount every month from your investments. See how long the money lasts.")
        val corpus = f.number("Investment amount (₹)", "e.g. 5000000", "5000000")
        val wd = f.number("Monthly withdrawal (₹)", "e.g. 30000", "30000")
        val ret = f.number("Expected return (% per year)", "e.g. 8", "8")
        val years = f.number("Period (years)", "e.g. 20", "20")
        val res = f.result()
        fun calc() {
            val y = years.num().toInt()
            if (corpus.num() <= 0 || wd.num() <= 0 || y <= 0) { res.show("Fill in all the amounts", "", null); return }
            val r = PlannerCalculators.swp(corpus.num(), wd.num(), ret.num(), y)
            val tail = "\n\nYou could withdraw up to ${money(r.sustainableMonthly)} a month for $y years."
            if (r.depleted) {
                val yy = r.monthsLasted / 12; val mm = r.monthsLasted % 12
                res.show("Money lasts ${yy}y ${mm}m", "Total withdrawn: ${money(r.totalWithdrawn)}$tail", false)
            } else {
                res.show("Lasts the full $y years", "Balance left: ${money(r.endBalance)}\nTotal withdrawn: ${money(r.totalWithdrawn)}$tail", true)
            }
        }
        listOf(corpus, wd, ret, years).forEach { it.onChange { calc() } }
        calc()
    }
}
