package com.investtrack.utils

import com.investtrack.data.models.Security
import com.investtrack.data.models.TransactionType
import java.util.Calendar

data class ParsedTransaction(
    val type: TransactionType,
    val amount: Double?,
    val units: Double?,
    val nav: Double?,
    val date: Long?,
    val folio: String?,
    val security: Security?
)

/** Reads an SMS / e-mail about a purchase or redemption and pulls out the numbers. Best effort. */
object SmsParser {

    private val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
    private val stopWords = setOf("fund", "plan", "growth", "direct", "regular", "option", "scheme", "the", "and", "ltd", "limited", "india", "mutual")

    private fun num(s: String?): Double? = s?.replace(",", "")?.trim()?.trimEnd('.')?.toDoubleOrNull()

    fun parse(text: String, securities: List<Security>): ParsedTransaction {
        val lower = text.lowercase()

        val type = when {
            Regex("""matur""").containsMatchIn(lower) -> TransactionType.MATURITY
            Regex("""redeem|redemption|redeemed|\bsold\b|\bsell\b|withdraw|switch.?out""").containsMatchIn(lower) -> TransactionType.SELL
            else -> TransactionType.BUY
        }

        // Amount: Rs. 5,000.00 / INR 5000 / ₹5,000 (first one that is not the NAV)
        val amountRegex = Regex("""(?:rs\.?|inr|₹)\s*([\d,]+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
        val navRegex = Regex("""nav[^\d]{0,15}([\d,]+\.\d+|[\d,]+)""", RegexOption.IGNORE_CASE)
        val nav = num(navRegex.find(text)?.groupValues?.get(1))

        var amount: Double? = null
        for (m in amountRegex.findAll(text)) {
            val v = num(m.groupValues[1]) ?: continue
            // skip the figure that is the NAV itself
            val isNav = nav != null && Math.abs(v - nav) < 0.0001 && Regex("""nav[^\d]{0,15}$""", RegexOption.IGNORE_CASE).containsMatchIn(text.substring(0, m.range.first + 1).takeLast(20))
            if (!isNav) { amount = v; break }
        }

        val unitsRegex1 = Regex("""([\d,]+\.\d+|[\d,]+)\s*units""", RegexOption.IGNORE_CASE)
        val unitsRegex2 = Regex("""units?\s*(?:allotted|purchased|redeemed|sold)?\s*[:\-]?\s*([\d,]+\.\d+)""", RegexOption.IGNORE_CASE)
        val units = num(unitsRegex1.find(text)?.groupValues?.get(1)) ?: num(unitsRegex2.find(text)?.groupValues?.get(1))

        val folio = Regex("""folio\s*(?:no\.?|number|#)?\s*[:\-]?\s*([A-Za-z0-9/]+)""", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1)?.takeIf { it.any { c -> c.isDigit() } }

        return ParsedTransaction(type, amount, units, nav, parseDate(text), folio, matchSecurity(lower, securities))
    }

    private fun parseDate(text: String): Long? {
        // 12-Mar-2025, 12 March 2025, 12/Mar/25
        Regex("""(\d{1,2})[\s\-/.,]+([A-Za-z]{3,9})[\s\-/.,]+(\d{2,4})""").find(text)?.let { m ->
            val mi = months.indexOf(m.groupValues[2].lowercase().take(3))
            if (mi >= 0) return build(m.groupValues[3].toInt(), mi, m.groupValues[1].toInt())
        }
        // 12/03/2025, 12-03-25
        Regex("""(\d{1,2})[\-/.](\d{1,2})[\-/.](\d{2,4})""").find(text)?.let { m ->
            return build(m.groupValues[3].toInt(), m.groupValues[2].toInt() - 1, m.groupValues[1].toInt())
        }
        return null
    }

    private fun build(yearIn: Int, month: Int, day: Int): Long? {
        val year = if (yearIn < 100) 2000 + yearIn else yearIn
        if (month !in 0..11 || day !in 1..31) return null
        return Calendar.getInstance().apply { clear(); set(year, month, day, 12, 0, 0) }.timeInMillis
    }

    private fun matchSecurity(lower: String, securities: List<Security>): Security? {
        var best: Security? = null
        var bestScore = 0
        for (s in securities) {
            val tokens = s.name.lowercase().split(Regex("""[^a-z0-9]+""")).filter { it.length > 2 && it !in stopWords }
            if (tokens.isEmpty()) continue
            var score = tokens.count { lower.contains(it) }
            if (s.isin.isNotBlank() && lower.contains(s.isin.lowercase())) score += 5
            if (s.securityCode.isNotBlank() && lower.contains(s.securityCode.lowercase())) score += 3
            if (score > bestScore) { bestScore = score; best = s }
        }
        return if (bestScore >= 2 || (bestScore == 1 && securities.size == 1)) best else null
    }
}
