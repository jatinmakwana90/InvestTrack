package com.investtrack.ui.whatsapp

import android.os.Bundle
import android.view.*
import android.widget.NumberPicker
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.investtrack.R
import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.WhatsAppContactDao
import com.investtrack.data.models.WhatsAppContact
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentWhatsappTemplatesBinding
import com.investtrack.databinding.ItemWhatsappContactBinding
import com.investtrack.whatsapp.WhatsAppLauncher
import com.investtrack.whatsapp.WhatsAppMessageBuilder
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import javax.inject.Inject

private enum class Template { AUM, FLOW, LOAN, BUDGET }

@HiltViewModel
class WhatsAppTemplatesViewModel @Inject constructor(
    investmentRepository: InvestmentRepository,
    accountDao: AccountDao,
    loanDao: LoanDao,
    loanAdjustmentDao: LoanAdjustmentDao,
    incomeExpenseDao: IncomeExpenseDao,
    val contactDao: WhatsAppContactDao
) : ViewModel() {

    private val messageBuilder = WhatsAppMessageBuilder(
        investmentRepository, accountDao, loanDao, loanAdjustmentDao, incomeExpenseDao
    )

    val contacts: StateFlow<List<WhatsAppContact>> = contactDao.getAllContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    suspend fun buildAum(): String = withContext(Dispatchers.IO) { messageBuilder.buildAumMessage() }

    suspend fun buildFlow(periodLabel: String, start: Long, end: Long): String =
        withContext(Dispatchers.IO) { messageBuilder.buildInflowOutflowMessage(periodLabel, start, end) }

    suspend fun buildLoan(): String = withContext(Dispatchers.IO) { messageBuilder.buildLoanSummaryMessage() }

    suspend fun buildBudget(periodLabel: String, start: Long, end: Long): String =
        withContext(Dispatchers.IO) { messageBuilder.buildBudgetMessage(periodLabel, start, end) }

    fun addContact(name: String, phone: String) {
        viewModelScope.launch { contactDao.insertContact(WhatsAppContact(name = name, phoneNumber = phone)) }
    }

    fun deleteContact(id: Long) {
        viewModelScope.launch { contactDao.deleteContact(id) }
    }
}

@AndroidEntryPoint
class WhatsAppTemplatesFragment : Fragment() {
    private var _binding: FragmentWhatsappTemplatesBinding? = null
    private val binding get() = _binding!!
    private val viewModel: WhatsAppTemplatesViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentWhatsappTemplatesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        binding.cardTemplateAum.setOnClickListener { startSendFlow(Template.AUM) }
        binding.cardTemplateFlow.setOnClickListener { startSendFlow(Template.FLOW) }
        binding.cardTemplateLoan.setOnClickListener { startSendFlow(Template.LOAN) }
        binding.cardTemplateBudget.setOnClickListener { startSendFlow(Template.BUDGET) }

        val adapter = ContactAdapter { contact -> viewModel.deleteContact(contact.id) }
        binding.rvContacts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.btnAddContact.setOnClickListener { showAddContactDialog() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.contacts.collect { list ->
                adapter.submitList(list)
                binding.rvContacts.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    /** Period-based templates ask for year/month first; AUM and Loan skip straight to recipient. */
    private fun startSendFlow(template: Template) {
        when (template) {
            Template.AUM -> generateAndPickRecipient { viewModel.buildAum() }
            Template.LOAN -> generateAndPickRecipient { viewModel.buildLoan() }
            Template.FLOW, Template.BUDGET -> showPeriodPicker { periodLabel, start, end ->
                generateAndPickRecipient {
                    if (template == Template.FLOW) viewModel.buildFlow(periodLabel, start, end)
                    else viewModel.buildBudget(periodLabel, start, end)
                }
            }
        }
    }

    private fun generateAndPickRecipient(build: suspend () -> String) {
        viewLifecycleOwner.lifecycleScope.launch {
            val message = try { build() } catch (e: Exception) {
                android.widget.Toast.makeText(requireContext(), "Could not build message: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                return@launch
            }
            showRecipientPicker(message)
        }
    }

    private fun showPeriodPicker(onPicked: (label: String, start: Long, end: Long) -> Unit) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_period_picker, null)
        val btnYear = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.btn_mode_year)
        val btnMonth = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.btn_mode_month)
        val npMonth = dialogView.findViewById<NumberPicker>(R.id.np_month)
        val npYear = dialogView.findViewById<NumberPicker>(R.id.np_year)

        val monthNames = arrayOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
        val currentYear = Calendar.getInstance().get(Calendar.YEAR)
        val currentMonth = Calendar.getInstance().get(Calendar.MONTH)

        npMonth.minValue = 0; npMonth.maxValue = 11
        npMonth.displayedValues = monthNames
        npMonth.value = currentMonth

        npYear.minValue = currentYear - 10; npYear.maxValue = currentYear
        npYear.value = currentYear

        var isYearly = true
        fun updateMode(yearly: Boolean) {
            isYearly = yearly
            npMonth.visibility = if (yearly) View.GONE else View.VISIBLE
            btnYear.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (yearly) R.color.primary else R.color.divider)
            )
            btnMonth.backgroundTintList = android.content.res.ColorStateList.valueOf(
                requireContext().getColor(if (!yearly) R.color.primary else R.color.divider)
            )
        }
        btnYear.setOnClickListener { updateMode(true) }
        btnMonth.setOnClickListener { updateMode(false) }
        updateMode(true)

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Choose Period")
            .setView(dialogView)
            .setPositiveButton("Next") { _, _ ->
                if (isYearly) {
                    val (start, end) = WhatsAppMessageBuilder.yearRange(npYear.value)
                    onPicked("Year ${npYear.value}", start, end)
                } else {
                    val (start, end) = WhatsAppMessageBuilder.monthRange(npYear.value, npMonth.value)
                    onPicked("${monthNames[npMonth.value]} ${npYear.value}", start, end)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showRecipientPicker(message: String) {
        val contacts = viewModel.contacts.value
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_whatsapp_contact, null)
        val etName = dialogView.findViewById<TextInputEditText>(R.id.et_contact_name)
        val etPhone = dialogView.findViewById<TextInputEditText>(R.id.et_contact_phone)
        etName.hint = "Save as (optional)"
        etPhone.hint = "Phone number with country code"

        val savedNames = contacts.map { it.name }.toTypedArray()

        val builder = android.app.AlertDialog.Builder(requireContext()).setTitle("Send To")

        if (contacts.isNotEmpty()) {
            builder.setItems(savedNames + "Enter a new number...") { dialog, which ->
                if (which < contacts.size) {
                    WhatsAppLauncher.sendMessage(requireContext(), contacts[which].phoneNumber, message)
                } else {
                    showManualNumberDialog(message)
                }
                dialog.dismiss()
            }
            builder.setNegativeButton("Cancel", null)
            builder.show()
        } else {
            showManualNumberDialog(message)
        }
    }

    private fun showManualNumberDialog(message: String) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_whatsapp_contact, null)
        val etName = dialogView.findViewById<TextInputEditText>(R.id.et_contact_name)
        val etPhone = dialogView.findViewById<TextInputEditText>(R.id.et_contact_phone)
        etName.hint = "Save as (optional)"

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Enter Phone Number")
            .setView(dialogView)
            .setPositiveButton("Send") { _, _ ->
                val phone = etPhone.text?.toString()?.trim().orEmpty()
                if (phone.isBlank()) {
                    android.widget.Toast.makeText(requireContext(), "Enter a phone number", android.widget.Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val name = etName.text?.toString()?.trim().orEmpty()
                if (name.isNotBlank()) viewModel.addContact(name, phone.filter { it.isDigit() })
                WhatsAppLauncher.sendMessage(requireContext(), phone, message)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddContactDialog() {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_whatsapp_contact, null)
        val etName = dialogView.findViewById<TextInputEditText>(R.id.et_contact_name)
        val etPhone = dialogView.findViewById<TextInputEditText>(R.id.et_contact_phone)

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Add Contact")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text?.toString()?.trim().orEmpty()
                val phone = etPhone.text?.toString()?.trim()?.filter { it.isDigit() }.orEmpty()
                if (name.isBlank() || phone.isBlank()) {
                    android.widget.Toast.makeText(requireContext(), "Enter both name and phone number", android.widget.Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.addContact(name, phone)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

private class ContactAdapter(
    private val onDelete: (WhatsAppContact) -> Unit
) : ListAdapter<WhatsAppContact, ContactAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemWhatsappContactBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(contact: WhatsAppContact) {
            b.tvContactName.text = contact.name
            b.tvContactPhone.text = contact.phoneNumber
            b.btnDeleteContact.setOnClickListener { onDelete(contact) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemWhatsappContactBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<WhatsAppContact>() {
            override fun areItemsTheSame(a: WhatsAppContact, b: WhatsAppContact) = a.id == b.id
            override fun areContentsTheSame(a: WhatsAppContact, b: WhatsAppContact) = a == b
        }
    }
}
