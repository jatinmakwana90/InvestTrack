package com.investtrack.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.XIRRCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val loanDao: com.investtrack.data.dao.LoanDao,
    private val loanAdjustmentDao: com.investtrack.data.dao.LoanAdjustmentDao,
    private val liveShare: com.investtrack.data.share.LiveShareManager,
    private val settingsManager: com.investtrack.data.settings.SettingsManager,
    @dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboard()
        observeLoans()
        publishSnapshots()
    }

    /** Keeps the shareable live link up to date whenever the dashboard numbers change. */
    @OptIn(kotlinx.coroutines.FlowPreview::class)
    private fun publishSnapshots() {
        viewModelScope.launch {
            _uiState
                .filter { it.portfolioSummary != null }
                .debounce(2000)
                .collect { state ->
                    try { liveShare.onSnapshot(buildSnapshotJson(state)) } catch (_: Exception) { }
                    try { com.investtrack.widget.OverviewWidget.refreshAll(appContext) } catch (_: Exception) { }
                }
        }
    }

    private fun buildSnapshotJson(state: DashboardUiState): String {
        val sm = state.portfolioSummary!!
        val root = org.json.JSONObject()
        root.put("appName", settingsManager.appName.value)
        root.put("updatedAt", System.currentTimeMillis())
        root.put("totalValue", sm.currentValue)
        root.put("invested", sm.totalInvested)
        root.put("pnl", sm.totalPnL)
        root.put("pnlPercent", sm.totalPnLPercent)
        root.put("dayChange", sm.dayChange)
        root.put("dayChangePercent", sm.dayChangePercent)
        root.put("xirr", state.overallXirr ?: org.json.JSONObject.NULL)
        root.put("loanOutstanding", state.totalLoanOutstanding)
        root.put("monthlyEmi", state.totalMonthlyEmi)
        val accounts = org.json.JSONArray()
        state.accountSummaries.forEach { a ->
            accounts.put(org.json.JSONObject().apply {
                put("name", a.account.name)
                put("type", a.account.type.name.replace("_", " "))
                put("value", a.summary.currentValue)
                put("invested", a.summary.totalInvested)
                put("pnl", a.summary.totalPnL)
                put("pnlPercent", a.summary.totalPnLPercent)
                put("holdings", a.summary.folioCount)
                put("xirr", a.xirrPercent ?: org.json.JSONObject.NULL)
            })
        }
        root.put("accounts", accounts)
        val loans = org.json.JSONArray()
        state.loans.forEach { l ->
            loans.put(org.json.JSONObject().apply {
                put("name", l.name)
                put("outstanding", l.outstanding)
                put("emi", l.emi)
                put("emiDay", l.emiDay)
            })
        }
        root.put("loans", loans)
        return root.toString()
    }

    /** Loan figures come from the live amortisation schedule, same as the Loan master screen. */
    private fun observeLoans() {
        viewModelScope.launch {
            loanDao.getAllLoans().collect { loans ->
                val lastDates = mutableListOf<Long>()
                val items = loans.filter { it.isActive }.mapNotNull { loan ->
                    val adjustments = loanAdjustmentDao.getAdjustmentsForLoanList(loan.id)
                    val schedule = com.investtrack.utils.LoanAmortizationCalculator.buildSchedule(loan, adjustments)
                    if (schedule.currentOutstanding <= 0.5 || schedule.remainingInstallments <= 0) null
                    else { schedule.lastEmiDate?.let { lastDates += it }; DashboardLoanItem(
                        loanId = loan.id,
                        name = loan.loanName,
                        outstanding = schedule.currentOutstanding,
                        emi = schedule.currentEmi,
                        emiDay = loan.emiDay
                    ) }
                }
                _uiState.update {
                    it.copy(
                        loans = items,
                        totalLoanOutstanding = items.sumOf { l -> l.outstanding },
                        totalMonthlyEmi = items.sumOf { l -> l.emi },
                        debtFreeDate = lastDates.maxOrNull()
                    )
                }
            }
        }
    }

    fun loadDashboard() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                // Re-run whenever accounts, security prices or transactions change, so a price
                // update (manual or automatic) shows up here without restarting the app.
                combine(repository.getAllAccounts(), repository.getAllSecurities(), repository.getAllTransactions()) { accounts, _, _ -> accounts }
                    .collectLatest { accounts ->
                    val summary = repository.getPortfolioSummary()
                    val accountSummaries = accounts.map { account ->
                        val acSummary = repository.getAccountPortfolioSummary(account.id)
                        val txns = repository.getTransactionsByAccountList(account.id)
                        val xirr = try {
                            val flows = XIRRCalculator.buildCashFlows(txns, acSummary.currentValue)
                            XIRRCalculator.calculate(flows)
                        } catch (e: Exception) { null }
                        AccountSummaryItem(account = account, summary = acSummary, xirrPercent = xirr)
                    }
                    val allTxns = repository.getAllTransactionsList()
                    val overallXirr = try {
                        val flows = XIRRCalculator.buildCashFlows(allTxns, summary.currentValue)
                        XIRRCalculator.calculate(flows)
                    } catch (e: Exception) { null }

                    _uiState.update {
                        it.copy(isLoading = false, portfolioSummary = summary,
                            accountSummaries = accountSummaries, overallXirr = overallXirr)
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}

data class DashboardUiState(
    val isLoading: Boolean = false,
    val portfolioSummary: PortfolioSummary? = null,
    val accountSummaries: List<AccountSummaryItem> = emptyList(),
    val overallXirr: Double? = null,
    val profileCount: Int = 0,
    val error: String? = null,
    val totalLoanOutstanding: Double = 0.0,
    val totalMonthlyEmi: Double = 0.0,
    val loans: List<DashboardLoanItem> = emptyList(),
    val debtFreeDate: Long? = null
)

data class DashboardLoanItem(
    val loanId: Long,
    val name: String,
    val outstanding: Double,
    val emi: Double,
    val emiDay: Int
)

data class AccountSummaryItem(
    val account: Account,
    val summary: PortfolioSummary,
    val xirrPercent: Double? = null
)

data class TypeAllocation(val type: SecurityType, val value: Double, val invested: Double)
