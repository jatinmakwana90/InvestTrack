package com.investtrack.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.XIRRCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class ReturnMode { ABS, XIRR }

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    private val _returnMode = MutableStateFlow(ReturnMode.ABS)
    val returnMode: StateFlow<ReturnMode> = _returnMode

    init { loadDashboard() }

    fun loadDashboard() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                repository.getAllAccounts().collect { accounts ->
                    val summary = repository.getPortfolioSummary()
                    val accountSummaries = accounts.map { account ->
                        val acSummary = repository.getAccountPortfolioSummary(account.id)
                        // Calculate XIRR for each account
                        val txns = repository.getTransactionsByAccountList(account.id)
                        val xirr = try {
                            val flows = XIRRCalculator.buildCashFlows(txns, acSummary.currentValue)
                            XIRRCalculator.calculate(flows)
                        } catch (e: Exception) { null }
                        AccountSummaryItem(account = account, summary = acSummary, xirrPercent = xirr)
                    }
                    // Overall XIRR
                    val allTxns = repository.getAllTransactionsList()
                    val overallXirr = try {
                        val flows = XIRRCalculator.buildCashFlows(allTxns, summary.currentValue)
                        XIRRCalculator.calculate(flows)
                    } catch (e: Exception) { null }

                    _uiState.update {
                        it.copy(isLoading = false, portfolioSummary = summary,
                            accountSummaries = accountSummaries, overallXirr = overallXirr)
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun toggleReturnMode() {
        _returnMode.value = if (_returnMode.value == ReturnMode.ABS) ReturnMode.XIRR else ReturnMode.ABS
    }
}

data class DashboardUiState(
    val isLoading: Boolean = false,
    val portfolioSummary: PortfolioSummary? = null,
    val accountSummaries: List<AccountSummaryItem> = emptyList(),
    val overallXirr: Double? = null,
    val profileCount: Int = 0,
    val error: String? = null
)

data class AccountSummaryItem(
    val account: Account,
    val summary: PortfolioSummary,
    val xirrPercent: Double? = null
)

data class TypeAllocation(val type: SecurityType, val value: Double, val invested: Double)
