package com.investtrack.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.XIRRCalculator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val loanDao: com.investtrack.data.dao.LoanDao,
    private val loanAdjustmentDao: com.investtrack.data.dao.LoanAdjustmentDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        loadDashboard()
        observeLoans()
    }

    /** Loan figures come from the live amortisation schedule, same as the Loan master screen. */
    private fun observeLoans() {
        viewModelScope.launch {
            loanDao.getAllLoans().collect { loans ->
                val items = loans.filter { it.isActive }.mapNotNull { loan ->
                    val adjustments = loanAdjustmentDao.getAdjustmentsForLoanList(loan.id)
                    val schedule = com.investtrack.utils.LoanAmortizationCalculator.buildSchedule(loan, adjustments)
                    if (schedule.currentOutstanding <= 0.5 || schedule.remainingInstallments <= 0) null
                    else DashboardLoanItem(
                        loanId = loan.id,
                        name = loan.loanName,
                        outstanding = schedule.currentOutstanding,
                        emi = schedule.currentEmi,
                        emiDay = loan.emiDay
                    )
                }
                _uiState.update {
                    it.copy(
                        loans = items,
                        totalLoanOutstanding = items.sumOf { l -> l.outstanding },
                        totalMonthlyEmi = items.sumOf { l -> l.emi }
                    )
                }
            }
        }
    }

    fun loadDashboard() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                repository.getAllAccounts().collect { accounts ->
                    val summary = repository.getPortfolioSummary()
                    val accountSummaries = accounts.map { account ->
                        val acSummary = repository.getAccountPortfolioSummary(account.id)
                        val txns = repository.getTransactionsByAccountList(account.id)
                        val xirr = try {
                            val flows = XIRRCalculator.buildCashFlows(txns, acSummary.currentValue)
                            XIRRCalculator.calculate(flows)
                        } catch (e: Exception) { null }
                        AccountSummaryItem(account = account, summary = acSummary, xirrPercent = xirr)
                    }
                    val allTxns = repository.getAllTransactionsList()
                    val overallXirr = try {
                        val flows = XIRRCalculator.buildCashFlows(allTxns, summary.currentValue)
                        XIRRCalculator.calculate(flows)
                    } catch (e: Exception) { null }

                    _uiState.update {
                        it.copy(isLoading = false, portfolioSummary = summary,
                            accountSummaries = accountSummaries, overallXirr = overallXirr)
                    }
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}

data class DashboardUiState(
    val isLoading: Boolean = false,
    val portfolioSummary: PortfolioSummary? = null,
    val accountSummaries: List<AccountSummaryItem> = emptyList(),
    val overallXirr: Double? = null,
    val profileCount: Int = 0,
    val error: String? = null,
    val totalLoanOutstanding: Double = 0.0,
    val totalMonthlyEmi: Double = 0.0,
    val loans: List<DashboardLoanItem> = emptyList()
)

data class DashboardLoanItem(
    val loanId: Long,
    val name: String,
    val outstanding: Double,
    val emi: Double,
    val emiDay: Int
)

data class AccountSummaryItem(
    val account: Account,
    val summary: PortfolioSummary,
    val xirrPercent: Double? = null
)

data class TypeAllocation(val type: SecurityType, val value: Double, val invested: Double)
