package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** A fixed deposit, recurring deposit or bond tracked in the Maturity Calendar. */
@Serializable
@Entity(tableName = "deposits")
data class Deposit(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    /** FD, RD, BOND or OTHER */
    val kind: String,
    val institution: String,
    val principal: Double,
    val interestRate: Double,
    val startDate: Long,
    val maturityDate: Long,
    /** Amount received at maturity. 0 = not known, the app estimates it. */
    val maturityAmount: Double,
    val notes: String,
    val isClosed: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)
