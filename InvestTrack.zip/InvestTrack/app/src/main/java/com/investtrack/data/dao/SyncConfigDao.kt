package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.SyncConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncConfigDao {
    @Query("SELECT * FROM sync_config WHERE id = 1")
    fun getSyncConfig(): Flow<SyncConfig?>

    @Query("SELECT * FROM sync_config WHERE id = 1")
    suspend fun getSyncConfigOnce(): SyncConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSyncConfig(config: SyncConfig)

    @Query("UPDATE sync_config SET lastSyncTime = :time WHERE id = 1")
    suspend fun updateLastSyncTime(time: Long)
}
