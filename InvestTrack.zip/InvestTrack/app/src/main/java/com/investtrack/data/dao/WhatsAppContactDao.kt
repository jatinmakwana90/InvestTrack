package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.WhatsAppContact
import kotlinx.coroutines.flow.Flow

@Dao
interface WhatsAppContactDao {
    @Query("SELECT * FROM whatsapp_contacts ORDER BY name ASC")
    fun getAllContacts(): Flow<List<WhatsAppContact>>

    @Query("SELECT * FROM whatsapp_contacts ORDER BY name ASC")
    suspend fun getAllContactsList(): List<WhatsAppContact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: WhatsAppContact): Long

    @Query("DELETE FROM whatsapp_contacts WHERE id = :id")
    suspend fun deleteContact(id: Long)
}
