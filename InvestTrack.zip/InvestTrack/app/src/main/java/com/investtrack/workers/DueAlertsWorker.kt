package com.investtrack.workers

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.investtrack.data.dao.DepositDao
import com.investtrack.data.dao.LendingDao
import com.investtrack.data.dao.PolicyDao
import com.investtrack.data.models.SecurityType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.DateUtil
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject

/**
 * Runs every morning and warns before: FD / bond maturities (30, 7, 1 days and on the day),
 * insurance premiums (7, 1 days and on the day) and money due back from or to people.
 */
@HiltWorker
class DueAlertsWorker @AssistedInject constructor(
    @Assisted private val appContext: Context,
    @Assisted params: WorkerParameters,
    private val depositDao: DepositDao,
    private val policyDao: PolicyDao,
    private val lendingDao: LendingDao,
    private val repository: InvestmentRepository
) : CoroutineWorker(appContext, params) {

    private fun money(v: Double) = CurrencyFormatter.formatFullNoDecimals(v)

    private fun notify(kind: Int, id: Long, slot: Int, title: String, text: String) {
        val nid = kind * 1_000_000 + ((id % 100_000).toInt()) * 10 + slot
        NotificationHelper.showReminderNotification(appContext, nid, title, text)
    }

    override suspend fun doWork(): Result {
        try {
            NotificationHelper.createChannels(appContext)

            // FDs / RDs / bonds entered in the Maturity Calendar
            depositDao.getAllList().filter { !it.isClosed }.forEach { d ->
                val days = DateUtil.daysUntil(d.maturityDate)
                val slot = when (days) { 30 -> 1; 7 -> 2; 1 -> 4; 0 -> 5; else -> 0 }
                if (slot > 0) {
                    val value = if (d.maturityAmount > 0) d.maturityAmount else d.principal
                    notify(11, d.id, slot, "${d.name} matures ${DateUtil.duesLabel(days)}",
                        "About ${money(value)} will be available on ${DateUtil.format(d.maturityDate)}. Decide where to reinvest it so it doesn't sit idle.")
                }
            }

            // FDs / bonds held as investments
            try {
                val secs = repository.getAllSecuritiesList().associateBy { it.id }
                repository.getAllFolios()
                    .filter { it.securityType == SecurityType.FIXED_DEPOSIT || it.securityType == SecurityType.BOND }
                    .groupBy { it.securityId }
                    .forEach { (secId, folios) ->
                        val sec = secs[secId] ?: return@forEach
                        val maturity = sec.maturityDate ?: return@forEach
                        val days = DateUtil.daysUntil(maturity)
                        val slot = when (days) { 30 -> 1; 7 -> 2; 1 -> 4; 0 -> 5; else -> 0 }
                        if (slot > 0) notify(12, secId, slot, "${sec.name} matures ${DateUtil.duesLabel(days)}",
                            "Current value ${money(folios.sumOf { it.currentValue })}, maturing on ${DateUtil.format(maturity)}.")
                    }
            } catch (e: Exception) { }

            // Insurance premiums
            policyDao.getAllList().filter { it.isActive }.forEach { p ->
                val days = DateUtil.daysUntil(p.nextDueDate)
                val slot = when (days) { 7 -> 2; 1 -> 4; 0 -> 5; else -> 0 }
                if (slot > 0) notify(13, p.id, slot, "${p.name} premium due ${DateUtil.duesLabel(days)}",
                    "${money(p.premiumAmount)} is due on ${DateUtil.format(p.nextDueDate)}.")
            }

            // Lending
            val payments = lendingDao.getPaymentsList()
            lendingDao.getEntriesList().filter { !it.isSettled && it.dueDate > 0 }.forEach { e ->
                val pending = e.amount - payments.filter { it.lendingId == e.id }.sumOf { it.amount }
                if (pending <= 0.5) return@forEach
                val days = DateUtil.daysUntil(e.dueDate)
                val slot = when {
                    days == 3 -> 3
                    days == 0 -> 5
                    days < 0 && (-days) % 7 == 0 -> 6   // a weekly nudge while overdue
                    else -> 0
                }
                if (slot > 0) {
                    val lent = e.direction == "LENT"
                    notify(14, e.id, slot,
                        if (lent) "${e.personName} owes you ${money(pending)}" else "You owe ${e.personName} ${money(pending)}",
                        if (days < 0) "This was due ${DateUtil.format(e.dueDate)} (${-days} days ago)." else "Due ${DateUtil.duesLabel(days)} (${DateUtil.format(e.dueDate)}).")
                }
            }
        } catch (e: Exception) {
            return Result.retry()
        }
        return Result.success()
    }
}
