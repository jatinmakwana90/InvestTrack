package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.Policy
import kotlinx.coroutines.flow.Flow

@Dao
interface PolicyDao {
    @Query("SELECT * FROM policies ORDER BY isActive DESC, nextDueDate ASC")
    fun getAll(): Flow<List<Policy>>

    @Query("SELECT * FROM policies ORDER BY nextDueDate ASC")
    suspend fun getAllList(): List<Policy>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(policy: Policy): Long

    @Query("DELETE FROM policies WHERE id = :id")
    suspend fun delete(id: Long)
}
