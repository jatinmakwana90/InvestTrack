package com.investtrack.report

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.util.Locale

/** Draws the report onto A4 pages with Android's built-in PdfDocument (no extra library). */
object PdfReportWriter {

    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 32f
    private const val ROW_H = 17f

    private val teal = Color.parseColor("#00695C")
    private val numberFmt: NumberFormat = NumberFormat.getNumberInstance(Locale("en", "IN")).apply { maximumFractionDigits = 2 }

    private fun cellText(v: Any?): String = when (v) {
        null -> ""
        is Double -> if (Math.abs(v) >= 1000) numberFmt.apply { maximumFractionDigits = 0 }.format(v)
                     else numberFmt.apply { maximumFractionDigits = 2 }.format(v)
        else -> v.toString()
    }

    private fun fit(text: String, paint: Paint, maxW: Float): String {
        if (paint.measureText(text) <= maxW) return text
        val n = paint.breakText(text, true, maxW - paint.measureText("…"), null)
        return text.substring(0, n.coerceAtLeast(0)) + "…"
    }

    fun write(data: ReportData, file: File) {
        val doc = PdfDocument()
        var pageNumber = 0
        var page: PdfDocument.Page? = null
        var canvas: Canvas = Canvas()
        var y = 0f

        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = teal; textSize = 22f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val sub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 10f }
        val h2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 13f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; textSize = 9f }
        val bold = Paint(body).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 8.5f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val headBg = Paint().apply { color = teal }
        val zebra = Paint().apply { color = Color.parseColor("#EEF5F3") }

        fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNumber++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNumber).create())
            page = p
            canvas = p.canvas
            y = MARGIN + 10f
        }
        fun ensure(space: Float) { if (y + space > PAGE_H - MARGIN) newPage() }

        newPage()
        canvas.drawText(data.appName, MARGIN, y + 8f, title); y += 30f
        canvas.drawText(data.title + " · " + data.subtitle, MARGIN, y, sub); y += 22f

        // Summary: two columns of label / value
        canvas.drawText("Summary", MARGIN, y, h2); y += 8f
        val colW = (PAGE_W - 2 * MARGIN) / 2f
        data.summary.chunked(2).forEach { pair ->
            ensure(34f)
            pair.forEachIndexed { i, (label, value) ->
                val x = MARGIN + i * colW
                canvas.drawText(label, x, y + 14f, sub)
                canvas.drawText(fit(value, bold.apply { textSize = 11f }, colW - 10f), x, y + 28f, bold)
            }
            y += 36f
        }
        bold.textSize = 9f
        y += 6f

        data.tables.forEach { table ->
            if (table.rows.isEmpty()) return@forEach
            ensure(60f)
            y += 6f
            canvas.drawText(table.title, MARGIN, y + 12f, h2); y += 20f

            val width = PAGE_W - 2 * MARGIN
            val weights = table.headers.indices.map { c ->
                val longest = maxOf(table.headers[c].length, table.rows.take(60).maxOf { cellText(it.getOrNull(c)).length })
                longest.coerceIn(5, 22).toFloat()
            }
            val total = weights.sum()
            val widths = weights.map { it / total * width }

            fun drawHeader() {
                canvas.drawRect(MARGIN, y, MARGIN + width, y + ROW_H, headBg)
                var x = MARGIN
                table.headers.forEachIndexed { i, h -> canvas.drawText(fit(h, head, widths[i] - 6f), x + 3f, y + 12f, head); x += widths[i] }
                y += ROW_H
            }
            drawHeader()
            table.rows.forEachIndexed { r, row ->
                if (y + ROW_H > PAGE_H - MARGIN) { newPage(); drawHeader() }
                if (r % 2 == 1) canvas.drawRect(MARGIN, y, MARGIN + width, y + ROW_H, zebra)
                var x = MARGIN
                table.headers.indices.forEach { c ->
                    canvas.drawText(fit(cellText(row.getOrNull(c)), body, widths[c] - 6f), x + 3f, y + 12f, body)
                    x += widths[c]
                }
                y += ROW_H
            }
            y += 10f
        }

        page?.let { doc.finishPage(it) }
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
    }
}
