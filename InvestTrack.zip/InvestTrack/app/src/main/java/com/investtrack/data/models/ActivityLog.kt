package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One line of the activity log: what was added, edited or deleted, and when. */
@Entity(tableName = "activity_log")
data class ActivityLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    /** ADDED, EDITED or DELETED */
    val action: String,
    /** Transaction, Account, Security, Loan, … */
    val entity: String,
    val description: String
)
