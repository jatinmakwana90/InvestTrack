package com.investtrack.ui.tools

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.databinding.FragmentToolFormBinding
import com.investtrack.databinding.ItemToolTileBinding
import com.investtrack.ui.MainActivity
import dagger.hilt.android.AndroidEntryPoint

/** A grid of all the extra tools, opened from the Dashboard. */
@AndroidEntryPoint
class ToolsHubFragment : Fragment() {

    private class Tile(val icon: String, val title: String, val sub: String, val open: () -> Fragment)

    private val tiles = listOf(
        Tile("📅", "Maturity Calendar", "FDs, RDs and bonds") { MaturitiesFragment() },
        Tile("🛡️", "Insurance", "Policies and premiums") { InsuranceFragment() },
        Tile("🤝", "Lending", "Money lent or borrowed") { LendingFragment() },
        Tile("🆘", "Emergency Fund", "Months of expenses covered") { EmergencyFundFragment() },
        Tile("📊", "Year in Review", "Invested, earned, EMIs") { YearReviewFragment() },
        Tile("🧮", "Planners", "SIP step-up, lump sum, SWP") { PlannersFragment() },
        Tile("🏦", "Loan Tools", "Balance transfer, affordability") { LoanToolsFragment() },
        Tile("✉️", "Quick Add", "Add a transaction from an SMS") { QuickAddFragment.newInstance(null) },
        Tile("🔍", "Search", "Find anything in the app") { SearchFragment() }
    )

    private var _b: FragmentToolFormBinding? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentToolFormBinding.inflate(inflater, container, false)
        return _b!!.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val b = _b!!
        b.tvToolTitle.text = "Tools"
        b.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val grid = RecyclerView(requireContext()).apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            isNestedScrollingEnabled = false
            adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                override fun getItemCount() = tiles.size
                override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
                    object : RecyclerView.ViewHolder(ItemToolTileBinding.inflate(LayoutInflater.from(parent.context), parent, false).root) {}
                override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                    val t = tiles[position]
                    holder.itemView.findViewById<TextView>(R.id.tv_tile_icon).text = t.icon
                    holder.itemView.findViewById<TextView>(R.id.tv_tile_title).text = t.title
                    holder.itemView.findViewById<TextView>(R.id.tv_tile_sub).text = t.sub
                    holder.itemView.setOnClickListener { (activity as? MainActivity)?.navigateTo(t.open()) }
                }
            }
        }
        b.formContainer.setPadding(0, 0, 0, 0)
        b.formContainer.addView(grid, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    override fun onDestroyView() { _b = null; super.onDestroyView() }
}
