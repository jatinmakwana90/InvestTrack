package com.investtrack.ui.common

import android.content.Context
import android.widget.ArrayAdapter
import android.widget.Filter

/**
 * Dropdown adapter that always lists every item. The normal ArrayAdapter filters the list by the
 * text already in the box, so a dropdown that is pre-filled with "Sunday" or "1st" would only offer
 * that one choice.
 */
class NoFilterAdapter<T>(
    context: Context,
    items: List<T>,
    resource: Int = android.R.layout.simple_dropdown_item_1line
) : ArrayAdapter<T>(context, resource, items.toList()) {

    constructor(context: Context, items: Array<T>, resource: Int = android.R.layout.simple_dropdown_item_1line) :
        this(context, items.toList(), resource)

    private val all: List<T> = items.toList()

    override fun getFilter(): Filter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults =
            FilterResults().apply { values = all; count = all.size }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            notifyDataSetChanged()
        }
    }
}
