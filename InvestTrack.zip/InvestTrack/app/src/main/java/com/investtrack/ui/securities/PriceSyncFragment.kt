package com.investtrack.ui.securities

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.models.Security
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentPriceSyncBinding
import com.investtrack.databinding.ItemPriceSyncBinding
import com.investtrack.network.YahooFinanceService
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class PriceSyncItem(
    val security: Security,
    val newPrice: Double = 0.0,
    val change: Double = 0.0,
    val changePercent: Double = 0.0,
    val status: SyncStatus = SyncStatus.PENDING
)

enum class SyncStatus { PENDING, UPDATING, SUCCESS, FAILED, NO_CODE }

@HiltViewModel
class PriceSyncViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val yahooFinanceService: YahooFinanceService
) : ViewModel() {

    private val _items = MutableStateFlow<List<PriceSyncItem>>(emptyList())
    val items: StateFlow<List<PriceSyncItem>> = _items

    private val _isUpdating = MutableStateFlow(false)
    val isUpdating: StateFlow<Boolean> = _isUpdating

    private val _lastUpdated = MutableStateFlow("")
    val lastUpdated: StateFlow<String> = _lastUpdated

    init {
        viewModelScope.launch {
            repository.getAllSecurities().collect { securities ->
                _items.value = securities.map { sec ->
                    PriceSyncItem(
                        security = sec,
                        newPrice = sec.currentPrice,
                        status = if (sec.yahooFinanceCode.isBlank()) SyncStatus.NO_CODE else SyncStatus.PENDING
                    )
                }
            }
        }
    }

    fun syncAll() {
        viewModelScope.launch {
            val updatable = _items.value.filter { it.security.yahooFinanceCode.isNotBlank() }
            if (updatable.isEmpty()) return@launch
            _isUpdating.value = true
            _items.update { list -> list.map { if (it.security.yahooFinanceCode.isNotBlank()) it.copy(status = SyncStatus.UPDATING) else it } }

            withContext(Dispatchers.IO) {
                val codes = updatable.map { it.security.yahooFinanceCode }
                val prices = yahooFinanceService.fetchPrices(codes)
                val updated = _items.value.map { item ->
                    val result = prices[item.security.yahooFinanceCode]
                    if (result != null) {
                        repository.updatePrice(item.security.id, result.price, result.previousClose)
                        item.copy(newPrice = result.price, change = result.change, changePercent = result.changePercent, status = SyncStatus.SUCCESS)
                    } else if (item.security.yahooFinanceCode.isNotBlank()) item.copy(status = SyncStatus.FAILED)
                    else item
                }
                withContext(Dispatchers.Main) {
                    _items.value = updated
                    _isUpdating.value = false
                    _lastUpdated.value = "Updated: ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())}"
                }
            }
        }
    }

    fun syncSingle(security: Security) {
        viewModelScope.launch {
            if (security.yahooFinanceCode.isBlank()) return@launch
            _items.update { list -> list.map { if (it.security.id == security.id) it.copy(status = SyncStatus.UPDATING) else it } }
            withContext(Dispatchers.IO) {
                val result = yahooFinanceService.fetchPrice(security.yahooFinanceCode)
                withContext(Dispatchers.Main) {
                    if (result != null) {
                        repository.updatePrice(security.id, result.price, result.previousClose)
                        _items.update { list -> list.map { if (it.security.id == security.id) it.copy(newPrice = result.price, change = result.change, changePercent = result.changePercent, status = SyncStatus.SUCCESS) else it } }
                    } else {
                        _items.update { list -> list.map { if (it.security.id == security.id) it.copy(status = SyncStatus.FAILED) else it } }
                    }
                }
            }
        }
    }
}

@AndroidEntryPoint
class PriceSyncFragment : Fragment() {

    private var _binding: FragmentPriceSyncBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PriceSyncViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPriceSyncBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = PriceSyncAdapter { item -> viewModel.syncSingle(item.security) }
        binding.rvPrices.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.btnSyncAll.setOnClickListener { viewModel.syncAll() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.items.collect { adapter.submitList(it) }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isUpdating.collect { updating ->
                binding.btnSyncAll.isEnabled = !updating
                binding.btnSyncAll.text = if (updating) "Syncing..." else "Sync All Prices"
                binding.progressBar.visibility = if (updating) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.lastUpdated.collect { msg ->
                binding.tvLastUpdated.text = msg
                binding.tvLastUpdated.visibility = if (msg.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class PriceSyncAdapter(
    private val onSync: (PriceSyncItem) -> Unit
) : ListAdapter<PriceSyncItem, PriceSyncAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemPriceSyncBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: PriceSyncItem) {
            val sec = item.security
            b.tvName.text = sec.name
            b.tvType.text = sec.type.displayName
            b.tvYahooCode.text = if (sec.yahooFinanceCode.isNotBlank()) sec.yahooFinanceCode else "No Yahoo code set"
            b.tvYahooCode.setTextColor(b.root.context.getColor(
                if (sec.yahooFinanceCode.isNotBlank()) com.investtrack.R.color.text_secondary else com.investtrack.R.color.loss_red))
            b.tvStoredPrice.text = CurrencyFormatter.format(sec.currentPrice)

            when (item.status) {
                SyncStatus.SUCCESS -> {
                    b.tvNewPrice.text = CurrencyFormatter.format(item.newPrice)
                    b.tvNewPrice.visibility = View.VISIBLE
                    val sign = if (item.change >= 0) "▲" else "▼"
                    b.tvChange.text = "$sign ${String.format("%.2f", kotlin.math.abs(item.changePercent))}%"
                    b.tvChange.setTextColor(b.root.context.getColor(if (item.change >= 0) com.investtrack.R.color.gain_green else com.investtrack.R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.VISIBLE
                }
                SyncStatus.UPDATING -> {
                    b.progressItem.visibility = View.VISIBLE
                    b.btnSync.visibility = View.GONE
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                }
                SyncStatus.FAILED -> {
                    b.tvChange.text = "Failed"
                    b.tvChange.setTextColor(b.root.context.getColor(com.investtrack.R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.VISIBLE
                    b.tvNewPrice.visibility = View.GONE
                }
                SyncStatus.NO_CODE -> {
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.GONE
                }
                else -> {
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = if (sec.yahooFinanceCode.isNotBlank()) View.VISIBLE else View.GONE
                }
            }
            b.btnSync.setOnClickListener { onSync(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPriceSyncBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PriceSyncItem>() {
            override fun areItemsTheSame(a: PriceSyncItem, b: PriceSyncItem) = a.security.id == b.security.id
            override fun areContentsTheSame(a: PriceSyncItem, b: PriceSyncItem) = a == b
        }
    }
}
