package com.investtrack.ui.securities

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.Security
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentPriceSyncBinding
import com.investtrack.databinding.ItemPriceSyncBinding
import com.investtrack.network.PriceService
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class PriceSyncItem(
    val security: Security,
    val newPrice: Double = 0.0,
    val change: Double = 0.0,
    val changePercent: Double = 0.0,
    val status: SyncStatus = SyncStatus.PENDING,
    val source: String = ""
)
enum class SyncStatus { PENDING, UPDATING, SUCCESS, FAILED, NO_CODE }

@HiltViewModel
class PriceSyncViewModel @Inject constructor(
    private val repository: InvestmentRepository,
    private val priceService: PriceService
) : ViewModel() {

    private val _items = MutableStateFlow<List<PriceSyncItem>>(emptyList())
    val items: StateFlow<List<PriceSyncItem>> = _items
    private val _isUpdating = MutableStateFlow(false)
    val isUpdating: StateFlow<Boolean> = _isUpdating
    private val _lastUpdated = MutableStateFlow("")
    val lastUpdated: StateFlow<String> = _lastUpdated

    init {
        viewModelScope.launch {
            repository.getAllSecurities().collect { list ->
                _items.value = list.map {
                    PriceSyncItem(it, it.currentPrice,
                        status = if (it.yahooFinanceCode.isBlank()) SyncStatus.NO_CODE else SyncStatus.PENDING)
                }
            }
        }
    }

    fun syncAll() {
        viewModelScope.launch {
            val updatable = _items.value.filter { it.security.yahooFinanceCode.isNotBlank() }
            if (updatable.isEmpty()) return@launch
            _isUpdating.value = true
            _items.update { list -> list.map { if (it.security.yahooFinanceCode.isNotBlank()) it.copy(status = SyncStatus.UPDATING) else it } }

            withContext(Dispatchers.IO) {
                val prices = priceService.fetchPrices(updatable.map { it.security.yahooFinanceCode })
                val updated = _items.value.map { item ->
                    val r = prices[item.security.yahooFinanceCode]
                    if (r != null) {
                        repository.updatePrice(item.security.id, r.price, r.previousClose)
                        item.copy(newPrice = r.price, change = r.change, changePercent = r.changePercent, status = SyncStatus.SUCCESS, source = r.source)
                    } else if (item.security.yahooFinanceCode.isNotBlank()) item.copy(status = SyncStatus.FAILED)
                    else item
                }
                withContext(Dispatchers.Main) {
                    _items.value = updated
                    _isUpdating.value = false
                    _lastUpdated.value = "Updated: ${SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date())}"
                }
            }
        }
    }

    fun syncSingle(security: Security) {
        viewModelScope.launch {
            if (security.yahooFinanceCode.isBlank()) return@launch
            _items.update { list -> list.map { if (it.security.id == security.id) it.copy(status = SyncStatus.UPDATING) else it } }
            withContext(Dispatchers.IO) {
                val r = priceService.fetchPrice(security.yahooFinanceCode)
                withContext(Dispatchers.Main) {
                    if (r != null) {
                        repository.updatePrice(security.id, r.price, r.previousClose)
                        _items.update { list -> list.map { if (it.security.id == security.id) it.copy(newPrice = r.price, change = r.change, changePercent = r.changePercent, status = SyncStatus.SUCCESS, source = r.source) else it } }
                    } else {
                        _items.update { list -> list.map { if (it.security.id == security.id) it.copy(status = SyncStatus.FAILED) else it } }
                    }
                }
            }
        }
    }
}

@AndroidEntryPoint
class PriceSyncFragment : Fragment() {
    private var _binding: FragmentPriceSyncBinding? = null
    private val binding get() = _binding!!
    private val viewModel: PriceSyncViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPriceSyncBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        val adapter = PriceSyncAdapter { viewModel.syncSingle(it.security) }
        binding.rvPrices.apply { layoutManager = LinearLayoutManager(requireContext()); this.adapter = adapter }
        binding.btnSyncAll.setOnClickListener { viewModel.syncAll() }
        viewLifecycleOwner.lifecycleScope.launch { viewModel.items.collect { adapter.submitList(it) } }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.isUpdating.collect { u ->
                binding.btnSyncAll.isEnabled = !u
                binding.btnSyncAll.text = if (u) "Syncing..." else "Sync All Prices"
                binding.progressBar.visibility = if (u) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.lastUpdated.collect {
                binding.tvLastUpdated.text = it
                binding.tvLastUpdated.visibility = if (it.isNotEmpty()) View.VISIBLE else View.GONE
            }
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class PriceSyncAdapter(private val onSync: (PriceSyncItem) -> Unit) :
    ListAdapter<PriceSyncItem, PriceSyncAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemPriceSyncBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: PriceSyncItem) {
            val sec = item.security
            b.tvName.text = sec.name
            b.tvType.text = sec.type.displayName
            // Show source hint in yahoo code field
            b.tvYahooCode.text = when {
                sec.yahooFinanceCode.isBlank() -> "No price code set"
                sec.yahooFinanceCode.matches(Regex("^\\d+$")) -> "AMFI: ${sec.yahooFinanceCode}"
                else -> "Yahoo: ${sec.yahooFinanceCode}"
            }
            b.tvYahooCode.setTextColor(b.root.context.getColor(
                if (sec.yahooFinanceCode.isNotBlank()) R.color.text_secondary else R.color.loss_red))
            b.tvStoredPrice.text = CurrencyFormatter.format(sec.currentPrice)
            when (item.status) {
                SyncStatus.SUCCESS -> {
                    b.tvNewPrice.text = CurrencyFormatter.format(item.newPrice)
                    b.tvNewPrice.visibility = View.VISIBLE
                    b.tvChange.text = "${if (item.change >= 0) "▲" else "▼"} ${String.format("%.2f", kotlin.math.abs(item.changePercent))}% • ${item.source}"
                    b.tvChange.setTextColor(b.root.context.getColor(if (item.change >= 0) R.color.gain_green else R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.VISIBLE
                }
                SyncStatus.UPDATING -> {
                    b.progressItem.visibility = View.VISIBLE
                    b.btnSync.visibility = View.GONE
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                }
                SyncStatus.FAILED -> {
                    b.tvChange.text = "Failed — check code"
                    b.tvChange.setTextColor(b.root.context.getColor(R.color.loss_red))
                    b.tvChange.visibility = View.VISIBLE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.VISIBLE
                    b.tvNewPrice.visibility = View.GONE
                }
                SyncStatus.NO_CODE -> {
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = View.GONE
                }
                else -> {
                    b.tvChange.visibility = View.GONE
                    b.tvNewPrice.visibility = View.GONE
                    b.progressItem.visibility = View.GONE
                    b.btnSync.visibility = if (sec.yahooFinanceCode.isNotBlank()) View.VISIBLE else View.GONE
                }
            }
            b.btnSync.setOnClickListener { onSync(item) }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPriceSyncBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))
    companion object {
        val DIFF = object : DiffUtil.ItemCallback<PriceSyncItem>() {
            override fun areItemsTheSame(a: PriceSyncItem, b: PriceSyncItem) = a.security.id == b.security.id
            override fun areContentsTheSame(a: PriceSyncItem, b: PriceSyncItem) = a == b
        }
    }
}
