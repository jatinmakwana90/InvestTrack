package com.investtrack.ui.viewer

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.investtrack.data.share.LiveShareManager
import com.investtrack.databinding.FragmentViewerBinding
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLEncoder
import javax.inject.Inject

/** Read-only view of another person's portfolio, using the code they shared. */
@AndroidEntryPoint
class ViewerFragment : Fragment() {

    @Inject lateinit var liveShare: LiveShareManager

    private var _binding: FragmentViewerBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentViewerBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        }
        binding.webView.setBackgroundColor(android.graphics.Color.TRANSPARENT)

        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.btnChangeCode.setOnClickListener { showCodePanel() }
        binding.btnView.setOnClickListener {
            val code = binding.etCode.text?.toString().orEmpty().trim()
            if (LiveShareManager.parseCode(code) == null) {
                binding.tvError.text = "That code is not valid. Copy the full code that starts with IT1-"
                binding.tvError.visibility = View.VISIBLE
            } else {
                binding.tvError.visibility = View.GONE
                liveShare.viewerCode = code
                showViewer()
            }
        }

        if (LiveShareManager.parseCode(liveShare.viewerCode) != null) showViewer() else showCodePanel()
    }

    private fun showCodePanel() {
        binding.etCode.setText(liveShare.viewerCode)
        binding.layoutCode.visibility = View.VISIBLE
        binding.webView.visibility = View.GONE
        binding.btnChangeCode.visibility = View.GONE
    }

    private fun showViewer() {
        val (db, token) = LiveShareManager.parseCode(liveShare.viewerCode) ?: return showCodePanel()
        binding.layoutCode.visibility = View.GONE
        binding.webView.visibility = View.VISIBLE
        binding.btnChangeCode.visibility = View.VISIBLE
        val url = "file:///android_asset/viewer/index.html#db=${URLEncoder.encode(db, "UTF-8")}&t=$token"
        binding.webView.loadUrl(url)
    }

    override fun onDestroyView() {
        _binding?.webView?.destroy()
        _binding = null
        super.onDestroyView()
    }
}
