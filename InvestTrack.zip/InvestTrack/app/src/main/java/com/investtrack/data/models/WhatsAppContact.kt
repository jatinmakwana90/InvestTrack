package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

/** A saved contact for quick reuse when sending WhatsApp template messages. */
@Parcelize
@Serializable
@Entity(tableName = "whatsapp_contacts")
data class WhatsAppContact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String,       // digits only, with country code, e.g. "919876543210"
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
