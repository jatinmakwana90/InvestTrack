package com.investtrack.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.investtrack.R
import com.investtrack.data.database.InvestTrackDatabase
import com.investtrack.ui.MainActivity
import com.investtrack.utils.DateUtil
import com.investtrack.utils.LoanAmortizationCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** One widget with both the portfolio value and the next EMI. */
class OverviewWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            onUpdate(context, mgr, mgr.getAppWidgetIds(ComponentName(context, OverviewWidget::class.java)))
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.investtrack.OVERVIEW_WIDGET_REFRESH"

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_overview)
            views.setOnClickPendingIntent(R.id.widget_ov_root, PendingIntent.getActivity(
                context, 10, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            views.setOnClickPendingIntent(R.id.btn_ov_refresh, PendingIntent.getBroadcast(
                context, 11, Intent(context, OverviewWidget::class.java).apply { action = ACTION_REFRESH },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))

            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = InvestTrackDatabase.getInstance(context)
                    val secMap = db.securityDao().getAllSecuritiesList().associateBy { it.id }
                    var value = 0.0
                    var invested = 0.0
                    db.transactionDao().getAllActiveFolios().forEach { raw ->
                        val sec = secMap[raw.securityId] ?: return@forEach
                        val net = db.transactionDao().getNetInvestment(raw.accountId, raw.securityId)
                        val price = if (sec.currentPrice > 0) sec.currentPrice else if (raw.netQty > 0) net / raw.netQty else 0.0
                        value += raw.netQty * price
                        invested += net
                    }
                    val pnl = value - invested
                    val pct = if (invested > 0) pnl / invested * 100 else 0.0
                    views.setTextViewText(R.id.tv_ov_value, amount(value))
                    views.setTextViewText(R.id.tv_ov_pnl,
                        "${if (pnl >= 0) "▲ +" else "▼ -"}${amount(Math.abs(pnl))} (${String.format("%.1f", Math.abs(pct))}%)")

                    // Next EMI across all active loans
                    data class Next(val name: String, val emi: Double, val due: Long)
                    val next = db.loanDao().getAllLoansList().filter { it.isActive }.mapNotNull { loan ->
                        val sch = LoanAmortizationCalculator.buildSchedule(loan, db.loanAdjustmentDao().getAdjustmentsForLoanList(loan.id))
                        val due = sch.nextEmiDate ?: return@mapNotNull null
                        Next(loan.loanName, sch.currentEmi, due)
                    }.minByOrNull { it.due }
                    if (next == null) {
                        views.setTextViewText(R.id.tv_ov_emi, "No active loans")
                        views.setTextViewText(R.id.tv_ov_emi_due, "")
                    } else {
                        val days = DateUtil.daysUntil(next.due)
                        views.setTextViewText(R.id.tv_ov_emi, "${next.name} · ${amount(next.emi)}")
                        views.setTextViewText(R.id.tv_ov_emi_due,
                            (if (days < 0) "Overdue by ${-days} day${if (days != -1) "s" else ""}" else "Due ${DateUtil.duesLabel(days)}") + " · ${DateUtil.format(next.due)}")
                    }
                } catch (e: Exception) {
                    views.setTextViewText(R.id.tv_ov_value, "Tap to open app")
                }
                manager.updateAppWidget(widgetId, views)
            }
        }

        private fun amount(v: Double): String = when {
            Math.abs(v) >= 10_000_000 -> "₹${String.format("%.2f", v / 10_000_000)}Cr"
            Math.abs(v) >= 100_000 -> "₹${String.format("%.2f", v / 100_000)}L"
            else -> "₹${String.format("%,.0f", v)}"
        }

        /** Asks every home-screen widget to redraw (called when the dashboard numbers change). */
        fun refreshAll(context: Context) {
            listOf(
                Intent(context, PortfolioWidget::class.java).apply { action = PortfolioWidget.ACTION_REFRESH },
                Intent(context, LoanEmiWidget::class.java).apply { action = LoanEmiWidget.ACTION_REFRESH },
                Intent(context, OverviewWidget::class.java).apply { action = ACTION_REFRESH }
            ).forEach { try { context.sendBroadcast(it) } catch (e: Exception) { } }
        }
    }
}
