package com.investtrack

import android.app.Application
import android.content.Intent
import com.investtrack.ui.CrashActivity
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class InvestTrackApp : Application() {

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val error = buildString {
                    appendLine("CRASH REPORT"); appendLine("=============")
                    appendLine(throwable.javaClass.name)
                    appendLine(throwable.message ?: "no message")
                    appendLine("---")
                    throwable.stackTrace.take(10).forEach { appendLine(it.toString()) }
                    throwable.cause?.let { cause ->
                        appendLine("CAUSED BY:"); appendLine(cause.javaClass.name)
                        appendLine(cause.message ?: "")
                        cause.stackTrace.take(5).forEach { appendLine(it.toString()) }
                    }
                }
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", error)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            } catch (e: Exception) {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }
}
