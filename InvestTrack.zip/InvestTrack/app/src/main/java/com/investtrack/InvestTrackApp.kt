package com.investtrack

import android.app.Application
import android.content.Intent
import androidx.appcompat.app.AppCompatDelegate
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.investtrack.ui.CrashActivity
import com.investtrack.utils.NotificationHelper
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsManager: com.investtrack.data.settings.SettingsManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()

        NotificationHelper.createChannels(this)

        // Apply saved dark mode preference
        when (settingsManager.darkMode.value) {
            com.investtrack.data.settings.DarkModeOption.LIGHT ->
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            com.investtrack.data.settings.DarkModeOption.DARK ->
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            com.investtrack.data.settings.DarkModeOption.SYSTEM ->
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val error = buildString {
                    appendLine("CRASH REPORT"); appendLine("=============")
                    appendLine(throwable.javaClass.name)
                    appendLine(throwable.message ?: "no message"); appendLine("---")
                    throwable.stackTrace.take(10).forEach { appendLine(it.toString()) }
                    throwable.cause?.let { c ->
                        appendLine("CAUSED BY:"); appendLine(c.javaClass.name)
                        appendLine(c.message ?: "")
                        c.stackTrace.take(5).forEach { appendLine(it.toString()) }
                    }
                }
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", error)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            } catch (e: Exception) { defaultHandler?.uncaughtException(thread, throwable) }
        }
    }
}
