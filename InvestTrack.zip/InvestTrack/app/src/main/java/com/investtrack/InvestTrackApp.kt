package com.investtrack

import android.app.Application
import com.investtrack.data.preload.DataPreloader
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application() {

    @Inject lateinit var dataPreloader: DataPreloader

    override fun onCreate() {
        super.onCreate()
        // Preload seed data in background - only runs if DB is empty
        CoroutineScope(Dispatchers.IO).launch {
            try { dataPreloader.preloadIfEmpty() } catch (e: Exception) { e.printStackTrace() }
        }
    }
}
