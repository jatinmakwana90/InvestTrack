package com.investtrack

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.investtrack.workers.MarketPriceWorker
import com.investtrack.workers.WifiSyncWorker
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .setMinimumLoggingLevel(android.util.Log.INFO)
            .build()

    override fun onCreate() {
        super.onCreate()
        try { MarketPriceWorker.schedule(this) } catch (e: Exception) { /* ignore */ }
        try { WifiSyncWorker.schedule(this) } catch (e: Exception) { /* ignore */ }
    }
}
