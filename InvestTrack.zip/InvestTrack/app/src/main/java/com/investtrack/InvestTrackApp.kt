package com.investtrack

import android.app.Application
import android.content.Intent
import androidx.appcompat.app.AppCompatDelegate
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.investtrack.ui.CrashActivity
import com.investtrack.utils.NotificationHelper
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsManager: com.investtrack.data.settings.SettingsManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()

        // Install the crash handler FIRST, before anything else that could throw —
        // otherwise an early failure (e.g. during dependency setup) bypasses this
        // handler entirely and the app just force-closes with no diagnostic screen.
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val error = buildString {
                    appendLine("CRASH REPORT"); appendLine("=============")
                    appendLine(throwable.javaClass.name)
                    appendLine(throwable.message ?: "no message"); appendLine("---")
                    throwable.stackTrace.take(15).forEach { appendLine(it.toString()) }
                    throwable.cause?.let { c ->
                        appendLine("CAUSED BY:"); appendLine(c.javaClass.name)
                        appendLine(c.message ?: "")
                        c.stackTrace.take(10).forEach { appendLine(it.toString()) }
                    }
                }
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", error)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            } catch (e: Exception) { defaultHandler?.uncaughtException(thread, throwable) }
        }

        NotificationHelper.createChannels(this)

        // Apply saved dark mode preference. Guarded because this reads a Hilt-injected
        // field's StateFlow immediately at startup — any unexpected failure here should
        // route to the crash screen instead of silently killing the whole app.
        try {
            when (settingsManager.darkMode.value) {
                com.investtrack.data.settings.DarkModeOption.LIGHT ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                com.investtrack.data.settings.DarkModeOption.DARK ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                com.investtrack.data.settings.DarkModeOption.SYSTEM ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
        } catch (e: Exception) {
            // Fall back to following the system setting rather than crashing app startup
            // over a display preference.
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        }
    }
}
