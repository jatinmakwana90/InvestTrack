package com.investtrack

import android.app.Application
import android.content.Intent
import androidx.appcompat.app.AppCompatDelegate
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.investtrack.debug.StartupTrace
import com.investtrack.ui.CrashActivity
import com.investtrack.utils.NotificationHelper
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var settingsManager: com.investtrack.data.settings.SettingsManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        StartupTrace.mark("=== InvestTrackApp.onCreate STARTING ===")
        StartupTrace.mark("InvestTrackApp.onCreate START (Hilt fields already injected)")

        // Install the crash handler FIRST, before anything else that could throw —
        // otherwise an early failure (e.g. during dependency setup) bypasses this
        // handler entirely and the app just force-closes with no diagnostic screen.
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val error = buildString {
                    appendLine("CRASH REPORT"); appendLine("=============")
                    appendLine(throwable.javaClass.name)
                    appendLine(throwable.message ?: "no message"); appendLine("---")
                    throwable.stackTrace.take(15).forEach { appendLine(it.toString()) }
                    throwable.cause?.let { c ->
                        appendLine("CAUSED BY:"); appendLine(c.javaClass.name)
                        appendLine(c.message ?: "")
                        c.stackTrace.take(10).forEach { appendLine(it.toString()) }
                    }
                }
                StartupTrace.mark("CRASH CAUGHT: ${throwable.javaClass.simpleName}: ${throwable.message}")
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", error)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            } catch (e: Exception) { defaultHandler?.uncaughtException(thread, throwable) }
        }
        StartupTrace.mark("Crash handler installed")

        NotificationHelper.createChannels(this)
        StartupTrace.mark("NotificationHelper channels created")

        // Apply saved dark mode preference. Guarded because this reads a Hilt-injected
        // field's StateFlow immediately at startup — any unexpected failure here should
        // route to the crash screen instead of silently killing the whole app.
        try {
            when (settingsManager.darkMode.value) {
                com.investtrack.data.settings.DarkModeOption.LIGHT ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                com.investtrack.data.settings.DarkModeOption.DARK ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                com.investtrack.data.settings.DarkModeOption.SYSTEM ->
                    AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            }
            StartupTrace.mark("Dark mode preference applied")
        } catch (e: Exception) {
            // Fall back to following the system setting rather than crashing app startup
            // over a display preference.
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            StartupTrace.mark("Dark mode preference FAILED: ${e.message}")
        }
        StartupTrace.mark("InvestTrackApp.onCreate END")

        // A second, independent watchdog: if MainActivity itself never even reaches
        // onCreate (e.g. the launcher never starts it, or something blocks before that),
        // this thread-based timer fires regardless — it doesn't depend on any Activity
        // or Looper being alive yet.
        Thread {
            Thread.sleep(8000)
            if (!StartupTrace.reachedEnd) {
                try {
                    startActivity(Intent(this, CrashActivity::class.java).apply {
                        putExtra("crash_text", "APPLICATION-LEVEL WATCHDOG — MainActivity did not finish " +
                            "loading within 8 seconds of Application.onCreate.\n\n" +
                            "Checkpoints reached:\n" + StartupTrace.dump())
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    })
                } catch (e: Exception) { /* best effort */ }
            }
        }.start()
    }
}
