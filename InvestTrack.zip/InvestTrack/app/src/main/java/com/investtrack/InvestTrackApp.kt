package com.investtrack

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import androidx.work.WorkManager
import com.investtrack.workers.MarketPriceWorker
import com.investtrack.workers.WifiSyncWorker
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        // Defer WorkManager scheduling to avoid blocking/crashing app startup.
        try {
            WorkManager.getInstance(this)
            MarketPriceWorker.schedule(this)
            WifiSyncWorker.schedule(this)
        } catch (t: Throwable) {
            // Never let background scheduling crash the app on launch.
            t.printStackTrace()
        }
    }
}
