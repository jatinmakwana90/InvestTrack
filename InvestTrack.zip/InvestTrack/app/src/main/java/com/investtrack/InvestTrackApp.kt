package com.investtrack

import android.app.Application
import android.content.Intent
import com.investtrack.data.preload.DataPreloader
import com.investtrack.ui.CrashActivity
import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltAndroidApp
class InvestTrackApp : Application() {

    @Inject lateinit var dataPreloader: DataPreloader

    override fun onCreate() {
        super.onCreate()

        // Crash reporter
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val error = buildString {
                    appendLine("CRASH REPORT"); appendLine("=============")
                    appendLine(throwable.javaClass.name)
                    appendLine(throwable.message ?: "no message"); appendLine("---")
                    throwable.stackTrace.take(10).forEach { appendLine(it.toString()) }
                    throwable.cause?.let { c ->
                        appendLine("CAUSED BY:"); appendLine(c.javaClass.name)
                        appendLine(c.message ?: "")
                        c.stackTrace.take(5).forEach { appendLine(it.toString()) }
                    }
                }
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", error)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            } catch (e: Exception) { defaultHandler?.uncaughtException(thread, throwable) }
        }

        // Preload seed data on first launch only
        CoroutineScope(Dispatchers.IO).launch {
            try { dataPreloader.preloadIfEmpty() } catch (e: Exception) { e.printStackTrace() }
        }
    }
}
