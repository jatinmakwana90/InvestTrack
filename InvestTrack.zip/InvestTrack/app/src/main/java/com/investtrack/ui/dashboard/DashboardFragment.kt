package com.investtrack.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.databinding.FragmentDashboardBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AccountDetailFragment
 
import com.investtrack.ui.transactions.AddTransactionFragment
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var accountAdapter: AccountSummaryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        accountAdapter = AccountSummaryAdapter { accountItem ->
            val fragment = AccountDetailFragment.newInstance(accountItem.account.id)
            (activity as? MainActivity)?.navigateTo(fragment)
        }
        binding.rvAccounts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = accountAdapter
            isNestedScrollingEnabled = false
        }

        // Account creation moved to Master tab. Dashboard remains read-only summary view.

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                state.portfolioSummary?.let { summary ->
                    binding.tvTotalValue.text = CurrencyFormatter.format(summary.currentValue)
                    binding.tvTotalInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested)}"
                    val pnl = summary.totalPnL
                    val pct = summary.totalPnLPercent
                    binding.tvTotalPnl.text = "${if (pnl >= 0) "+" else ""}${CurrencyFormatter.format(pnl)} (${String.format("%.2f", pct)}%)"
                    binding.tvTotalPnl.setTextColor(
                        requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red)
                    )
                    binding.tvAccountCount.text = summary.accountCount.toString()
                    binding.tvFolioCount.text = summary.folioCount.toString()
                }
                accountAdapter.submitList(state.accountSummaries)
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
