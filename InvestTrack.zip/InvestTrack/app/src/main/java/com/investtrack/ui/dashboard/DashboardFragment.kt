package com.investtrack.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment

// NO @AndroidEntryPoint - no Hilt at all for this test
class DashboardFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Build UI 100% programmatically - no XML inflation at all
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val title = TextView(requireContext()).apply {
            text = "InvestTrack"
            textSize = 32f
            setTextColor(Color.parseColor("#1A237E"))
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 16)
        }

        val subtitle = TextView(requireContext()).apply {
            text = "App is working!\nDashboard loading..."
            textSize = 16f
            setTextColor(Color.parseColor("#5C6B9A"))
            gravity = Gravity.CENTER
            setPadding(32, 0, 32, 32)
        }

        layout.addView(title)
        layout.addView(subtitle)
        return layout
    }
}
