package com.investtrack.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentDashboardBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AccountDetailFragment
import com.investtrack.ui.transactions.AddTransactionFragment
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()

    @Inject lateinit var settingsManager: SettingsManager
    @Inject lateinit var liveShare: com.investtrack.data.share.LiveShareManager
    @Inject lateinit var policyDao: com.investtrack.data.dao.PolicyDao

    private lateinit var accountAdapter: AccountSummaryAdapter
    private lateinit var loanAdapter: DashboardLoanAdapter
    private lateinit var policyAdapter: DashboardPolicyAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        accountAdapter = AccountSummaryAdapter(
            returnMode = settingsManager.returnMode.value,
            amountMode = settingsManager.amountMode.value,
            onClick = { item ->
                val fragment = AccountDetailFragment.newInstance(item.account.id)
                (activity as? MainActivity)?.navigateTo(fragment)
            }
        )
        binding.rvAccounts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = accountAdapter
            isNestedScrollingEnabled = false
        }

        policyAdapter = DashboardPolicyAdapter {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.tools.InsuranceFragment())
        }
        binding.rvInsurance.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = policyAdapter
            isNestedScrollingEnabled = false
        }
        binding.tvInsuranceTitle.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.tools.InsuranceFragment())
        }
        viewLifecycleOwner.lifecycleScope.launch {
            policyDao.getAll().collect { all ->
                val active = all.filter { it.isActive }
                policyAdapter.submitList(active)
                val show = if (active.isEmpty()) View.GONE else View.VISIBLE
                _binding?.tvInsuranceTitle?.visibility = show
                _binding?.rvInsurance?.visibility = show
            }
        }

        binding.btnSearch.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.tools.SearchFragment())
        }
        binding.btnSharePortfolio.setOnClickListener {
            val text = liveShare.shareText()
            if (text == null) {
                android.widget.Toast.makeText(requireContext(),
                    "Set up Live Portfolio Link in Settings first", android.widget.Toast.LENGTH_LONG).show()
                (activity as? MainActivity)?.selectTab(MainActivity.TAB_SETTINGS)
            } else {
                viewLifecycleOwner.lifecycleScope.launch { liveShare.pushLatest() } // make sure the link shows the latest numbers
                startActivity(android.content.Intent.createChooser(
                    android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, text)
                    }, "Share portfolio link"))
            }
        }

        loanAdapter = DashboardLoanAdapter(settingsManager.amountMode.value) {
            (activity as? MainActivity)?.navigateTo(com.investtrack.ui.loans.LoansFragment())
        }
        binding.rvLoans.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = loanAdapter
            isNestedScrollingEnabled = false
        }

        binding.fabAddTransaction.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddTransactionFragment.newInstance(0L))
        }

        // Tap the loan totals → Loan master
        binding.cardLoans.setOnClickListener {
            val main = activity as? MainActivity ?: return@setOnClickListener
            main.navigateTo(com.investtrack.ui.loans.LoansFragment())
        }

        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.appName.collect { binding.tvAppTitle.text = it }
        }

        // Observe settings changes and re-render
        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.returnMode.collect { renderPortfolioSummary() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.amountMode.collect { mode ->
                accountAdapter.updateModes(settingsManager.returnMode.value, mode)
                loanAdapter.updateAmountMode(mode)
                renderPortfolioSummary()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                accountAdapter.submitList(state.accountSummaries)
                accountAdapter.updateModes(settingsManager.returnMode.value, settingsManager.amountMode.value)
                binding.tvEmpty.visibility =
                    if (state.accountSummaries.isEmpty() && !state.isLoading) View.VISIBLE else View.GONE
                // Loan summary
                binding.tvLoanOutstanding.text = CurrencyFormatter.format(state.totalLoanOutstanding, settingsManager.amountMode.value)
                binding.tvLoanEmi.text = CurrencyFormatter.format(state.totalMonthlyEmi, settingsManager.amountMode.value)
                loanAdapter.updateAmountMode(settingsManager.amountMode.value)
                loanAdapter.submitList(state.loans)
                val hasLoans = state.loans.isNotEmpty()
                binding.tvLoansTitle.visibility = if (hasLoans) View.VISIBLE else View.GONE
                binding.rvLoans.visibility = if (hasLoans) View.VISIBLE else View.GONE
                val free = state.debtFreeDate
                if (hasLoans && free != null) {
                    val months = com.investtrack.utils.GoalCalculator.monthsBetween(System.currentTimeMillis(), free)
                    val y = months / 12; val m = months % 12
                    val togo = when {
                        months <= 0 -> "this month"
                        y > 0 && m > 0 -> "$y year${if (y > 1) "s" else ""} $m month${if (m > 1) "s" else ""} to go"
                        y > 0 -> "$y year${if (y > 1) "s" else ""} to go"
                        else -> "$m month${if (m > 1) "s" else ""} to go"
                    }
                    binding.tvDebtFree.text = "🎉 Debt-free by " + java.text.SimpleDateFormat("MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(free)) + " · " + togo
                    binding.tvDebtFree.visibility = View.VISIBLE
                } else binding.tvDebtFree.visibility = View.GONE
                renderPortfolioSummary()
            }
        }
    }

    private fun renderPortfolioSummary() {
        val state = viewModel.uiState.value
        val summary = state.portfolioSummary ?: return
        val amountMode = settingsManager.amountMode.value
        val returnMode = settingsManager.returnMode.value

        binding.tvTotalValue.text = CurrencyFormatter.format(summary.currentValue, amountMode)
        binding.tvTotalInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested, amountMode)}"

        if (returnMode == ReturnDisplayMode.ABS) {
            val pnl = summary.totalPnL
            val pct = summary.totalPnLPercent
            val sign = if (pnl >= 0) "+" else ""
            binding.tvTotalPnl.text = "$sign${CurrencyFormatter.format(pnl, amountMode)} ($sign${String.format("%.2f", pct)}%)"
            binding.tvTotalPnl.setTextColor(requireContext().getColor(if (pnl >= 0) R.color.gain_on_primary else R.color.loss_on_primary))
        } else {
            val xirr = state.overallXirr
            if (xirr != null) {
                val sign = if (xirr >= 0) "+" else ""
                binding.tvTotalPnl.text = "XIRR: $sign${String.format("%.2f", xirr)}% p.a."
                binding.tvTotalPnl.setTextColor(requireContext().getColor(if (xirr >= 0) R.color.gain_on_primary else R.color.loss_on_primary))
            } else {
                binding.tvTotalPnl.text = "XIRR: N/A"
                binding.tvTotalPnl.setTextColor(requireContext().getColor(R.color.on_primary_muted))
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
