package com.investtrack.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.investtrack.R
import com.investtrack.databinding.FragmentDashboardBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()
    private lateinit var accountAdapter: AccountSummaryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerViews()
        observeState()

        binding.fabAddAccount.setOnClickListener { showQuickActionSheet() }
        binding.swipeRefresh.setOnRefreshListener { viewModel.loadDashboard() }
        binding.btnViewAllAccounts.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_addAccount)
        }
        binding.btnUpdatePrices.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_marketUpdate)
        }
        binding.btnManageProfiles.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_profileList)
        }
    }

    private fun showQuickActionSheet() {
        val dialog = BottomSheetDialog(requireContext())
        val sheetView = layoutInflater.inflate(R.layout.bottom_sheet_quick_actions, null)
        dialog.setContentView(sheetView)
        sheetView.findViewById<View>(R.id.btn_add_transaction).setOnClickListener {
            dialog.dismiss()
            val bundle = Bundle().apply { putLong("accountId", 0L) }
            findNavController().navigate(R.id.action_dashboard_to_addTransaction, bundle)
        }
        sheetView.findViewById<View>(R.id.btn_add_account).setOnClickListener {
            dialog.dismiss()
            findNavController().navigate(R.id.action_dashboard_to_addAccount)
        }
        sheetView.findViewById<View>(R.id.btn_update_prices_sheet).setOnClickListener {
            dialog.dismiss()
            findNavController().navigate(R.id.action_dashboard_to_marketUpdate)
        }
        dialog.show()
    }

    private fun setupRecyclerViews() {
        accountAdapter = AccountSummaryAdapter { accountItem ->
            val bundle = Bundle().apply { putLong("accountId", accountItem.account.id) }
            findNavController().navigate(R.id.action_dashboard_to_accountDetail, bundle)
        }
        binding.rvAccounts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = accountAdapter
            isNestedScrollingEnabled = false
        }
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.swipeRefresh.isRefreshing = state.isLoading
                state.portfolioSummary?.let { summary ->
                    binding.tvTotalValue.text = CurrencyFormatter.format(summary.currentValue)
                    binding.tvTotalInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested)}"
                    val pnl = summary.totalPnL
                    val pct = summary.totalPnLPercent
                    val sign = if (pnl >= 0) "▲ +" else "▼ "
                    binding.tvTotalPnl.text = "$sign${CurrencyFormatter.format(kotlin.math.abs(pnl))} (${String.format("%.2f", kotlin.math.abs(pct))}%)"
                    binding.tvTotalPnl.setTextColor(
                        requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red)
                    )
                    binding.tvAccountCount.text = summary.accountCount.toString()
                    binding.tvFolioCount.text = summary.folioCount.toString()
                    binding.tvProfileCount.text = state.profileCount.toString()
                }
                accountAdapter.submitList(state.accountSummaries)
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
