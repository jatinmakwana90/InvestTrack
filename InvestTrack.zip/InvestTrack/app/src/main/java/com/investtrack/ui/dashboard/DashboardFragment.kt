package com.investtrack.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentDashboardBinding
import com.investtrack.debug.StartupTrace
import com.investtrack.ui.MainActivity
import com.investtrack.ui.accounts.AccountDetailFragment
import com.investtrack.ui.transactions.AddTransactionFragment
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()

    @Inject lateinit var settingsManager: SettingsManager

    private lateinit var accountAdapter: AccountSummaryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        StartupTrace.mark(requireContext(), "DashboardFragment.onCreateView START")
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        StartupTrace.mark(requireContext(), "DashboardFragment binding inflated")
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        StartupTrace.mark(requireContext(), "DashboardFragment.onViewCreated START")

        accountAdapter = AccountSummaryAdapter(
            returnMode = settingsManager.returnMode.value,
            amountMode = settingsManager.amountMode.value,
            onClick = { item ->
                val fragment = AccountDetailFragment.newInstance(item.account.id)
                (activity as? MainActivity)?.navigateTo(fragment)
            }
        )
        binding.rvAccounts.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = accountAdapter
            isNestedScrollingEnabled = false
        }

        binding.fabAddTransaction.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddTransactionFragment.newInstance(0L))
        }

        // Tap loan card → go to Loans tab
        binding.cardLoans.setOnClickListener {
            val main = activity as? MainActivity ?: return@setOnClickListener
            main.loadFragment(com.investtrack.ui.loans.LoansFragment(), "loans")
            main.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(
                com.investtrack.R.id.bottom_navigation)?.selectedItemId = com.investtrack.R.id.nav_loans
        }

        // Observe settings changes and re-render
        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.returnMode.collect { renderPortfolioSummary() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.amountMode.collect { mode ->
                accountAdapter.updateModes(settingsManager.returnMode.value, mode)
                renderPortfolioSummary()
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.tvAccountCount.text = state.portfolioSummary?.accountCount?.toString() ?: "0"
                binding.tvFolioCount.text = state.portfolioSummary?.folioCount?.toString() ?: "0"
                accountAdapter.submitList(state.accountSummaries)
                accountAdapter.updateModes(settingsManager.returnMode.value, settingsManager.amountMode.value)
                binding.tvEmpty.visibility =
                    if (state.accountSummaries.isEmpty() && !state.isLoading) View.VISIBLE else View.GONE
                // Loan summary
                binding.tvLoanOutstanding.text = CurrencyFormatter.format(state.totalLoanOutstanding, settingsManager.amountMode.value)
                binding.tvLoanEmi.text = CurrencyFormatter.format(state.totalMonthlyEmi, settingsManager.amountMode.value)
                binding.cardLoans.visibility = if (state.totalLoanOutstanding > 0) View.VISIBLE else View.GONE
                renderPortfolioSummary()
            }
        }
        StartupTrace.mark(requireContext(), "DashboardFragment.onViewCreated END (all listeners wired)")
    }

    private fun renderPortfolioSummary() {
        val state = viewModel.uiState.value
        val summary = state.portfolioSummary ?: return
        val amountMode = settingsManager.amountMode.value
        val returnMode = settingsManager.returnMode.value

        binding.tvTotalValue.text = CurrencyFormatter.format(summary.currentValue, amountMode)
        binding.tvTotalInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested, amountMode)}"

        if (returnMode == ReturnDisplayMode.ABS) {
            val pnl = summary.totalPnL
            val pct = summary.totalPnLPercent
            val sign = if (pnl >= 0) "+" else ""
            binding.tvTotalPnl.text = "$sign${CurrencyFormatter.format(pnl, amountMode)} ($sign${String.format("%.2f", pct)}%)"
            binding.tvTotalPnl.setTextColor(requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red))
        } else {
            val xirr = state.overallXirr
            if (xirr != null) {
                val sign = if (xirr >= 0) "+" else ""
                binding.tvTotalPnl.text = "XIRR: $sign${String.format("%.2f", xirr)}% p.a."
                binding.tvTotalPnl.setTextColor(requireContext().getColor(if (xirr >= 0) R.color.gain_green else R.color.loss_red))
            } else {
                binding.tvTotalPnl.text = "XIRR: N/A"
                binding.tvTotalPnl.setTextColor(requireContext().getColor(R.color.text_secondary))
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
