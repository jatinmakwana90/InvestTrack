package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.Serializable

enum class IncomeExpenseType { INCOME, EXPENSE }

/**
 * A single income or expense entry — the "Budget Planning" screen. Deliberately simple:
 * a free-text label (no fixed category list), an amount, a type, and a date. Net savings is
 * computed as total income minus total expense across whatever entries exist.
 */
@Parcelize
@Serializable
@Entity(tableName = "income_expense_entries")
data class IncomeExpenseEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val label: String,
    val amount: Double,
    val type: IncomeExpenseType,
    val date: Long = System.currentTimeMillis(),
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable
