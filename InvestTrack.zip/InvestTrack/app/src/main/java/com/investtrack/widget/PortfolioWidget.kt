package com.investtrack.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.investtrack.R
import com.investtrack.data.database.InvestTrackDatabase
import com.investtrack.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

class PortfolioWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, PortfolioWidget::class.java))
            onUpdate(context, mgr, ids)
        }
    }

    companion object {
        const val ACTION_REFRESH = "com.investtrack.WIDGET_REFRESH"

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_portfolio)

            // Open app on click
            val openIntent = Intent(context, MainActivity::class.java)
            val openPi = PendingIntent.getActivity(context, 0, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.widget_root, openPi)

            // Refresh button
            val refreshIntent = Intent(context, PortfolioWidget::class.java).apply {
                action = ACTION_REFRESH
            }
            val refreshPi = PendingIntent.getBroadcast(context, 1, refreshIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            views.setOnClickPendingIntent(R.id.btn_refresh, refreshPi)

            views.setTextViewText(R.id.tv_widget_value, "Loading...")
            manager.updateAppWidget(widgetId, views)

            // Load data from DB
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = InvestTrackDatabase.getInstance(context)
                    val securities = db.securityDao().getAllSecuritiesList()
                    val secMap = securities.associateBy { it.id }

                    val folioRaws = db.transactionDao().getAllActiveFolios()
                    var totalValue = 0.0
                    var totalInvested = 0.0

                    folioRaws.forEach { raw ->
                        val sec = secMap[raw.securityId] ?: return@forEach
                        val netInvested = db.transactionDao().getNetInvestment(raw.accountId, raw.securityId)
                        val price = if (sec.currentPrice > 0) sec.currentPrice else
                            if (raw.netQty > 0) netInvested / raw.netQty else 0.0
                        totalValue += raw.netQty * price
                        totalInvested += netInvested
                    }

                    val pnl = totalValue - totalInvested
                    val pnlPct = if (totalInvested > 0) pnl / totalInvested * 100 else 0.0

                    val fmt = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

                    withContext(Dispatchers.Main) {
                        val valueText = formatAmount(totalValue)
                        val pnlText = "${if (pnl >= 0) "▲ +" else "▼ "}${formatAmount(kotlin.math.abs(pnl))} (${String.format("%.1f", kotlin.math.abs(pnlPct))}%)"

                        views.setTextViewText(R.id.tv_widget_value, valueText)
                        views.setTextViewText(R.id.tv_widget_pnl, pnlText)
                        views.setTextViewText(R.id.tv_widget_invested, "Invested: ${formatAmount(totalInvested)}")
                        manager.updateAppWidget(widgetId, views)
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        views.setTextViewText(R.id.tv_widget_value, "Tap to open app")
                        manager.updateAppWidget(widgetId, views)
                    }
                }
            }
        }

        private fun formatAmount(amount: Double): String {
            return when {
                kotlin.math.abs(amount) >= 10_000_000 -> "₹${String.format("%.2f", amount / 10_000_000)}Cr"
                kotlin.math.abs(amount) >= 100_000 -> "₹${String.format("%.2f", amount / 100_000)}L"
                else -> "₹${String.format("%,.0f", amount)}"
            }
        }
    }
}
