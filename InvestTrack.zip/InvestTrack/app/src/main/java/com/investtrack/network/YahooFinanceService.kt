package com.investtrack.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YahooFinanceService @Inject constructor() {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            chain.proceed(chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10)")
                .build())
        }.build()

    data class PriceResult(val yahooCode: String, val price: Double, val previousClose: Double, val change: Double, val changePercent: Double)

    fun fetchPrice(yahooCode: String): PriceResult? {
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$yahooCode?interval=1d&range=1d"
            client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                if (!r.isSuccessful) return null
                val body = r.body?.string() ?: return null
                val price = Regex(""""regularMarketPrice"\s*:\s*([\d.]+)""").find(body)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
                val prev = Regex(""""regularMarketPreviousClose"\s*:\s*([\d.]+)""").find(body)?.groupValues?.get(1)?.toDoubleOrNull() ?: price
                PriceResult(yahooCode, price, prev, price - prev, if (prev > 0) (price - prev) / prev * 100 else 0.0)
            }
        } catch (e: Exception) { null }
    }

    fun fetchPrices(codes: List<String>): Map<String, PriceResult> {
        val results = mutableMapOf<String, PriceResult>()
        codes.forEach { code -> fetchPrice(code)?.let { results[code] = it }; Thread.sleep(300) }
        return results
    }
}
