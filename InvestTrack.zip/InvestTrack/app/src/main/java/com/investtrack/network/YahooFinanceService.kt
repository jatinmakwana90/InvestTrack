package com.investtrack.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YahooFinanceService @Inject constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                .header("Accept", "application/json")
                .build()
            chain.proceed(req)
        }
        .build()

    data class PriceResult(
        val yahooCode: String,
        val price: Double,
        val previousClose: Double,
        val change: Double,
        val changePercent: Double,
        val companyName: String = ""
    )

    fun fetchPrice(yahooCode: String): PriceResult? {
        return try {
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$yahooCode?interval=1d&range=1d"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                parsePrice(yahooCode, body)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parsePrice(yahooCode: String, json: String): PriceResult? {
        return try {
            val priceRegex = Regex(""""regularMarketPrice"\s*:\s*([\d.]+)""")
            val prevCloseRegex = Regex(""""regularMarketPreviousClose"\s*:\s*([\d.]+)""")
            val nameRegex = Regex(""""longName"\s*:\s*"([^"]+)"""")
            val price = priceRegex.find(json)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
            val prevClose = prevCloseRegex.find(json)?.groupValues?.get(1)?.toDoubleOrNull() ?: price
            val name = nameRegex.find(json)?.groupValues?.get(1) ?: ""
            val change = price - prevClose
            val changePct = if (prevClose > 0) (change / prevClose) * 100 else 0.0
            PriceResult(yahooCode, price, prevClose, change, changePct, name)
        } catch (e: Exception) {
            null
        }
    }

    fun fetchPrices(yahooCodes: List<String>): Map<String, PriceResult> {
        val results = mutableMapOf<String, PriceResult>()
        yahooCodes.forEach { code ->
            fetchPrice(code)?.let { results[code] = it }
            Thread.sleep(200)
        }
        return results
    }
}
