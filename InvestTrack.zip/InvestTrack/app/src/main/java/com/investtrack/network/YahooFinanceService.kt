package com.investtrack.network

import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YahooFinanceService @Inject constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor { chain ->
            val req = chain.request().newBuilder()
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
                .header("Accept", "application/json")
                .build()
            chain.proceed(req)
        }
        .build()

    data class PriceResult(
        val symbol: String,
        val price: Double,
        val previousClose: Double,
        val change: Double,
        val changePercent: Double
    )

    fun fetchPrice(symbol: String): PriceResult? {
        return try {
            val nseSymbol = if (!symbol.contains(".")) "${symbol}.NS" else symbol
            val url = "https://query1.finance.yahoo.com/v8/finance/chart/$nseSymbol?interval=1d&range=1d"
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val body = response.body?.string() ?: return null
                parsePrice(symbol, body)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parsePrice(symbol: String, json: String): PriceResult? {
        return try {
            // Extract regularMarketPrice
            val priceRegex = Regex(""""regularMarketPrice"\s*:\s*([\d.]+)""")
            val prevCloseRegex = Regex(""""regularMarketPreviousClose"\s*:\s*([\d.]+)""")
            val price = priceRegex.find(json)?.groupValues?.get(1)?.toDoubleOrNull() ?: return null
            val prevClose = prevCloseRegex.find(json)?.groupValues?.get(1)?.toDoubleOrNull() ?: price
            val change = price - prevClose
            val changePct = if (prevClose > 0) (change / prevClose) * 100 else 0.0
            PriceResult(symbol, price, prevClose, change, changePct)
        } catch (e: Exception) {
            null
        }
    }

    fun fetchPrices(symbols: List<String>): Map<String, PriceResult> {
        val results = mutableMapOf<String, PriceResult>()
        symbols.forEach { sym ->
            fetchPrice(sym)?.let { results[sym] = it }
            Thread.sleep(300) // avoid rate limiting
        }
        return results
    }
}
