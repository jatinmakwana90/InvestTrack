package com.investtrack.report

/** A table in the report. Cells are String, Double (numbers stay numeric in Excel) or null. */
data class ReportTable(val title: String, val headers: List<String>, val rows: List<List<Any?>>)

data class ReportData(
    val appName: String,
    val title: String,
    val subtitle: String,
    val summary: List<Pair<String, String>>,
    val tables: List<ReportTable>
)
