package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drive_backup_config")
data class DriveBackupConfig(
    @PrimaryKey
    val id: Int = 1,
    val isEnabled: Boolean = false,
    val hour: Int = 2,           // default 2 AM
    val minute: Int = 0,
    val accountEmail: String = "",
    val driveFolderId: String = "",   // "InvestTrack Backups" folder id, cached after first creation
    val driveFileId: String = "",     // fixed backup file id, cached after first upload so we overwrite it
    val lastBackupAt: Long = 0,
    val lastBackupStatus: String = "" // human-readable status of the last attempt
)
