package com.investtrack.ui.loans

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.google.android.material.button.MaterialButton
import com.investtrack.R
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.models.Loan
import com.investtrack.data.models.Reminder
import com.investtrack.data.models.ReminderType
import com.investtrack.data.models.LoanType
import com.investtrack.databinding.FragmentAddEditLoanBinding
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.workers.ReminderWorker
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class AddEditLoanViewModel @Inject constructor(
    private val loanDao: LoanDao,
    private val reminderDao: ReminderDao,
    @dagger.hilt.android.qualifiers.ApplicationContext private val appContext: android.content.Context,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val loanId: Long = savedStateHandle.get<Long>("loanId") ?: 0L

    private val _loan = MutableStateFlow<Loan?>(null)
    val loan: StateFlow<Loan?> = _loan

    private val _existingReminderEnabled = MutableStateFlow(true)
    val existingReminderEnabled: StateFlow<Boolean> = _existingReminderEnabled

    private val _done = MutableStateFlow(false)
    val done: StateFlow<Boolean> = _done

    init {
        if (loanId != 0L) {
            viewModelScope.launch {
                _loan.value = loanDao.getLoanById(loanId)
                _existingReminderEnabled.value = reminderDao.getReminderForLoan(loanId) != null
            }
        }
    }

    fun save(loan: Loan, emiReminderEnabled: Boolean) {
        viewModelScope.launch {
            val savedId = if (loan.id == 0L) loanDao.insertLoan(loan) else {
                loanDao.updateLoan(loan); loan.id
            }
            syncEmiReminder(loan.copy(id = savedId), emiReminderEnabled)
            _done.value = true
        }
    }

    private suspend fun syncEmiReminder(loan: Loan, enabled: Boolean) {
        val existing = reminderDao.getReminderForLoan(loan.id)
        if (!enabled || !loan.isActive) {
            if (existing != null) {
                ReminderWorker.cancelAll(appContext, existing.id)
                reminderDao.deleteReminderForLoan(loan.id)
            }
            return
        }

        val reminder = (existing ?: Reminder(
            title = "${loan.loanName} EMI",
            type = ReminderType.EMI,
            dueDayOfMonth = loan.emiDay,
            amount = loan.emiAmount,
            linkedLoanId = loan.id
        )).copy(
            title = "${loan.loanName} EMI",
            dueDayOfMonth = loan.emiDay,
            amount = loan.emiAmount,
            description = "Pay EMI for ${loan.loanName} (${loan.lenderName.ifEmpty { loan.loanType.displayName }})"
        )
        val savedReminderId = reminderDao.insertReminder(reminder)
        val finalReminder = if (reminder.id == 0L) reminder.copy(id = savedReminderId) else reminder
        ReminderWorker.scheduleAll(appContext, finalReminder)
    }
}

@AndroidEntryPoint
class AddEditLoanFragment : Fragment() {
    private var _binding: FragmentAddEditLoanBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddEditLoanViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

    private var selectedStartDate = System.currentTimeMillis()
    private var selectedType = LoanType.HOME_LOAN
    private var enterByTenure = true
    private var existingPaidInstallments = ""
    private var existingEmisPaid = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddEditLoanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvScreenTitle.text = if (viewModel.loanId == 0L) "Add Loan" else "Edit Loan"
        binding.btnSave.text = if (viewModel.loanId == 0L) "Add Loan" else "Save Changes"
        binding.btnClose.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        setupLoanTypeDropdown()
        selectType(selectedType)

        binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
        binding.etStartDate.setOnClickListener { showDatePicker() }

        setToggleMode(tenureMode = true)
        binding.btnToggleTenure.setOnClickListener { setToggleMode(tenureMode = true) }
        binding.btnToggleEmi.setOnClickListener { setToggleMode(tenureMode = false) }

        val watcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { updateEmiPreview() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        binding.etPrincipal.addTextChangedListener(watcher)
        binding.etInterestRate.addTextChangedListener(watcher)
        binding.etTenureMonths.addTextChangedListener(watcher)
        binding.etFixedEmi.addTextChangedListener(watcher)

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.done.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.loan.collect { loan ->
                loan ?: return@collect
                selectedType = loan.loanType
                selectedStartDate = loan.startDate
                existingPaidInstallments = loan.paidInstallments
                existingEmisPaid = loan.emisPaid
                selectType(selectedType)
                binding.etLoanName.setText(loan.loanName)
                binding.etLender.setText(loan.lenderName)
                binding.etPrincipal.setText(formatNum(loan.principalAmount))
                binding.etInterestRate.setText(formatNum(loan.interestRate))
                binding.etTenureMonths.setText(loan.totalEmis.toString())
                binding.etFixedEmi.setText(formatNum(loan.emiAmount))
                binding.etNotes.setText(loan.notes)
                binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
            }
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.existingReminderEnabled.collect { binding.switchEmiReminder.isChecked = it }
        }

        binding.btnSave.setOnClickListener { save() }
    }

    private fun setupLoanTypeDropdown() {
        val types = LoanType.values().toList()
        val labels = types.map { "${it.emoji}  ${it.displayName}" }
        val adapter = ArrayAdapter(requireContext(), R.layout.item_loan_type_dropdown, labels)
        binding.etLoanType.setAdapter(adapter)
        binding.etLoanType.setOnClickListener { binding.etLoanType.showDropDown() }
        binding.tilLoanType.setEndIconOnClickListener { binding.etLoanType.showDropDown() }
        binding.etLoanType.setOnItemClickListener { _, _, position, _ ->
            selectType(types[position])
        }
    }

    private fun selectType(type: LoanType) {
        selectedType = type
        binding.etLoanType.setText("${type.emoji}  ${type.displayName}", false)
        if (binding.etLoanName.text.isNullOrBlank()) {
            binding.etLoanName.hint = "e.g. ${type.displayName}"
        }
    }

    private fun setToggleMode(tenureMode: Boolean) {
        enterByTenure = tenureMode
        binding.groupTenure.visibility = if (tenureMode) View.VISIBLE else View.GONE
        binding.groupEmi.visibility = if (tenureMode) View.GONE else View.VISIBLE
        styleToggleButton(binding.btnToggleTenure, tenureMode)
        styleToggleButton(binding.btnToggleEmi, !tenureMode)
        updateEmiPreview()
    }

    private fun styleToggleButton(button: MaterialButton, selected: Boolean) {
        button.background = resources.getDrawable(
            if (selected) R.drawable.bg_loan_toggle_selected else R.drawable.bg_loan_toggle_unselected, null
        )
        button.setTextColor(
            if (selected) android.graphics.Color.WHITE
            else resources.getColor(R.color.loan_text_secondary, null)
        )
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance().apply { timeInMillis = selectedStartDate }
        DatePickerDialog(requireContext(), { _, y, m, d ->
            cal.set(y, m, d)
            selectedStartDate = cal.timeInMillis
            binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
            updateEmiPreview()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateEmiPreview() {
        val principal = binding.etPrincipal.text.toString().toDoubleOrNull()
        val rate = binding.etInterestRate.text.toString().toDoubleOrNull()
        if (principal == null || principal <= 0 || rate == null || rate <= 0) {
            binding.tvEmiCalc.visibility = View.GONE
            return
        }
        val monthlyRate = rate / 12 / 100
        if (enterByTenure) {
            val months = binding.etTenureMonths.text.toString().toIntOrNull()
            if (months == null || months <= 0) { binding.tvEmiCalc.visibility = View.GONE; return }
            val emi = LoanAmortizationCalculator.emiFor(principal, monthlyRate, months)
            binding.tvEmiCalc.text = "Estimated EMI: ${com.investtrack.utils.CurrencyFormatter.formatFullNoDecimals(emi)} / month"
            binding.tvEmiCalc.visibility = View.VISIBLE
        } else {
            val emi = binding.etFixedEmi.text.toString().toDoubleOrNull()
            if (emi == null || emi <= 0) { binding.tvEmiCalc.visibility = View.GONE; return }
            val months = LoanAmortizationCalculator.tenureFor(principal, monthlyRate, emi)
            binding.tvEmiCalc.text = "Estimated tenure: $months months (~${"%.1f".format(months / 12.0)} yrs)"
            binding.tvEmiCalc.visibility = View.VISIBLE
        }
    }

    private fun formatNum(v: Double): String =
        if (v == v.toLong().toDouble()) v.toLong().toString() else "%.2f".format(v)

    private fun save() {
        val name = binding.etLoanName.text.toString().trim().ifEmpty {
            binding.etLoanName.hint?.toString()?.removePrefix("e.g. ") ?: selectedType.displayName
        }
        val principal = binding.etPrincipal.text.toString().toDoubleOrNull()
        if (principal == null || principal <= 0) { binding.tilPrincipal.error = "Enter principal amount"; return }
        val rate = binding.etInterestRate.text.toString().toDoubleOrNull() ?: 0.0
        val monthlyRate = rate / 12 / 100

        val totalEmis: Int
        val emiAmount: Double

        if (enterByTenure) {
            val months = binding.etTenureMonths.text.toString().toIntOrNull()
            if (months == null || months <= 0) {
                binding.tilPrincipal.error = null
                android.widget.Toast.makeText(requireContext(), "Enter a valid tenure in months", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            totalEmis = months
            emiAmount = if (monthlyRate > 0) LoanAmortizationCalculator.emiFor(principal, monthlyRate, months)
                        else principal / months
        } else {
            val emi = binding.etFixedEmi.text.toString().toDoubleOrNull()
            if (emi == null || emi <= 0) {
                binding.tilPrincipal.error = null
                android.widget.Toast.makeText(requireContext(), "Enter a valid EMI amount", android.widget.Toast.LENGTH_SHORT).show()
                return
            }
            emiAmount = emi
            totalEmis = if (monthlyRate > 0) LoanAmortizationCalculator.tenureFor(principal, monthlyRate, emi)
                        else Math.ceil(principal / emi).toInt()
        }

        binding.tilPrincipal.error = null
        binding.btnSave.isEnabled = false
        binding.btnSave.text = "Saving..."

        val cal = Calendar.getInstance().apply { timeInMillis = selectedStartDate; add(Calendar.MONTH, totalEmis) }

        val loan = Loan(
            id = viewModel.loanId,
            loanName = name,
            lenderName = binding.etLender.text.toString().trim(),
            loanType = selectedType,
            principalAmount = principal,
            outstandingAmount = principal,
            interestRate = rate,
            emiAmount = emiAmount,
            emiDay = Calendar.getInstance().apply { timeInMillis = selectedStartDate }.get(Calendar.DAY_OF_MONTH),
            startDate = selectedStartDate,
            endDate = cal.timeInMillis,
            totalEmis = totalEmis,
            emisPaid = existingEmisPaid,
            paidInstallments = existingPaidInstallments,
            notes = binding.etNotes.text.toString().trim()
        )
        viewModel.save(loan, binding.switchEmiReminder.isChecked)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(loanId: Long) = AddEditLoanFragment().apply {
            arguments = Bundle().apply { putLong("loanId", loanId) }
        }
    }
}
