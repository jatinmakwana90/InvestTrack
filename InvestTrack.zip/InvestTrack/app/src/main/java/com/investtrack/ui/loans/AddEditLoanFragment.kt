package com.investtrack.ui.loans

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.*
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.models.Loan
import com.investtrack.data.models.LoanType
import com.investtrack.databinding.FragmentAddEditLoanBinding
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@HiltViewModel
class AddEditLoanViewModel @Inject constructor(
    private val loanDao: LoanDao,
    savedStateHandle: SavedStateHandle
) : ViewModel() {
    val loanId: Long = savedStateHandle.get<Long>("loanId") ?: 0L

    private val _loan = MutableStateFlow<Loan?>(null)
    val loan: StateFlow<Loan?> = _loan

    private val _done = MutableStateFlow(false)
    val done: StateFlow<Boolean> = _done

    init {
        if (loanId != 0L) {
            viewModelScope.launch { _loan.value = loanDao.getLoanById(loanId) }
        }
    }

    fun save(loan: Loan) {
        viewModelScope.launch {
            if (loan.id == 0L) loanDao.insertLoan(loan)
            else loanDao.updateLoan(loan)
            _done.value = true
        }
    }
}

@AndroidEntryPoint
class AddEditLoanFragment : Fragment() {
    private var _binding: FragmentAddEditLoanBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AddEditLoanViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private var selectedStartDate = System.currentTimeMillis()
    private var selectedEndDate = System.currentTimeMillis() + (365L * 24 * 60 * 60 * 1000 * 20) // 20 years default
    private var selectedType = LoanType.HOME_LOAN

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAddEditLoanBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.title = if (viewModel.loanId == 0L) "Add Loan" else "Edit Loan"
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        // Loan type dropdown
        val types = LoanType.values().map { it.displayName }
        binding.actvLoanType.setAdapter(ArrayAdapter(requireContext(), android.R.layout.simple_dropdown_item_1line, types))
        binding.actvLoanType.setText(types[0], false)
        binding.actvLoanType.setOnItemClickListener { _, _, pos, _ ->
            selectedType = LoanType.values()[pos]
        }

        // Date pickers
        binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
        binding.etEndDate.setText(dateFmt.format(Date(selectedEndDate)))

        binding.etStartDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = selectedStartDate }
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d); selectedStartDate = cal.timeInMillis
                binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
                autoCalculateEmis()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding.etEndDate.setOnClickListener {
            val cal = Calendar.getInstance().apply { timeInMillis = selectedEndDate }
            DatePickerDialog(requireContext(), { _, y, m, d ->
                cal.set(y, m, d); selectedEndDate = cal.timeInMillis
                binding.etEndDate.setText(dateFmt.format(Date(selectedEndDate)))
                autoCalculateEmis()
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        // Auto-calculate EMI when fields change
        val watcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { autoCalculateEmi() }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        }
        binding.etPrincipal.addTextChangedListener(watcher)
        binding.etInterestRate.addTextChangedListener(watcher)

        // Done observer
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.done.collect { if (it) activity?.onBackPressedDispatcher?.onBackPressed() }
        }

        // Load existing loan for edit
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.loan.collect { loan ->
                loan ?: return@collect
                selectedType = loan.loanType
                selectedStartDate = loan.startDate
                selectedEndDate = loan.endDate
                binding.etLoanName.setText(loan.loanName)
                binding.etLender.setText(loan.lenderName)
                binding.actvLoanType.setText(loan.loanType.displayName, false)
                binding.etPrincipal.setText(loan.principalAmount.toString())
                binding.etOutstanding.setText(loan.outstandingAmount.toString())
                binding.etInterestRate.setText(loan.interestRate.toString())
                binding.etEmiAmount.setText(loan.emiAmount.toString())
                binding.etEmiDay.setText(loan.emiDay.toString())
                binding.etTotalEmis.setText(loan.totalEmis.toString())
                binding.etEmisPaid.setText(loan.emisPaid.toString())
                binding.etNotes.setText(loan.notes)
                binding.etStartDate.setText(dateFmt.format(Date(selectedStartDate)))
                binding.etEndDate.setText(dateFmt.format(Date(selectedEndDate)))
            }
        }

        binding.btnSave.setOnClickListener { save() }
    }

    private fun autoCalculateEmi() {
        val principal = binding.etPrincipal.text.toString().toDoubleOrNull() ?: return
        val rate = binding.etInterestRate.text.toString().toDoubleOrNull() ?: return
        if (rate <= 0) return
        // Auto-calc total EMIs from dates
        val months = monthsBetween(selectedStartDate, selectedEndDate)
        if (months > 0) {
            val monthlyRate = rate / 12 / 100
            val emi = principal * monthlyRate * Math.pow(1 + monthlyRate, months.toDouble()) /
                (Math.pow(1 + monthlyRate, months.toDouble()) - 1)
            binding.etEmiAmount.setText(String.format("%.2f", emi))
            binding.etTotalEmis.setText(months.toString())
            binding.tvEmiCalc.text = "EMI auto-calculated for $months months"
            binding.tvEmiCalc.visibility = View.VISIBLE
        }
    }

    private fun autoCalculateEmis() {
        val months = monthsBetween(selectedStartDate, selectedEndDate)
        if (months > 0) binding.etTotalEmis.setText(months.toString())
        autoCalculateEmi()
    }

    private fun monthsBetween(start: Long, end: Long): Int {
        val calStart = Calendar.getInstance().apply { timeInMillis = start }
        val calEnd = Calendar.getInstance().apply { timeInMillis = end }
        return (calEnd.get(Calendar.YEAR) - calStart.get(Calendar.YEAR)) * 12 +
               (calEnd.get(Calendar.MONTH) - calStart.get(Calendar.MONTH))
    }

    private fun save() {
        val name = binding.etLoanName.text.toString().trim()
        if (name.isEmpty()) { binding.tilLoanName.error = "Loan name required"; return }
        val principal = binding.etPrincipal.text.toString().toDoubleOrNull()
        if (principal == null || principal <= 0) { binding.tilPrincipal.error = "Enter principal amount"; return }

        binding.btnSave.isEnabled = false
        binding.btnSave.text = "Saving..."

        val loan = Loan(
            id = viewModel.loanId,
            loanName = name,
            lenderName = binding.etLender.text.toString().trim(),
            loanType = selectedType,
            principalAmount = principal,
            outstandingAmount = binding.etOutstanding.text.toString().toDoubleOrNull() ?: principal,
            interestRate = binding.etInterestRate.text.toString().toDoubleOrNull() ?: 0.0,
            emiAmount = binding.etEmiAmount.text.toString().toDoubleOrNull() ?: 0.0,
            emiDay = binding.etEmiDay.text.toString().toIntOrNull() ?: 5,
            startDate = selectedStartDate,
            endDate = selectedEndDate,
            totalEmis = binding.etTotalEmis.text.toString().toIntOrNull() ?: 0,
            emisPaid = binding.etEmisPaid.text.toString().toIntOrNull() ?: 0,
            notes = binding.etNotes.text.toString().trim()
        )
        viewModel.save(loan)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(loanId: Long) = AddEditLoanFragment().apply {
            arguments = Bundle().apply { putLong("loanId", loanId) }
        }
    }
}
