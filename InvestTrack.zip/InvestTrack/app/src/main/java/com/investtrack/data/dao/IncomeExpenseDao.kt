package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.IncomeExpenseEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeExpenseDao {
    @Query("SELECT * FROM income_expense_entries WHERE isActive = 1 ORDER BY sortOrder ASC, id ASC")
    fun getAllEntries(): Flow<List<IncomeExpenseEntry>>

    @Query("SELECT * FROM income_expense_entries WHERE id = :id")
    suspend fun getEntryById(id: Long): IncomeExpenseEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: IncomeExpenseEntry): Long

    @Update
    suspend fun updateEntry(entry: IncomeExpenseEntry)

    // Saves a whole re-ordered list in one transaction.
    @Update
    suspend fun updateEntries(entries: List<IncomeExpenseEntry>)

    @Query("SELECT MAX(sortOrder) FROM income_expense_entries")
    suspend fun getMaxSortOrder(): Int?

    @Query("DELETE FROM income_expense_entries WHERE id = :id")
    suspend fun deleteEntry(id: Long)

    @Query("SELECT * FROM income_expense_entries WHERE isActive = 1 ORDER BY sortOrder ASC, id ASC")
    suspend fun getAllEntriesList(): List<IncomeExpenseEntry>

    // Includes inactive (soft-deleted) entries too — used for full data backups so nothing is lost.
    @Query("SELECT * FROM income_expense_entries ORDER BY sortOrder ASC, id ASC")
    suspend fun getAllEntriesIncludingInactiveList(): List<IncomeExpenseEntry>

    @Query("""
        SELECT * FROM income_expense_entries
        WHERE isActive = 1 AND date >= :rangeStart AND date <= :rangeEnd
        ORDER BY sortOrder ASC, id ASC
    """)
    suspend fun getEntriesInRange(rangeStart: Long, rangeEnd: Long): List<IncomeExpenseEntry>
}
