package com.investtrack.ui.goals

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.data.dao.GoalDao
import com.investtrack.data.models.Goal
import com.investtrack.databinding.FragmentGoalsBinding
import com.investtrack.databinding.ItemGoalBinding
import com.investtrack.ui.MainActivity
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@HiltViewModel
class GoalsViewModel @Inject constructor(
    private val goalDao: GoalDao
) : ViewModel() {
    val goals: StateFlow<List<Goal>> = goalDao.getAllGoals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalSaved: StateFlow<Double> = goals.map { list -> list.sumOf { it.currentAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalTarget: StateFlow<Double> = goals.map { list -> list.sumOf { it.targetAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun delete(id: Long) = viewModelScope.launch { goalDao.deleteGoal(id) }
}

@AndroidEntryPoint
class GoalsFragment : Fragment() {
    private var _binding: FragmentGoalsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: GoalsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGoalsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        val adapter = GoalAdapter(
            onEdit = { goal -> (activity as? MainActivity)?.navigateTo(AddEditGoalFragment.newInstance(goal.id)) },
            onDelete = { goal ->
                android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Delete Goal")
                    .setMessage("Remove \"${goal.name}\"?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(goal.id) }
                    .setNegativeButton("Cancel", null).show()
            }
        )

        binding.rvGoals.apply {
            layoutManager = LinearLayoutManager(requireContext())
            this.adapter = adapter
        }

        binding.fabAddGoal.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddEditGoalFragment.newInstance(0L))
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.goals.collect { list ->
                adapter.submitList(list)
                binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalSaved.collect { binding.tvTotalSaved.text = CurrencyFormatter.format(it) }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.totalTarget.collect { binding.tvTotalTarget.text = CurrencyFormatter.format(it) }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}

class GoalAdapter(
    private val onEdit: (Goal) -> Unit,
    private val onDelete: (Goal) -> Unit
) : ListAdapter<Goal, GoalAdapter.VH>(DIFF) {

    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    inner class VH(private val b: ItemGoalBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(goal: Goal) {
            val color = runCatching { android.graphics.Color.parseColor(goal.color) }
                .getOrDefault(android.graphics.Color.parseColor("#10b981"))

            b.tvGoalIcon.text = goal.icon
            val iconBg = (b.tvGoalIcon.background?.mutate() as? android.graphics.drawable.GradientDrawable)
            iconBg?.setStroke(4, color)
            iconBg?.setColor(android.graphics.Color.argb(34, android.graphics.Color.red(color), android.graphics.Color.green(color), android.graphics.Color.blue(color)))
            b.tvGoalIcon.background = iconBg

            b.tvGoalName.text = goal.name
            b.tvGoalDeadline.text = goal.deadline?.let { "By ${dateFmt.format(Date(it))}" } ?: ""

            val pct = if (goal.targetAmount > 0)
                ((goal.currentAmount / goal.targetAmount) * 100).toInt().coerceIn(0, 100) else 0
            val remaining = (goal.targetAmount - goal.currentAmount).coerceAtLeast(0.0)

            b.tvGoalCurrent.text = "Saved ${CurrencyFormatter.format(goal.currentAmount)}"
            b.tvGoalTarget.text = "Goal ${CurrencyFormatter.format(goal.targetAmount)}"
            b.progressGoal.progress = pct
            b.progressGoal.progressTintList = android.content.res.ColorStateList.valueOf(color)
            b.tvGoalPct.text = "$pct% complete"
            b.tvGoalPct.setTextColor(color)
            b.tvGoalRemaining.text = "${CurrencyFormatter.format(remaining)} to go"

            b.btnEdit.setOnClickListener { onEdit(goal) }
            b.btnDelete.setOnClickListener { onDelete(goal) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemGoalBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Goal>() {
            override fun areItemsTheSame(a: Goal, b: Goal) = a.id == b.id
            override fun areContentsTheSame(a: Goal, b: Goal) = a == b
        }
    }
}
