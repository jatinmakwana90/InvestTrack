package com.investtrack.ui.goals

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewModelScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.investtrack.R
import com.investtrack.data.dao.GoalDao
import com.investtrack.data.models.Account
import com.investtrack.data.models.Goal
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentGoalsBinding
import com.investtrack.databinding.ItemGoalBinding
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.GoalCalculator
import com.investtrack.utils.GoalProgress
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

data class GoalItem(val goal: Goal, val progress: GoalProgress, val accountLabel: String)

@HiltViewModel
class GoalsViewModel @Inject constructor(
    private val goalDao: GoalDao,
    private val repository: InvestmentRepository
) : ViewModel() {

    private val tick = MutableStateFlow(0)

    val items: StateFlow<List<GoalItem>> = combine(goalDao.getAllGoals(), tick) { goals, _ -> goals }
        .map { goals ->
            val accounts = repository.getAllAccountsList().associateBy { it.id }
            goals.map { g ->
                val ids = g.accountIdSet()
                val value = if (ids.isEmpty()) repository.getPortfolioSummary().currentValue
                else ids.sumOf { id -> try { repository.getAccountPortfolioSummary(id).currentValue } catch (e: Exception) { 0.0 } }
                val label = if (ids.isEmpty()) "Whole portfolio" else ids.mapNotNull { accounts[it]?.name }.joinToString(", ")
                GoalItem(g, GoalCalculator.evaluate(g, value), label.ifBlank { "Selected accounts" })
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun refresh() { tick.value = tick.value + 1 }
    suspend fun accounts(): List<Account> = repository.getAllAccountsList()
    fun save(goal: Goal) { viewModelScope.launch { goalDao.insertGoal(goal) } }
    fun delete(id: Long) { viewModelScope.launch { goalDao.deleteGoal(id) } }
}

@AndroidEntryPoint
class GoalsFragment : Fragment() {

    private var _binding: FragmentGoalsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: GoalsViewModel by viewModels()
    private lateinit var adapter: GoalAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentGoalsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = GoalAdapter(
            onEdit = { showGoalDialog(it.goal) },
            onDelete = { item ->
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Delete goal?")
                    .setMessage("\"${item.goal.name}\" will be removed.")
                    .setPositiveButton("Delete") { _, _ -> viewModel.delete(item.goal.id) }
                    .setNegativeButton("Cancel", null).show()
            }
        )
        binding.rvGoals.layoutManager = LinearLayoutManager(requireContext())
        binding.rvGoals.adapter = adapter
        binding.fabAddGoal.setOnClickListener { showGoalDialog(null) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.items.collect { list ->
                    adapter.submitList(list)
                    binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refresh() // portfolio values may have changed since this screen was last shown
    }

    private fun showGoalDialog(existing: Goal?) {
        val ctx = requireContext()
        val v = LayoutInflater.from(ctx).inflate(R.layout.dialog_add_goal, null)
        val etName = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_name)
        val etTarget = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_target)
        val etDate = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_date)
        val etAccounts = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_accounts)
        val etAlloc = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_alloc)
        val etReturn = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_return)
        val etNotes = v.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_goal_notes)

        val dateFmt = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        var targetDate = existing?.targetDate ?: Calendar.getInstance().apply { add(Calendar.YEAR, 5) }.timeInMillis
        var selectedIds: Set<Long> = existing?.accountIdSet() ?: emptySet()
        var allAccounts: List<Account> = emptyList()

        etName.setText(existing?.name.orEmpty())
        if (existing != null) etTarget.setText(formatPlain(existing.targetAmount))
        etDate.setText(dateFmt.format(Date(targetDate)))
        etAlloc.setText((existing?.allocationPercent ?: 100).toString())
        etReturn.setText(formatPlain(existing?.expectedReturn ?: 10.0))
        etNotes.setText(existing?.notes.orEmpty())

        fun refreshAccountsLabel() {
            etAccounts.setText(
                if (selectedIds.isEmpty()) "Whole portfolio"
                else allAccounts.filter { it.id in selectedIds }.joinToString(", ") { it.name }.ifBlank { "Selected accounts" }
            )
        }
        viewLifecycleOwner.lifecycleScope.launch {
            allAccounts = viewModel.accounts()
            refreshAccountsLabel()
        }

        etDate.setOnClickListener {
            val c = Calendar.getInstance().apply { timeInMillis = targetDate }
            android.app.DatePickerDialog(ctx, R.style.InvestTrackPickerDialog, { _, y, m, d ->
                targetDate = Calendar.getInstance().apply { set(y, m, d, 12, 0, 0) }.timeInMillis
                etDate.setText(dateFmt.format(Date(targetDate)))
            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
        }
        etAccounts.setOnClickListener {
            if (allAccounts.isEmpty()) return@setOnClickListener
            val names = allAccounts.map { it.name }.toTypedArray()
            val checked = BooleanArray(names.size) { allAccounts[it].id in selectedIds }
            MaterialAlertDialogBuilder(ctx)
                .setTitle("Accounts for this goal")
                .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
                .setPositiveButton("OK") { _, _ ->
                    selectedIds = allAccounts.filterIndexed { i, _ -> checked[i] }.map { it.id }.toSet()
                    refreshAccountsLabel()
                }
                .setNeutralButton("Whole portfolio") { _, _ -> selectedIds = emptySet(); refreshAccountsLabel() }
                .setNegativeButton("Cancel", null).show()
        }

        MaterialAlertDialogBuilder(ctx)
            .setTitle(if (existing == null) "Add Goal" else "Edit Goal")
            .setView(v)
            .setPositiveButton("Save") { _, _ ->
                val name = etName.text?.toString().orEmpty().trim()
                val target = etTarget.text?.toString()?.replace(",", "")?.toDoubleOrNull() ?: 0.0
                if (name.isEmpty() || target <= 0) {
                    android.widget.Toast.makeText(ctx, "Enter a goal name and a target amount", android.widget.Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                viewModel.save(
                    Goal(
                        id = existing?.id ?: 0,
                        name = name,
                        targetAmount = target,
                        targetDate = targetDate,
                        accountIds = selectedIds.joinToString(","),
                        allocationPercent = (etAlloc.text?.toString()?.toIntOrNull() ?: 100).coerceIn(1, 100),
                        expectedReturn = (etReturn.text?.toString()?.toDoubleOrNull() ?: 10.0).coerceIn(0.0, 50.0),
                        notes = etNotes.text?.toString().orEmpty().trim(),
                        createdAt = existing?.createdAt ?: System.currentTimeMillis()
                    )
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun formatPlain(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else v.toString()

    override fun onDestroyView() { _binding = null; super.onDestroyView() }
}

class GoalAdapter(
    private val onEdit: (GoalItem) -> Unit,
    private val onDelete: (GoalItem) -> Unit
) : ListAdapter<GoalItem, GoalAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemGoalBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: GoalItem) {
            val ctx = b.root.context
            val g = item.goal; val p = item.progress
            b.tvGoalName.text = g.name
            b.tvGoalTarget.text = "Target ${CurrencyFormatter.format(g.targetAmount)} by " +
                SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(g.targetDate)) +
                " · " + GoalCalculator.timeLeftLabel(p.monthsLeft)
            b.tvGoalAccounts.text = "${item.accountLabel} · ${g.allocationPercent}% earmarked"
            b.progressGoal.setProgressCompat(p.progressPercent.coerceIn(0.0, 100.0).toInt(), true)
            b.tvGoalProgress.text = "${CurrencyFormatter.format(p.current)} of ${CurrencyFormatter.format(g.targetAmount)} · ${String.format(Locale.getDefault(), "%.1f", p.progressPercent)}%"
            if (p.onTrack) {
                b.tvGoalStatus.text = "On track — grows to about ${CurrencyFormatter.format(p.projected)} at ${formatRate(g.expectedReturn)}% a year"
                b.tvGoalStatus.setTextColor(ctx.getColor(R.color.gain_green))
            } else {
                b.tvGoalStatus.text = "Invest about ${CurrencyFormatter.format(p.requiredMonthly)} more every month to reach it (at ${formatRate(g.expectedReturn)}% a year)"
                b.tvGoalStatus.setTextColor(ctx.getColor(R.color.text_accent))
            }
            b.btnGoalEdit.setOnClickListener { onEdit(item) }
            b.btnGoalDelete.setOnClickListener { onDelete(item) }
            b.root.setOnClickListener { onEdit(item) }
        }
        private fun formatRate(v: Double) = if (v == v.toLong().toDouble()) v.toLong().toString() else String.format(Locale.getDefault(), "%.1f", v)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemGoalBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<GoalItem>() {
            override fun areItemsTheSame(a: GoalItem, b: GoalItem) = a.goal.id == b.goal.id
            override fun areContentsTheSame(a: GoalItem, b: GoalItem) = a == b
        }
    }
}
