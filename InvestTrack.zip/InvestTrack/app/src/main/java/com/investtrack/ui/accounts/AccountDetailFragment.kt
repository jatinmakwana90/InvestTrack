package com.investtrack.ui.accounts

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.investtrack.R
import com.investtrack.databinding.FragmentAccountDetailBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AccountDetailFragment : Fragment() {

    private var _binding: FragmentAccountDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AccountDetailViewModel by viewModels()
    private lateinit var folioAdapter: FolioAdapter
    private lateinit var transactionAdapter: TransactionAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAccountDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupAdapters()
        setupTabs()
        observeState()

        binding.fabAddTransaction.setOnClickListener {
            val bundle = Bundle().apply { putLong("accountId", viewModel.accountId) }
            findNavController().navigate(R.id.action_accountDetail_to_addTransaction, bundle)
        }
        binding.toolbar.setNavigationOnClickListener { findNavController().navigateUp() }

        // Edit button in toolbar
        binding.toolbar.inflateMenu(R.menu.menu_account_detail)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_edit_account) {
                val bundle = Bundle().apply { putLong("accountId", viewModel.accountId) }
                findNavController().navigate(R.id.action_accountDetail_to_editAccount, bundle)
                true
            } else false
        }
    }

    private fun setupAdapters() {
        folioAdapter = FolioAdapter { folio ->
            val bundle = Bundle().apply {
                putLong("accountId", folio.accountId)
                putLong("securityId", folio.securityId)
            }
            findNavController().navigate(R.id.action_accountDetail_to_folioDetail, bundle)
        }
        transactionAdapter = TransactionAdapter()
        binding.rvContent.apply {
            layoutManager = LinearLayoutManager(requireContext())
            isNestedScrollingEnabled = false
        }
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                binding.rvContent.adapter = if (tab.position == 0) folioAdapter else transactionAdapter
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
        binding.rvContent.adapter = folioAdapter
    }

    private fun observeState() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                state.account?.let { binding.toolbar.title = it.name }
                state.summary?.let { summary ->
                    binding.tvCurrentValue.text = CurrencyFormatter.format(summary.currentValue)
                    binding.tvInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested)}"
                    val pnl = summary.totalPnL
                    binding.tvPnl.text = "${if (pnl >= 0) "+" else ""}${CurrencyFormatter.format(pnl)} (${String.format("%.2f", summary.totalPnLPercent)}%)"
                    binding.tvPnl.setTextColor(
                        requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red)
                    )
                }
                folioAdapter.submitList(state.folios)
                transactionAdapter.submitList(state.transactions)
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
