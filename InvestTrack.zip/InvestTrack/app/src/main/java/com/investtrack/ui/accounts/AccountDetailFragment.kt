package com.investtrack.ui.accounts

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.investtrack.R
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import com.investtrack.databinding.FragmentAccountDetailBinding
import com.investtrack.ui.MainActivity
import com.investtrack.ui.transactions.AddTransactionFragment
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AccountDetailFragment : Fragment() {

    private var _binding: FragmentAccountDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AccountDetailViewModel by viewModels()
    private lateinit var folioAdapter: FolioAdapter
    @Inject lateinit var settingsManager: SettingsManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentAccountDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        folioAdapter = FolioAdapter(amountMode = settingsManager.amountMode.value) { folio ->
            // Click on security → go to FolioListFragment (folio-wise breakdown)
            val fragment = FolioListFragment.newInstance(folio.accountId, folio.securityId, folio.securityName)
            (activity as? MainActivity)?.navigateTo(fragment)
        }

        binding.rvContent.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = folioAdapter
            isNestedScrollingEnabled = false
        }

        // Hide tab layout - no longer needed
        binding.tabLayout.visibility = View.GONE

        binding.fabAddTransaction.setOnClickListener {
            (activity as? MainActivity)?.navigateTo(AddTransactionFragment.newInstance(viewModel.accountId))
        }

        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }
        binding.toolbar.inflateMenu(R.menu.menu_account_detail)
        binding.toolbar.setOnMenuItemClickListener { item ->
            if (item.itemId == R.id.action_edit_account) {
                (activity as? MainActivity)?.navigateTo(EditAccountFragment.newInstance(viewModel.accountId))
                true
            } else false
        }

        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.amountMode.collect { mode ->
                folioAdapter.updateAmountMode(mode)
                renderSummary()
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            settingsManager.returnMode.collect { renderSummary() }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                state.account?.let { binding.toolbar.title = it.name }
                folioAdapter.submitList(state.folios)
                renderSummary()
            }
        }
    }

    private fun renderSummary() {
        val state = viewModel.uiState.value
        val summary = state.summary ?: return
        val amountMode = settingsManager.amountMode.value
        binding.tvCurrentValue.text = CurrencyFormatter.format(summary.currentValue, amountMode)
        binding.tvInvested.text = "Invested: ${CurrencyFormatter.format(summary.totalInvested, amountMode)}"
        if (settingsManager.returnMode.value == ReturnDisplayMode.ABS) {
            val pnl = summary.totalPnL
            val sign = if (pnl >= 0) "+" else ""
            binding.tvPnl.text = "$sign${CurrencyFormatter.format(pnl, amountMode)} ($sign${String.format("%.2f", summary.totalPnLPercent)}%)"
            binding.tvPnl.setTextColor(requireContext().getColor(if (pnl >= 0) R.color.gain_green else R.color.loss_red))
        } else {
            val xirr = state.xirrPercent
            if (xirr != null) {
                binding.tvPnl.text = "XIRR: ${if (xirr >= 0) "+" else ""}${String.format("%.2f", xirr)}% p.a."
                binding.tvPnl.setTextColor(requireContext().getColor(if (xirr >= 0) R.color.gain_green else R.color.loss_red))
            } else {
                binding.tvPnl.text = "XIRR: N/A"
                binding.tvPnl.setTextColor(requireContext().getColor(R.color.text_secondary))
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }

    companion object {
        fun newInstance(accountId: Long) = AccountDetailFragment().apply {
            arguments = Bundle().apply { putLong("accountId", accountId) }
        }
    }
}
