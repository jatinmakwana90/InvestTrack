package com.investtrack.utils

import com.investtrack.data.settings.AmountDisplayMode
import java.text.NumberFormat
import java.util.Locale

object CurrencyFormatter {
    private val inrFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

    /** Rounded/short form: ₹1.25Cr, ₹4.50L, ₹12,345.00 */
    fun formatRounded(amount: Double): String {
        return when {
            kotlin.math.abs(amount) >= 10_000_000 -> "₹${String.format("%.2f", amount / 10_000_000)}Cr"
            kotlin.math.abs(amount) >= 100_000 -> "₹${String.format("%.2f", amount / 100_000)}L"
            else -> "₹${String.format("%,.2f", amount)}"
        }
    }

    /** Full/absolute form: ₹1,23,45,678.00 */
    fun formatFull(amount: Double): String {
        return "₹${String.format("%,.2f", amount)}"
    }

    /** Default - kept for backward compatibility, uses rounded form */
    fun format(amount: Double): String = formatRounded(amount)

    /** Format according to the user's chosen display mode */
    fun format(amount: Double, mode: AmountDisplayMode): String {
        return when (mode) {
            AmountDisplayMode.ROUNDED -> formatRounded(amount)
            AmountDisplayMode.FULL -> formatFull(amount)
        }
    }
}
