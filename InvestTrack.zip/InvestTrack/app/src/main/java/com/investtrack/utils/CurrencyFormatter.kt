package com.investtrack.utils

import com.investtrack.data.settings.AmountDisplayMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

object CurrencyFormatter {
    private val indiaLocale = Locale("en", "IN")

    // Indian digit grouping (lakh/crore): last 3 digits, then groups of 2.
    // e.g. 2938546 -> 29,38,546. DecimalFormat with #,##,##0 pattern handles this
    // correctly and reliably across Android versions (unlike relying on the JVM's
    // default Locale for %,.2f, which groups in thousands like 2,938,546).
    private fun indianDecimalFormat(fractionDigits: Int): DecimalFormat {
        val symbols = DecimalFormatSymbols(indiaLocale)
        val pattern = if (fractionDigits > 0) "#,##,##0.${"0".repeat(fractionDigits)}" else "#,##,##0"
        return DecimalFormat(pattern, symbols)
    }

    /** Rounded/short form: ₹1.25Cr, ₹4.50L, ₹12,345.00 */
    fun formatRounded(amount: Double): String {
        return when {
            kotlin.math.abs(amount) >= 10_000_000 -> "₹${String.format(indiaLocale, "%.2f", amount / 10_000_000)}Cr"
            kotlin.math.abs(amount) >= 100_000 -> "₹${String.format(indiaLocale, "%.2f", amount / 100_000)}L"
            else -> "₹${indianDecimalFormat(2).format(amount)}"
        }
    }

    /** Full/absolute form: ₹1,23,45,678.00 (Indian lakh/crore grouping) */
    fun formatFull(amount: Double): String {
        return "₹${indianDecimalFormat(2).format(amount)}"
    }

    /** Full form with no decimals: ₹1,23,45,678 */
    fun formatFullNoDecimals(amount: Double): String {
        return "₹${indianDecimalFormat(0).format(Math.round(amount))}"
    }

    /** Default - kept for backward compatibility, uses rounded form */
    fun format(amount: Double): String = formatRounded(amount)

    /** Format according to the user's chosen display mode */
    fun format(amount: Double, mode: AmountDisplayMode): String {
        return when (mode) {
            AmountDisplayMode.ROUNDED -> formatRounded(amount)
            AmountDisplayMode.FULL -> formatFull(amount)
        }
    }
}
