package com.investtrack.ui.tools

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.investtrack.R
import com.investtrack.data.dao.ActivityLogDao
import com.investtrack.data.models.ActivityLog
import com.investtrack.utils.DateUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject

/** What was added, edited or deleted, and when (latest 500 changes). */
@AndroidEntryPoint
class ActivityLogFragment : ToolListFragment() {

    @Inject lateinit var logDao: ActivityLogDao

    override val screenTitle = "Activity Log"
    override val emptyText = "No changes recorded yet.\nEvery add, edit and delete will show up here."
    override val canAdd = false

    private val timeFmt = SimpleDateFormat("h:mm a", Locale.getDefault())

    override fun observe() {
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                logDao.recent().collect { render(it) }
            }
        }
    }

    private fun dayLabel(ts: Long): String {
        val days = DateUtil.daysUntil(ts)
        return when (days) {
            0 -> "Today"
            -1 -> "Yesterday"
            else -> DateUtil.format(ts)
        }
    }

    private fun render(list: List<ActivityLog>) {
        val rows = mutableListOf<ToolRow>()
        var lastDay = ""
        list.forEach { e ->
            val day = dayLabel(e.timestamp)
            if (day != lastDay) { rows += ToolRow("h:$day", day, isHeader = true); lastDay = day }
            val (label, color) = when (e.action) {
                "ADDED" -> "Added" to R.color.gain_green
                "DELETED" -> "Deleted" to R.color.loss_red
                else -> "Edited" to R.color.text_accent
            }
            rows += ToolRow(
                key = "log:${e.id}",
                title = e.description,
                subtitle = "${e.entity} · ${timeFmt.format(Date(e.timestamp))}",
                status = label, statusColor = color
            )
        }
        if (list.isNotEmpty()) {
            rows += ToolRow("clear", "", actions = listOf("clear" to "Clear the log"))
        }
        submit(rows, if (list.isEmpty()) "" else "Latest ${list.size} changes")
    }

    override fun onAdd() {}
    override fun onRowClick(row: ToolRow) {}

    override fun onRowAction(row: ToolRow, action: String) {
        if (action != "clear") return
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Clear the activity log?")
            .setMessage("This only removes the list of changes. Your data is not affected.")
            .setPositiveButton("Clear") { _, _ -> viewLifecycleOwner.lifecycleScope.launch { logDao.clear() } }
            .setNegativeButton("Cancel", null).show()
    }
}
