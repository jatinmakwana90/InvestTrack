package com.investtrack.utils

object CodeGenerator {

    fun generateAccountCode(existingCount: Int): String {
        return "AC${String.format("%04d", existingCount + 1)}"
    }

    fun generateSecurityCode(prefix: String, existingCount: Int): String {
        // prefix based on type e.g. EQ, MF, FD, BD, ET, GD, PP, NP, CR
        return "${prefix}${String.format("%04d", existingCount + 1)}"
    }

    fun generateTransactionCode(existingCount: Int): String {
        return "TRN${String.format("%05d", existingCount + 1)}"
    }

    fun securityTypePrefix(typeName: String): String {
        return when (typeName) {
            "EQUITY" -> "EQ"
            "EQUITY_MF" -> "EM"
            "DEBT_MF" -> "DM"
            "GOLD" -> "GD"
            "FIXED_DEPOSIT" -> "FD"
            "BOND" -> "BD"
            "ETF" -> "ET"
            "PPF" -> "PP"
            "NPS" -> "NP"
            "CRYPTO" -> "CR"
            else -> "SC"
        }
    }
}
