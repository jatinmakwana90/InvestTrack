package com.investtrack.report

import android.content.Context
import com.investtrack.data.dao.*
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.data.settings.SettingsManager
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.GoalCalculator
import com.investtrack.utils.LoanAmortizationCalculator
import com.investtrack.utils.XIRRCalculator
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ReportGenerator @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: InvestmentRepository,
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val incomeExpenseDao: IncomeExpenseDao,
    private val goalDao: GoalDao,
    private val settingsManager: SettingsManager
) {
    private val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    private fun money(v: Double) = CurrencyFormatter.formatFullNoDecimals(v)
    private fun pct(v: Double) = (if (v >= 0) "+" else "") + String.format(Locale.US, "%.2f", v) + "%"

    /**
     * @param fullTransactions true = every transaction (Excel), false = only the last 31 days (PDF).
     */
    suspend fun build(fullTransactions: Boolean): ReportData = withContext(Dispatchers.IO) {
        val appName = settingsManager.appName.value
        val summary = repository.getPortfolioSummary()
        val allTxns = transactionDao.getAllTransactionsList()
        val xirr = try { XIRRCalculator.calculate(XIRRCalculator.buildCashFlows(allTxns, summary.currentValue)) } catch (e: Exception) { null }

        // Accounts
        val accounts = accountDao.getAllAccountsList()
        val accountRows = accounts.map { a ->
            val s = repository.getAccountPortfolioSummary(a.id)
            listOf<Any?>(a.name, a.type.name.replace("_", " "), s.totalInvested, s.currentValue, s.totalPnL, s.totalPnLPercent)
        }

        // Loans
        var loanOutstanding = 0.0
        var loanEmi = 0.0
        val loanRows = loanDao.getAllLoansList().filter { it.isActive }.mapNotNull { loan ->
            val sch = LoanAmortizationCalculator.buildSchedule(loan, loanAdjustmentDao.getAdjustmentsForLoanList(loan.id))
            if (sch.currentOutstanding <= 0.5 || sch.remainingInstallments <= 0) return@mapNotNull null
            loanOutstanding += sch.currentOutstanding
            loanEmi += sch.currentEmi
            listOf<Any?>(
                loan.loanName, loan.lenderName, loan.interestRate, sch.currentOutstanding, sch.currentEmi,
                sch.remainingInstallments.toDouble(), sch.nextEmiDate?.let { dateFmt.format(Date(it)) } ?: ""
            )
        }

        // Goals
        val goalRows = goalDao.getAllGoalsList().map { g ->
            val ids = g.accountIdSet()
            val value = if (ids.isEmpty()) summary.currentValue
            else ids.sumOf { id -> try { repository.getAccountPortfolioSummary(id).currentValue } catch (e: Exception) { 0.0 } }
            val p = GoalCalculator.evaluate(g, value)
            listOf<Any?>(
                g.name, g.targetAmount, dateFmt.format(Date(g.targetDate)), p.current, p.progressPercent,
                if (p.onTrack) "On track" else "Needs ${money(p.requiredMonthly)}/month"
            )
        }

        // Last 12 months inflow / outflow / net flow (same rules as the Reports tab)
        val monthFmt = SimpleDateFormat("MMM yyyy", Locale.getDefault())
        val flowRows = mutableListOf<List<Any?>>()
        var totalIn = 0.0
        var totalOut = 0.0
        for (back in 11 downTo 0) {
            val start = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.MONTH, -back)
            }
            val end = (start.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
            val inRange = allTxns.filter { it.transactionDate >= start.timeInMillis && it.transactionDate < end.timeInMillis }
            val inflow = inRange.filter { it.type == TransactionType.BUY }.sumOf { it.amount }
            val outflow = inRange.filter { it.type != TransactionType.BUY }.sumOf { it.amount }
            totalIn += inflow; totalOut += outflow
            flowRows += listOf<Any?>(monthFmt.format(start.time), inflow, outflow, inflow - outflow)
        }
        flowRows += listOf<Any?>("Total", totalIn, totalOut, totalIn - totalOut)

        // Transactions
        val securities = securityDao.getAllSecuritiesIncludingInactiveList().associateBy { it.id }
        val accountNames = accountDao.getAllAccountsIncludingInactiveList().associate { it.id to it.name }
        val txnRows = allTxns
            .sortedByDescending { it.transactionDate }
            .let { if (fullTransactions) it else it.take(30) }
            .map { t ->
                listOf<Any?>(
                    dateFmt.format(Date(t.transactionDate)), accountNames[t.accountId] ?: "",
                    securities[t.securityId]?.name ?: "", t.type.displayName,
                    t.units ?: t.quantity, t.nav ?: t.price, t.amount
                )
            }

        val tables = mutableListOf<ReportTable>()
        tables += ReportTable("Accounts", listOf("Account", "Type", "Invested", "Current Value", "Gain/Loss", "Return %"), accountRows)
        if (loanRows.isNotEmpty())
            tables += ReportTable("Loans", listOf("Loan", "Lender", "Rate %", "Outstanding", "EMI", "EMIs Left", "Next EMI"), loanRows)
        if (goalRows.isNotEmpty())
            tables += ReportTable("Goals", listOf("Goal", "Target", "By", "Saved So Far", "Progress %", "Status"), goalRows)
        tables += ReportTable(
            "Last 12 Months Cash Flow",
            listOf("Month", "Inflow (Invested)", "Outflow (Withdrawn)", "Net Flow"), flowRows
        )
        tables += ReportTable(
            if (fullTransactions) "Transactions" else "Last 30 Transactions",
            listOf("Date", "Account", "Security", "Type", "Units", "Price/NAV", "Amount"), txnRows
        )

        ReportData(
            appName = appName,
            title = "Portfolio Report",
            subtitle = "Generated on " + SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date()),
            summary = listOf(
                "Total portfolio value" to money(summary.currentValue),
                "Total invested" to money(summary.totalInvested),
                "Gain / Loss" to "${money(summary.totalPnL)} (${pct(summary.totalPnLPercent)})",
                "XIRR" to (xirr?.let { pct(it) + " p.a." } ?: "—"),
                "Loan outstanding" to money(loanOutstanding),
                "Monthly EMI" to money(loanEmi)
            ),
            tables = tables
        )
    }

    private fun reportsDir(): File = File(context.filesDir, "reports").apply { mkdirs() }

    suspend fun createPdf(): File = withContext(Dispatchers.IO) {
        val data = build(fullTransactions = false)
        val name = "Portfolio_Report_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".pdf"
        File(reportsDir(), name).also { PdfReportWriter.write(data, it) }
    }

    suspend fun createExcel(): File = withContext(Dispatchers.IO) {
        val data = build(fullTransactions = true)
        val name = "Portfolio_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".xlsx"
        File(reportsDir(), name).also { XlsxWriter.write(data, it) }
    }
}
