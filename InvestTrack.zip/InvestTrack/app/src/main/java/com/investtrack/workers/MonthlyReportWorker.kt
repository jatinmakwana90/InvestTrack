package com.investtrack.workers

import android.app.PendingIntent
import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.WorkerParameters
import com.investtrack.data.settings.AutomationSettings
import com.investtrack.report.ReportGenerator
import com.investtrack.utils.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.io.File

/** Creates the monthly PDF report and posts a notification; tapping it opens the share sheet. */
@HiltWorker
class MonthlyReportWorker @AssistedInject constructor(
    @Assisted private val appContext: Context,
    @Assisted params: WorkerParameters,
    private val reportGenerator: ReportGenerator,
    private val automation: AutomationSettings
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        if (!automation.monthlyEnabled) return Result.success()
        try {
            NotificationHelper.createChannels(appContext)
            val file = reportGenerator.createPdf()
            val pi = PendingIntent.getActivity(
                appContext, 7102, shareIntent(appContext, file, "application/pdf"),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            NotificationHelper.showActionNotification(
                appContext, 7102, "Monthly portfolio report ready",
                "Your PDF report is ready. Tap to share it.", pi
            )
        } catch (e: Exception) {
            // fall through and still schedule next month
        }
        AutomationScheduler.scheduleMonthly(appContext, automation, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return Result.success()
    }

    companion object {
        fun shareIntent(context: Context, file: File, mime: String): Intent {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newRawUri("", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            return Intent.createChooser(send, "Share report").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }
}
