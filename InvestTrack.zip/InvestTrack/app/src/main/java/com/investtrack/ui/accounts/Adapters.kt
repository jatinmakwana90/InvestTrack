package com.investtrack.ui.accounts

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.models.Folio
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.databinding.ItemFolioBinding
import com.investtrack.databinding.ItemTransactionBinding
import com.investtrack.utils.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

class FolioAdapter(
    private var amountMode: AmountDisplayMode = AmountDisplayMode.ROUNDED,
    private val onClick: (Folio) -> Unit
) : ListAdapter<Folio, FolioAdapter.VH>(DIFF) {

    fun updateAmountMode(mode: AmountDisplayMode) {
        amountMode = mode
        notifyDataSetChanged()
    }

    inner class VH(private val b: ItemFolioBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(f: Folio) {
            b.tvSecurityName.text = f.securityName
            b.tvSymbol.text = f.securitySymbol.ifEmpty { f.securityType.displayName }
            b.tvSecurityType.text = f.securityType.displayName
            b.tvCurrentValue.text = CurrencyFormatter.format(f.currentValue, amountMode)
            b.tvUnits.text = "Units: ${String.format("%.3f", f.totalUnits)}"
            b.tvAvgCost.text = "Avg: ${CurrencyFormatter.format(f.avgCostPrice, amountMode)}"
            b.tvCmp.text = if (f.isPriceEstimated)
                "CMP: ${CurrencyFormatter.format(f.currentPrice, amountMode)} (Est.)"
            else
                "CMP: ${CurrencyFormatter.format(f.currentPrice, amountMode)}"
            b.tvPnl.text = "${if (f.pnl >= 0) "+" else ""}${CurrencyFormatter.format(f.pnl, amountMode)} (${String.format("%.2f", f.pnlPercent)}%)"
            b.tvPnl.setTextColor(b.root.context.getColor(if (f.pnl >= 0) R.color.gain_green else R.color.loss_red))
            if (f.folioNumber.isNotEmpty()) {
                b.tvFolioNo.text = "Folio: ${f.folioNumber}"
                b.tvFolioNo.visibility = android.view.View.VISIBLE
            } else {
                b.tvFolioNo.visibility = android.view.View.GONE
            }
            b.root.setOnClickListener { onClick(f) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemFolioBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Folio>() {
            override fun areItemsTheSame(a: Folio, b: Folio) = a.accountId == b.accountId && a.securityId == b.securityId
            override fun areContentsTheSame(a: Folio, b: Folio) = a == b
        }
    }
}
