package com.investtrack.utils

data class TransferResult(
    val currentEmi: Double,
    val newEmi: Double,
    val currentInterest: Double,
    val newInterest: Double,
    val fees: Double,
    val netSaving: Double,
    val monthlySaving: Double,
    val breakEvenMonths: Int?   // months until the fees are recovered; null if it never pays off
)

data class AffordResult(val maxEmi: Double, val maxLoan: Double, val currentRatioPercent: Double)

object LoanToolsCalculator {

    fun pmt(principal: Double, annualRate: Double, months: Int): Double {
        if (months <= 0) return 0.0
        val r = annualRate / 12.0 / 100.0
        return if (r == 0.0) principal / months
        else principal * r * Math.pow(1 + r, months.toDouble()) / (Math.pow(1 + r, months.toDouble()) - 1)
    }

    /** Present value of an EMI stream = the loan amount that EMI can service. */
    fun loanFor(emi: Double, annualRate: Double, months: Int): Double {
        if (months <= 0 || emi <= 0) return 0.0
        val r = annualRate / 12.0 / 100.0
        return if (r == 0.0) emi * months else emi * (1 - Math.pow(1 + r, -months.toDouble())) / r
    }

    fun balanceTransfer(
        outstanding: Double, currentRate: Double, remainingMonths: Int,
        newRate: Double, newTenureMonths: Int, feePercent: Double, otherCharges: Double,
        currentEmiOverride: Double? = null
    ): TransferResult {
        val curEmi = currentEmiOverride ?: pmt(outstanding, currentRate, remainingMonths)
        val newEmi = pmt(outstanding, newRate, newTenureMonths)
        val curInterest = (curEmi * remainingMonths - outstanding).coerceAtLeast(0.0)
        val newInterest = (newEmi * newTenureMonths - outstanding).coerceAtLeast(0.0)
        val fees = outstanding * feePercent / 100.0 + otherCharges
        val net = curInterest - newInterest - fees
        val monthly = curEmi - newEmi
        val breakEven = if (monthly > 0.5) Math.ceil(fees / monthly).toInt() else null
        return TransferResult(curEmi, newEmi, curInterest, newInterest, fees, net, monthly, breakEven)
    }

    /** [foirPercent] = share of monthly income that may go to EMIs (banks usually allow 40–50%). */
    fun affordability(income: Double, existingEmis: Double, foirPercent: Double, annualRate: Double, years: Int): AffordResult {
        val maxEmi = (income * foirPercent / 100.0 - existingEmis).coerceAtLeast(0.0)
        val ratio = if (income > 0) existingEmis / income * 100.0 else 0.0
        return AffordResult(maxEmi, loanFor(maxEmi, annualRate, years * 12), ratio)
    }
}
