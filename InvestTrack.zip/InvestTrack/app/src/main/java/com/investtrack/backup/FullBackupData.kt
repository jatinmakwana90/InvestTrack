package com.investtrack.backup

import com.investtrack.data.dao.AccountDao
import com.investtrack.data.dao.AutoSyncConfigDao
import com.investtrack.data.dao.IncomeExpenseDao
import com.investtrack.data.dao.LoanAdjustmentDao
import com.investtrack.data.dao.LoanDao
import com.investtrack.data.dao.ReminderDao
import com.investtrack.data.dao.SecurityDao
import com.investtrack.data.dao.TransactionDao
import com.investtrack.data.models.Account
import com.investtrack.data.models.AutoSyncConfig
import com.investtrack.data.models.IncomeExpenseEntry
import com.investtrack.data.models.Loan
import com.investtrack.data.models.LoanAdjustment
import com.investtrack.data.models.Reminder
import com.investtrack.data.models.Security
import com.investtrack.data.models.Transaction
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.data.settings.DarkModeOption
import com.investtrack.data.settings.ReturnDisplayMode
import com.investtrack.data.settings.SettingsManager
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * A complete snapshot of everything InvestTrack stores: all data tables plus display settings.
 * This is the single format used by both the manual "Create Backup File" export and the
 * automatic daily Google Drive backup, so a restore from either source brings back everything.
 *
 * Note: older backup files (version 3/4) may contain now-removed "budgetLimits" or "goals"
 * arrays from earlier iterations of the Budget Planning screen — ignoreUnknownKeys means these
 * are safely skipped on restore rather than causing an error.
 */
@Serializable
data class FullBackupData(
    val version: Int = 5,
    val exportedAt: Long = System.currentTimeMillis(),
    val accounts: List<Account> = emptyList(),
    val securities: List<Security> = emptyList(),
    val transactions: List<Transaction> = emptyList(),
    val loans: List<Loan> = emptyList(),
    val loanAdjustments: List<LoanAdjustment> = emptyList(),
    val reminders: List<Reminder> = emptyList(),
    val autoSyncConfig: AutoSyncConfig? = null,
    val incomeExpenseEntries: List<IncomeExpenseEntry> = emptyList(),
    val settings: BackedUpSettings = BackedUpSettings()
)

@Serializable
data class BackedUpSettings(
    val returnMode: String = ReturnDisplayMode.ABS.name,
    val amountMode: String = AmountDisplayMode.ROUNDED.name,
    val darkMode: String = DarkModeOption.SYSTEM.name
)

val backupJson = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }

/**
 * Builds a [FullBackupData] snapshot from the database and settings. Call from a background
 * (non-main) thread/coroutine dispatcher — this issues several suspend DAO calls in sequence.
 */
class FullBackupBuilder(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val reminderDao: ReminderDao,
    private val autoSyncConfigDao: AutoSyncConfigDao,
    private val settingsManager: SettingsManager,
    private val incomeExpenseDao: IncomeExpenseDao
) {
    suspend fun build(): FullBackupData {
        val loans = loanDao.getAllLoansIncludingInactiveList()
        val loanAdjustments = loans.flatMap { loanAdjustmentDao.getAdjustmentsForLoanList(it.id) }

        return FullBackupData(
            accounts = accountDao.getAllAccountsIncludingInactiveList(),
            securities = securityDao.getAllSecuritiesIncludingInactiveList(),
            transactions = transactionDao.getAllTransactionsList(),
            loans = loans,
            loanAdjustments = loanAdjustments,
            reminders = reminderDao.getAllRemindersList(),
            autoSyncConfig = autoSyncConfigDao.getConfigOnce(),
            incomeExpenseEntries = incomeExpenseDao.getAllEntriesIncludingInactiveList(),
            settings = BackedUpSettings(
                returnMode = settingsManager.returnMode.value.name,
                amountMode = settingsManager.amountMode.value.name,
                darkMode = settingsManager.darkMode.value.name
            )
        )
    }

    fun toJson(data: FullBackupData): String = backupJson.encodeToString(FullBackupData.serializer(), data)
}

/**
 * Restores a [FullBackupData] snapshot into the database and settings.
 * Existing rows are upserted by primary key (REPLACE), so restoring is safe to re-run.
 */
class FullBackupRestorer(
    private val accountDao: AccountDao,
    private val securityDao: SecurityDao,
    private val transactionDao: TransactionDao,
    private val loanDao: LoanDao,
    private val loanAdjustmentDao: LoanAdjustmentDao,
    private val reminderDao: ReminderDao,
    private val autoSyncConfigDao: AutoSyncConfigDao,
    private val settingsManager: SettingsManager,
    private val incomeExpenseDao: IncomeExpenseDao
) {
    data class RestoreSummary(
        val accounts: Int, val securities: Int, val transactions: Int,
        val loans: Int, val reminders: Int, val incomeExpenseEntries: Int
    )

    suspend fun restore(data: FullBackupData): RestoreSummary {
        data.accounts.forEach { accountDao.insertAccount(it) }
        data.securities.forEach { securityDao.insertSecurity(it) }
        data.transactions.forEach { transactionDao.insertTransaction(it) }
        data.loans.forEach { loanDao.insertLoan(it) }
        // LoanAdjustment uses a plain @Insert (no REPLACE), so clear existing adjustments per
        // loan first to keep restores idempotent rather than duplicating rows on re-run.
        data.loans.map { it.id }.distinct().forEach { loanId ->
            loanAdjustmentDao.deleteAllForLoan(loanId)
        }
        data.loanAdjustments.forEach { loanAdjustmentDao.insert(it) }
        data.reminders.forEach { reminderDao.insertReminder(it) }
        data.autoSyncConfig?.let { autoSyncConfigDao.upsert(it) }
        data.incomeExpenseEntries.forEach { incomeExpenseDao.insertEntry(it) }

        runCatching { ReturnDisplayMode.valueOf(data.settings.returnMode) }
            .getOrNull()?.let { settingsManager.setReturnMode(it) }
        runCatching { AmountDisplayMode.valueOf(data.settings.amountMode) }
            .getOrNull()?.let { settingsManager.setAmountMode(it) }
        runCatching { DarkModeOption.valueOf(data.settings.darkMode) }
            .getOrNull()?.let { settingsManager.setDarkMode(it) }

        return RestoreSummary(
            accounts = data.accounts.size,
            securities = data.securities.size,
            transactions = data.transactions.size,
            loans = data.loans.size,
            reminders = data.reminders.size,
            incomeExpenseEntries = data.incomeExpenseEntries.size
        )
    }

    fun fromJson(content: String): FullBackupData =
        backupJson.decodeFromString(FullBackupData.serializer(), content)
}
