package com.investtrack.ui.dashboard

import com.investtrack.ui.common.themeColor

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.investtrack.R
import com.investtrack.data.settings.AmountDisplayMode
import com.investtrack.databinding.ItemDashboardLoanBinding
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.ReminderSchedule
import java.text.SimpleDateFormat
import java.util.Locale

class DashboardLoanAdapter(
    private var amountMode: AmountDisplayMode,
    private val onClick: (DashboardLoanItem) -> Unit
) : ListAdapter<DashboardLoanItem, DashboardLoanAdapter.VH>(DIFF) {

    fun updateAmountMode(mode: AmountDisplayMode) {
        if (mode != amountMode) { amountMode = mode; notifyDataSetChanged() }
    }

    inner class VH(private val b: ItemDashboardLoanBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: DashboardLoanItem) {
            val ctx = b.root.context
            b.tvLoanName.text = item.name
            val outText = CurrencyFormatter.format(item.outstanding, amountMode)
            b.tvOutstanding.text = android.text.SpannableStringBuilder(outText).apply {
                val start = length
                append(" outstanding")
                setSpan(android.text.style.RelativeSizeSpan(0.72f), start, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                setSpan(android.text.style.ForegroundColorSpan(ctx.getColor(R.color.text_secondary)), start, length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            b.tvEmi.text = "EMI " + CurrencyFormatter.format(item.emi, amountMode)

            // EMI date + how many days away it is from today (29/30/31 fall on the month's last day)
            val due = ReminderSchedule.nextDueDate(item.emiDay)
            val days = ReminderSchedule.daysUntilDue(item.emiDay)
            b.tvEmiDate.text = "on " + SimpleDateFormat("d MMM", Locale.getDefault()).format(due.time)
            b.tvDueIn.text = when (days) {
                0 -> "Due today"
                1 -> "in 1 day"
                else -> "in $days days"
            }
            val urgent = days <= 3
            b.tvDueIn.backgroundTintList = ColorStateList.valueOf(
                if (urgent) ctx.getColor(R.color.chip_urgent_bg) else ctx.themeColor(R.attr.accentTint)
            )
            b.tvDueIn.setTextColor(if (urgent) ctx.getColor(R.color.loss_red) else ctx.themeColor(R.attr.accentLink))
            b.root.setOnClickListener { onClick(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemDashboardLoanBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<DashboardLoanItem>() {
            override fun areItemsTheSame(a: DashboardLoanItem, b: DashboardLoanItem) = a.loanId == b.loanId
            override fun areContentsTheSame(a: DashboardLoanItem, b: DashboardLoanItem) = a == b
        }
    }
}
