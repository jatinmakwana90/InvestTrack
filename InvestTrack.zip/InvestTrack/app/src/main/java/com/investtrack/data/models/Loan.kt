package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanName: String,           // e.g. "Home Loan - SBI"
    val lenderName: String = "",    // e.g. "SBI", "HDFC"
    val loanType: LoanType,
    val principalAmount: Double,    // original loan amount
    val outstandingAmount: Double,  // current outstanding
    val interestRate: Double,       // annual % rate
    val emiAmount: Double,          // monthly EMI
    val emiDay: Int = 5,            // day of month EMI is due
    val startDate: Long,
    val endDate: Long,              // maturity/closure date
    val totalEmis: Int = 0,         // total number of EMIs
    val emisPaid: Int = 0,          // EMIs paid so far
    val notes: String = "",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable

enum class LoanType(val displayName: String) {
    HOME_LOAN("Home Loan"),
    CAR_LOAN("Car Loan"),
    PERSONAL_LOAN("Personal Loan"),
    EDUCATION_LOAN("Education Loan"),
    GOLD_LOAN("Gold Loan"),
    BUSINESS_LOAN("Business Loan"),
    OTHER("Other")
}
