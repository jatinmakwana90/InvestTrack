package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity(tableName = "loans")
data class Loan(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanName: String,           // e.g. "Home Loan - SBI"
    val lenderName: String = "",    // e.g. "SBI", "HDFC"
    val loanType: LoanType,
    val principalAmount: Double,    // original loan amount
    val outstandingAmount: Double,  // current outstanding
    val interestRate: Double,       // annual % rate
    val emiAmount: Double,          // monthly EMI
    val emiDay: Int = 5,            // day of month EMI is due
    val startDate: Long,
    val endDate: Long,              // maturity/closure date
    val totalEmis: Int = 0,         // total number of EMIs
    val emisPaid: Int = 0,          // EMIs paid so far
    val notes: String = "",
    val isActive: Boolean = true,
    // Comma-separated list of installment indices (1-based) that have been marked as paid.
    // Kept as a simple string to avoid a type converter / migration for a Set<Int>.
    val paidInstallments: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Parcelable {
    fun paidInstallmentSet(): Set<Int> =
        paidInstallments.split(",").mapNotNull { it.trim().toIntOrNull() }.toSet()
}

enum class LoanType(val displayName: String, val emoji: String) {
    HOME_LOAN("Home Loan", "\uD83C\uDFE0"),
    CAR_LOAN("Car Loan", "\uD83D\uDE97"),
    PERSONAL_LOAN("Personal Loan", "\uD83D\uDCBC"),
    CREDIT_CARD("Credit Card", "\uD83D\uDCB3"),
    EDUCATION_LOAN("Education Loan", "\uD83C\uDF93"),
    GOLD_LOAN("Gold Loan", "\uD83D\uDFE1"),
    BUSINESS_LOAN("Business Loan", "\uD83C\uDFE2"),
    OTHER("Other", "\uD83C\uDFDB\uFE0F")
}
