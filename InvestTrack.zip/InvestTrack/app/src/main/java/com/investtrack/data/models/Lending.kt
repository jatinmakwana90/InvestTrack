package com.investtrack.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/** Money lent to, or borrowed from, a friend or family member. */
@Serializable
@Entity(tableName = "lending_entries")
data class LendingEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personName: String,
    /** LENT (they owe me) or BORROWED (I owe them) */
    val direction: String,
    val amount: Double,
    val date: Long,
    /** Date the money is due back. 0 = no due date. */
    val dueDate: Long,
    val notes: String,
    val isSettled: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)

/** A part or full repayment against a [LendingEntry]. */
@Serializable
@Entity(tableName = "lending_payments")
data class LendingPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val lendingId: Long,
    val amount: Double,
    val date: Long,
    val notes: String
)
