package com.investtrack.data.dao

import androidx.room.*
import com.investtrack.data.models.AutoSyncConfig
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoSyncConfigDao {
    @Query("SELECT * FROM auto_sync_config WHERE id = 1")
    fun getConfig(): Flow<AutoSyncConfig?>

    @Query("SELECT * FROM auto_sync_config WHERE id = 1")
    suspend fun getConfigOnce(): AutoSyncConfig?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(config: AutoSyncConfig)
}
