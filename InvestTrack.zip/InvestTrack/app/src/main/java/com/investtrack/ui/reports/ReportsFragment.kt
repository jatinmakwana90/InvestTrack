package com.investtrack.ui.reports

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.investtrack.data.models.*
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentReportsBinding
import com.investtrack.utils.CurrencyFormatter
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ReportsUiState())
    val uiState: StateFlow<ReportsUiState> = _uiState.asStateFlow()

    init { load() }

    fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            try {
                val folios = repository.getAllFolios()
                val totalInvested = folios.sumOf { it.totalInvested }
                val currentValue = folios.sumOf { it.currentValue }
                val totalPnL = currentValue - totalInvested
                val pnlPct = if (totalInvested > 0) (totalPnL / totalInvested) * 100 else 0.0

                // By type allocation
                val byType = folios.groupBy { it.securityType }
                    .map { (type, list) ->
                        TypeReport(
                            type = type,
                            invested = list.sumOf { it.totalInvested },
                            currentValue = list.sumOf { it.currentValue },
                            pnl = list.sumOf { it.pnl },
                            count = list.size
                        )
                    }.sortedByDescending { it.currentValue }

                // Top gainers
                val gainers = folios.filter { it.pnl > 0 }
                    .sortedByDescending { it.pnlPercent }.take(5)

                // Top losers
                val losers = folios.filter { it.pnl < 0 }
                    .sortedBy { it.pnlPercent }.take(5)

                _uiState.update {
                    it.copy(
                        isLoading = false,
                        totalInvested = totalInvested,
                        currentValue = currentValue,
                        totalPnL = totalPnL,
                        pnlPercent = pnlPct,
                        typeReports = byType,
                        topGainers = gainers,
                        topLosers = losers,
                        totalHoldings = folios.size
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }
}

data class ReportsUiState(
    val isLoading: Boolean = false,
    val totalInvested: Double = 0.0,
    val currentValue: Double = 0.0,
    val totalPnL: Double = 0.0,
    val pnlPercent: Double = 0.0,
    val typeReports: List<TypeReport> = emptyList(),
    val topGainers: List<Folio> = emptyList(),
    val topLosers: List<Folio> = emptyList(),
    val totalHoldings: Int = 0,
    val error: String? = null
)

data class TypeReport(
    val type: SecurityType,
    val invested: Double,
    val currentValue: Double,
    val pnl: Double,
    val count: Int
) {
    val pnlPercent: Double get() = if (invested > 0) (pnl / invested) * 100 else 0.0
    val allocationPercent: Double = 0.0
}

@AndroidEntryPoint
class ReportsFragment : Fragment() {

    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportsViewModel by viewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.swipeRefresh.setOnRefreshListener { viewModel.load() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.swipeRefresh.isRefreshing = state.isLoading

                // Summary row
                binding.tvTotalValue.text = CurrencyFormatter.format(state.currentValue)
                binding.tvTotalInvested.text = CurrencyFormatter.format(state.totalInvested)
                val pnl = state.totalPnL
                binding.tvTotalPnl.text = "${if (pnl >= 0) "▲ +" else "▼ "}${CurrencyFormatter.format(kotlin.math.abs(pnl))} (${String.format("%.2f", kotlin.math.abs(state.pnlPercent))}%)"
                binding.tvTotalPnl.setTextColor(requireContext().getColor(if (pnl >= 0) com.investtrack.R.color.gain_green else com.investtrack.R.color.loss_red))
                binding.tvHoldingsCount.text = "${state.totalHoldings} Holdings"

                // Build allocation table
                binding.llAllocation.removeAllViews()
                val totalVal = state.typeReports.sumOf { it.currentValue }.takeIf { it > 0 } ?: 1.0
                state.typeReports.forEach { report ->
                    val row = layoutInflater.inflate(com.investtrack.R.layout.item_type_report, binding.llAllocation, false)
                    val tvType = row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_type_name)
                    val tvValue = row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_type_value)
                    val tvPnl = row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_type_pnl)
                    val tvAlloc = row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_type_alloc)
                    val progressBar = row.findViewById<android.widget.ProgressBar>(com.investtrack.R.id.progress_alloc)
                    tvType.text = "${report.type.displayName} (${report.count})"
                    tvValue.text = CurrencyFormatter.format(report.currentValue)
                    val rPnl = report.pnl
                    tvPnl.text = "${if (rPnl >= 0) "+" else ""}${String.format("%.2f", report.pnlPercent)}%"
                    tvPnl.setTextColor(requireContext().getColor(if (rPnl >= 0) com.investtrack.R.color.gain_green else com.investtrack.R.color.loss_red))
                    val allocPct = (report.currentValue / totalVal * 100).toInt()
                    tvAlloc.text = "$allocPct%"
                    progressBar.progress = allocPct
                    binding.llAllocation.addView(row)
                }

                // Gainers
                binding.llGainers.removeAllViews()
                state.topGainers.forEach { folio ->
                    val row = buildFolioRow(folio, true)
                    binding.llGainers.addView(row)
                }
                binding.cardGainers.visibility = if (state.topGainers.isEmpty()) View.GONE else View.VISIBLE

                // Losers
                binding.llLosers.removeAllViews()
                state.topLosers.forEach { folio ->
                    val row = buildFolioRow(folio, false)
                    binding.llLosers.addView(row)
                }
                binding.cardLosers.visibility = if (state.topLosers.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun buildFolioRow(folio: Folio, isGainer: Boolean): View {
        val row = layoutInflater.inflate(com.investtrack.R.layout.item_folio_mini, binding.llGainers, false)
        row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_mini_name).text = folio.securityName
        row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_mini_type).text = folio.securityType.displayName
        val pnlTv = row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_mini_pnl)
        pnlTv.text = "${if (folio.pnl >= 0) "+" else ""}${String.format("%.2f", folio.pnlPercent)}%"
        pnlTv.setTextColor(requireContext().getColor(if (folio.pnl >= 0) com.investtrack.R.color.gain_green else com.investtrack.R.color.loss_red))
        row.findViewById<android.widget.TextView>(com.investtrack.R.id.tv_mini_value).text = CurrencyFormatter.format(folio.currentValue)
        return row
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
