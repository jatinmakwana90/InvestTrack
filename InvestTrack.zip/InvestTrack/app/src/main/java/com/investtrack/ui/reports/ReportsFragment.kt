package com.investtrack.ui.reports

import com.investtrack.ui.common.themeColor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupMenu
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.button.MaterialButton
import com.investtrack.R
import com.investtrack.databinding.FragmentReportsBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ReportsFragment : Fragment() {
    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportsViewModel by viewModels()

    private lateinit var cashFlowAdapter: CashFlowYearAdapter
    private lateinit var openLotAdapter: OpenLotReportAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        cashFlowAdapter = CashFlowYearAdapter { year -> viewModel.toggleYearExpanded(year) }
        binding.rvCashflowYears.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = cashFlowAdapter
            isNestedScrollingEnabled = false
        }

        openLotAdapter = OpenLotReportAdapter { securityId -> viewModel.toggleSecurityExpanded(securityId) }
        binding.rvOpenLots.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = openLotAdapter
            isNestedScrollingEnabled = false
        }

        binding.btnTabCashflow.setOnClickListener { viewModel.selectTab(ReportTab.CASH_FLOW) }
        binding.btnTabOpenlots.setOnClickListener { viewModel.selectTab(ReportTab.OPEN_LOTS) }
        binding.btnAccountFilter.setOnClickListener { showAccountFilterMenu() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE

                // Tab visibility
                val onCashFlow = state.selectedTab == ReportTab.CASH_FLOW
                binding.scrollCashflow.visibility = if (onCashFlow) View.VISIBLE else View.GONE
                binding.layoutOpenlots.visibility = if (onCashFlow) View.GONE else View.VISIBLE
                styleToggle(binding.btnTabCashflow, onCashFlow)
                styleToggle(binding.btnTabOpenlots, !onCashFlow)

                // Account filter label
                binding.tvAccountFilterLabel.text = state.selectedAccountId
                    ?.let { id -> state.accounts.firstOrNull { it.id == id }?.name ?: "All Accounts" }
                    ?: "All Accounts"

                if (!state.isLoading) {
                    // Cash flow
                    binding.tvCashflowEmpty.visibility = if (state.cashFlowYears.isEmpty()) View.VISIBLE else View.GONE
                    cashFlowAdapter.submit(state.cashFlowYears, state.expandedYears)

                    // Open lots
                    val report = state.openLotReport
                    val hasLots = report != null && report.groups.isNotEmpty()
                    binding.tvOpenlotsEmpty.visibility = if (hasLots) View.GONE else View.VISIBLE
                    binding.hscrollLots.visibility = if (hasLots) View.VISIBLE else View.GONE
                    if (report != null) openLotAdapter.submit(report, state.expandedSecurities)
                }
            }
        }
    }

    private fun showAccountFilterMenu() {
        val state = viewModel.uiState.value
        val popup = PopupMenu(requireContext(), binding.btnAccountFilter)
        popup.menu.add(0, -1, 0, "All Accounts")
        state.accounts.forEachIndexed { index, account ->
            popup.menu.add(0, index, index + 1, account.name)
        }
        popup.setOnMenuItemClickListener { item ->
            val accountId = if (item.itemId == -1) null else state.accounts[item.itemId].id
            viewModel.selectAccount(accountId)
            true
        }
        popup.show()
    }

    private fun styleToggle(button: MaterialButton, selected: Boolean) {
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(
            resources.getColor(if (selected) R.color.toggle_on_bg else R.color.toggle_off_bg, null)
        )
        button.setTextColor(
            if (selected) requireContext().themeColor(R.attr.accentBar) else requireContext().getColor(R.color.toggle_off_text)
        )
    }

    override fun onResume() {
        super.onResume()
        viewModel.load() // prices / transactions may have changed while this tab was in the background
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
