package com.investtrack.ui.reports

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.investtrack.data.models.TransactionType
import com.investtrack.data.repository.InvestmentRepository
import com.investtrack.databinding.FragmentReportsBinding
import com.investtrack.utils.CurrencyFormatter
import com.investtrack.utils.XIRRCalculator
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class CapitalGainItem(
    val securityName: String,
    val units: Double,
    val buyPrice: Double,
    val sellPrice: Double,
    val buyDate: Long,
    val sellDate: Long,
    val realizedPnL: Double,
    val isLongTerm: Boolean  // >1 year = long term
)

data class FundXIRR(val name: String, val xirr: Double?, val currentValue: Double, val invested: Double)

@HiltViewModel
class ReportsViewModel @Inject constructor(
    private val repository: InvestmentRepository
) : ViewModel() {

    private val _capitalGains = MutableStateFlow<List<CapitalGainItem>>(emptyList())
    val capitalGains: StateFlow<List<CapitalGainItem>> = _capitalGains

    private val _fundXirrs = MutableStateFlow<List<FundXIRR>>(emptyList())
    val fundXirrs: StateFlow<List<FundXIRR>> = _fundXirrs

    private val _monthlyData = MutableStateFlow<List<Pair<String, Double>>>(emptyList())
    val monthlyData: StateFlow<List<Pair<String, Double>>> = _monthlyData

    init { load() }

    private fun load() {
        viewModelScope.launch {
            val allTxns = repository.getAllTransactionsList()
            val securities = repository.getAllSecuritiesList()
            val secMap = securities.associateBy { it.id }

            // Capital Gains from FIFO
            val gains = mutableListOf<CapitalGainItem>()
            val byFolio = allTxns.groupBy { it.securityId }
            byFolio.forEach { (secId, txns) ->
                val sec = secMap[secId] ?: return@forEach
                val fifoSells = com.investtrack.utils.FIFOCalculator.processFIFO(txns)
                fifoSells.forEach { sell ->
                    sell.allocations.forEach { alloc ->
                        val holdingDays = (sell.sellTransaction.transactionDate - alloc.buyDate) / (1000 * 60 * 60 * 24)
                        gains.add(CapitalGainItem(
                            securityName = sec.name,
                            units = alloc.quantity,
                            buyPrice = alloc.buyPrice,
                            sellPrice = alloc.sellPrice,
                            buyDate = alloc.buyDate,
                            sellDate = sell.sellTransaction.transactionDate,
                            realizedPnL = alloc.realizedPnL,
                            isLongTerm = holdingDays > 365
                        ))
                    }
                }
            }
            _capitalGains.value = gains.sortedByDescending { it.sellDate }

            // XIRR per fund
            val xirrs = mutableListOf<FundXIRR>()
            byFolio.forEach { (secId, txns) ->
                val sec = secMap[secId] ?: return@forEach
                val folios = repository.getFoliosForAccount(
                    txns.first().accountId
                ).filter { it.securityId == secId }
                val cv = folios.sumOf { it.currentValue }
                val inv = folios.sumOf { it.totalInvested }
                val flows = XIRRCalculator.buildCashFlows(txns, cv)
                val xirr = try { XIRRCalculator.calculate(flows) } catch (e: Exception) { null }
                xirrs.add(FundXIRR(sec.name, xirr, cv, inv))
            }
            _fundXirrs.value = xirrs.sortedByDescending { it.xirr ?: -999.0 }

            // Monthly investment data (last 12 months)
            val monthly = mutableMapOf<String, Double>()
            val fmt = SimpleDateFormat("MMM yy", Locale.getDefault())
            val cal = Calendar.getInstance()
            // Initialize last 12 months with 0
            repeat(12) {
                monthly[fmt.format(cal.time)] = 0.0
                cal.add(Calendar.MONTH, -1)
            }
            allTxns.filter { it.type == TransactionType.BUY }.forEach { txn ->
                val label = fmt.format(Date(txn.transactionDate))
                if (monthly.containsKey(label)) {
                    monthly[label] = (monthly[label] ?: 0.0) + txn.amount
                }
            }
            _monthlyData.value = monthly.entries
                .sortedBy { SimpleDateFormat("MMM yy", Locale.getDefault()).parse(it.key) }
                .map { it.key to it.value }
        }
    }
}

@AndroidEntryPoint
class ReportsFragment : Fragment() {
    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportsViewModel by viewModels()
    private val dateFmt = SimpleDateFormat("dd MMM yy", Locale.getDefault())

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.toolbar.setNavigationOnClickListener { activity?.onBackPressedDispatcher?.onBackPressed() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.capitalGains.collect { gains ->
                renderCapitalGains(gains)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.fundXirrs.collect { xirrs ->
                renderFundXirrs(xirrs)
            }
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.monthlyData.collect { data ->
                if (data.isNotEmpty()) renderBarChart(data)
            }
        }
    }

    private fun renderCapitalGains(gains: List<CapitalGainItem>) {
        if (gains.isEmpty()) { binding.tvCapGains.text = "No realized gains/losses yet."; return }
        val stGains = gains.filter { !it.isLongTerm }
        val ltGains = gains.filter { it.isLongTerm }
        val stTotal = stGains.sumOf { it.realizedPnL }
        val ltTotal = ltGains.sumOf { it.realizedPnL }

        val sb = StringBuilder()
        sb.appendLine("SHORT TERM (< 1 year)")
        sb.appendLine("Total: ${if (stTotal >= 0) "+" else ""}${CurrencyFormatter.format(stTotal)}")
        stGains.take(5).forEach {
            sb.appendLine("  ${it.securityName.take(22)}  ${if (it.realizedPnL >= 0) "+" else ""}${CurrencyFormatter.format(it.realizedPnL)}")
        }
        sb.appendLine()
        sb.appendLine("LONG TERM (> 1 year)")
        sb.appendLine("Total: ${if (ltTotal >= 0) "+" else ""}${CurrencyFormatter.format(ltTotal)}")
        ltGains.take(5).forEach {
            sb.appendLine("  ${it.securityName.take(22)}  ${if (it.realizedPnL >= 0) "+" else ""}${CurrencyFormatter.format(it.realizedPnL)}")
        }
        binding.tvCapGains.text = sb.toString().trimEnd()
    }

    private fun renderFundXirrs(xirrs: List<FundXIRR>) {
        if (xirrs.isEmpty()) { binding.tvFundXirr.text = "No data yet."; return }
        val sb = StringBuilder()
        xirrs.forEach { f ->
            val xirrStr = if (f.xirr != null) "${String.format("%.1f", f.xirr)}%" else "N/A"
            sb.appendLine("${f.name.take(28)}")
            sb.appendLine("  XIRR: $xirrStr  |  ${CurrencyFormatter.format(f.currentValue)}")
            sb.appendLine()
        }
        binding.tvFundXirr.text = sb.toString().trimEnd()
    }

    private fun renderBarChart(data: List<Pair<String, Double>>) {
        val entries = data.mapIndexed { i, (_, v) -> BarEntry(i.toFloat(), v.toFloat()) }
        val labels = data.map { it.first }
        val dataset = BarDataSet(entries, "Monthly Investment").apply {
            color = requireContext().getColor(com.investtrack.R.color.primary)
            valueTextColor = requireContext().getColor(com.investtrack.R.color.text_secondary)
            valueTextSize = 9f
        }
        binding.barChart.apply {
            data = BarData(dataset)
            description.isEnabled = false
            legend.isEnabled = false
            xAxis.apply {
                valueFormatter = IndexAxisValueFormatter(labels)
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                textColor = requireContext().getColor(com.investtrack.R.color.text_hint)
                textSize = 9f
                setDrawGridLines(false)
            }
            axisLeft.apply {
                textColor = requireContext().getColor(com.investtrack.R.color.text_hint)
                textSize = 9f
            }
            axisRight.isEnabled = false
            setBackgroundColor(requireContext().getColor(com.investtrack.R.color.card_background))
            animateY(600)
            invalidate()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
