package com.investtrack.ui.reports

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.investtrack.R
import com.investtrack.databinding.FragmentReportsBinding
import com.investtrack.utils.CashFlowBucket
import com.investtrack.utils.CashFlowPeriod
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ReportsFragment : Fragment() {
    private var _binding: FragmentReportsBinding? = null
    private val binding get() = _binding!!
    private val viewModel: ReportsViewModel by viewModels()

    private lateinit var cashFlowAdapter: CashFlowSummaryAdapter
    private lateinit var openLotAdapter: OpenLotReportAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentReportsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupChart()

        cashFlowAdapter = CashFlowSummaryAdapter()
        binding.rvCashflowSummary.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = cashFlowAdapter
            isNestedScrollingEnabled = false
        }

        openLotAdapter = OpenLotReportAdapter()
        binding.rvOpenLots.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = openLotAdapter
            isNestedScrollingEnabled = false
        }

        binding.btnTabCashflow.setOnClickListener { viewModel.selectTab(ReportTab.CASH_FLOW) }
        binding.btnTabOpenlots.setOnClickListener { viewModel.selectTab(ReportTab.OPEN_LOTS) }
        binding.btnPeriodYearly.setOnClickListener { viewModel.setCashFlowPeriod(CashFlowPeriod.YEARLY) }
        binding.btnPeriodMonthly.setOnClickListener { viewModel.setCashFlowPeriod(CashFlowPeriod.MONTHLY) }

        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE

                // Tab visibility
                val onCashFlow = state.selectedTab == ReportTab.CASH_FLOW
                binding.scrollCashflow.visibility = if (onCashFlow) View.VISIBLE else View.GONE
                binding.layoutOpenlots.visibility = if (onCashFlow) View.GONE else View.VISIBLE
                styleToggle(binding.btnTabCashflow, onCashFlow)
                styleToggle(binding.btnTabOpenlots, !onCashFlow)

                // Period toggle style
                val isYearly = state.cashFlowPeriod == CashFlowPeriod.YEARLY
                styleToggle(binding.btnPeriodYearly, isYearly)
                styleToggle(binding.btnPeriodMonthly, !isYearly)

                // Cash flow chart + list
                if (!state.isLoading) {
                    binding.tvCashflowEmpty.visibility = if (state.cashFlowBuckets.isEmpty()) View.VISIBLE else View.GONE
                    bindChart(state.cashFlowBuckets)
                    cashFlowAdapter.submit(state.cashFlowBuckets)

                    // Open lots
                    val report = state.openLotReport
                    val hasLots = report != null && report.groups.isNotEmpty()
                    binding.tvOpenlotsEmpty.visibility = if (hasLots) View.GONE else View.VISIBLE
                    binding.hscrollLots.visibility = if (hasLots) View.VISIBLE else View.GONE
                    if (report != null) openLotAdapter.submit(report)
                }
            }
        }
    }

    private fun styleToggle(button: com.google.android.material.button.MaterialButton, selected: Boolean) {
        button.background = resources.getDrawable(
            if (selected) R.drawable.bg_report_toggle_selected else R.drawable.bg_report_toggle_unselected, null
        )
        button.setTextColor(
            if (selected) Color.WHITE else resources.getColor(R.color.text_secondary, null)
        )
    }

    private fun setupChart() {
        val chart = binding.barChart
        chart.description.isEnabled = false
        chart.setDrawGridBackground(false)
        chart.setDrawBarShadow(false)
        chart.setDrawValueAboveBar(true)
        chart.setPinchZoom(false)
        chart.setScaleEnabled(false)
        chart.setNoDataText("No transactions yet")
        chart.axisRight.isEnabled = false

        val xAxis = chart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setDrawGridLines(false)
        xAxis.granularity = 1f
        xAxis.textColor = resources.getColor(R.color.text_secondary, null)

        chart.axisLeft.setDrawGridLines(true)
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.textColor = resources.getColor(R.color.text_secondary, null)

        chart.legend.isEnabled = false
        chart.animateY(600, Easing.EaseInOutQuad)
    }

    private fun bindChart(buckets: List<CashFlowBucket>) {
        val chart = binding.barChart
        if (buckets.isEmpty()) {
            chart.clear()
            chart.invalidate()
            return
        }

        val inflowEntries = buckets.mapIndexed { i, b -> BarEntry(i.toFloat(), b.inflow.toFloat()) }
        val outflowEntries = buckets.mapIndexed { i, b -> BarEntry(i.toFloat(), b.outflow.toFloat()) }

        val inflowSet = BarDataSet(inflowEntries, "Inflow").apply {
            color = resources.getColor(R.color.gain_green, null)
            setDrawValues(false)
        }
        val outflowSet = BarDataSet(outflowEntries, "Outflow").apply {
            color = resources.getColor(R.color.loss_red, null)
            setDrawValues(false)
        }

        val groupSpace = 0.26f
        val barSpace = 0.02f
        val barWidth = 0.35f
        // (barWidth + barSpace) * 2 datasets + groupSpace = (0.35 + 0.02) * 2 + 0.26 = 1.00

        val data = BarData(inflowSet, outflowSet)
        data.barWidth = barWidth

        chart.data = data
        chart.xAxis.valueFormatter = IndexAxisValueFormatter(buckets.map { it.periodLabel })
        chart.xAxis.axisMinimum = 0f
        chart.xAxis.axisMaximum = 0f + buckets.size
        chart.xAxis.labelCount = buckets.size
        chart.xAxis.setCenterAxisLabels(true)
        chart.xAxis.granularity = 1f

        chart.groupBars(0f, groupSpace, barSpace)
        chart.setVisibleXRangeMaximum(6f)
        if (buckets.size > 6) chart.moveViewToX(buckets.size.toFloat())
        chart.invalidate()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
