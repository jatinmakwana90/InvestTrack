package com.investtrack.ui

import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.investtrack.R
import com.investtrack.ui.budget.IncomeExpenseFragment
import com.investtrack.ui.dashboard.DashboardFragment
import com.investtrack.ui.loans.LoansFragment
import com.investtrack.ui.masters.MastersFragment
import com.investtrack.ui.reminders.RemindersFragment
import com.investtrack.ui.reports.ReportsFragment
import com.investtrack.ui.settings.SettingsFragment
import com.investtrack.ui.transactions.TransactionsFragment
import com.investtrack.ui.whatsapp.WhatsAppTemplatesFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_DASHBOARD = 0
        const val TAB_TRANSACTIONS = 1
        const val TAB_LOANS = 2
        const val TAB_MASTERS = 3
        const val TAB_REPORTS = 4
        const val TAB_BUDGET = 5
        const val TAB_WHATSAPP = 6
        const val TAB_REMINDERS = 7
        const val TAB_SETTINGS = 8

        /** Tab order: Dashboard, Transactions, Loans, Masters, Reports, Budget, WhatsApp, Reminders, Settings */
        private val TABS: List<Pair<String, () -> Fragment>> = listOf(
            "Dashboard" to { DashboardFragment() },
            "Transactions" to { TransactionsFragment() },
            "Loans" to { LoansFragment() },
            "Masters" to { MastersFragment() },
            "Reports" to { ReportsFragment() },
            "Budget" to { IncomeExpenseFragment() },
            "WhatsApp" to { WhatsAppTemplatesFragment() },
            "Reminders" to { RemindersFragment() },
            "Settings" to { SettingsFragment() }
        )
    }

    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var overlay: View

    private val tabBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            // From any other tab, back goes to Dashboard first
            viewPager.currentItem = TAB_DASHBOARD
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tabLayout = findViewById(R.id.top_tabs)
        viewPager = findViewById(R.id.view_pager)
        overlay = findViewById(R.id.fragment_container)

        viewPager.adapter = object : FragmentStateAdapter(this as FragmentActivity) {
            override fun getItemCount() = TABS.size
            override fun createFragment(position: Int): Fragment = TABS[position].second()
        }
        viewPager.offscreenPageLimit = 1
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = TABS[position].first
        }.attach()

        onBackPressedDispatcher.addCallback(this, tabBackCallback)
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateBackHandling()
        })
        supportFragmentManager.addOnBackStackChangedListener {
            overlay.visibility = if (supportFragmentManager.backStackEntryCount > 0) View.VISIBLE else View.GONE
            updateBackHandling()
        }
    }

    private fun updateBackHandling() {
        tabBackCallback.isEnabled =
            supportFragmentManager.backStackEntryCount == 0 && viewPager.currentItem != TAB_DASHBOARD
    }

    /** Jump to one of the top tabs (use the TAB_* constants). */
    fun selectTab(index: Int) {
        supportFragmentManager.popBackStack(null, androidx.fragment.app.FragmentManager.POP_BACK_STACK_INCLUSIVE)
        viewPager.setCurrentItem(index, true)
    }

    /** Push a detail / form screen on top of the tabs (with back-stack). */
    fun navigateTo(fragment: Fragment) {
        overlay.visibility = View.VISIBLE
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
