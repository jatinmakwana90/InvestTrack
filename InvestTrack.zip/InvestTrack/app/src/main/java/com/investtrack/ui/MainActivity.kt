package com.investtrack.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.investtrack.R
import com.investtrack.debug.StartupTrace
import com.investtrack.ui.dashboard.DashboardFragment
import com.investtrack.ui.loans.LoansFragment
import com.investtrack.ui.masters.MastersFragment
import com.investtrack.ui.reports.ReportsFragment
import com.investtrack.ui.settings.SettingsFragment
import com.investtrack.ui.transactions.TransactionsFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        StartupTrace.mark("MainActivity.onCreate START")
        setContentView(R.layout.activity_main)
        StartupTrace.mark("setContentView done")
        bottomNav = findViewById(R.id.bottom_navigation)
        StartupTrace.mark("bottomNav found")
        if (savedInstanceState == null) {
            loadFragment(DashboardFragment(), "dashboard")
            StartupTrace.mark("DashboardFragment loadFragment() called")
        }

        bottomNav.setOnItemSelectedListener { item: MenuItem ->
            when (item.itemId) {
                R.id.nav_dashboard -> loadFragment(DashboardFragment(), "dashboard")
                R.id.nav_transactions -> loadFragment(TransactionsFragment(), "transactions")
                R.id.nav_loans -> loadFragment(LoansFragment(), "loans")
                R.id.nav_masters -> loadFragment(MastersFragment(), "masters")
                R.id.nav_reports -> loadFragment(ReportsFragment(), "reports")
                R.id.nav_settings -> loadFragment(SettingsFragment(), "settings")
            }
            true
        }
        StartupTrace.mark("MainActivity.onCreate END")

        // Startup watchdog: if the app hasn't finished loading real data within a few
        // seconds, show exactly what DID happen instead of leaving the person staring at
        // a frozen/blank screen with no way to tell what's wrong.
        Handler(Looper.getMainLooper()).postDelayed({
            if (!StartupTrace.reachedEnd) {
                startActivity(Intent(this, CrashActivity::class.java).apply {
                    putExtra("crash_text", "STARTUP WATCHDOG — app did not finish loading within 6 seconds.\n\n" +
                        "Checkpoints reached:\n" + StartupTrace.dump())
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                })
            }
        }, 6000)
    }

    fun loadFragment(fragment: Fragment, tag: String = "") {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment, tag)
            .commit()
    }

    fun navigateTo(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
