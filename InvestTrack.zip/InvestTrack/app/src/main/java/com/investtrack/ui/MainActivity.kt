package com.investtrack.ui

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Bypass Navigation Component entirely - just show a view directly
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val tv = TextView(this).apply {
            text = "InvestTrack\nApp is Working!"
            textSize = 28f
            setTextColor(Color.parseColor("#1A237E"))
            gravity = Gravity.CENTER
        }

        layout.addView(tv)
        setContentView(layout)
    }
}
