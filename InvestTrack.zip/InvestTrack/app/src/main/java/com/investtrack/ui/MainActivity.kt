package com.investtrack.ui

import android.os.Bundle
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.investtrack.R
import com.investtrack.ui.dashboard.DashboardFragment
import com.investtrack.ui.loans.LoansFragment
import com.investtrack.ui.masters.MastersFragment
import com.investtrack.ui.reports.ReportsFragment
import com.investtrack.ui.settings.SettingsFragment
import com.investtrack.ui.transactions.TransactionsFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bottomNav = findViewById(R.id.bottom_navigation)
        if (savedInstanceState == null) loadFragment(DashboardFragment(), "dashboard")

        bottomNav.setOnItemSelectedListener { item: MenuItem ->
            when (item.itemId) {
                R.id.nav_dashboard -> loadFragment(DashboardFragment(), "dashboard")
                R.id.nav_transactions -> loadFragment(TransactionsFragment(), "transactions")
                R.id.nav_loans -> loadFragment(LoansFragment(), "loans")
                R.id.nav_masters -> loadFragment(MastersFragment(), "masters")
                R.id.nav_reports -> loadFragment(ReportsFragment(), "reports")
                R.id.nav_settings -> loadFragment(SettingsFragment(), "settings")
            }
            true
        }
    }

    fun loadFragment(fragment: Fragment, tag: String = "") {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment, tag)
            .commit()
    }

    fun navigateTo(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
