package com.investtrack.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.investtrack.R
import com.investtrack.databinding.ActivityMainBinding
import com.investtrack.workers.MarketPriceWorker
import com.investtrack.workers.WifiSyncWorker
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        binding.bottomNavigation.setupWithNavController(navController)

        // Schedule background workers after UI is up; never let this block or crash launch.
        try {
            MarketPriceWorker.schedule(applicationContext)
            WifiSyncWorker.schedule(applicationContext)
        } catch (t: Throwable) {
            t.printStackTrace()
        }
    }
}
