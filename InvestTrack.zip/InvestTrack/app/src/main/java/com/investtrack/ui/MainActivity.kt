package com.investtrack.ui

import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.investtrack.R
import com.investtrack.ui.dashboard.DashboardFragment
import com.investtrack.ui.host.MastersHostFragment
import com.investtrack.ui.host.PlannerHostFragment
import com.investtrack.ui.reports.ReportsFragment
import com.investtrack.ui.settings.SettingsFragment
import com.investtrack.ui.transactions.TransactionsFragment
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    companion object {
        const val TAB_DASHBOARD = 0
        const val TAB_TRANSACTIONS = 1
        const val TAB_MASTERS = 2
        const val TAB_REPORTS = 3
        const val TAB_PLANNER = 4
        const val TAB_SETTINGS = 5

        // Inner tabs of Masters
        const val MASTER_ACCOUNT = 0
        const val MASTER_SECURITY = 1
        const val MASTER_LOAN = 2

        // Inner tabs of Planner
        const val PLANNER_BUDGET = 0
        const val PLANNER_GOALS = 1
        const val PLANNER_REMINDERS = 2
        const val PLANNER_WHATSAPP = 3

        private class Tab(val title: String, val icon: Int, val create: () -> Fragment, val key: String? = null)

        /** Dashboard, Transactions, Masters (Account/Security/Loan), Reports, Planner (Budget/Reminders/WhatsApp), Settings */
        private val TABS = listOf(
            Tab("Dashboard", R.drawable.ic_nav_dashboard, { DashboardFragment() }),
            Tab("Transactions", R.drawable.ic_nav_transactions, { TransactionsFragment() }),
            Tab("Masters", R.drawable.ic_nav_masters, { MastersHostFragment() }, "masters"),
            Tab("Reports", R.drawable.ic_nav_reports, { ReportsFragment() }),
            Tab("Planner", R.drawable.ic_nav_planner, { PlannerHostFragment() }, "planner"),
            Tab("Settings", R.drawable.ic_nav_settings, { SettingsFragment() })
        )
    }

    private lateinit var tabLayout: TabLayout
    private lateinit var viewPager: ViewPager2
    private lateinit var overlay: View
    @javax.inject.Inject lateinit var appLock: com.investtrack.data.settings.AppLockManager
    @javax.inject.Inject lateinit var settingsManager: com.investtrack.data.settings.SettingsManager
    private lateinit var lockController: com.investtrack.ui.lock.LockScreenController

    // While the lock screen is up, Back sends the app to the background instead of going into the app.
    private val lockBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { moveTaskToBack(true) }
    }

    private val tabBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            viewPager.currentItem = TAB_DASHBOARD
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tabLayout = findViewById(R.id.bottom_tabs)
        viewPager = findViewById(R.id.view_pager)
        overlay = findViewById(R.id.fragment_container)

        viewPager.adapter = object : FragmentStateAdapter(this as FragmentActivity) {
            override fun getItemCount() = TABS.size
            override fun createFragment(position: Int): Fragment = TABS[position].create()
        }
        // Bottom tabs only: screens inside Masters / Planner swipe, the main pages do not.
        viewPager.isUserInputEnabled = false
        viewPager.offscreenPageLimit = 1
        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            tab.text = TABS[position].title
            tab.setIcon(TABS[position].icon)
        }.attach()

        onBackPressedDispatcher.addCallback(this, tabBackCallback)

        lockController = com.investtrack.ui.lock.LockScreenController(
            this, findViewById(R.id.lock_overlay), appLock
        ) { showing -> lockBackCallback.isEnabled = showing }
        onBackPressedDispatcher.addCallback(this, lockBackCallback)
        applyLockWindowFlags()
        if (appLock.shouldLock()) { lockController.setAppName(settingsManager.appName.value); lockController.show(autoBiometric = false) }
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) = updateBackHandling()
        })
        supportFragmentManager.addOnBackStackChangedListener {
            overlay.visibility = if (supportFragmentManager.backStackEntryCount > 0) View.VISIBLE else View.GONE
            updateBackHandling()
        }
    }

    private fun applyLockWindowFlags() {
        if (appLock.enabled && appLock.hideInRecents)
            window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        else
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
    }

    override fun onStart() {
        super.onStart()
        applyLockWindowFlags()
        if (appLock.shouldLock()) {
            appLock.relock()
            lockController.setAppName(settingsManager.appName.value)
            lockController.show(autoBiometric = true)
        } else if (lockController.isShowing) {
            lockController.show(autoBiometric = true)
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) appLock.onBackgrounded()
    }

    private fun updateBackHandling() {
        tabBackCallback.isEnabled =
            supportFragmentManager.backStackEntryCount == 0 && viewPager.currentItem != TAB_DASHBOARD
    }

    /** Jump to a bottom tab, optionally to one of its inner tabs (MASTER_* / PLANNER_*). */
    fun selectTab(index: Int, subTab: Int? = null) {
        supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        if (subTab != null) {
            TABS[index].key?.let { key ->
                supportFragmentManager.setFragmentResult("sub_tab_$key", bundleOf("sub" to subTab))
            }
        }
        viewPager.setCurrentItem(index, false)
    }

    /** Push a detail / form screen on top of the tabs (with back-stack). */
    fun navigateTo(fragment: Fragment) {
        overlay.visibility = View.VISIBLE
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .commit()
    }
}
