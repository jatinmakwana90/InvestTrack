package com.investtrack.workers

import android.content.Context
import androidx.work.*
import com.investtrack.data.settings.AutomationSettings
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Starts / stops the automations according to [AutomationSettings]. Safe to call repeatedly. */
object AutomationScheduler {

    const val LOAN_PAY = "loan_auto_pay"
    const val LOAN_PAY_NOW = "loan_auto_pay_now"
    const val WEEKLY = "weekly_whatsapp_summary"
    const val MONTHLY = "monthly_pdf_report"
    const val DUE_ALERTS = "due_alerts"
    const val BRIEFING = "morning_briefing"

    fun syncAll(context: Context, a: AutomationSettings) {
        scheduleDueAlerts(context)
        if (a.briefingEnabled) scheduleBriefing(context, a, ExistingWorkPolicy.REPLACE)
        else WorkManager.getInstance(context).cancelUniqueWork(BRIEFING)
        applyLoanAutoPay(context, a.autoPayEmis)
        if (a.weeklyEnabled) scheduleWeekly(context, a, ExistingWorkPolicy.REPLACE)
        else WorkManager.getInstance(context).cancelUniqueWork(WEEKLY)
        if (a.monthlyEnabled) scheduleMonthly(context, a, ExistingWorkPolicy.REPLACE)
        else WorkManager.getInstance(context).cancelUniqueWork(MONTHLY)
    }

    /** Every morning at about 9: maturity, premium and lending alerts. */
    fun scheduleDueAlerts(context: Context) {
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis - System.currentTimeMillis()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            DUE_ALERTS, ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<DueAlertsWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(next.coerceAtLeast(0), TimeUnit.MILLISECONDS).build()
        )
    }

    fun applyLoanAutoPay(context: Context, enabled: Boolean) {
        val wm = WorkManager.getInstance(context)
        if (enabled) {
            // Catch up right away, then check again every day.
            wm.enqueueUniqueWork(LOAN_PAY_NOW, ExistingWorkPolicy.REPLACE,
                OneTimeWorkRequestBuilder<LoanAutoPayWorker>().build())
            wm.enqueueUniquePeriodicWork(LOAN_PAY, ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<LoanAutoPayWorker>(1, TimeUnit.DAYS).build())
        } else {
            wm.cancelUniqueWork(LOAN_PAY_NOW)
            wm.cancelUniqueWork(LOAN_PAY)
        }
    }

    fun nextWeekly(dayOfWeek: Int, hour: Int, minute: Int, now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.DAY_OF_WEEK, dayOfWeek); set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 7)
        return c.timeInMillis
    }

    fun nextMonthly(day: Int, hour: Int, minute: Int, now: Long = System.currentTimeMillis()): Long {
        for (offset in 0..1) {
            val c = Calendar.getInstance().apply {
                timeInMillis = now
                set(Calendar.DAY_OF_MONTH, 1); add(Calendar.MONTH, offset)
                set(Calendar.DAY_OF_MONTH, day.coerceIn(1, getActualMaximum(Calendar.DAY_OF_MONTH)))
                set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis > now) return c.timeInMillis
        }
        return now + TimeUnit.DAYS.toMillis(30)
    }

    fun nextDaily(hour: Int, minute: Int, now: Long = System.currentTimeMillis()): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun scheduleBriefing(context: Context, a: AutomationSettings, policy: ExistingWorkPolicy) {
        val delay = nextDaily(a.briefingHour, a.briefingMinute) - System.currentTimeMillis()
        WorkManager.getInstance(context).enqueueUniqueWork(
            BRIEFING, policy,
            OneTimeWorkRequestBuilder<MorningBriefingWorker>().setInitialDelay(delay.coerceAtLeast(0), TimeUnit.MILLISECONDS).build()
        )
    }

    fun scheduleWeekly(context: Context, a: AutomationSettings, policy: ExistingWorkPolicy) {
        val delay = nextWeekly(a.weeklyDay, a.weeklyHour, a.weeklyMinute) - System.currentTimeMillis()
        WorkManager.getInstance(context).enqueueUniqueWork(
            WEEKLY, policy,
            OneTimeWorkRequestBuilder<WeeklySummaryWorker>().setInitialDelay(delay.coerceAtLeast(0), TimeUnit.MILLISECONDS).build()
        )
    }

    fun scheduleMonthly(context: Context, a: AutomationSettings, policy: ExistingWorkPolicy) {
        val delay = nextMonthly(a.monthlyDay, a.monthlyHour, a.monthlyMinute) - System.currentTimeMillis()
        WorkManager.getInstance(context).enqueueUniqueWork(
            MONTHLY, policy,
            OneTimeWorkRequestBuilder<MonthlyReportWorker>().setInitialDelay(delay.coerceAtLeast(0), TimeUnit.MILLISECONDS).build()
        )
    }
}
