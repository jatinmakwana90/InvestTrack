# Live Portfolio Link – one-time setup (about 10 minutes, free)

The app uploads a small read-only snapshot of your portfolio to a private Firebase
Realtime Database path. `index.html` (this folder) is a viewer page that any phone can open
to see it. The page contains no data itself; the data location and secret are in the link.

## 1. Firebase database
1. Go to https://console.firebase.google.com → **Add project** (Analytics not needed).
2. **Build → Realtime Database → Create database** (any region, start in *locked mode*).
3. Open the **Rules** tab, paste this and **Publish**:

```json
{
  "rules": {
    "shared": {
      "$token": {
        ".read": true,
        ".write": true,
        ".validate": "newData.hasChildren(['updatedAt'])"
      }
    }
  }
}
```
   Nobody can list `shared`; a snapshot can only be read by someone who knows its long secret token.
4. Copy the database URL shown at the top of the Data tab, e.g.
   `https://yourproject-default-rtdb.firebaseio.com`

## 2. Host the viewer page (pick one)
* **GitHub Pages:** create a repo, upload `index.html`, then *Settings → Pages → Deploy from branch (main, /root)*.
  Your viewer URL is `https://<username>.github.io/<repo>/`
* **Netlify Drop / Firebase Hosting / any static host** also works.

## 3. In the app
**Settings → Live Portfolio Link**: paste the database URL and viewer URL → **Save & Sync** → **Share Link**.
Send the link to the other phone (WhatsApp etc.). Opening it shows the portfolio; it refreshes every
30 seconds and whenever the page is reopened.

The app pushes new numbers whenever the Dashboard values change (e.g. after you add a transaction or
sync prices while the app is open).

## Privacy notes
* Anyone who has the link can see the portfolio. Share it only with people you trust.
* **Reset link** in the app creates a new secret; the old link then stops working (Save & Sync again).
